#include <string.h>
#include <jni.h>
#include "ThostFtdcTraderApi.h"
jmethodID spi_methodIDs[125];
jmethodID ctp_struct_methodIDs[353];

//jni native methond to construct CThostFtdcTraderSpi.java and MyTdSpi
class MyTdSpi: public CThostFtdcTraderSpi
{
public:
	JavaVM* jvm;
	jobject jspi;//here the reference should be global from NewGlobalRef()
	MyTdSpi(JavaVM* jvm, jobject jspi):jvm(jvm), jspi(jspi)
	{
	}
	class JWrap
	{
		const MyTdSpi* myspi;
	public:
		JNIEnv *env;
		int env_status;
		JWrap(const MyTdSpi* myspi):myspi(myspi),env(0),env_status(0)
		{
			env_status = myspi->jvm->GetEnv((void**)&env, JNI_VERSION_1_8);
			myspi->jvm->AttachCurrentThread((void**)&env, NULL);
		}

		~JWrap()
		{
			if (JNI_EDETACHED == env_status)
			{
				myspi->jvm->DetachCurrentThread();
			}
		}
		JNIEnv * getEnv() {
			return env;
		}
	};
	void OnFrontConnected()
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		env->CallVoidMethod(jspi,spi_methodIDs[0]);
	}

	void OnFrontDisconnected(int  nReason)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		env->CallVoidMethod(jspi,spi_methodIDs[1],nReason);
	}

	void OnHeartBeatWarning(int  nTimeLapse)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		env->CallVoidMethod(jspi,spi_methodIDs[2],nTimeLapse);
	}

	void OnRspAuthenticate(CThostFtdcRspAuthenticateField * pRspAuthenticateField,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspAuthenticateField;");
		jobject RspAuthenticateField = env->AllocObject(jclazz);
		if(pRspAuthenticateField)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspAuthenticateField->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspAuthenticateField->BrokerID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspAuthenticateField->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspAuthenticateField->UserID);
			jbyteArray UserProductInfo = env->NewByteArray(11);
			if(pRspAuthenticateField->UserProductInfo)
				env->SetByteArrayRegion(UserProductInfo , 0, 11, (const jbyte*)pRspAuthenticateField->UserProductInfo);
			jbyteArray AppID = env->NewByteArray(33);
			if(pRspAuthenticateField->AppID)
				env->SetByteArrayRegion(AppID , 0, 33, (const jbyte*)pRspAuthenticateField->AppID);
			RspAuthenticateField = env->NewObject(jclazz, ctp_struct_methodIDs[6],BrokerID,UserID,UserProductInfo,AppID,pRspAuthenticateField->AppType);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[3],RspAuthenticateField, RspInfo, nRequestID, bIsLast);
	}

	void OnRspUserLogin(CThostFtdcRspUserLoginField * pRspUserLogin,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspUserLoginField;");
		jobject RspUserLogin = env->AllocObject(jclazz);
		if(pRspUserLogin)
		{
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pRspUserLogin->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pRspUserLogin->TradingDay);
			jbyteArray LoginTime = env->NewByteArray(9);
			if(pRspUserLogin->LoginTime)
				env->SetByteArrayRegion(LoginTime , 0, 9, (const jbyte*)pRspUserLogin->LoginTime);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspUserLogin->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspUserLogin->BrokerID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspUserLogin->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspUserLogin->UserID);
			jbyteArray SystemName = env->NewByteArray(41);
			if(pRspUserLogin->SystemName)
				env->SetByteArrayRegion(SystemName , 0, 41, (const jbyte*)pRspUserLogin->SystemName);
			jbyteArray MaxOrderRef = env->NewByteArray(13);
			if(pRspUserLogin->MaxOrderRef)
				env->SetByteArrayRegion(MaxOrderRef , 0, 13, (const jbyte*)pRspUserLogin->MaxOrderRef);
			jbyteArray SHFETime = env->NewByteArray(9);
			if(pRspUserLogin->SHFETime)
				env->SetByteArrayRegion(SHFETime , 0, 9, (const jbyte*)pRspUserLogin->SHFETime);
			jbyteArray DCETime = env->NewByteArray(9);
			if(pRspUserLogin->DCETime)
				env->SetByteArrayRegion(DCETime , 0, 9, (const jbyte*)pRspUserLogin->DCETime);
			jbyteArray CZCETime = env->NewByteArray(9);
			if(pRspUserLogin->CZCETime)
				env->SetByteArrayRegion(CZCETime , 0, 9, (const jbyte*)pRspUserLogin->CZCETime);
			jbyteArray FFEXTime = env->NewByteArray(9);
			if(pRspUserLogin->FFEXTime)
				env->SetByteArrayRegion(FFEXTime , 0, 9, (const jbyte*)pRspUserLogin->FFEXTime);
			jbyteArray INETime = env->NewByteArray(9);
			if(pRspUserLogin->INETime)
				env->SetByteArrayRegion(INETime , 0, 9, (const jbyte*)pRspUserLogin->INETime);
			RspUserLogin = env->NewObject(jclazz, ctp_struct_methodIDs[2],TradingDay,LoginTime,BrokerID,UserID,SystemName,pRspUserLogin->FrontID,pRspUserLogin->SessionID,MaxOrderRef,SHFETime,DCETime,CZCETime,FFEXTime,INETime);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[4],RspUserLogin, RspInfo, nRequestID, bIsLast);
	}

	void OnRspUserLogout(CThostFtdcUserLogoutField * pUserLogout,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcUserLogoutField;");
		jobject UserLogout = env->AllocObject(jclazz);
		if(pUserLogout)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pUserLogout->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pUserLogout->BrokerID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pUserLogout->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pUserLogout->UserID);
			UserLogout = env->NewObject(jclazz, ctp_struct_methodIDs[3],BrokerID,UserID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[5],UserLogout, RspInfo, nRequestID, bIsLast);
	}

	void OnRspUserPasswordUpdate(CThostFtdcUserPasswordUpdateField * pUserPasswordUpdate,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcUserPasswordUpdateField;");
		jobject UserPasswordUpdate = env->AllocObject(jclazz);
		if(pUserPasswordUpdate)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pUserPasswordUpdate->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pUserPasswordUpdate->BrokerID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pUserPasswordUpdate->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pUserPasswordUpdate->UserID);
			jbyteArray OldPassword = env->NewByteArray(41);
			if(pUserPasswordUpdate->OldPassword)
				env->SetByteArrayRegion(OldPassword , 0, 41, (const jbyte*)pUserPasswordUpdate->OldPassword);
			jbyteArray NewPassword = env->NewByteArray(41);
			if(pUserPasswordUpdate->NewPassword)
				env->SetByteArrayRegion(NewPassword , 0, 41, (const jbyte*)pUserPasswordUpdate->NewPassword);
			UserPasswordUpdate = env->NewObject(jclazz, ctp_struct_methodIDs[51],BrokerID,UserID,OldPassword,NewPassword);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[6],UserPasswordUpdate, RspInfo, nRequestID, bIsLast);
	}

	void OnRspTradingAccountPasswordUpdate(CThostFtdcTradingAccountPasswordUpdateField * pTradingAccountPasswordUpdate,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountPasswordUpdateField;");
		jobject TradingAccountPasswordUpdate = env->AllocObject(jclazz);
		if(pTradingAccountPasswordUpdate)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pTradingAccountPasswordUpdate->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pTradingAccountPasswordUpdate->BrokerID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pTradingAccountPasswordUpdate->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pTradingAccountPasswordUpdate->AccountID);
			jbyteArray OldPassword = env->NewByteArray(41);
			if(pTradingAccountPasswordUpdate->OldPassword)
				env->SetByteArrayRegion(OldPassword , 0, 41, (const jbyte*)pTradingAccountPasswordUpdate->OldPassword);
			jbyteArray NewPassword = env->NewByteArray(41);
			if(pTradingAccountPasswordUpdate->NewPassword)
				env->SetByteArrayRegion(NewPassword , 0, 41, (const jbyte*)pTradingAccountPasswordUpdate->NewPassword);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pTradingAccountPasswordUpdate->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pTradingAccountPasswordUpdate->CurrencyID);
			TradingAccountPasswordUpdate = env->NewObject(jclazz, ctp_struct_methodIDs[223],BrokerID,AccountID,OldPassword,NewPassword,CurrencyID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[7],TradingAccountPasswordUpdate, RspInfo, nRequestID, bIsLast);
	}

	void OnRspUserAuthMethod(CThostFtdcRspUserAuthMethodField * pRspUserAuthMethod,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspUserAuthMethodField;");
		jobject RspUserAuthMethod = env->AllocObject(jclazz);
		if(pRspUserAuthMethod)
		{
			RspUserAuthMethod = env->NewObject(jclazz, ctp_struct_methodIDs[340],pRspUserAuthMethod->UsableAuthMethod);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[8],RspUserAuthMethod, RspInfo, nRequestID, bIsLast);
	}

	void OnRspGenUserCaptcha(CThostFtdcRspGenUserCaptchaField * pRspGenUserCaptcha,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspGenUserCaptchaField;");
		jobject RspGenUserCaptcha = env->AllocObject(jclazz);
		if(pRspGenUserCaptcha)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspGenUserCaptcha->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspGenUserCaptcha->BrokerID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspGenUserCaptcha->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspGenUserCaptcha->UserID);
			jbyteArray CaptchaInfo = env->NewByteArray(2561);
			if(pRspGenUserCaptcha->CaptchaInfo)
				env->SetByteArrayRegion(CaptchaInfo , 0, 2561, (const jbyte*)pRspGenUserCaptcha->CaptchaInfo);
			RspGenUserCaptcha = env->NewObject(jclazz, ctp_struct_methodIDs[342],BrokerID,UserID,pRspGenUserCaptcha->CaptchaInfoLen,CaptchaInfo);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[9],RspGenUserCaptcha, RspInfo, nRequestID, bIsLast);
	}

	void OnRspGenUserText(CThostFtdcRspGenUserTextField * pRspGenUserText,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspGenUserTextField;");
		jobject RspGenUserText = env->AllocObject(jclazz);
		if(pRspGenUserText)
		{
			RspGenUserText = env->NewObject(jclazz, ctp_struct_methodIDs[344],pRspGenUserText->UserTextSeq);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[10],RspGenUserText, RspInfo, nRequestID, bIsLast);
	}

	void OnRspOrderInsert(CThostFtdcInputOrderField * pInputOrder,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOrderField;");
		jobject InputOrder = env->AllocObject(jclazz);
		if(pInputOrder)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputOrder->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputOrder->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputOrder->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputOrder->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputOrder->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputOrder->InstrumentID);
			jbyteArray OrderRef = env->NewByteArray(13);
			if(pInputOrder->OrderRef)
				env->SetByteArrayRegion(OrderRef , 0, 13, (const jbyte*)pInputOrder->OrderRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputOrder->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputOrder->UserID);
			jbyteArray CombOffsetFlag = env->NewByteArray(5);
			if(pInputOrder->CombOffsetFlag)
				env->SetByteArrayRegion(CombOffsetFlag , 0, 5, (const jbyte*)pInputOrder->CombOffsetFlag);
			jbyteArray CombHedgeFlag = env->NewByteArray(5);
			if(pInputOrder->CombHedgeFlag)
				env->SetByteArrayRegion(CombHedgeFlag , 0, 5, (const jbyte*)pInputOrder->CombHedgeFlag);
			jbyteArray GTDDate = env->NewByteArray(9);
			if(pInputOrder->GTDDate)
				env->SetByteArrayRegion(GTDDate , 0, 9, (const jbyte*)pInputOrder->GTDDate);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pInputOrder->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pInputOrder->BusinessUnit);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputOrder->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputOrder->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputOrder->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputOrder->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pInputOrder->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pInputOrder->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pInputOrder->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pInputOrder->CurrencyID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pInputOrder->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pInputOrder->ClientID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputOrder->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputOrder->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputOrder->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputOrder->MacAddress);
			InputOrder = env->NewObject(jclazz, ctp_struct_methodIDs[52],BrokerID,InvestorID,InstrumentID,OrderRef,UserID,pInputOrder->OrderPriceType,pInputOrder->Direction,CombOffsetFlag,CombHedgeFlag,pInputOrder->LimitPrice,pInputOrder->VolumeTotalOriginal,pInputOrder->TimeCondition,GTDDate,pInputOrder->VolumeCondition,pInputOrder->MinVolume,pInputOrder->ContingentCondition,pInputOrder->StopPrice,pInputOrder->ForceCloseReason,pInputOrder->IsAutoSuspend,BusinessUnit,pInputOrder->RequestID,pInputOrder->UserForceClose,pInputOrder->IsSwapOrder,ExchangeID,InvestUnitID,AccountID,CurrencyID,ClientID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[11],InputOrder, RspInfo, nRequestID, bIsLast);
	}

	void OnRspParkedOrderInsert(CThostFtdcParkedOrderField * pParkedOrder,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcParkedOrderField;");
		jobject ParkedOrder = env->AllocObject(jclazz);
		if(pParkedOrder)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pParkedOrder->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pParkedOrder->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pParkedOrder->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pParkedOrder->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pParkedOrder->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pParkedOrder->InstrumentID);
			jbyteArray OrderRef = env->NewByteArray(13);
			if(pParkedOrder->OrderRef)
				env->SetByteArrayRegion(OrderRef , 0, 13, (const jbyte*)pParkedOrder->OrderRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pParkedOrder->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pParkedOrder->UserID);
			jbyteArray CombOffsetFlag = env->NewByteArray(5);
			if(pParkedOrder->CombOffsetFlag)
				env->SetByteArrayRegion(CombOffsetFlag , 0, 5, (const jbyte*)pParkedOrder->CombOffsetFlag);
			jbyteArray CombHedgeFlag = env->NewByteArray(5);
			if(pParkedOrder->CombHedgeFlag)
				env->SetByteArrayRegion(CombHedgeFlag , 0, 5, (const jbyte*)pParkedOrder->CombHedgeFlag);
			jbyteArray GTDDate = env->NewByteArray(9);
			if(pParkedOrder->GTDDate)
				env->SetByteArrayRegion(GTDDate , 0, 9, (const jbyte*)pParkedOrder->GTDDate);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pParkedOrder->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pParkedOrder->BusinessUnit);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pParkedOrder->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pParkedOrder->ExchangeID);
			jbyteArray ParkedOrderID = env->NewByteArray(13);
			if(pParkedOrder->ParkedOrderID)
				env->SetByteArrayRegion(ParkedOrderID , 0, 13, (const jbyte*)pParkedOrder->ParkedOrderID);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pParkedOrder->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pParkedOrder->ErrorMsg);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pParkedOrder->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pParkedOrder->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pParkedOrder->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pParkedOrder->CurrencyID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pParkedOrder->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pParkedOrder->ClientID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pParkedOrder->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pParkedOrder->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pParkedOrder->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pParkedOrder->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pParkedOrder->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pParkedOrder->MacAddress);
			ParkedOrder = env->NewObject(jclazz, ctp_struct_methodIDs[235],BrokerID,InvestorID,InstrumentID,OrderRef,UserID,pParkedOrder->OrderPriceType,pParkedOrder->Direction,CombOffsetFlag,CombHedgeFlag,pParkedOrder->LimitPrice,pParkedOrder->VolumeTotalOriginal,pParkedOrder->TimeCondition,GTDDate,pParkedOrder->VolumeCondition,pParkedOrder->MinVolume,pParkedOrder->ContingentCondition,pParkedOrder->StopPrice,pParkedOrder->ForceCloseReason,pParkedOrder->IsAutoSuspend,BusinessUnit,pParkedOrder->RequestID,pParkedOrder->UserForceClose,ExchangeID,ParkedOrderID,pParkedOrder->UserType,pParkedOrder->Status,pParkedOrder->ErrorID,ErrorMsg,pParkedOrder->IsSwapOrder,AccountID,CurrencyID,ClientID,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[12],ParkedOrder, RspInfo, nRequestID, bIsLast);
	}

	void OnRspParkedOrderAction(CThostFtdcParkedOrderActionField * pParkedOrderAction,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcParkedOrderActionField;");
		jobject ParkedOrderAction = env->AllocObject(jclazz);
		if(pParkedOrderAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pParkedOrderAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pParkedOrderAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pParkedOrderAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pParkedOrderAction->InvestorID);
			jbyteArray OrderRef = env->NewByteArray(13);
			if(pParkedOrderAction->OrderRef)
				env->SetByteArrayRegion(OrderRef , 0, 13, (const jbyte*)pParkedOrderAction->OrderRef);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pParkedOrderAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pParkedOrderAction->ExchangeID);
			jbyteArray OrderSysID = env->NewByteArray(21);
			if(pParkedOrderAction->OrderSysID)
				env->SetByteArrayRegion(OrderSysID , 0, 21, (const jbyte*)pParkedOrderAction->OrderSysID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pParkedOrderAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pParkedOrderAction->UserID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pParkedOrderAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pParkedOrderAction->InstrumentID);
			jbyteArray ParkedOrderActionID = env->NewByteArray(13);
			if(pParkedOrderAction->ParkedOrderActionID)
				env->SetByteArrayRegion(ParkedOrderActionID , 0, 13, (const jbyte*)pParkedOrderAction->ParkedOrderActionID);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pParkedOrderAction->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pParkedOrderAction->ErrorMsg);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pParkedOrderAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pParkedOrderAction->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pParkedOrderAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pParkedOrderAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pParkedOrderAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pParkedOrderAction->MacAddress);
			ParkedOrderAction = env->NewObject(jclazz, ctp_struct_methodIDs[236],BrokerID,InvestorID,pParkedOrderAction->OrderActionRef,OrderRef,pParkedOrderAction->RequestID,pParkedOrderAction->FrontID,pParkedOrderAction->SessionID,ExchangeID,OrderSysID,pParkedOrderAction->ActionFlag,pParkedOrderAction->LimitPrice,pParkedOrderAction->VolumeChange,UserID,InstrumentID,ParkedOrderActionID,pParkedOrderAction->UserType,pParkedOrderAction->Status,pParkedOrderAction->ErrorID,ErrorMsg,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[13],ParkedOrderAction, RspInfo, nRequestID, bIsLast);
	}

	void OnRspOrderAction(CThostFtdcInputOrderActionField * pInputOrderAction,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOrderActionField;");
		jobject InputOrderAction = env->AllocObject(jclazz);
		if(pInputOrderAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputOrderAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputOrderAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputOrderAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputOrderAction->InvestorID);
			jbyteArray OrderRef = env->NewByteArray(13);
			if(pInputOrderAction->OrderRef)
				env->SetByteArrayRegion(OrderRef , 0, 13, (const jbyte*)pInputOrderAction->OrderRef);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputOrderAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputOrderAction->ExchangeID);
			jbyteArray OrderSysID = env->NewByteArray(21);
			if(pInputOrderAction->OrderSysID)
				env->SetByteArrayRegion(OrderSysID , 0, 21, (const jbyte*)pInputOrderAction->OrderSysID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputOrderAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputOrderAction->UserID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputOrderAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputOrderAction->InstrumentID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputOrderAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputOrderAction->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputOrderAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputOrderAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputOrderAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputOrderAction->MacAddress);
			InputOrderAction = env->NewObject(jclazz, ctp_struct_methodIDs[56],BrokerID,InvestorID,pInputOrderAction->OrderActionRef,OrderRef,pInputOrderAction->RequestID,pInputOrderAction->FrontID,pInputOrderAction->SessionID,ExchangeID,OrderSysID,pInputOrderAction->ActionFlag,pInputOrderAction->LimitPrice,pInputOrderAction->VolumeChange,UserID,InstrumentID,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[14],InputOrderAction, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQueryMaxOrderVolume(CThostFtdcQueryMaxOrderVolumeField * pQueryMaxOrderVolume,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcQueryMaxOrderVolumeField;");
		jobject QueryMaxOrderVolume = env->AllocObject(jclazz);
		if(pQueryMaxOrderVolume)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pQueryMaxOrderVolume->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pQueryMaxOrderVolume->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pQueryMaxOrderVolume->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pQueryMaxOrderVolume->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pQueryMaxOrderVolume->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pQueryMaxOrderVolume->InstrumentID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pQueryMaxOrderVolume->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pQueryMaxOrderVolume->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pQueryMaxOrderVolume->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pQueryMaxOrderVolume->InvestUnitID);
			QueryMaxOrderVolume = env->NewObject(jclazz, ctp_struct_methodIDs[63],BrokerID,InvestorID,InstrumentID,pQueryMaxOrderVolume->Direction,pQueryMaxOrderVolume->OffsetFlag,pQueryMaxOrderVolume->HedgeFlag,pQueryMaxOrderVolume->MaxVolume,ExchangeID,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[15],QueryMaxOrderVolume, RspInfo, nRequestID, bIsLast);
	}

	void OnRspSettlementInfoConfirm(CThostFtdcSettlementInfoConfirmField * pSettlementInfoConfirm,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcSettlementInfoConfirmField;");
		jobject SettlementInfoConfirm = env->AllocObject(jclazz);
		if(pSettlementInfoConfirm)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pSettlementInfoConfirm->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pSettlementInfoConfirm->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pSettlementInfoConfirm->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pSettlementInfoConfirm->InvestorID);
			jbyteArray ConfirmDate = env->NewByteArray(9);
			if(pSettlementInfoConfirm->ConfirmDate)
				env->SetByteArrayRegion(ConfirmDate , 0, 9, (const jbyte*)pSettlementInfoConfirm->ConfirmDate);
			jbyteArray ConfirmTime = env->NewByteArray(9);
			if(pSettlementInfoConfirm->ConfirmTime)
				env->SetByteArrayRegion(ConfirmTime , 0, 9, (const jbyte*)pSettlementInfoConfirm->ConfirmTime);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pSettlementInfoConfirm->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pSettlementInfoConfirm->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pSettlementInfoConfirm->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pSettlementInfoConfirm->CurrencyID);
			SettlementInfoConfirm = env->NewObject(jclazz, ctp_struct_methodIDs[64],BrokerID,InvestorID,ConfirmDate,ConfirmTime,pSettlementInfoConfirm->SettlementID,AccountID,CurrencyID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[16],SettlementInfoConfirm, RspInfo, nRequestID, bIsLast);
	}

	void OnRspRemoveParkedOrder(CThostFtdcRemoveParkedOrderField * pRemoveParkedOrder,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRemoveParkedOrderField;");
		jobject RemoveParkedOrder = env->AllocObject(jclazz);
		if(pRemoveParkedOrder)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRemoveParkedOrder->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRemoveParkedOrder->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pRemoveParkedOrder->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pRemoveParkedOrder->InvestorID);
			jbyteArray ParkedOrderID = env->NewByteArray(13);
			if(pRemoveParkedOrder->ParkedOrderID)
				env->SetByteArrayRegion(ParkedOrderID , 0, 13, (const jbyte*)pRemoveParkedOrder->ParkedOrderID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pRemoveParkedOrder->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pRemoveParkedOrder->InvestUnitID);
			RemoveParkedOrder = env->NewObject(jclazz, ctp_struct_methodIDs[239],BrokerID,InvestorID,ParkedOrderID,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[17],RemoveParkedOrder, RspInfo, nRequestID, bIsLast);
	}

	void OnRspRemoveParkedOrderAction(CThostFtdcRemoveParkedOrderActionField * pRemoveParkedOrderAction,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRemoveParkedOrderActionField;");
		jobject RemoveParkedOrderAction = env->AllocObject(jclazz);
		if(pRemoveParkedOrderAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRemoveParkedOrderAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRemoveParkedOrderAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pRemoveParkedOrderAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pRemoveParkedOrderAction->InvestorID);
			jbyteArray ParkedOrderActionID = env->NewByteArray(13);
			if(pRemoveParkedOrderAction->ParkedOrderActionID)
				env->SetByteArrayRegion(ParkedOrderActionID , 0, 13, (const jbyte*)pRemoveParkedOrderAction->ParkedOrderActionID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pRemoveParkedOrderAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pRemoveParkedOrderAction->InvestUnitID);
			RemoveParkedOrderAction = env->NewObject(jclazz, ctp_struct_methodIDs[240],BrokerID,InvestorID,ParkedOrderActionID,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[18],RemoveParkedOrderAction, RspInfo, nRequestID, bIsLast);
	}

	void OnRspExecOrderInsert(CThostFtdcInputExecOrderField * pInputExecOrder,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputExecOrderField;");
		jobject InputExecOrder = env->AllocObject(jclazz);
		if(pInputExecOrder)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputExecOrder->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputExecOrder->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputExecOrder->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputExecOrder->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputExecOrder->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputExecOrder->InstrumentID);
			jbyteArray ExecOrderRef = env->NewByteArray(13);
			if(pInputExecOrder->ExecOrderRef)
				env->SetByteArrayRegion(ExecOrderRef , 0, 13, (const jbyte*)pInputExecOrder->ExecOrderRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputExecOrder->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputExecOrder->UserID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pInputExecOrder->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pInputExecOrder->BusinessUnit);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputExecOrder->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputExecOrder->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputExecOrder->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputExecOrder->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pInputExecOrder->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pInputExecOrder->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pInputExecOrder->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pInputExecOrder->CurrencyID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pInputExecOrder->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pInputExecOrder->ClientID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputExecOrder->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputExecOrder->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputExecOrder->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputExecOrder->MacAddress);
			InputExecOrder = env->NewObject(jclazz, ctp_struct_methodIDs[117],BrokerID,InvestorID,InstrumentID,ExecOrderRef,UserID,pInputExecOrder->Volume,pInputExecOrder->RequestID,BusinessUnit,pInputExecOrder->OffsetFlag,pInputExecOrder->HedgeFlag,pInputExecOrder->ActionType,pInputExecOrder->PosiDirection,pInputExecOrder->ReservePositionFlag,pInputExecOrder->CloseFlag,ExchangeID,InvestUnitID,AccountID,CurrencyID,ClientID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[19],InputExecOrder, RspInfo, nRequestID, bIsLast);
	}

	void OnRspExecOrderAction(CThostFtdcInputExecOrderActionField * pInputExecOrderAction,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputExecOrderActionField;");
		jobject InputExecOrderAction = env->AllocObject(jclazz);
		if(pInputExecOrderAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputExecOrderAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputExecOrderAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputExecOrderAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputExecOrderAction->InvestorID);
			jbyteArray ExecOrderRef = env->NewByteArray(13);
			if(pInputExecOrderAction->ExecOrderRef)
				env->SetByteArrayRegion(ExecOrderRef , 0, 13, (const jbyte*)pInputExecOrderAction->ExecOrderRef);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputExecOrderAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputExecOrderAction->ExchangeID);
			jbyteArray ExecOrderSysID = env->NewByteArray(21);
			if(pInputExecOrderAction->ExecOrderSysID)
				env->SetByteArrayRegion(ExecOrderSysID , 0, 21, (const jbyte*)pInputExecOrderAction->ExecOrderSysID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputExecOrderAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputExecOrderAction->UserID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputExecOrderAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputExecOrderAction->InstrumentID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputExecOrderAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputExecOrderAction->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputExecOrderAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputExecOrderAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputExecOrderAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputExecOrderAction->MacAddress);
			InputExecOrderAction = env->NewObject(jclazz, ctp_struct_methodIDs[118],BrokerID,InvestorID,pInputExecOrderAction->ExecOrderActionRef,ExecOrderRef,pInputExecOrderAction->RequestID,pInputExecOrderAction->FrontID,pInputExecOrderAction->SessionID,ExchangeID,ExecOrderSysID,pInputExecOrderAction->ActionFlag,UserID,InstrumentID,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[20],InputExecOrderAction, RspInfo, nRequestID, bIsLast);
	}

	void OnRspForQuoteInsert(CThostFtdcInputForQuoteField * pInputForQuote,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputForQuoteField;");
		jobject InputForQuote = env->AllocObject(jclazz);
		if(pInputForQuote)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputForQuote->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputForQuote->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputForQuote->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputForQuote->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputForQuote->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputForQuote->InstrumentID);
			jbyteArray ForQuoteRef = env->NewByteArray(13);
			if(pInputForQuote->ForQuoteRef)
				env->SetByteArrayRegion(ForQuoteRef , 0, 13, (const jbyte*)pInputForQuote->ForQuoteRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputForQuote->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputForQuote->UserID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputForQuote->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputForQuote->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputForQuote->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputForQuote->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputForQuote->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputForQuote->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputForQuote->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputForQuote->MacAddress);
			InputForQuote = env->NewObject(jclazz, ctp_struct_methodIDs[133],BrokerID,InvestorID,InstrumentID,ForQuoteRef,UserID,ExchangeID,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[21],InputForQuote, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQuoteInsert(CThostFtdcInputQuoteField * pInputQuote,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputQuoteField;");
		jobject InputQuote = env->AllocObject(jclazz);
		if(pInputQuote)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputQuote->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputQuote->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputQuote->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputQuote->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputQuote->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputQuote->InstrumentID);
			jbyteArray QuoteRef = env->NewByteArray(13);
			if(pInputQuote->QuoteRef)
				env->SetByteArrayRegion(QuoteRef , 0, 13, (const jbyte*)pInputQuote->QuoteRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputQuote->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputQuote->UserID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pInputQuote->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pInputQuote->BusinessUnit);
			jbyteArray AskOrderRef = env->NewByteArray(13);
			if(pInputQuote->AskOrderRef)
				env->SetByteArrayRegion(AskOrderRef , 0, 13, (const jbyte*)pInputQuote->AskOrderRef);
			jbyteArray BidOrderRef = env->NewByteArray(13);
			if(pInputQuote->BidOrderRef)
				env->SetByteArrayRegion(BidOrderRef , 0, 13, (const jbyte*)pInputQuote->BidOrderRef);
			jbyteArray ForQuoteSysID = env->NewByteArray(21);
			if(pInputQuote->ForQuoteSysID)
				env->SetByteArrayRegion(ForQuoteSysID , 0, 21, (const jbyte*)pInputQuote->ForQuoteSysID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputQuote->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputQuote->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputQuote->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputQuote->InvestUnitID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pInputQuote->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pInputQuote->ClientID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputQuote->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputQuote->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputQuote->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputQuote->MacAddress);
			InputQuote = env->NewObject(jclazz, ctp_struct_methodIDs[138],BrokerID,InvestorID,InstrumentID,QuoteRef,UserID,pInputQuote->AskPrice,pInputQuote->BidPrice,pInputQuote->AskVolume,pInputQuote->BidVolume,pInputQuote->RequestID,BusinessUnit,pInputQuote->AskOffsetFlag,pInputQuote->BidOffsetFlag,pInputQuote->AskHedgeFlag,pInputQuote->BidHedgeFlag,AskOrderRef,BidOrderRef,ForQuoteSysID,ExchangeID,InvestUnitID,ClientID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[22],InputQuote, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQuoteAction(CThostFtdcInputQuoteActionField * pInputQuoteAction,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputQuoteActionField;");
		jobject InputQuoteAction = env->AllocObject(jclazz);
		if(pInputQuoteAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputQuoteAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputQuoteAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputQuoteAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputQuoteAction->InvestorID);
			jbyteArray QuoteRef = env->NewByteArray(13);
			if(pInputQuoteAction->QuoteRef)
				env->SetByteArrayRegion(QuoteRef , 0, 13, (const jbyte*)pInputQuoteAction->QuoteRef);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputQuoteAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputQuoteAction->ExchangeID);
			jbyteArray QuoteSysID = env->NewByteArray(21);
			if(pInputQuoteAction->QuoteSysID)
				env->SetByteArrayRegion(QuoteSysID , 0, 21, (const jbyte*)pInputQuoteAction->QuoteSysID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputQuoteAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputQuoteAction->UserID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputQuoteAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputQuoteAction->InstrumentID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputQuoteAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputQuoteAction->InvestUnitID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pInputQuoteAction->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pInputQuoteAction->ClientID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputQuoteAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputQuoteAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputQuoteAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputQuoteAction->MacAddress);
			InputQuoteAction = env->NewObject(jclazz, ctp_struct_methodIDs[139],BrokerID,InvestorID,pInputQuoteAction->QuoteActionRef,QuoteRef,pInputQuoteAction->RequestID,pInputQuoteAction->FrontID,pInputQuoteAction->SessionID,ExchangeID,QuoteSysID,pInputQuoteAction->ActionFlag,UserID,InstrumentID,InvestUnitID,ClientID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[23],InputQuoteAction, RspInfo, nRequestID, bIsLast);
	}

	void OnRspBatchOrderAction(CThostFtdcInputBatchOrderActionField * pInputBatchOrderAction,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputBatchOrderActionField;");
		jobject InputBatchOrderAction = env->AllocObject(jclazz);
		if(pInputBatchOrderAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputBatchOrderAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputBatchOrderAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputBatchOrderAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputBatchOrderAction->InvestorID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputBatchOrderAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputBatchOrderAction->ExchangeID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputBatchOrderAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputBatchOrderAction->UserID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputBatchOrderAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputBatchOrderAction->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputBatchOrderAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputBatchOrderAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputBatchOrderAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputBatchOrderAction->MacAddress);
			InputBatchOrderAction = env->NewObject(jclazz, ctp_struct_methodIDs[152],BrokerID,InvestorID,pInputBatchOrderAction->OrderActionRef,pInputBatchOrderAction->RequestID,pInputBatchOrderAction->FrontID,pInputBatchOrderAction->SessionID,ExchangeID,UserID,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[24],InputBatchOrderAction, RspInfo, nRequestID, bIsLast);
	}

	void OnRspOptionSelfCloseInsert(CThostFtdcInputOptionSelfCloseField * pInputOptionSelfClose,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOptionSelfCloseField;");
		jobject InputOptionSelfClose = env->AllocObject(jclazz);
		if(pInputOptionSelfClose)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputOptionSelfClose->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputOptionSelfClose->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputOptionSelfClose->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputOptionSelfClose->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputOptionSelfClose->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputOptionSelfClose->InstrumentID);
			jbyteArray OptionSelfCloseRef = env->NewByteArray(13);
			if(pInputOptionSelfClose->OptionSelfCloseRef)
				env->SetByteArrayRegion(OptionSelfCloseRef , 0, 13, (const jbyte*)pInputOptionSelfClose->OptionSelfCloseRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputOptionSelfClose->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputOptionSelfClose->UserID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pInputOptionSelfClose->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pInputOptionSelfClose->BusinessUnit);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputOptionSelfClose->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputOptionSelfClose->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputOptionSelfClose->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputOptionSelfClose->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pInputOptionSelfClose->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pInputOptionSelfClose->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pInputOptionSelfClose->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pInputOptionSelfClose->CurrencyID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pInputOptionSelfClose->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pInputOptionSelfClose->ClientID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputOptionSelfClose->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputOptionSelfClose->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputOptionSelfClose->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputOptionSelfClose->MacAddress);
			InputOptionSelfClose = env->NewObject(jclazz, ctp_struct_methodIDs[178],BrokerID,InvestorID,InstrumentID,OptionSelfCloseRef,UserID,pInputOptionSelfClose->Volume,pInputOptionSelfClose->RequestID,BusinessUnit,pInputOptionSelfClose->HedgeFlag,pInputOptionSelfClose->OptSelfCloseFlag,ExchangeID,InvestUnitID,AccountID,CurrencyID,ClientID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[25],InputOptionSelfClose, RspInfo, nRequestID, bIsLast);
	}

	void OnRspOptionSelfCloseAction(CThostFtdcInputOptionSelfCloseActionField * pInputOptionSelfCloseAction,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOptionSelfCloseActionField;");
		jobject InputOptionSelfCloseAction = env->AllocObject(jclazz);
		if(pInputOptionSelfCloseAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputOptionSelfCloseAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputOptionSelfCloseAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputOptionSelfCloseAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputOptionSelfCloseAction->InvestorID);
			jbyteArray OptionSelfCloseRef = env->NewByteArray(13);
			if(pInputOptionSelfCloseAction->OptionSelfCloseRef)
				env->SetByteArrayRegion(OptionSelfCloseRef , 0, 13, (const jbyte*)pInputOptionSelfCloseAction->OptionSelfCloseRef);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputOptionSelfCloseAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputOptionSelfCloseAction->ExchangeID);
			jbyteArray OptionSelfCloseSysID = env->NewByteArray(21);
			if(pInputOptionSelfCloseAction->OptionSelfCloseSysID)
				env->SetByteArrayRegion(OptionSelfCloseSysID , 0, 21, (const jbyte*)pInputOptionSelfCloseAction->OptionSelfCloseSysID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputOptionSelfCloseAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputOptionSelfCloseAction->UserID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputOptionSelfCloseAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputOptionSelfCloseAction->InstrumentID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputOptionSelfCloseAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputOptionSelfCloseAction->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputOptionSelfCloseAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputOptionSelfCloseAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputOptionSelfCloseAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputOptionSelfCloseAction->MacAddress);
			InputOptionSelfCloseAction = env->NewObject(jclazz, ctp_struct_methodIDs[179],BrokerID,InvestorID,pInputOptionSelfCloseAction->OptionSelfCloseActionRef,OptionSelfCloseRef,pInputOptionSelfCloseAction->RequestID,pInputOptionSelfCloseAction->FrontID,pInputOptionSelfCloseAction->SessionID,ExchangeID,OptionSelfCloseSysID,pInputOptionSelfCloseAction->ActionFlag,UserID,InstrumentID,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[26],InputOptionSelfCloseAction, RspInfo, nRequestID, bIsLast);
	}

	void OnRspCombActionInsert(CThostFtdcInputCombActionField * pInputCombAction,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputCombActionField;");
		jobject InputCombAction = env->AllocObject(jclazz);
		if(pInputCombAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputCombAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputCombAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputCombAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputCombAction->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputCombAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputCombAction->InstrumentID);
			jbyteArray CombActionRef = env->NewByteArray(13);
			if(pInputCombAction->CombActionRef)
				env->SetByteArrayRegion(CombActionRef , 0, 13, (const jbyte*)pInputCombAction->CombActionRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputCombAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputCombAction->UserID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputCombAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputCombAction->ExchangeID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputCombAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputCombAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputCombAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputCombAction->MacAddress);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputCombAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputCombAction->InvestUnitID);
			InputCombAction = env->NewObject(jclazz, ctp_struct_methodIDs[158],BrokerID,InvestorID,InstrumentID,CombActionRef,UserID,pInputCombAction->Direction,pInputCombAction->Volume,pInputCombAction->CombDirection,pInputCombAction->HedgeFlag,ExchangeID,IPAddress,MacAddress,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[27],InputCombAction, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryOrder(CThostFtdcOrderField * pOrder,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcOrderField;");
		jobject Order = env->AllocObject(jclazz);
		if(pOrder)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pOrder->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pOrder->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pOrder->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pOrder->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pOrder->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pOrder->InstrumentID);
			jbyteArray OrderRef = env->NewByteArray(13);
			if(pOrder->OrderRef)
				env->SetByteArrayRegion(OrderRef , 0, 13, (const jbyte*)pOrder->OrderRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pOrder->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pOrder->UserID);
			jbyteArray CombOffsetFlag = env->NewByteArray(5);
			if(pOrder->CombOffsetFlag)
				env->SetByteArrayRegion(CombOffsetFlag , 0, 5, (const jbyte*)pOrder->CombOffsetFlag);
			jbyteArray CombHedgeFlag = env->NewByteArray(5);
			if(pOrder->CombHedgeFlag)
				env->SetByteArrayRegion(CombHedgeFlag , 0, 5, (const jbyte*)pOrder->CombHedgeFlag);
			jbyteArray GTDDate = env->NewByteArray(9);
			if(pOrder->GTDDate)
				env->SetByteArrayRegion(GTDDate , 0, 9, (const jbyte*)pOrder->GTDDate);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pOrder->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pOrder->BusinessUnit);
			jbyteArray OrderLocalID = env->NewByteArray(13);
			if(pOrder->OrderLocalID)
				env->SetByteArrayRegion(OrderLocalID , 0, 13, (const jbyte*)pOrder->OrderLocalID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pOrder->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pOrder->ExchangeID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pOrder->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pOrder->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pOrder->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pOrder->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pOrder->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pOrder->ExchangeInstID);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pOrder->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pOrder->TraderID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pOrder->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pOrder->TradingDay);
			jbyteArray OrderSysID = env->NewByteArray(21);
			if(pOrder->OrderSysID)
				env->SetByteArrayRegion(OrderSysID , 0, 21, (const jbyte*)pOrder->OrderSysID);
			jbyteArray InsertDate = env->NewByteArray(9);
			if(pOrder->InsertDate)
				env->SetByteArrayRegion(InsertDate , 0, 9, (const jbyte*)pOrder->InsertDate);
			jbyteArray InsertTime = env->NewByteArray(9);
			if(pOrder->InsertTime)
				env->SetByteArrayRegion(InsertTime , 0, 9, (const jbyte*)pOrder->InsertTime);
			jbyteArray ActiveTime = env->NewByteArray(9);
			if(pOrder->ActiveTime)
				env->SetByteArrayRegion(ActiveTime , 0, 9, (const jbyte*)pOrder->ActiveTime);
			jbyteArray SuspendTime = env->NewByteArray(9);
			if(pOrder->SuspendTime)
				env->SetByteArrayRegion(SuspendTime , 0, 9, (const jbyte*)pOrder->SuspendTime);
			jbyteArray UpdateTime = env->NewByteArray(9);
			if(pOrder->UpdateTime)
				env->SetByteArrayRegion(UpdateTime , 0, 9, (const jbyte*)pOrder->UpdateTime);
			jbyteArray CancelTime = env->NewByteArray(9);
			if(pOrder->CancelTime)
				env->SetByteArrayRegion(CancelTime , 0, 9, (const jbyte*)pOrder->CancelTime);
			jbyteArray ActiveTraderID = env->NewByteArray(21);
			if(pOrder->ActiveTraderID)
				env->SetByteArrayRegion(ActiveTraderID , 0, 21, (const jbyte*)pOrder->ActiveTraderID);
			jbyteArray ClearingPartID = env->NewByteArray(11);
			if(pOrder->ClearingPartID)
				env->SetByteArrayRegion(ClearingPartID , 0, 11, (const jbyte*)pOrder->ClearingPartID);
			jbyteArray UserProductInfo = env->NewByteArray(11);
			if(pOrder->UserProductInfo)
				env->SetByteArrayRegion(UserProductInfo , 0, 11, (const jbyte*)pOrder->UserProductInfo);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pOrder->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pOrder->StatusMsg);
			jbyteArray ActiveUserID = env->NewByteArray(16);
			if(pOrder->ActiveUserID)
				env->SetByteArrayRegion(ActiveUserID , 0, 16, (const jbyte*)pOrder->ActiveUserID);
			jbyteArray RelativeOrderSysID = env->NewByteArray(21);
			if(pOrder->RelativeOrderSysID)
				env->SetByteArrayRegion(RelativeOrderSysID , 0, 21, (const jbyte*)pOrder->RelativeOrderSysID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pOrder->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pOrder->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pOrder->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pOrder->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pOrder->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pOrder->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pOrder->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pOrder->CurrencyID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pOrder->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pOrder->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pOrder->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pOrder->MacAddress);
			Order = env->NewObject(jclazz, ctp_struct_methodIDs[53],BrokerID,InvestorID,InstrumentID,OrderRef,UserID,pOrder->OrderPriceType,pOrder->Direction,CombOffsetFlag,CombHedgeFlag,pOrder->LimitPrice,pOrder->VolumeTotalOriginal,pOrder->TimeCondition,GTDDate,pOrder->VolumeCondition,pOrder->MinVolume,pOrder->ContingentCondition,pOrder->StopPrice,pOrder->ForceCloseReason,pOrder->IsAutoSuspend,BusinessUnit,pOrder->RequestID,OrderLocalID,ExchangeID,ParticipantID,ClientID,ExchangeInstID,TraderID,pOrder->InstallID,pOrder->OrderSubmitStatus,pOrder->NotifySequence,TradingDay,pOrder->SettlementID,OrderSysID,pOrder->OrderSource,pOrder->OrderStatus,pOrder->OrderType,pOrder->VolumeTraded,pOrder->VolumeTotal,InsertDate,InsertTime,ActiveTime,SuspendTime,UpdateTime,CancelTime,ActiveTraderID,ClearingPartID,pOrder->SequenceNo,pOrder->FrontID,pOrder->SessionID,UserProductInfo,StatusMsg,pOrder->UserForceClose,ActiveUserID,pOrder->BrokerOrderSeq,RelativeOrderSysID,pOrder->ZCETotalTradedVolume,pOrder->IsSwapOrder,BranchID,InvestUnitID,AccountID,CurrencyID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[28],Order, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryTrade(CThostFtdcTradeField * pTrade,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcTradeField;");
		jobject Trade = env->AllocObject(jclazz);
		if(pTrade)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pTrade->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pTrade->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pTrade->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pTrade->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pTrade->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pTrade->InstrumentID);
			jbyteArray OrderRef = env->NewByteArray(13);
			if(pTrade->OrderRef)
				env->SetByteArrayRegion(OrderRef , 0, 13, (const jbyte*)pTrade->OrderRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pTrade->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pTrade->UserID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pTrade->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pTrade->ExchangeID);
			jbyteArray TradeID = env->NewByteArray(21);
			if(pTrade->TradeID)
				env->SetByteArrayRegion(TradeID , 0, 21, (const jbyte*)pTrade->TradeID);
			jbyteArray OrderSysID = env->NewByteArray(21);
			if(pTrade->OrderSysID)
				env->SetByteArrayRegion(OrderSysID , 0, 21, (const jbyte*)pTrade->OrderSysID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pTrade->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pTrade->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pTrade->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pTrade->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pTrade->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pTrade->ExchangeInstID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pTrade->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pTrade->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pTrade->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pTrade->TradeTime);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pTrade->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pTrade->TraderID);
			jbyteArray OrderLocalID = env->NewByteArray(13);
			if(pTrade->OrderLocalID)
				env->SetByteArrayRegion(OrderLocalID , 0, 13, (const jbyte*)pTrade->OrderLocalID);
			jbyteArray ClearingPartID = env->NewByteArray(11);
			if(pTrade->ClearingPartID)
				env->SetByteArrayRegion(ClearingPartID , 0, 11, (const jbyte*)pTrade->ClearingPartID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pTrade->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pTrade->BusinessUnit);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pTrade->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pTrade->TradingDay);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pTrade->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pTrade->InvestUnitID);
			Trade = env->NewObject(jclazz, ctp_struct_methodIDs[61],BrokerID,InvestorID,InstrumentID,OrderRef,UserID,ExchangeID,TradeID,pTrade->Direction,OrderSysID,ParticipantID,ClientID,pTrade->TradingRole,ExchangeInstID,pTrade->OffsetFlag,pTrade->HedgeFlag,pTrade->Price,pTrade->Volume,TradeDate,TradeTime,pTrade->TradeType,pTrade->PriceSource,TraderID,OrderLocalID,ClearingPartID,BusinessUnit,pTrade->SequenceNo,TradingDay,pTrade->SettlementID,pTrade->BrokerOrderSeq,pTrade->TradeSource,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[29],Trade, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryInvestorPosition(CThostFtdcInvestorPositionField * pInvestorPosition,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorPositionField;");
		jobject InvestorPosition = env->AllocObject(jclazz);
		if(pInvestorPosition)
		{
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInvestorPosition->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInvestorPosition->InstrumentID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInvestorPosition->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInvestorPosition->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInvestorPosition->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInvestorPosition->InvestorID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pInvestorPosition->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pInvestorPosition->TradingDay);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInvestorPosition->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInvestorPosition->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInvestorPosition->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInvestorPosition->InvestUnitID);
			InvestorPosition = env->NewObject(jclazz, ctp_struct_methodIDs[31],InstrumentID,BrokerID,InvestorID,pInvestorPosition->PosiDirection,pInvestorPosition->HedgeFlag,pInvestorPosition->PositionDate,pInvestorPosition->YdPosition,pInvestorPosition->Position,pInvestorPosition->LongFrozen,pInvestorPosition->ShortFrozen,pInvestorPosition->LongFrozenAmount,pInvestorPosition->ShortFrozenAmount,pInvestorPosition->OpenVolume,pInvestorPosition->CloseVolume,pInvestorPosition->OpenAmount,pInvestorPosition->CloseAmount,pInvestorPosition->PositionCost,pInvestorPosition->PreMargin,pInvestorPosition->UseMargin,pInvestorPosition->FrozenMargin,pInvestorPosition->FrozenCash,pInvestorPosition->FrozenCommission,pInvestorPosition->CashIn,pInvestorPosition->Commission,pInvestorPosition->CloseProfit,pInvestorPosition->PositionProfit,pInvestorPosition->PreSettlementPrice,pInvestorPosition->SettlementPrice,TradingDay,pInvestorPosition->SettlementID,pInvestorPosition->OpenCost,pInvestorPosition->ExchangeMargin,pInvestorPosition->CombPosition,pInvestorPosition->CombLongFrozen,pInvestorPosition->CombShortFrozen,pInvestorPosition->CloseProfitByDate,pInvestorPosition->CloseProfitByTrade,pInvestorPosition->TodayPosition,pInvestorPosition->MarginRateByMoney,pInvestorPosition->MarginRateByVolume,pInvestorPosition->StrikeFrozen,pInvestorPosition->StrikeFrozenAmount,pInvestorPosition->AbandonFrozen,ExchangeID,pInvestorPosition->YdStrikeFrozen,InvestUnitID,pInvestorPosition->PositionCostOffset);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[30],InvestorPosition, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryTradingAccount(CThostFtdcTradingAccountField * pTradingAccount,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountField;");
		jobject TradingAccount = env->AllocObject(jclazz);
		if(pTradingAccount)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pTradingAccount->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pTradingAccount->BrokerID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pTradingAccount->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pTradingAccount->AccountID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pTradingAccount->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pTradingAccount->TradingDay);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pTradingAccount->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pTradingAccount->CurrencyID);
			TradingAccount = env->NewObject(jclazz, ctp_struct_methodIDs[30],BrokerID,AccountID,pTradingAccount->PreMortgage,pTradingAccount->PreCredit,pTradingAccount->PreDeposit,pTradingAccount->PreBalance,pTradingAccount->PreMargin,pTradingAccount->InterestBase,pTradingAccount->Interest,pTradingAccount->Deposit,pTradingAccount->Withdraw,pTradingAccount->FrozenMargin,pTradingAccount->FrozenCash,pTradingAccount->FrozenCommission,pTradingAccount->CurrMargin,pTradingAccount->CashIn,pTradingAccount->Commission,pTradingAccount->CloseProfit,pTradingAccount->PositionProfit,pTradingAccount->Balance,pTradingAccount->Available,pTradingAccount->WithdrawQuota,pTradingAccount->Reserve,TradingDay,pTradingAccount->SettlementID,pTradingAccount->Credit,pTradingAccount->Mortgage,pTradingAccount->ExchangeMargin,pTradingAccount->DeliveryMargin,pTradingAccount->ExchangeDeliveryMargin,pTradingAccount->ReserveBalance,CurrencyID,pTradingAccount->PreFundMortgageIn,pTradingAccount->PreFundMortgageOut,pTradingAccount->FundMortgageIn,pTradingAccount->FundMortgageOut,pTradingAccount->FundMortgageAvailable,pTradingAccount->MortgageableFund,pTradingAccount->SpecProductMargin,pTradingAccount->SpecProductFrozenMargin,pTradingAccount->SpecProductCommission,pTradingAccount->SpecProductFrozenCommission,pTradingAccount->SpecProductPositionProfit,pTradingAccount->SpecProductCloseProfit,pTradingAccount->SpecProductPositionProfitByAlg,pTradingAccount->SpecProductExchangeMargin,pTradingAccount->BizType,pTradingAccount->FrozenSwap,pTradingAccount->RemainSwap);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[31],TradingAccount, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryInvestor(CThostFtdcInvestorField * pInvestor,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorField;");
		jobject Investor = env->AllocObject(jclazz);
		if(pInvestor)
		{
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInvestor->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInvestor->InvestorID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInvestor->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInvestor->BrokerID);
			jbyteArray InvestorGroupID = env->NewByteArray(13);
			if(pInvestor->InvestorGroupID)
				env->SetByteArrayRegion(InvestorGroupID , 0, 13, (const jbyte*)pInvestor->InvestorGroupID);
			jbyteArray InvestorName = env->NewByteArray(81);
			if(pInvestor->InvestorName)
				env->SetByteArrayRegion(InvestorName , 0, 81, (const jbyte*)pInvestor->InvestorName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pInvestor->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pInvestor->IdentifiedCardNo);
			jbyteArray Telephone = env->NewByteArray(41);
			if(pInvestor->Telephone)
				env->SetByteArrayRegion(Telephone , 0, 41, (const jbyte*)pInvestor->Telephone);
			jbyteArray Address = env->NewByteArray(101);
			if(pInvestor->Address)
				env->SetByteArrayRegion(Address , 0, 101, (const jbyte*)pInvestor->Address);
			jbyteArray OpenDate = env->NewByteArray(9);
			if(pInvestor->OpenDate)
				env->SetByteArrayRegion(OpenDate , 0, 9, (const jbyte*)pInvestor->OpenDate);
			jbyteArray Mobile = env->NewByteArray(41);
			if(pInvestor->Mobile)
				env->SetByteArrayRegion(Mobile , 0, 41, (const jbyte*)pInvestor->Mobile);
			jbyteArray CommModelID = env->NewByteArray(13);
			if(pInvestor->CommModelID)
				env->SetByteArrayRegion(CommModelID , 0, 13, (const jbyte*)pInvestor->CommModelID);
			jbyteArray MarginModelID = env->NewByteArray(13);
			if(pInvestor->MarginModelID)
				env->SetByteArrayRegion(MarginModelID , 0, 13, (const jbyte*)pInvestor->MarginModelID);
			Investor = env->NewObject(jclazz, ctp_struct_methodIDs[24],InvestorID,BrokerID,InvestorGroupID,InvestorName,pInvestor->IdentifiedCardType,IdentifiedCardNo,pInvestor->IsActive,Telephone,Address,OpenDate,Mobile,CommModelID,MarginModelID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[32],Investor, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryTradingCode(CThostFtdcTradingCodeField * pTradingCode,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingCodeField;");
		jobject TradingCode = env->AllocObject(jclazz);
		if(pTradingCode)
		{
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pTradingCode->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pTradingCode->InvestorID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pTradingCode->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pTradingCode->BrokerID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pTradingCode->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pTradingCode->ExchangeID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pTradingCode->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pTradingCode->ClientID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pTradingCode->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pTradingCode->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pTradingCode->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pTradingCode->InvestUnitID);
			TradingCode = env->NewObject(jclazz, ctp_struct_methodIDs[25],InvestorID,BrokerID,ExchangeID,ClientID,pTradingCode->IsActive,pTradingCode->ClientIDType,BranchID,pTradingCode->BizType,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[33],TradingCode, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryInstrumentMarginRate(CThostFtdcInstrumentMarginRateField * pInstrumentMarginRate,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentMarginRateField;");
		jobject InstrumentMarginRate = env->AllocObject(jclazz);
		if(pInstrumentMarginRate)
		{
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInstrumentMarginRate->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInstrumentMarginRate->InstrumentID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInstrumentMarginRate->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInstrumentMarginRate->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInstrumentMarginRate->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInstrumentMarginRate->InvestorID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInstrumentMarginRate->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInstrumentMarginRate->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInstrumentMarginRate->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInstrumentMarginRate->InvestUnitID);
			InstrumentMarginRate = env->NewObject(jclazz, ctp_struct_methodIDs[32],InstrumentID,pInstrumentMarginRate->InvestorRange,BrokerID,InvestorID,pInstrumentMarginRate->HedgeFlag,pInstrumentMarginRate->LongMarginRatioByMoney,pInstrumentMarginRate->LongMarginRatioByVolume,pInstrumentMarginRate->ShortMarginRatioByMoney,pInstrumentMarginRate->ShortMarginRatioByVolume,pInstrumentMarginRate->IsRelative,ExchangeID,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[34],InstrumentMarginRate, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryInstrumentCommissionRate(CThostFtdcInstrumentCommissionRateField * pInstrumentCommissionRate,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentCommissionRateField;");
		jobject InstrumentCommissionRate = env->AllocObject(jclazz);
		if(pInstrumentCommissionRate)
		{
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInstrumentCommissionRate->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInstrumentCommissionRate->InstrumentID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInstrumentCommissionRate->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInstrumentCommissionRate->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInstrumentCommissionRate->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInstrumentCommissionRate->InvestorID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInstrumentCommissionRate->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInstrumentCommissionRate->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInstrumentCommissionRate->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInstrumentCommissionRate->InvestUnitID);
			InstrumentCommissionRate = env->NewObject(jclazz, ctp_struct_methodIDs[33],InstrumentID,pInstrumentCommissionRate->InvestorRange,BrokerID,InvestorID,pInstrumentCommissionRate->OpenRatioByMoney,pInstrumentCommissionRate->OpenRatioByVolume,pInstrumentCommissionRate->CloseRatioByMoney,pInstrumentCommissionRate->CloseRatioByVolume,pInstrumentCommissionRate->CloseTodayRatioByMoney,pInstrumentCommissionRate->CloseTodayRatioByVolume,ExchangeID,pInstrumentCommissionRate->BizType,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[35],InstrumentCommissionRate, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryExchange(CThostFtdcExchangeField * pExchange,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeField;");
		jobject Exchange = env->AllocObject(jclazz);
		if(pExchange)
		{
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pExchange->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pExchange->ExchangeID);
			jbyteArray ExchangeName = env->NewByteArray(61);
			if(pExchange->ExchangeName)
				env->SetByteArrayRegion(ExchangeName , 0, 61, (const jbyte*)pExchange->ExchangeName);
			Exchange = env->NewObject(jclazz, ctp_struct_methodIDs[19],ExchangeID,ExchangeName,pExchange->ExchangeProperty);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[36],Exchange, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryProduct(CThostFtdcProductField * pProduct,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcProductField;");
		jobject Product = env->AllocObject(jclazz);
		if(pProduct)
		{
			jbyteArray ProductID = env->NewByteArray(31);
			if(pProduct->ProductID)
				env->SetByteArrayRegion(ProductID , 0, 31, (const jbyte*)pProduct->ProductID);
			jbyteArray ProductName = env->NewByteArray(21);
			if(pProduct->ProductName)
				env->SetByteArrayRegion(ProductName , 0, 21, (const jbyte*)pProduct->ProductName);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pProduct->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pProduct->ExchangeID);
			jbyteArray TradeCurrencyID = env->NewByteArray(4);
			if(pProduct->TradeCurrencyID)
				env->SetByteArrayRegion(TradeCurrencyID , 0, 4, (const jbyte*)pProduct->TradeCurrencyID);
			jbyteArray ExchangeProductID = env->NewByteArray(31);
			if(pProduct->ExchangeProductID)
				env->SetByteArrayRegion(ExchangeProductID , 0, 31, (const jbyte*)pProduct->ExchangeProductID);
			Product = env->NewObject(jclazz, ctp_struct_methodIDs[20],ProductID,ProductName,ExchangeID,pProduct->ProductClass,pProduct->VolumeMultiple,pProduct->PriceTick,pProduct->MaxMarketOrderVolume,pProduct->MinMarketOrderVolume,pProduct->MaxLimitOrderVolume,pProduct->MinLimitOrderVolume,pProduct->PositionType,pProduct->PositionDateType,pProduct->CloseDealType,TradeCurrencyID,pProduct->MortgageFundUseRange,ExchangeProductID,pProduct->UnderlyingMultiple);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[37],Product, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryInstrument(CThostFtdcInstrumentField * pInstrument,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentField;");
		jobject Instrument = env->AllocObject(jclazz);
		if(pInstrument)
		{
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInstrument->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInstrument->InstrumentID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInstrument->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInstrument->ExchangeID);
			jbyteArray InstrumentName = env->NewByteArray(21);
			if(pInstrument->InstrumentName)
				env->SetByteArrayRegion(InstrumentName , 0, 21, (const jbyte*)pInstrument->InstrumentName);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pInstrument->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pInstrument->ExchangeInstID);
			jbyteArray ProductID = env->NewByteArray(31);
			if(pInstrument->ProductID)
				env->SetByteArrayRegion(ProductID , 0, 31, (const jbyte*)pInstrument->ProductID);
			jbyteArray CreateDate = env->NewByteArray(9);
			if(pInstrument->CreateDate)
				env->SetByteArrayRegion(CreateDate , 0, 9, (const jbyte*)pInstrument->CreateDate);
			jbyteArray OpenDate = env->NewByteArray(9);
			if(pInstrument->OpenDate)
				env->SetByteArrayRegion(OpenDate , 0, 9, (const jbyte*)pInstrument->OpenDate);
			jbyteArray ExpireDate = env->NewByteArray(9);
			if(pInstrument->ExpireDate)
				env->SetByteArrayRegion(ExpireDate , 0, 9, (const jbyte*)pInstrument->ExpireDate);
			jbyteArray StartDelivDate = env->NewByteArray(9);
			if(pInstrument->StartDelivDate)
				env->SetByteArrayRegion(StartDelivDate , 0, 9, (const jbyte*)pInstrument->StartDelivDate);
			jbyteArray EndDelivDate = env->NewByteArray(9);
			if(pInstrument->EndDelivDate)
				env->SetByteArrayRegion(EndDelivDate , 0, 9, (const jbyte*)pInstrument->EndDelivDate);
			jbyteArray UnderlyingInstrID = env->NewByteArray(31);
			if(pInstrument->UnderlyingInstrID)
				env->SetByteArrayRegion(UnderlyingInstrID , 0, 31, (const jbyte*)pInstrument->UnderlyingInstrID);
			Instrument = env->NewObject(jclazz, ctp_struct_methodIDs[21],InstrumentID,ExchangeID,InstrumentName,ExchangeInstID,ProductID,pInstrument->ProductClass,pInstrument->DeliveryYear,pInstrument->DeliveryMonth,pInstrument->MaxMarketOrderVolume,pInstrument->MinMarketOrderVolume,pInstrument->MaxLimitOrderVolume,pInstrument->MinLimitOrderVolume,pInstrument->VolumeMultiple,pInstrument->PriceTick,CreateDate,OpenDate,ExpireDate,StartDelivDate,EndDelivDate,pInstrument->InstLifePhase,pInstrument->IsTrading,pInstrument->PositionType,pInstrument->PositionDateType,pInstrument->LongMarginRatio,pInstrument->ShortMarginRatio,pInstrument->MaxMarginSideAlgorithm,UnderlyingInstrID,pInstrument->StrikePrice,pInstrument->OptionsType,pInstrument->UnderlyingMultiple,pInstrument->CombinationType);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[38],Instrument, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryDepthMarketData(CThostFtdcDepthMarketDataField * pDepthMarketData,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcDepthMarketDataField;");
		jobject DepthMarketData = env->AllocObject(jclazz);
		if(pDepthMarketData)
		{
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pDepthMarketData->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pDepthMarketData->TradingDay);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pDepthMarketData->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pDepthMarketData->InstrumentID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pDepthMarketData->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pDepthMarketData->ExchangeID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pDepthMarketData->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pDepthMarketData->ExchangeInstID);
			jbyteArray UpdateTime = env->NewByteArray(9);
			if(pDepthMarketData->UpdateTime)
				env->SetByteArrayRegion(UpdateTime , 0, 9, (const jbyte*)pDepthMarketData->UpdateTime);
			jbyteArray ActionDay = env->NewByteArray(9);
			if(pDepthMarketData->ActionDay)
				env->SetByteArrayRegion(ActionDay , 0, 9, (const jbyte*)pDepthMarketData->ActionDay);
			DepthMarketData = env->NewObject(jclazz, ctp_struct_methodIDs[34],TradingDay,InstrumentID,ExchangeID,ExchangeInstID,pDepthMarketData->LastPrice,pDepthMarketData->PreSettlementPrice,pDepthMarketData->PreClosePrice,pDepthMarketData->PreOpenInterest,pDepthMarketData->OpenPrice,pDepthMarketData->HighestPrice,pDepthMarketData->LowestPrice,pDepthMarketData->Volume,pDepthMarketData->Turnover,pDepthMarketData->OpenInterest,pDepthMarketData->ClosePrice,pDepthMarketData->SettlementPrice,pDepthMarketData->UpperLimitPrice,pDepthMarketData->LowerLimitPrice,pDepthMarketData->PreDelta,pDepthMarketData->CurrDelta,UpdateTime,pDepthMarketData->UpdateMillisec,pDepthMarketData->BidPrice1,pDepthMarketData->BidVolume1,pDepthMarketData->AskPrice1,pDepthMarketData->AskVolume1,pDepthMarketData->BidPrice2,pDepthMarketData->BidVolume2,pDepthMarketData->AskPrice2,pDepthMarketData->AskVolume2,pDepthMarketData->BidPrice3,pDepthMarketData->BidVolume3,pDepthMarketData->AskPrice3,pDepthMarketData->AskVolume3,pDepthMarketData->BidPrice4,pDepthMarketData->BidVolume4,pDepthMarketData->AskPrice4,pDepthMarketData->AskVolume4,pDepthMarketData->BidPrice5,pDepthMarketData->BidVolume5,pDepthMarketData->AskPrice5,pDepthMarketData->AskVolume5,pDepthMarketData->AveragePrice,ActionDay);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[39],DepthMarketData, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQrySettlementInfo(CThostFtdcSettlementInfoField * pSettlementInfo,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcSettlementInfoField;");
		jobject SettlementInfo = env->AllocObject(jclazz);
		if(pSettlementInfo)
		{
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pSettlementInfo->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pSettlementInfo->TradingDay);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pSettlementInfo->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pSettlementInfo->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pSettlementInfo->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pSettlementInfo->InvestorID);
			jbyteArray Content = env->NewByteArray(501);
			if(pSettlementInfo->Content)
				env->SetByteArrayRegion(Content , 0, 501, (const jbyte*)pSettlementInfo->Content);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pSettlementInfo->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pSettlementInfo->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pSettlementInfo->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pSettlementInfo->CurrencyID);
			SettlementInfo = env->NewObject(jclazz, ctp_struct_methodIDs[40],TradingDay,pSettlementInfo->SettlementID,BrokerID,InvestorID,pSettlementInfo->SequenceNo,Content,AccountID,CurrencyID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[40],SettlementInfo, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryTransferBank(CThostFtdcTransferBankField * pTransferBank,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferBankField;");
		jobject TransferBank = env->AllocObject(jclazz);
		if(pTransferBank)
		{
			jbyteArray BankID = env->NewByteArray(4);
			if(pTransferBank->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pTransferBank->BankID);
			jbyteArray BankBrchID = env->NewByteArray(5);
			if(pTransferBank->BankBrchID)
				env->SetByteArrayRegion(BankBrchID , 0, 5, (const jbyte*)pTransferBank->BankBrchID);
			jbyteArray BankName = env->NewByteArray(101);
			if(pTransferBank->BankName)
				env->SetByteArrayRegion(BankName , 0, 101, (const jbyte*)pTransferBank->BankName);
			TransferBank = env->NewObject(jclazz, ctp_struct_methodIDs[210],BankID,BankBrchID,BankName,pTransferBank->IsActive);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[41],TransferBank, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryInvestorPositionDetail(CThostFtdcInvestorPositionDetailField * pInvestorPositionDetail,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorPositionDetailField;");
		jobject InvestorPositionDetail = env->AllocObject(jclazz);
		if(pInvestorPositionDetail)
		{
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInvestorPositionDetail->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInvestorPositionDetail->InstrumentID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInvestorPositionDetail->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInvestorPositionDetail->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInvestorPositionDetail->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInvestorPositionDetail->InvestorID);
			jbyteArray OpenDate = env->NewByteArray(9);
			if(pInvestorPositionDetail->OpenDate)
				env->SetByteArrayRegion(OpenDate , 0, 9, (const jbyte*)pInvestorPositionDetail->OpenDate);
			jbyteArray TradeID = env->NewByteArray(21);
			if(pInvestorPositionDetail->TradeID)
				env->SetByteArrayRegion(TradeID , 0, 21, (const jbyte*)pInvestorPositionDetail->TradeID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pInvestorPositionDetail->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pInvestorPositionDetail->TradingDay);
			jbyteArray CombInstrumentID = env->NewByteArray(31);
			if(pInvestorPositionDetail->CombInstrumentID)
				env->SetByteArrayRegion(CombInstrumentID , 0, 31, (const jbyte*)pInvestorPositionDetail->CombInstrumentID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInvestorPositionDetail->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInvestorPositionDetail->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInvestorPositionDetail->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInvestorPositionDetail->InvestUnitID);
			InvestorPositionDetail = env->NewObject(jclazz, ctp_struct_methodIDs[212],InstrumentID,BrokerID,InvestorID,pInvestorPositionDetail->HedgeFlag,pInvestorPositionDetail->Direction,OpenDate,TradeID,pInvestorPositionDetail->Volume,pInvestorPositionDetail->OpenPrice,TradingDay,pInvestorPositionDetail->SettlementID,pInvestorPositionDetail->TradeType,CombInstrumentID,ExchangeID,pInvestorPositionDetail->CloseProfitByDate,pInvestorPositionDetail->CloseProfitByTrade,pInvestorPositionDetail->PositionProfitByDate,pInvestorPositionDetail->PositionProfitByTrade,pInvestorPositionDetail->Margin,pInvestorPositionDetail->ExchMargin,pInvestorPositionDetail->MarginRateByMoney,pInvestorPositionDetail->MarginRateByVolume,pInvestorPositionDetail->LastSettlementPrice,pInvestorPositionDetail->SettlementPrice,pInvestorPositionDetail->CloseVolume,pInvestorPositionDetail->CloseAmount,pInvestorPositionDetail->TimeFirstVolume,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[42],InvestorPositionDetail, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryNotice(CThostFtdcNoticeField * pNotice,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcNoticeField;");
		jobject Notice = env->AllocObject(jclazz);
		if(pNotice)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pNotice->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pNotice->BrokerID);
			jbyteArray Content = env->NewByteArray(501);
			if(pNotice->Content)
				env->SetByteArrayRegion(Content , 0, 501, (const jbyte*)pNotice->Content);
			jbyteArray SequenceLabel = env->NewByteArray(2);
			if(pNotice->SequenceLabel)
				env->SetByteArrayRegion(SequenceLabel , 0, 2, (const jbyte*)pNotice->SequenceLabel);
			Notice = env->NewObject(jclazz, ctp_struct_methodIDs[217],BrokerID,Content,SequenceLabel);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[43],Notice, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQrySettlementInfoConfirm(CThostFtdcSettlementInfoConfirmField * pSettlementInfoConfirm,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcSettlementInfoConfirmField;");
		jobject SettlementInfoConfirm = env->AllocObject(jclazz);
		if(pSettlementInfoConfirm)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pSettlementInfoConfirm->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pSettlementInfoConfirm->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pSettlementInfoConfirm->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pSettlementInfoConfirm->InvestorID);
			jbyteArray ConfirmDate = env->NewByteArray(9);
			if(pSettlementInfoConfirm->ConfirmDate)
				env->SetByteArrayRegion(ConfirmDate , 0, 9, (const jbyte*)pSettlementInfoConfirm->ConfirmDate);
			jbyteArray ConfirmTime = env->NewByteArray(9);
			if(pSettlementInfoConfirm->ConfirmTime)
				env->SetByteArrayRegion(ConfirmTime , 0, 9, (const jbyte*)pSettlementInfoConfirm->ConfirmTime);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pSettlementInfoConfirm->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pSettlementInfoConfirm->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pSettlementInfoConfirm->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pSettlementInfoConfirm->CurrencyID);
			SettlementInfoConfirm = env->NewObject(jclazz, ctp_struct_methodIDs[64],BrokerID,InvestorID,ConfirmDate,ConfirmTime,pSettlementInfoConfirm->SettlementID,AccountID,CurrencyID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[44],SettlementInfoConfirm, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryInvestorPositionCombineDetail(CThostFtdcInvestorPositionCombineDetailField * pInvestorPositionCombineDetail,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorPositionCombineDetailField;");
		jobject InvestorPositionCombineDetail = env->AllocObject(jclazz);
		if(pInvestorPositionCombineDetail)
		{
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pInvestorPositionCombineDetail->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pInvestorPositionCombineDetail->TradingDay);
			jbyteArray OpenDate = env->NewByteArray(9);
			if(pInvestorPositionCombineDetail->OpenDate)
				env->SetByteArrayRegion(OpenDate , 0, 9, (const jbyte*)pInvestorPositionCombineDetail->OpenDate);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInvestorPositionCombineDetail->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInvestorPositionCombineDetail->ExchangeID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInvestorPositionCombineDetail->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInvestorPositionCombineDetail->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInvestorPositionCombineDetail->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInvestorPositionCombineDetail->InvestorID);
			jbyteArray ComTradeID = env->NewByteArray(21);
			if(pInvestorPositionCombineDetail->ComTradeID)
				env->SetByteArrayRegion(ComTradeID , 0, 21, (const jbyte*)pInvestorPositionCombineDetail->ComTradeID);
			jbyteArray TradeID = env->NewByteArray(21);
			if(pInvestorPositionCombineDetail->TradeID)
				env->SetByteArrayRegion(TradeID , 0, 21, (const jbyte*)pInvestorPositionCombineDetail->TradeID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInvestorPositionCombineDetail->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInvestorPositionCombineDetail->InstrumentID);
			jbyteArray CombInstrumentID = env->NewByteArray(31);
			if(pInvestorPositionCombineDetail->CombInstrumentID)
				env->SetByteArrayRegion(CombInstrumentID , 0, 31, (const jbyte*)pInvestorPositionCombineDetail->CombInstrumentID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInvestorPositionCombineDetail->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInvestorPositionCombineDetail->InvestUnitID);
			InvestorPositionCombineDetail = env->NewObject(jclazz, ctp_struct_methodIDs[234],TradingDay,OpenDate,ExchangeID,pInvestorPositionCombineDetail->SettlementID,BrokerID,InvestorID,ComTradeID,TradeID,InstrumentID,pInvestorPositionCombineDetail->HedgeFlag,pInvestorPositionCombineDetail->Direction,pInvestorPositionCombineDetail->TotalAmt,pInvestorPositionCombineDetail->Margin,pInvestorPositionCombineDetail->ExchMargin,pInvestorPositionCombineDetail->MarginRateByMoney,pInvestorPositionCombineDetail->MarginRateByVolume,pInvestorPositionCombineDetail->LegID,pInvestorPositionCombineDetail->LegMultiple,CombInstrumentID,pInvestorPositionCombineDetail->TradeGroupID,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[45],InvestorPositionCombineDetail, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryCFMMCTradingAccountKey(CThostFtdcCFMMCTradingAccountKeyField * pCFMMCTradingAccountKey,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcCFMMCTradingAccountKeyField;");
		jobject CFMMCTradingAccountKey = env->AllocObject(jclazz);
		if(pCFMMCTradingAccountKey)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pCFMMCTradingAccountKey->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pCFMMCTradingAccountKey->BrokerID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pCFMMCTradingAccountKey->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pCFMMCTradingAccountKey->ParticipantID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pCFMMCTradingAccountKey->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pCFMMCTradingAccountKey->AccountID);
			jbyteArray CurrentKey = env->NewByteArray(21);
			if(pCFMMCTradingAccountKey->CurrentKey)
				env->SetByteArrayRegion(CurrentKey , 0, 21, (const jbyte*)pCFMMCTradingAccountKey->CurrentKey);
			CFMMCTradingAccountKey = env->NewObject(jclazz, ctp_struct_methodIDs[265],BrokerID,ParticipantID,AccountID,pCFMMCTradingAccountKey->KeyID,CurrentKey);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[46],CFMMCTradingAccountKey, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryEWarrantOffset(CThostFtdcEWarrantOffsetField * pEWarrantOffset,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcEWarrantOffsetField;");
		jobject EWarrantOffset = env->AllocObject(jclazz);
		if(pEWarrantOffset)
		{
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pEWarrantOffset->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pEWarrantOffset->TradingDay);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pEWarrantOffset->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pEWarrantOffset->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pEWarrantOffset->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pEWarrantOffset->InvestorID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pEWarrantOffset->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pEWarrantOffset->ExchangeID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pEWarrantOffset->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pEWarrantOffset->InstrumentID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pEWarrantOffset->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pEWarrantOffset->InvestUnitID);
			EWarrantOffset = env->NewObject(jclazz, ctp_struct_methodIDs[273],TradingDay,BrokerID,InvestorID,ExchangeID,InstrumentID,pEWarrantOffset->Direction,pEWarrantOffset->HedgeFlag,pEWarrantOffset->Volume,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[47],EWarrantOffset, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryInvestorProductGroupMargin(CThostFtdcInvestorProductGroupMarginField * pInvestorProductGroupMargin,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorProductGroupMarginField;");
		jobject InvestorProductGroupMargin = env->AllocObject(jclazz);
		if(pInvestorProductGroupMargin)
		{
			jbyteArray ProductGroupID = env->NewByteArray(31);
			if(pInvestorProductGroupMargin->ProductGroupID)
				env->SetByteArrayRegion(ProductGroupID , 0, 31, (const jbyte*)pInvestorProductGroupMargin->ProductGroupID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInvestorProductGroupMargin->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInvestorProductGroupMargin->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInvestorProductGroupMargin->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInvestorProductGroupMargin->InvestorID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pInvestorProductGroupMargin->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pInvestorProductGroupMargin->TradingDay);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInvestorProductGroupMargin->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInvestorProductGroupMargin->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInvestorProductGroupMargin->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInvestorProductGroupMargin->InvestUnitID);
			InvestorProductGroupMargin = env->NewObject(jclazz, ctp_struct_methodIDs[276],ProductGroupID,BrokerID,InvestorID,TradingDay,pInvestorProductGroupMargin->SettlementID,pInvestorProductGroupMargin->FrozenMargin,pInvestorProductGroupMargin->LongFrozenMargin,pInvestorProductGroupMargin->ShortFrozenMargin,pInvestorProductGroupMargin->UseMargin,pInvestorProductGroupMargin->LongUseMargin,pInvestorProductGroupMargin->ShortUseMargin,pInvestorProductGroupMargin->ExchMargin,pInvestorProductGroupMargin->LongExchMargin,pInvestorProductGroupMargin->ShortExchMargin,pInvestorProductGroupMargin->CloseProfit,pInvestorProductGroupMargin->FrozenCommission,pInvestorProductGroupMargin->Commission,pInvestorProductGroupMargin->FrozenCash,pInvestorProductGroupMargin->CashIn,pInvestorProductGroupMargin->PositionProfit,pInvestorProductGroupMargin->OffsetAmount,pInvestorProductGroupMargin->LongOffsetAmount,pInvestorProductGroupMargin->ShortOffsetAmount,pInvestorProductGroupMargin->ExchOffsetAmount,pInvestorProductGroupMargin->LongExchOffsetAmount,pInvestorProductGroupMargin->ShortExchOffsetAmount,pInvestorProductGroupMargin->HedgeFlag,ExchangeID,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[48],InvestorProductGroupMargin, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryExchangeMarginRate(CThostFtdcExchangeMarginRateField * pExchangeMarginRate,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeMarginRateField;");
		jobject ExchangeMarginRate = env->AllocObject(jclazz);
		if(pExchangeMarginRate)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pExchangeMarginRate->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pExchangeMarginRate->BrokerID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pExchangeMarginRate->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pExchangeMarginRate->InstrumentID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pExchangeMarginRate->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pExchangeMarginRate->ExchangeID);
			ExchangeMarginRate = env->NewObject(jclazz, ctp_struct_methodIDs[42],BrokerID,InstrumentID,pExchangeMarginRate->HedgeFlag,pExchangeMarginRate->LongMarginRatioByMoney,pExchangeMarginRate->LongMarginRatioByVolume,pExchangeMarginRate->ShortMarginRatioByMoney,pExchangeMarginRate->ShortMarginRatioByVolume,ExchangeID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[49],ExchangeMarginRate, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryExchangeMarginRateAdjust(CThostFtdcExchangeMarginRateAdjustField * pExchangeMarginRateAdjust,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeMarginRateAdjustField;");
		jobject ExchangeMarginRateAdjust = env->AllocObject(jclazz);
		if(pExchangeMarginRateAdjust)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pExchangeMarginRateAdjust->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pExchangeMarginRateAdjust->BrokerID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pExchangeMarginRateAdjust->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pExchangeMarginRateAdjust->InstrumentID);
			ExchangeMarginRateAdjust = env->NewObject(jclazz, ctp_struct_methodIDs[43],BrokerID,InstrumentID,pExchangeMarginRateAdjust->HedgeFlag,pExchangeMarginRateAdjust->LongMarginRatioByMoney,pExchangeMarginRateAdjust->LongMarginRatioByVolume,pExchangeMarginRateAdjust->ShortMarginRatioByMoney,pExchangeMarginRateAdjust->ShortMarginRatioByVolume,pExchangeMarginRateAdjust->ExchLongMarginRatioByMoney,pExchangeMarginRateAdjust->ExchLongMarginRatioByVolume,pExchangeMarginRateAdjust->ExchShortMarginRatioByMoney,pExchangeMarginRateAdjust->ExchShortMarginRatioByVolume,pExchangeMarginRateAdjust->NoLongMarginRatioByMoney,pExchangeMarginRateAdjust->NoLongMarginRatioByVolume,pExchangeMarginRateAdjust->NoShortMarginRatioByMoney,pExchangeMarginRateAdjust->NoShortMarginRatioByVolume);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[50],ExchangeMarginRateAdjust, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryExchangeRate(CThostFtdcExchangeRateField * pExchangeRate,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeRateField;");
		jobject ExchangeRate = env->AllocObject(jclazz);
		if(pExchangeRate)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pExchangeRate->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pExchangeRate->BrokerID);
			jbyteArray FromCurrencyID = env->NewByteArray(4);
			if(pExchangeRate->FromCurrencyID)
				env->SetByteArrayRegion(FromCurrencyID , 0, 4, (const jbyte*)pExchangeRate->FromCurrencyID);
			jbyteArray ToCurrencyID = env->NewByteArray(4);
			if(pExchangeRate->ToCurrencyID)
				env->SetByteArrayRegion(ToCurrencyID , 0, 4, (const jbyte*)pExchangeRate->ToCurrencyID);
			ExchangeRate = env->NewObject(jclazz, ctp_struct_methodIDs[44],BrokerID,FromCurrencyID,pExchangeRate->FromCurrencyUnit,ToCurrencyID,pExchangeRate->ExchangeRate);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[51],ExchangeRate, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQrySecAgentACIDMap(CThostFtdcSecAgentACIDMapField * pSecAgentACIDMap,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcSecAgentACIDMapField;");
		jobject SecAgentACIDMap = env->AllocObject(jclazz);
		if(pSecAgentACIDMap)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pSecAgentACIDMap->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pSecAgentACIDMap->BrokerID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pSecAgentACIDMap->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pSecAgentACIDMap->UserID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pSecAgentACIDMap->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pSecAgentACIDMap->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pSecAgentACIDMap->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pSecAgentACIDMap->CurrencyID);
			jbyteArray BrokerSecAgentID = env->NewByteArray(13);
			if(pSecAgentACIDMap->BrokerSecAgentID)
				env->SetByteArrayRegion(BrokerSecAgentID , 0, 13, (const jbyte*)pSecAgentACIDMap->BrokerSecAgentID);
			SecAgentACIDMap = env->NewObject(jclazz, ctp_struct_methodIDs[317],BrokerID,UserID,AccountID,CurrencyID,BrokerSecAgentID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[52],SecAgentACIDMap, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryProductExchRate(CThostFtdcProductExchRateField * pProductExchRate,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcProductExchRateField;");
		jobject ProductExchRate = env->AllocObject(jclazz);
		if(pProductExchRate)
		{
			jbyteArray ProductID = env->NewByteArray(31);
			if(pProductExchRate->ProductID)
				env->SetByteArrayRegion(ProductID , 0, 31, (const jbyte*)pProductExchRate->ProductID);
			jbyteArray QuoteCurrencyID = env->NewByteArray(4);
			if(pProductExchRate->QuoteCurrencyID)
				env->SetByteArrayRegion(QuoteCurrencyID , 0, 4, (const jbyte*)pProductExchRate->QuoteCurrencyID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pProductExchRate->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pProductExchRate->ExchangeID);
			ProductExchRate = env->NewObject(jclazz, ctp_struct_methodIDs[163],ProductID,QuoteCurrencyID,pProductExchRate->ExchangeRate,ExchangeID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[53],ProductExchRate, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryProductGroup(CThostFtdcProductGroupField * pProductGroup,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcProductGroupField;");
		jobject ProductGroup = env->AllocObject(jclazz);
		if(pProductGroup)
		{
			jbyteArray ProductID = env->NewByteArray(31);
			if(pProductGroup->ProductID)
				env->SetByteArrayRegion(ProductID , 0, 31, (const jbyte*)pProductGroup->ProductID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pProductGroup->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pProductGroup->ExchangeID);
			jbyteArray ProductGroupID = env->NewByteArray(31);
			if(pProductGroup->ProductGroupID)
				env->SetByteArrayRegion(ProductGroupID , 0, 31, (const jbyte*)pProductGroup->ProductGroupID);
			ProductGroup = env->NewObject(jclazz, ctp_struct_methodIDs[280],ProductID,ExchangeID,ProductGroupID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[54],ProductGroup, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryMMInstrumentCommissionRate(CThostFtdcMMInstrumentCommissionRateField * pMMInstrumentCommissionRate,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcMMInstrumentCommissionRateField;");
		jobject MMInstrumentCommissionRate = env->AllocObject(jclazz);
		if(pMMInstrumentCommissionRate)
		{
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pMMInstrumentCommissionRate->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pMMInstrumentCommissionRate->InstrumentID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pMMInstrumentCommissionRate->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pMMInstrumentCommissionRate->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pMMInstrumentCommissionRate->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pMMInstrumentCommissionRate->InvestorID);
			MMInstrumentCommissionRate = env->NewObject(jclazz, ctp_struct_methodIDs[169],InstrumentID,pMMInstrumentCommissionRate->InvestorRange,BrokerID,InvestorID,pMMInstrumentCommissionRate->OpenRatioByMoney,pMMInstrumentCommissionRate->OpenRatioByVolume,pMMInstrumentCommissionRate->CloseRatioByMoney,pMMInstrumentCommissionRate->CloseRatioByVolume,pMMInstrumentCommissionRate->CloseTodayRatioByMoney,pMMInstrumentCommissionRate->CloseTodayRatioByVolume);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[55],MMInstrumentCommissionRate, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryMMOptionInstrCommRate(CThostFtdcMMOptionInstrCommRateField * pMMOptionInstrCommRate,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcMMOptionInstrCommRateField;");
		jobject MMOptionInstrCommRate = env->AllocObject(jclazz);
		if(pMMOptionInstrCommRate)
		{
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pMMOptionInstrCommRate->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pMMOptionInstrCommRate->InstrumentID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pMMOptionInstrCommRate->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pMMOptionInstrCommRate->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pMMOptionInstrCommRate->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pMMOptionInstrCommRate->InvestorID);
			MMOptionInstrCommRate = env->NewObject(jclazz, ctp_struct_methodIDs[167],InstrumentID,pMMOptionInstrCommRate->InvestorRange,BrokerID,InvestorID,pMMOptionInstrCommRate->OpenRatioByMoney,pMMOptionInstrCommRate->OpenRatioByVolume,pMMOptionInstrCommRate->CloseRatioByMoney,pMMOptionInstrCommRate->CloseRatioByVolume,pMMOptionInstrCommRate->CloseTodayRatioByMoney,pMMOptionInstrCommRate->CloseTodayRatioByVolume,pMMOptionInstrCommRate->StrikeRatioByMoney,pMMOptionInstrCommRate->StrikeRatioByVolume);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[56],MMOptionInstrCommRate, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryInstrumentOrderCommRate(CThostFtdcInstrumentOrderCommRateField * pInstrumentOrderCommRate,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentOrderCommRateField;");
		jobject InstrumentOrderCommRate = env->AllocObject(jclazz);
		if(pInstrumentOrderCommRate)
		{
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInstrumentOrderCommRate->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInstrumentOrderCommRate->InstrumentID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInstrumentOrderCommRate->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInstrumentOrderCommRate->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInstrumentOrderCommRate->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInstrumentOrderCommRate->InvestorID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInstrumentOrderCommRate->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInstrumentOrderCommRate->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInstrumentOrderCommRate->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInstrumentOrderCommRate->InvestUnitID);
			InstrumentOrderCommRate = env->NewObject(jclazz, ctp_struct_methodIDs[171],InstrumentID,pInstrumentOrderCommRate->InvestorRange,BrokerID,InvestorID,pInstrumentOrderCommRate->HedgeFlag,pInstrumentOrderCommRate->OrderCommByVolume,pInstrumentOrderCommRate->OrderActionCommByVolume,ExchangeID,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[57],InstrumentOrderCommRate, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQrySecAgentTradingAccount(CThostFtdcTradingAccountField * pTradingAccount,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountField;");
		jobject TradingAccount = env->AllocObject(jclazz);
		if(pTradingAccount)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pTradingAccount->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pTradingAccount->BrokerID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pTradingAccount->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pTradingAccount->AccountID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pTradingAccount->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pTradingAccount->TradingDay);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pTradingAccount->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pTradingAccount->CurrencyID);
			TradingAccount = env->NewObject(jclazz, ctp_struct_methodIDs[30],BrokerID,AccountID,pTradingAccount->PreMortgage,pTradingAccount->PreCredit,pTradingAccount->PreDeposit,pTradingAccount->PreBalance,pTradingAccount->PreMargin,pTradingAccount->InterestBase,pTradingAccount->Interest,pTradingAccount->Deposit,pTradingAccount->Withdraw,pTradingAccount->FrozenMargin,pTradingAccount->FrozenCash,pTradingAccount->FrozenCommission,pTradingAccount->CurrMargin,pTradingAccount->CashIn,pTradingAccount->Commission,pTradingAccount->CloseProfit,pTradingAccount->PositionProfit,pTradingAccount->Balance,pTradingAccount->Available,pTradingAccount->WithdrawQuota,pTradingAccount->Reserve,TradingDay,pTradingAccount->SettlementID,pTradingAccount->Credit,pTradingAccount->Mortgage,pTradingAccount->ExchangeMargin,pTradingAccount->DeliveryMargin,pTradingAccount->ExchangeDeliveryMargin,pTradingAccount->ReserveBalance,CurrencyID,pTradingAccount->PreFundMortgageIn,pTradingAccount->PreFundMortgageOut,pTradingAccount->FundMortgageIn,pTradingAccount->FundMortgageOut,pTradingAccount->FundMortgageAvailable,pTradingAccount->MortgageableFund,pTradingAccount->SpecProductMargin,pTradingAccount->SpecProductFrozenMargin,pTradingAccount->SpecProductCommission,pTradingAccount->SpecProductFrozenCommission,pTradingAccount->SpecProductPositionProfit,pTradingAccount->SpecProductCloseProfit,pTradingAccount->SpecProductPositionProfitByAlg,pTradingAccount->SpecProductExchangeMargin,pTradingAccount->BizType,pTradingAccount->FrozenSwap,pTradingAccount->RemainSwap);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[58],TradingAccount, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQrySecAgentCheckMode(CThostFtdcSecAgentCheckModeField * pSecAgentCheckMode,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcSecAgentCheckModeField;");
		jobject SecAgentCheckMode = env->AllocObject(jclazz);
		if(pSecAgentCheckMode)
		{
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pSecAgentCheckMode->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pSecAgentCheckMode->InvestorID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pSecAgentCheckMode->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pSecAgentCheckMode->BrokerID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pSecAgentCheckMode->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pSecAgentCheckMode->CurrencyID);
			jbyteArray BrokerSecAgentID = env->NewByteArray(13);
			if(pSecAgentCheckMode->BrokerSecAgentID)
				env->SetByteArrayRegion(BrokerSecAgentID , 0, 13, (const jbyte*)pSecAgentCheckMode->BrokerSecAgentID);
			SecAgentCheckMode = env->NewObject(jclazz, ctp_struct_methodIDs[190],InvestorID,BrokerID,CurrencyID,BrokerSecAgentID,pSecAgentCheckMode->CheckSelfAccount);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[59],SecAgentCheckMode, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQrySecAgentTradeInfo(CThostFtdcSecAgentTradeInfoField * pSecAgentTradeInfo,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcSecAgentTradeInfoField;");
		jobject SecAgentTradeInfo = env->AllocObject(jclazz);
		if(pSecAgentTradeInfo)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pSecAgentTradeInfo->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pSecAgentTradeInfo->BrokerID);
			jbyteArray BrokerSecAgentID = env->NewByteArray(13);
			if(pSecAgentTradeInfo->BrokerSecAgentID)
				env->SetByteArrayRegion(BrokerSecAgentID , 0, 13, (const jbyte*)pSecAgentTradeInfo->BrokerSecAgentID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pSecAgentTradeInfo->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pSecAgentTradeInfo->InvestorID);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pSecAgentTradeInfo->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pSecAgentTradeInfo->LongCustomerName);
			SecAgentTradeInfo = env->NewObject(jclazz, ctp_struct_methodIDs[191],BrokerID,BrokerSecAgentID,InvestorID,LongCustomerName);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[60],SecAgentTradeInfo, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryOptionInstrTradeCost(CThostFtdcOptionInstrTradeCostField * pOptionInstrTradeCost,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrTradeCostField;");
		jobject OptionInstrTradeCost = env->AllocObject(jclazz);
		if(pOptionInstrTradeCost)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pOptionInstrTradeCost->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pOptionInstrTradeCost->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pOptionInstrTradeCost->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pOptionInstrTradeCost->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pOptionInstrTradeCost->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pOptionInstrTradeCost->InstrumentID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pOptionInstrTradeCost->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pOptionInstrTradeCost->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pOptionInstrTradeCost->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pOptionInstrTradeCost->InvestUnitID);
			OptionInstrTradeCost = env->NewObject(jclazz, ctp_struct_methodIDs[113],BrokerID,InvestorID,InstrumentID,pOptionInstrTradeCost->HedgeFlag,pOptionInstrTradeCost->FixedMargin,pOptionInstrTradeCost->MiniMargin,pOptionInstrTradeCost->Royalty,pOptionInstrTradeCost->ExchFixedMargin,pOptionInstrTradeCost->ExchMiniMargin,ExchangeID,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[61],OptionInstrTradeCost, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryOptionInstrCommRate(CThostFtdcOptionInstrCommRateField * pOptionInstrCommRate,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrCommRateField;");
		jobject OptionInstrCommRate = env->AllocObject(jclazz);
		if(pOptionInstrCommRate)
		{
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pOptionInstrCommRate->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pOptionInstrCommRate->InstrumentID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pOptionInstrCommRate->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pOptionInstrCommRate->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pOptionInstrCommRate->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pOptionInstrCommRate->InvestorID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pOptionInstrCommRate->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pOptionInstrCommRate->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pOptionInstrCommRate->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pOptionInstrCommRate->InvestUnitID);
			OptionInstrCommRate = env->NewObject(jclazz, ctp_struct_methodIDs[112],InstrumentID,pOptionInstrCommRate->InvestorRange,BrokerID,InvestorID,pOptionInstrCommRate->OpenRatioByMoney,pOptionInstrCommRate->OpenRatioByVolume,pOptionInstrCommRate->CloseRatioByMoney,pOptionInstrCommRate->CloseRatioByVolume,pOptionInstrCommRate->CloseTodayRatioByMoney,pOptionInstrCommRate->CloseTodayRatioByVolume,pOptionInstrCommRate->StrikeRatioByMoney,pOptionInstrCommRate->StrikeRatioByVolume,ExchangeID,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[62],OptionInstrCommRate, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryExecOrder(CThostFtdcExecOrderField * pExecOrder,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcExecOrderField;");
		jobject ExecOrder = env->AllocObject(jclazz);
		if(pExecOrder)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pExecOrder->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pExecOrder->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pExecOrder->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pExecOrder->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pExecOrder->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pExecOrder->InstrumentID);
			jbyteArray ExecOrderRef = env->NewByteArray(13);
			if(pExecOrder->ExecOrderRef)
				env->SetByteArrayRegion(ExecOrderRef , 0, 13, (const jbyte*)pExecOrder->ExecOrderRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pExecOrder->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pExecOrder->UserID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pExecOrder->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pExecOrder->BusinessUnit);
			jbyteArray ExecOrderLocalID = env->NewByteArray(13);
			if(pExecOrder->ExecOrderLocalID)
				env->SetByteArrayRegion(ExecOrderLocalID , 0, 13, (const jbyte*)pExecOrder->ExecOrderLocalID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pExecOrder->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pExecOrder->ExchangeID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pExecOrder->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pExecOrder->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pExecOrder->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pExecOrder->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pExecOrder->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pExecOrder->ExchangeInstID);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pExecOrder->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pExecOrder->TraderID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pExecOrder->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pExecOrder->TradingDay);
			jbyteArray ExecOrderSysID = env->NewByteArray(21);
			if(pExecOrder->ExecOrderSysID)
				env->SetByteArrayRegion(ExecOrderSysID , 0, 21, (const jbyte*)pExecOrder->ExecOrderSysID);
			jbyteArray InsertDate = env->NewByteArray(9);
			if(pExecOrder->InsertDate)
				env->SetByteArrayRegion(InsertDate , 0, 9, (const jbyte*)pExecOrder->InsertDate);
			jbyteArray InsertTime = env->NewByteArray(9);
			if(pExecOrder->InsertTime)
				env->SetByteArrayRegion(InsertTime , 0, 9, (const jbyte*)pExecOrder->InsertTime);
			jbyteArray CancelTime = env->NewByteArray(9);
			if(pExecOrder->CancelTime)
				env->SetByteArrayRegion(CancelTime , 0, 9, (const jbyte*)pExecOrder->CancelTime);
			jbyteArray ClearingPartID = env->NewByteArray(11);
			if(pExecOrder->ClearingPartID)
				env->SetByteArrayRegion(ClearingPartID , 0, 11, (const jbyte*)pExecOrder->ClearingPartID);
			jbyteArray UserProductInfo = env->NewByteArray(11);
			if(pExecOrder->UserProductInfo)
				env->SetByteArrayRegion(UserProductInfo , 0, 11, (const jbyte*)pExecOrder->UserProductInfo);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pExecOrder->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pExecOrder->StatusMsg);
			jbyteArray ActiveUserID = env->NewByteArray(16);
			if(pExecOrder->ActiveUserID)
				env->SetByteArrayRegion(ActiveUserID , 0, 16, (const jbyte*)pExecOrder->ActiveUserID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pExecOrder->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pExecOrder->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pExecOrder->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pExecOrder->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pExecOrder->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pExecOrder->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pExecOrder->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pExecOrder->CurrencyID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pExecOrder->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pExecOrder->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pExecOrder->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pExecOrder->MacAddress);
			ExecOrder = env->NewObject(jclazz, ctp_struct_methodIDs[119],BrokerID,InvestorID,InstrumentID,ExecOrderRef,UserID,pExecOrder->Volume,pExecOrder->RequestID,BusinessUnit,pExecOrder->OffsetFlag,pExecOrder->HedgeFlag,pExecOrder->ActionType,pExecOrder->PosiDirection,pExecOrder->ReservePositionFlag,pExecOrder->CloseFlag,ExecOrderLocalID,ExchangeID,ParticipantID,ClientID,ExchangeInstID,TraderID,pExecOrder->InstallID,pExecOrder->OrderSubmitStatus,pExecOrder->NotifySequence,TradingDay,pExecOrder->SettlementID,ExecOrderSysID,InsertDate,InsertTime,CancelTime,pExecOrder->ExecResult,ClearingPartID,pExecOrder->SequenceNo,pExecOrder->FrontID,pExecOrder->SessionID,UserProductInfo,StatusMsg,ActiveUserID,pExecOrder->BrokerExecOrderSeq,BranchID,InvestUnitID,AccountID,CurrencyID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[63],ExecOrder, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryForQuote(CThostFtdcForQuoteField * pForQuote,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcForQuoteField;");
		jobject ForQuote = env->AllocObject(jclazz);
		if(pForQuote)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pForQuote->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pForQuote->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pForQuote->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pForQuote->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pForQuote->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pForQuote->InstrumentID);
			jbyteArray ForQuoteRef = env->NewByteArray(13);
			if(pForQuote->ForQuoteRef)
				env->SetByteArrayRegion(ForQuoteRef , 0, 13, (const jbyte*)pForQuote->ForQuoteRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pForQuote->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pForQuote->UserID);
			jbyteArray ForQuoteLocalID = env->NewByteArray(13);
			if(pForQuote->ForQuoteLocalID)
				env->SetByteArrayRegion(ForQuoteLocalID , 0, 13, (const jbyte*)pForQuote->ForQuoteLocalID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pForQuote->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pForQuote->ExchangeID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pForQuote->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pForQuote->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pForQuote->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pForQuote->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pForQuote->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pForQuote->ExchangeInstID);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pForQuote->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pForQuote->TraderID);
			jbyteArray InsertDate = env->NewByteArray(9);
			if(pForQuote->InsertDate)
				env->SetByteArrayRegion(InsertDate , 0, 9, (const jbyte*)pForQuote->InsertDate);
			jbyteArray InsertTime = env->NewByteArray(9);
			if(pForQuote->InsertTime)
				env->SetByteArrayRegion(InsertTime , 0, 9, (const jbyte*)pForQuote->InsertTime);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pForQuote->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pForQuote->StatusMsg);
			jbyteArray ActiveUserID = env->NewByteArray(16);
			if(pForQuote->ActiveUserID)
				env->SetByteArrayRegion(ActiveUserID , 0, 16, (const jbyte*)pForQuote->ActiveUserID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pForQuote->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pForQuote->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pForQuote->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pForQuote->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pForQuote->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pForQuote->MacAddress);
			ForQuote = env->NewObject(jclazz, ctp_struct_methodIDs[134],BrokerID,InvestorID,InstrumentID,ForQuoteRef,UserID,ForQuoteLocalID,ExchangeID,ParticipantID,ClientID,ExchangeInstID,TraderID,pForQuote->InstallID,InsertDate,InsertTime,pForQuote->ForQuoteStatus,pForQuote->FrontID,pForQuote->SessionID,StatusMsg,ActiveUserID,pForQuote->BrokerForQutoSeq,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[64],ForQuote, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryQuote(CThostFtdcQuoteField * pQuote,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcQuoteField;");
		jobject Quote = env->AllocObject(jclazz);
		if(pQuote)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pQuote->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pQuote->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pQuote->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pQuote->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pQuote->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pQuote->InstrumentID);
			jbyteArray QuoteRef = env->NewByteArray(13);
			if(pQuote->QuoteRef)
				env->SetByteArrayRegion(QuoteRef , 0, 13, (const jbyte*)pQuote->QuoteRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pQuote->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pQuote->UserID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pQuote->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pQuote->BusinessUnit);
			jbyteArray QuoteLocalID = env->NewByteArray(13);
			if(pQuote->QuoteLocalID)
				env->SetByteArrayRegion(QuoteLocalID , 0, 13, (const jbyte*)pQuote->QuoteLocalID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pQuote->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pQuote->ExchangeID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pQuote->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pQuote->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pQuote->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pQuote->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pQuote->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pQuote->ExchangeInstID);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pQuote->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pQuote->TraderID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pQuote->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pQuote->TradingDay);
			jbyteArray QuoteSysID = env->NewByteArray(21);
			if(pQuote->QuoteSysID)
				env->SetByteArrayRegion(QuoteSysID , 0, 21, (const jbyte*)pQuote->QuoteSysID);
			jbyteArray InsertDate = env->NewByteArray(9);
			if(pQuote->InsertDate)
				env->SetByteArrayRegion(InsertDate , 0, 9, (const jbyte*)pQuote->InsertDate);
			jbyteArray InsertTime = env->NewByteArray(9);
			if(pQuote->InsertTime)
				env->SetByteArrayRegion(InsertTime , 0, 9, (const jbyte*)pQuote->InsertTime);
			jbyteArray CancelTime = env->NewByteArray(9);
			if(pQuote->CancelTime)
				env->SetByteArrayRegion(CancelTime , 0, 9, (const jbyte*)pQuote->CancelTime);
			jbyteArray ClearingPartID = env->NewByteArray(11);
			if(pQuote->ClearingPartID)
				env->SetByteArrayRegion(ClearingPartID , 0, 11, (const jbyte*)pQuote->ClearingPartID);
			jbyteArray AskOrderSysID = env->NewByteArray(21);
			if(pQuote->AskOrderSysID)
				env->SetByteArrayRegion(AskOrderSysID , 0, 21, (const jbyte*)pQuote->AskOrderSysID);
			jbyteArray BidOrderSysID = env->NewByteArray(21);
			if(pQuote->BidOrderSysID)
				env->SetByteArrayRegion(BidOrderSysID , 0, 21, (const jbyte*)pQuote->BidOrderSysID);
			jbyteArray UserProductInfo = env->NewByteArray(11);
			if(pQuote->UserProductInfo)
				env->SetByteArrayRegion(UserProductInfo , 0, 11, (const jbyte*)pQuote->UserProductInfo);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pQuote->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pQuote->StatusMsg);
			jbyteArray ActiveUserID = env->NewByteArray(16);
			if(pQuote->ActiveUserID)
				env->SetByteArrayRegion(ActiveUserID , 0, 16, (const jbyte*)pQuote->ActiveUserID);
			jbyteArray AskOrderRef = env->NewByteArray(13);
			if(pQuote->AskOrderRef)
				env->SetByteArrayRegion(AskOrderRef , 0, 13, (const jbyte*)pQuote->AskOrderRef);
			jbyteArray BidOrderRef = env->NewByteArray(13);
			if(pQuote->BidOrderRef)
				env->SetByteArrayRegion(BidOrderRef , 0, 13, (const jbyte*)pQuote->BidOrderRef);
			jbyteArray ForQuoteSysID = env->NewByteArray(21);
			if(pQuote->ForQuoteSysID)
				env->SetByteArrayRegion(ForQuoteSysID , 0, 21, (const jbyte*)pQuote->ForQuoteSysID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pQuote->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pQuote->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pQuote->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pQuote->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pQuote->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pQuote->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pQuote->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pQuote->CurrencyID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pQuote->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pQuote->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pQuote->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pQuote->MacAddress);
			Quote = env->NewObject(jclazz, ctp_struct_methodIDs[140],BrokerID,InvestorID,InstrumentID,QuoteRef,UserID,pQuote->AskPrice,pQuote->BidPrice,pQuote->AskVolume,pQuote->BidVolume,pQuote->RequestID,BusinessUnit,pQuote->AskOffsetFlag,pQuote->BidOffsetFlag,pQuote->AskHedgeFlag,pQuote->BidHedgeFlag,QuoteLocalID,ExchangeID,ParticipantID,ClientID,ExchangeInstID,TraderID,pQuote->InstallID,pQuote->NotifySequence,pQuote->OrderSubmitStatus,TradingDay,pQuote->SettlementID,QuoteSysID,InsertDate,InsertTime,CancelTime,pQuote->QuoteStatus,ClearingPartID,pQuote->SequenceNo,AskOrderSysID,BidOrderSysID,pQuote->FrontID,pQuote->SessionID,UserProductInfo,StatusMsg,ActiveUserID,pQuote->BrokerQuoteSeq,AskOrderRef,BidOrderRef,ForQuoteSysID,BranchID,InvestUnitID,AccountID,CurrencyID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[65],Quote, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryOptionSelfClose(CThostFtdcOptionSelfCloseField * pOptionSelfClose,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionSelfCloseField;");
		jobject OptionSelfClose = env->AllocObject(jclazz);
		if(pOptionSelfClose)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pOptionSelfClose->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pOptionSelfClose->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pOptionSelfClose->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pOptionSelfClose->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pOptionSelfClose->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pOptionSelfClose->InstrumentID);
			jbyteArray OptionSelfCloseRef = env->NewByteArray(13);
			if(pOptionSelfClose->OptionSelfCloseRef)
				env->SetByteArrayRegion(OptionSelfCloseRef , 0, 13, (const jbyte*)pOptionSelfClose->OptionSelfCloseRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pOptionSelfClose->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pOptionSelfClose->UserID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pOptionSelfClose->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pOptionSelfClose->BusinessUnit);
			jbyteArray OptionSelfCloseLocalID = env->NewByteArray(13);
			if(pOptionSelfClose->OptionSelfCloseLocalID)
				env->SetByteArrayRegion(OptionSelfCloseLocalID , 0, 13, (const jbyte*)pOptionSelfClose->OptionSelfCloseLocalID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pOptionSelfClose->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pOptionSelfClose->ExchangeID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pOptionSelfClose->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pOptionSelfClose->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pOptionSelfClose->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pOptionSelfClose->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pOptionSelfClose->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pOptionSelfClose->ExchangeInstID);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pOptionSelfClose->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pOptionSelfClose->TraderID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pOptionSelfClose->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pOptionSelfClose->TradingDay);
			jbyteArray OptionSelfCloseSysID = env->NewByteArray(21);
			if(pOptionSelfClose->OptionSelfCloseSysID)
				env->SetByteArrayRegion(OptionSelfCloseSysID , 0, 21, (const jbyte*)pOptionSelfClose->OptionSelfCloseSysID);
			jbyteArray InsertDate = env->NewByteArray(9);
			if(pOptionSelfClose->InsertDate)
				env->SetByteArrayRegion(InsertDate , 0, 9, (const jbyte*)pOptionSelfClose->InsertDate);
			jbyteArray InsertTime = env->NewByteArray(9);
			if(pOptionSelfClose->InsertTime)
				env->SetByteArrayRegion(InsertTime , 0, 9, (const jbyte*)pOptionSelfClose->InsertTime);
			jbyteArray CancelTime = env->NewByteArray(9);
			if(pOptionSelfClose->CancelTime)
				env->SetByteArrayRegion(CancelTime , 0, 9, (const jbyte*)pOptionSelfClose->CancelTime);
			jbyteArray ClearingPartID = env->NewByteArray(11);
			if(pOptionSelfClose->ClearingPartID)
				env->SetByteArrayRegion(ClearingPartID , 0, 11, (const jbyte*)pOptionSelfClose->ClearingPartID);
			jbyteArray UserProductInfo = env->NewByteArray(11);
			if(pOptionSelfClose->UserProductInfo)
				env->SetByteArrayRegion(UserProductInfo , 0, 11, (const jbyte*)pOptionSelfClose->UserProductInfo);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pOptionSelfClose->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pOptionSelfClose->StatusMsg);
			jbyteArray ActiveUserID = env->NewByteArray(16);
			if(pOptionSelfClose->ActiveUserID)
				env->SetByteArrayRegion(ActiveUserID , 0, 16, (const jbyte*)pOptionSelfClose->ActiveUserID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pOptionSelfClose->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pOptionSelfClose->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pOptionSelfClose->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pOptionSelfClose->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pOptionSelfClose->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pOptionSelfClose->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pOptionSelfClose->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pOptionSelfClose->CurrencyID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pOptionSelfClose->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pOptionSelfClose->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pOptionSelfClose->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pOptionSelfClose->MacAddress);
			OptionSelfClose = env->NewObject(jclazz, ctp_struct_methodIDs[180],BrokerID,InvestorID,InstrumentID,OptionSelfCloseRef,UserID,pOptionSelfClose->Volume,pOptionSelfClose->RequestID,BusinessUnit,pOptionSelfClose->HedgeFlag,pOptionSelfClose->OptSelfCloseFlag,OptionSelfCloseLocalID,ExchangeID,ParticipantID,ClientID,ExchangeInstID,TraderID,pOptionSelfClose->InstallID,pOptionSelfClose->OrderSubmitStatus,pOptionSelfClose->NotifySequence,TradingDay,pOptionSelfClose->SettlementID,OptionSelfCloseSysID,InsertDate,InsertTime,CancelTime,pOptionSelfClose->ExecResult,ClearingPartID,pOptionSelfClose->SequenceNo,pOptionSelfClose->FrontID,pOptionSelfClose->SessionID,UserProductInfo,StatusMsg,ActiveUserID,pOptionSelfClose->BrokerOptionSelfCloseSeq,BranchID,InvestUnitID,AccountID,CurrencyID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[66],OptionSelfClose, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryInvestUnit(CThostFtdcInvestUnitField * pInvestUnit,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestUnitField;");
		jobject InvestUnit = env->AllocObject(jclazz);
		if(pInvestUnit)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInvestUnit->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInvestUnit->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInvestUnit->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInvestUnit->InvestorID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInvestUnit->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInvestUnit->InvestUnitID);
			jbyteArray InvestorUnitName = env->NewByteArray(81);
			if(pInvestUnit->InvestorUnitName)
				env->SetByteArrayRegion(InvestorUnitName , 0, 81, (const jbyte*)pInvestUnit->InvestorUnitName);
			jbyteArray InvestorGroupID = env->NewByteArray(13);
			if(pInvestUnit->InvestorGroupID)
				env->SetByteArrayRegion(InvestorGroupID , 0, 13, (const jbyte*)pInvestUnit->InvestorGroupID);
			jbyteArray CommModelID = env->NewByteArray(13);
			if(pInvestUnit->CommModelID)
				env->SetByteArrayRegion(CommModelID , 0, 13, (const jbyte*)pInvestUnit->CommModelID);
			jbyteArray MarginModelID = env->NewByteArray(13);
			if(pInvestUnit->MarginModelID)
				env->SetByteArrayRegion(MarginModelID , 0, 13, (const jbyte*)pInvestUnit->MarginModelID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pInvestUnit->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pInvestUnit->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pInvestUnit->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pInvestUnit->CurrencyID);
			InvestUnit = env->NewObject(jclazz, ctp_struct_methodIDs[188],BrokerID,InvestorID,InvestUnitID,InvestorUnitName,InvestorGroupID,CommModelID,MarginModelID,AccountID,CurrencyID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[67],InvestUnit, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryCombInstrumentGuard(CThostFtdcCombInstrumentGuardField * pCombInstrumentGuard,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcCombInstrumentGuardField;");
		jobject CombInstrumentGuard = env->AllocObject(jclazz);
		if(pCombInstrumentGuard)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pCombInstrumentGuard->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pCombInstrumentGuard->BrokerID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pCombInstrumentGuard->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pCombInstrumentGuard->InstrumentID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pCombInstrumentGuard->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pCombInstrumentGuard->ExchangeID);
			CombInstrumentGuard = env->NewObject(jclazz, ctp_struct_methodIDs[156],BrokerID,InstrumentID,ExchangeID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[68],CombInstrumentGuard, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryCombAction(CThostFtdcCombActionField * pCombAction,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcCombActionField;");
		jobject CombAction = env->AllocObject(jclazz);
		if(pCombAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pCombAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pCombAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pCombAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pCombAction->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pCombAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pCombAction->InstrumentID);
			jbyteArray CombActionRef = env->NewByteArray(13);
			if(pCombAction->CombActionRef)
				env->SetByteArrayRegion(CombActionRef , 0, 13, (const jbyte*)pCombAction->CombActionRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pCombAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pCombAction->UserID);
			jbyteArray ActionLocalID = env->NewByteArray(13);
			if(pCombAction->ActionLocalID)
				env->SetByteArrayRegion(ActionLocalID , 0, 13, (const jbyte*)pCombAction->ActionLocalID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pCombAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pCombAction->ExchangeID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pCombAction->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pCombAction->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pCombAction->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pCombAction->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pCombAction->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pCombAction->ExchangeInstID);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pCombAction->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pCombAction->TraderID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pCombAction->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pCombAction->TradingDay);
			jbyteArray UserProductInfo = env->NewByteArray(11);
			if(pCombAction->UserProductInfo)
				env->SetByteArrayRegion(UserProductInfo , 0, 11, (const jbyte*)pCombAction->UserProductInfo);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pCombAction->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pCombAction->StatusMsg);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pCombAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pCombAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pCombAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pCombAction->MacAddress);
			jbyteArray ComTradeID = env->NewByteArray(21);
			if(pCombAction->ComTradeID)
				env->SetByteArrayRegion(ComTradeID , 0, 21, (const jbyte*)pCombAction->ComTradeID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pCombAction->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pCombAction->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pCombAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pCombAction->InvestUnitID);
			CombAction = env->NewObject(jclazz, ctp_struct_methodIDs[159],BrokerID,InvestorID,InstrumentID,CombActionRef,UserID,pCombAction->Direction,pCombAction->Volume,pCombAction->CombDirection,pCombAction->HedgeFlag,ActionLocalID,ExchangeID,ParticipantID,ClientID,ExchangeInstID,TraderID,pCombAction->InstallID,pCombAction->ActionStatus,pCombAction->NotifySequence,TradingDay,pCombAction->SettlementID,pCombAction->SequenceNo,pCombAction->FrontID,pCombAction->SessionID,UserProductInfo,StatusMsg,IPAddress,MacAddress,ComTradeID,BranchID,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[69],CombAction, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryTransferSerial(CThostFtdcTransferSerialField * pTransferSerial,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferSerialField;");
		jobject TransferSerial = env->AllocObject(jclazz);
		if(pTransferSerial)
		{
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pTransferSerial->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pTransferSerial->TradeDate);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pTransferSerial->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pTransferSerial->TradingDay);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pTransferSerial->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pTransferSerial->TradeTime);
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pTransferSerial->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pTransferSerial->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pTransferSerial->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pTransferSerial->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pTransferSerial->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pTransferSerial->BankBranchID);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pTransferSerial->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pTransferSerial->BankAccount);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pTransferSerial->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pTransferSerial->BankSerial);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pTransferSerial->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pTransferSerial->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pTransferSerial->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pTransferSerial->BrokerBranchID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pTransferSerial->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pTransferSerial->AccountID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pTransferSerial->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pTransferSerial->InvestorID);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pTransferSerial->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pTransferSerial->IdentifiedCardNo);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pTransferSerial->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pTransferSerial->CurrencyID);
			jbyteArray OperatorCode = env->NewByteArray(17);
			if(pTransferSerial->OperatorCode)
				env->SetByteArrayRegion(OperatorCode , 0, 17, (const jbyte*)pTransferSerial->OperatorCode);
			jbyteArray BankNewAccount = env->NewByteArray(41);
			if(pTransferSerial->BankNewAccount)
				env->SetByteArrayRegion(BankNewAccount , 0, 41, (const jbyte*)pTransferSerial->BankNewAccount);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pTransferSerial->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pTransferSerial->ErrorMsg);
			TransferSerial = env->NewObject(jclazz, ctp_struct_methodIDs[307],pTransferSerial->PlateSerial,TradeDate,TradingDay,TradeTime,TradeCode,pTransferSerial->SessionID,BankID,BankBranchID,pTransferSerial->BankAccType,BankAccount,BankSerial,BrokerID,BrokerBranchID,pTransferSerial->FutureAccType,AccountID,InvestorID,pTransferSerial->FutureSerial,pTransferSerial->IdCardType,IdentifiedCardNo,CurrencyID,pTransferSerial->TradeAmount,pTransferSerial->CustFee,pTransferSerial->BrokerFee,pTransferSerial->AvailabilityFlag,OperatorCode,BankNewAccount,pTransferSerial->ErrorID,ErrorMsg);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[70],TransferSerial, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryAccountregister(CThostFtdcAccountregisterField * pAccountregister,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcAccountregisterField;");
		jobject Accountregister = env->AllocObject(jclazz);
		if(pAccountregister)
		{
			jbyteArray TradeDay = env->NewByteArray(9);
			if(pAccountregister->TradeDay)
				env->SetByteArrayRegion(TradeDay , 0, 9, (const jbyte*)pAccountregister->TradeDay);
			jbyteArray BankID = env->NewByteArray(4);
			if(pAccountregister->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pAccountregister->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pAccountregister->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pAccountregister->BankBranchID);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pAccountregister->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pAccountregister->BankAccount);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pAccountregister->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pAccountregister->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pAccountregister->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pAccountregister->BrokerBranchID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pAccountregister->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pAccountregister->AccountID);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pAccountregister->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pAccountregister->IdentifiedCardNo);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pAccountregister->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pAccountregister->CustomerName);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pAccountregister->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pAccountregister->CurrencyID);
			jbyteArray RegDate = env->NewByteArray(9);
			if(pAccountregister->RegDate)
				env->SetByteArrayRegion(RegDate , 0, 9, (const jbyte*)pAccountregister->RegDate);
			jbyteArray OutDate = env->NewByteArray(9);
			if(pAccountregister->OutDate)
				env->SetByteArrayRegion(OutDate , 0, 9, (const jbyte*)pAccountregister->OutDate);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pAccountregister->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pAccountregister->LongCustomerName);
			Accountregister = env->NewObject(jclazz, ctp_struct_methodIDs[313],TradeDay,BankID,BankBranchID,BankAccount,BrokerID,BrokerBranchID,AccountID,pAccountregister->IdCardType,IdentifiedCardNo,CustomerName,CurrencyID,pAccountregister->OpenOrDestroy,RegDate,OutDate,pAccountregister->TID,pAccountregister->CustType,pAccountregister->BankAccType,LongCustomerName);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[71],Accountregister, RspInfo, nRequestID, bIsLast);
	}

	void OnRspError(CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[72],RspInfo, nRequestID, bIsLast);
	}

	void OnRtnOrder(CThostFtdcOrderField * pOrder)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcOrderField;");
		jobject Order = env->AllocObject(jclazz);
		if(pOrder)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pOrder->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pOrder->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pOrder->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pOrder->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pOrder->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pOrder->InstrumentID);
			jbyteArray OrderRef = env->NewByteArray(13);
			if(pOrder->OrderRef)
				env->SetByteArrayRegion(OrderRef , 0, 13, (const jbyte*)pOrder->OrderRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pOrder->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pOrder->UserID);
			jbyteArray CombOffsetFlag = env->NewByteArray(5);
			if(pOrder->CombOffsetFlag)
				env->SetByteArrayRegion(CombOffsetFlag , 0, 5, (const jbyte*)pOrder->CombOffsetFlag);
			jbyteArray CombHedgeFlag = env->NewByteArray(5);
			if(pOrder->CombHedgeFlag)
				env->SetByteArrayRegion(CombHedgeFlag , 0, 5, (const jbyte*)pOrder->CombHedgeFlag);
			jbyteArray GTDDate = env->NewByteArray(9);
			if(pOrder->GTDDate)
				env->SetByteArrayRegion(GTDDate , 0, 9, (const jbyte*)pOrder->GTDDate);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pOrder->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pOrder->BusinessUnit);
			jbyteArray OrderLocalID = env->NewByteArray(13);
			if(pOrder->OrderLocalID)
				env->SetByteArrayRegion(OrderLocalID , 0, 13, (const jbyte*)pOrder->OrderLocalID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pOrder->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pOrder->ExchangeID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pOrder->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pOrder->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pOrder->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pOrder->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pOrder->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pOrder->ExchangeInstID);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pOrder->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pOrder->TraderID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pOrder->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pOrder->TradingDay);
			jbyteArray OrderSysID = env->NewByteArray(21);
			if(pOrder->OrderSysID)
				env->SetByteArrayRegion(OrderSysID , 0, 21, (const jbyte*)pOrder->OrderSysID);
			jbyteArray InsertDate = env->NewByteArray(9);
			if(pOrder->InsertDate)
				env->SetByteArrayRegion(InsertDate , 0, 9, (const jbyte*)pOrder->InsertDate);
			jbyteArray InsertTime = env->NewByteArray(9);
			if(pOrder->InsertTime)
				env->SetByteArrayRegion(InsertTime , 0, 9, (const jbyte*)pOrder->InsertTime);
			jbyteArray ActiveTime = env->NewByteArray(9);
			if(pOrder->ActiveTime)
				env->SetByteArrayRegion(ActiveTime , 0, 9, (const jbyte*)pOrder->ActiveTime);
			jbyteArray SuspendTime = env->NewByteArray(9);
			if(pOrder->SuspendTime)
				env->SetByteArrayRegion(SuspendTime , 0, 9, (const jbyte*)pOrder->SuspendTime);
			jbyteArray UpdateTime = env->NewByteArray(9);
			if(pOrder->UpdateTime)
				env->SetByteArrayRegion(UpdateTime , 0, 9, (const jbyte*)pOrder->UpdateTime);
			jbyteArray CancelTime = env->NewByteArray(9);
			if(pOrder->CancelTime)
				env->SetByteArrayRegion(CancelTime , 0, 9, (const jbyte*)pOrder->CancelTime);
			jbyteArray ActiveTraderID = env->NewByteArray(21);
			if(pOrder->ActiveTraderID)
				env->SetByteArrayRegion(ActiveTraderID , 0, 21, (const jbyte*)pOrder->ActiveTraderID);
			jbyteArray ClearingPartID = env->NewByteArray(11);
			if(pOrder->ClearingPartID)
				env->SetByteArrayRegion(ClearingPartID , 0, 11, (const jbyte*)pOrder->ClearingPartID);
			jbyteArray UserProductInfo = env->NewByteArray(11);
			if(pOrder->UserProductInfo)
				env->SetByteArrayRegion(UserProductInfo , 0, 11, (const jbyte*)pOrder->UserProductInfo);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pOrder->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pOrder->StatusMsg);
			jbyteArray ActiveUserID = env->NewByteArray(16);
			if(pOrder->ActiveUserID)
				env->SetByteArrayRegion(ActiveUserID , 0, 16, (const jbyte*)pOrder->ActiveUserID);
			jbyteArray RelativeOrderSysID = env->NewByteArray(21);
			if(pOrder->RelativeOrderSysID)
				env->SetByteArrayRegion(RelativeOrderSysID , 0, 21, (const jbyte*)pOrder->RelativeOrderSysID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pOrder->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pOrder->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pOrder->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pOrder->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pOrder->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pOrder->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pOrder->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pOrder->CurrencyID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pOrder->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pOrder->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pOrder->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pOrder->MacAddress);
			Order = env->NewObject(jclazz, ctp_struct_methodIDs[53],BrokerID,InvestorID,InstrumentID,OrderRef,UserID,pOrder->OrderPriceType,pOrder->Direction,CombOffsetFlag,CombHedgeFlag,pOrder->LimitPrice,pOrder->VolumeTotalOriginal,pOrder->TimeCondition,GTDDate,pOrder->VolumeCondition,pOrder->MinVolume,pOrder->ContingentCondition,pOrder->StopPrice,pOrder->ForceCloseReason,pOrder->IsAutoSuspend,BusinessUnit,pOrder->RequestID,OrderLocalID,ExchangeID,ParticipantID,ClientID,ExchangeInstID,TraderID,pOrder->InstallID,pOrder->OrderSubmitStatus,pOrder->NotifySequence,TradingDay,pOrder->SettlementID,OrderSysID,pOrder->OrderSource,pOrder->OrderStatus,pOrder->OrderType,pOrder->VolumeTraded,pOrder->VolumeTotal,InsertDate,InsertTime,ActiveTime,SuspendTime,UpdateTime,CancelTime,ActiveTraderID,ClearingPartID,pOrder->SequenceNo,pOrder->FrontID,pOrder->SessionID,UserProductInfo,StatusMsg,pOrder->UserForceClose,ActiveUserID,pOrder->BrokerOrderSeq,RelativeOrderSysID,pOrder->ZCETotalTradedVolume,pOrder->IsSwapOrder,BranchID,InvestUnitID,AccountID,CurrencyID,IPAddress,MacAddress);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[73],Order);
	}

	void OnRtnTrade(CThostFtdcTradeField * pTrade)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcTradeField;");
		jobject Trade = env->AllocObject(jclazz);
		if(pTrade)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pTrade->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pTrade->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pTrade->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pTrade->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pTrade->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pTrade->InstrumentID);
			jbyteArray OrderRef = env->NewByteArray(13);
			if(pTrade->OrderRef)
				env->SetByteArrayRegion(OrderRef , 0, 13, (const jbyte*)pTrade->OrderRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pTrade->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pTrade->UserID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pTrade->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pTrade->ExchangeID);
			jbyteArray TradeID = env->NewByteArray(21);
			if(pTrade->TradeID)
				env->SetByteArrayRegion(TradeID , 0, 21, (const jbyte*)pTrade->TradeID);
			jbyteArray OrderSysID = env->NewByteArray(21);
			if(pTrade->OrderSysID)
				env->SetByteArrayRegion(OrderSysID , 0, 21, (const jbyte*)pTrade->OrderSysID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pTrade->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pTrade->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pTrade->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pTrade->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pTrade->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pTrade->ExchangeInstID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pTrade->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pTrade->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pTrade->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pTrade->TradeTime);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pTrade->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pTrade->TraderID);
			jbyteArray OrderLocalID = env->NewByteArray(13);
			if(pTrade->OrderLocalID)
				env->SetByteArrayRegion(OrderLocalID , 0, 13, (const jbyte*)pTrade->OrderLocalID);
			jbyteArray ClearingPartID = env->NewByteArray(11);
			if(pTrade->ClearingPartID)
				env->SetByteArrayRegion(ClearingPartID , 0, 11, (const jbyte*)pTrade->ClearingPartID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pTrade->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pTrade->BusinessUnit);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pTrade->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pTrade->TradingDay);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pTrade->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pTrade->InvestUnitID);
			Trade = env->NewObject(jclazz, ctp_struct_methodIDs[61],BrokerID,InvestorID,InstrumentID,OrderRef,UserID,ExchangeID,TradeID,pTrade->Direction,OrderSysID,ParticipantID,ClientID,pTrade->TradingRole,ExchangeInstID,pTrade->OffsetFlag,pTrade->HedgeFlag,pTrade->Price,pTrade->Volume,TradeDate,TradeTime,pTrade->TradeType,pTrade->PriceSource,TraderID,OrderLocalID,ClearingPartID,BusinessUnit,pTrade->SequenceNo,TradingDay,pTrade->SettlementID,pTrade->BrokerOrderSeq,pTrade->TradeSource,InvestUnitID);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[74],Trade);
	}

	void OnErrRtnOrderInsert(CThostFtdcInputOrderField * pInputOrder,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOrderField;");
		jobject InputOrder = env->AllocObject(jclazz);
		if(pInputOrder)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputOrder->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputOrder->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputOrder->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputOrder->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputOrder->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputOrder->InstrumentID);
			jbyteArray OrderRef = env->NewByteArray(13);
			if(pInputOrder->OrderRef)
				env->SetByteArrayRegion(OrderRef , 0, 13, (const jbyte*)pInputOrder->OrderRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputOrder->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputOrder->UserID);
			jbyteArray CombOffsetFlag = env->NewByteArray(5);
			if(pInputOrder->CombOffsetFlag)
				env->SetByteArrayRegion(CombOffsetFlag , 0, 5, (const jbyte*)pInputOrder->CombOffsetFlag);
			jbyteArray CombHedgeFlag = env->NewByteArray(5);
			if(pInputOrder->CombHedgeFlag)
				env->SetByteArrayRegion(CombHedgeFlag , 0, 5, (const jbyte*)pInputOrder->CombHedgeFlag);
			jbyteArray GTDDate = env->NewByteArray(9);
			if(pInputOrder->GTDDate)
				env->SetByteArrayRegion(GTDDate , 0, 9, (const jbyte*)pInputOrder->GTDDate);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pInputOrder->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pInputOrder->BusinessUnit);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputOrder->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputOrder->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputOrder->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputOrder->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pInputOrder->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pInputOrder->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pInputOrder->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pInputOrder->CurrencyID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pInputOrder->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pInputOrder->ClientID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputOrder->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputOrder->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputOrder->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputOrder->MacAddress);
			InputOrder = env->NewObject(jclazz, ctp_struct_methodIDs[52],BrokerID,InvestorID,InstrumentID,OrderRef,UserID,pInputOrder->OrderPriceType,pInputOrder->Direction,CombOffsetFlag,CombHedgeFlag,pInputOrder->LimitPrice,pInputOrder->VolumeTotalOriginal,pInputOrder->TimeCondition,GTDDate,pInputOrder->VolumeCondition,pInputOrder->MinVolume,pInputOrder->ContingentCondition,pInputOrder->StopPrice,pInputOrder->ForceCloseReason,pInputOrder->IsAutoSuspend,BusinessUnit,pInputOrder->RequestID,pInputOrder->UserForceClose,pInputOrder->IsSwapOrder,ExchangeID,InvestUnitID,AccountID,CurrencyID,ClientID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[75],InputOrder, RspInfo);
	}

	void OnErrRtnOrderAction(CThostFtdcOrderActionField * pOrderAction,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcOrderActionField;");
		jobject OrderAction = env->AllocObject(jclazz);
		if(pOrderAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pOrderAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pOrderAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pOrderAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pOrderAction->InvestorID);
			jbyteArray OrderRef = env->NewByteArray(13);
			if(pOrderAction->OrderRef)
				env->SetByteArrayRegion(OrderRef , 0, 13, (const jbyte*)pOrderAction->OrderRef);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pOrderAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pOrderAction->ExchangeID);
			jbyteArray OrderSysID = env->NewByteArray(21);
			if(pOrderAction->OrderSysID)
				env->SetByteArrayRegion(OrderSysID , 0, 21, (const jbyte*)pOrderAction->OrderSysID);
			jbyteArray ActionDate = env->NewByteArray(9);
			if(pOrderAction->ActionDate)
				env->SetByteArrayRegion(ActionDate , 0, 9, (const jbyte*)pOrderAction->ActionDate);
			jbyteArray ActionTime = env->NewByteArray(9);
			if(pOrderAction->ActionTime)
				env->SetByteArrayRegion(ActionTime , 0, 9, (const jbyte*)pOrderAction->ActionTime);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pOrderAction->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pOrderAction->TraderID);
			jbyteArray OrderLocalID = env->NewByteArray(13);
			if(pOrderAction->OrderLocalID)
				env->SetByteArrayRegion(OrderLocalID , 0, 13, (const jbyte*)pOrderAction->OrderLocalID);
			jbyteArray ActionLocalID = env->NewByteArray(13);
			if(pOrderAction->ActionLocalID)
				env->SetByteArrayRegion(ActionLocalID , 0, 13, (const jbyte*)pOrderAction->ActionLocalID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pOrderAction->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pOrderAction->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pOrderAction->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pOrderAction->ClientID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pOrderAction->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pOrderAction->BusinessUnit);
			jbyteArray UserID = env->NewByteArray(16);
			if(pOrderAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pOrderAction->UserID);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pOrderAction->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pOrderAction->StatusMsg);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pOrderAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pOrderAction->InstrumentID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pOrderAction->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pOrderAction->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pOrderAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pOrderAction->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pOrderAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pOrderAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pOrderAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pOrderAction->MacAddress);
			OrderAction = env->NewObject(jclazz, ctp_struct_methodIDs[57],BrokerID,InvestorID,pOrderAction->OrderActionRef,OrderRef,pOrderAction->RequestID,pOrderAction->FrontID,pOrderAction->SessionID,ExchangeID,OrderSysID,pOrderAction->ActionFlag,pOrderAction->LimitPrice,pOrderAction->VolumeChange,ActionDate,ActionTime,TraderID,pOrderAction->InstallID,OrderLocalID,ActionLocalID,ParticipantID,ClientID,BusinessUnit,pOrderAction->OrderActionStatus,UserID,StatusMsg,InstrumentID,BranchID,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[76],OrderAction, RspInfo);
	}

	void OnRtnInstrumentStatus(CThostFtdcInstrumentStatusField * pInstrumentStatus)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentStatusField;");
		jobject InstrumentStatus = env->AllocObject(jclazz);
		if(pInstrumentStatus)
		{
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInstrumentStatus->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInstrumentStatus->ExchangeID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pInstrumentStatus->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pInstrumentStatus->ExchangeInstID);
			jbyteArray SettlementGroupID = env->NewByteArray(9);
			if(pInstrumentStatus->SettlementGroupID)
				env->SetByteArrayRegion(SettlementGroupID , 0, 9, (const jbyte*)pInstrumentStatus->SettlementGroupID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInstrumentStatus->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInstrumentStatus->InstrumentID);
			jbyteArray EnterTime = env->NewByteArray(9);
			if(pInstrumentStatus->EnterTime)
				env->SetByteArrayRegion(EnterTime , 0, 9, (const jbyte*)pInstrumentStatus->EnterTime);
			InstrumentStatus = env->NewObject(jclazz, ctp_struct_methodIDs[204],ExchangeID,ExchangeInstID,SettlementGroupID,InstrumentID,pInstrumentStatus->InstrumentStatus,pInstrumentStatus->TradingSegmentSN,EnterTime,pInstrumentStatus->EnterReason);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[77],InstrumentStatus);
	}

	void OnRtnBulletin(CThostFtdcBulletinField * pBulletin)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcBulletinField;");
		jobject Bulletin = env->AllocObject(jclazz);
		if(pBulletin)
		{
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pBulletin->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pBulletin->ExchangeID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pBulletin->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pBulletin->TradingDay);
			jbyteArray NewsType = env->NewByteArray(3);
			if(pBulletin->NewsType)
				env->SetByteArrayRegion(NewsType , 0, 3, (const jbyte*)pBulletin->NewsType);
			jbyteArray SendTime = env->NewByteArray(9);
			if(pBulletin->SendTime)
				env->SetByteArrayRegion(SendTime , 0, 9, (const jbyte*)pBulletin->SendTime);
			jbyteArray Abstract = env->NewByteArray(81);
			if(pBulletin->Abstract)
				env->SetByteArrayRegion(Abstract , 0, 81, (const jbyte*)pBulletin->Abstract);
			jbyteArray ComeFrom = env->NewByteArray(21);
			if(pBulletin->ComeFrom)
				env->SetByteArrayRegion(ComeFrom , 0, 21, (const jbyte*)pBulletin->ComeFrom);
			jbyteArray Content = env->NewByteArray(501);
			if(pBulletin->Content)
				env->SetByteArrayRegion(Content , 0, 501, (const jbyte*)pBulletin->Content);
			jbyteArray URLLink = env->NewByteArray(201);
			if(pBulletin->URLLink)
				env->SetByteArrayRegion(URLLink , 0, 201, (const jbyte*)pBulletin->URLLink);
			jbyteArray MarketID = env->NewByteArray(31);
			if(pBulletin->MarketID)
				env->SetByteArrayRegion(MarketID , 0, 31, (const jbyte*)pBulletin->MarketID);
			Bulletin = env->NewObject(jclazz, ctp_struct_methodIDs[281],ExchangeID,TradingDay,pBulletin->BulletinID,pBulletin->SequenceNo,NewsType,pBulletin->NewsUrgency,SendTime,Abstract,ComeFrom,Content,URLLink,MarketID);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[78],Bulletin);
	}

	void OnRtnTradingNotice(CThostFtdcTradingNoticeInfoField * pTradingNoticeInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingNoticeInfoField;");
		jobject TradingNoticeInfo = env->AllocObject(jclazz);
		if(pTradingNoticeInfo)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pTradingNoticeInfo->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pTradingNoticeInfo->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pTradingNoticeInfo->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pTradingNoticeInfo->InvestorID);
			jbyteArray SendTime = env->NewByteArray(9);
			if(pTradingNoticeInfo->SendTime)
				env->SetByteArrayRegion(SendTime , 0, 9, (const jbyte*)pTradingNoticeInfo->SendTime);
			jbyteArray FieldContent = env->NewByteArray(501);
			if(pTradingNoticeInfo->FieldContent)
				env->SetByteArrayRegion(FieldContent , 0, 501, (const jbyte*)pTradingNoticeInfo->FieldContent);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pTradingNoticeInfo->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pTradingNoticeInfo->InvestUnitID);
			TradingNoticeInfo = env->NewObject(jclazz, ctp_struct_methodIDs[246],BrokerID,InvestorID,SendTime,FieldContent,pTradingNoticeInfo->SequenceSeries,pTradingNoticeInfo->SequenceNo,InvestUnitID);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[79],TradingNoticeInfo);
	}

	void OnRtnErrorConditionalOrder(CThostFtdcErrorConditionalOrderField * pErrorConditionalOrder)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcErrorConditionalOrderField;");
		jobject ErrorConditionalOrder = env->AllocObject(jclazz);
		if(pErrorConditionalOrder)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pErrorConditionalOrder->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pErrorConditionalOrder->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pErrorConditionalOrder->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pErrorConditionalOrder->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pErrorConditionalOrder->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pErrorConditionalOrder->InstrumentID);
			jbyteArray OrderRef = env->NewByteArray(13);
			if(pErrorConditionalOrder->OrderRef)
				env->SetByteArrayRegion(OrderRef , 0, 13, (const jbyte*)pErrorConditionalOrder->OrderRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pErrorConditionalOrder->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pErrorConditionalOrder->UserID);
			jbyteArray CombOffsetFlag = env->NewByteArray(5);
			if(pErrorConditionalOrder->CombOffsetFlag)
				env->SetByteArrayRegion(CombOffsetFlag , 0, 5, (const jbyte*)pErrorConditionalOrder->CombOffsetFlag);
			jbyteArray CombHedgeFlag = env->NewByteArray(5);
			if(pErrorConditionalOrder->CombHedgeFlag)
				env->SetByteArrayRegion(CombHedgeFlag , 0, 5, (const jbyte*)pErrorConditionalOrder->CombHedgeFlag);
			jbyteArray GTDDate = env->NewByteArray(9);
			if(pErrorConditionalOrder->GTDDate)
				env->SetByteArrayRegion(GTDDate , 0, 9, (const jbyte*)pErrorConditionalOrder->GTDDate);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pErrorConditionalOrder->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pErrorConditionalOrder->BusinessUnit);
			jbyteArray OrderLocalID = env->NewByteArray(13);
			if(pErrorConditionalOrder->OrderLocalID)
				env->SetByteArrayRegion(OrderLocalID , 0, 13, (const jbyte*)pErrorConditionalOrder->OrderLocalID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pErrorConditionalOrder->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pErrorConditionalOrder->ExchangeID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pErrorConditionalOrder->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pErrorConditionalOrder->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pErrorConditionalOrder->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pErrorConditionalOrder->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pErrorConditionalOrder->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pErrorConditionalOrder->ExchangeInstID);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pErrorConditionalOrder->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pErrorConditionalOrder->TraderID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pErrorConditionalOrder->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pErrorConditionalOrder->TradingDay);
			jbyteArray OrderSysID = env->NewByteArray(21);
			if(pErrorConditionalOrder->OrderSysID)
				env->SetByteArrayRegion(OrderSysID , 0, 21, (const jbyte*)pErrorConditionalOrder->OrderSysID);
			jbyteArray InsertDate = env->NewByteArray(9);
			if(pErrorConditionalOrder->InsertDate)
				env->SetByteArrayRegion(InsertDate , 0, 9, (const jbyte*)pErrorConditionalOrder->InsertDate);
			jbyteArray InsertTime = env->NewByteArray(9);
			if(pErrorConditionalOrder->InsertTime)
				env->SetByteArrayRegion(InsertTime , 0, 9, (const jbyte*)pErrorConditionalOrder->InsertTime);
			jbyteArray ActiveTime = env->NewByteArray(9);
			if(pErrorConditionalOrder->ActiveTime)
				env->SetByteArrayRegion(ActiveTime , 0, 9, (const jbyte*)pErrorConditionalOrder->ActiveTime);
			jbyteArray SuspendTime = env->NewByteArray(9);
			if(pErrorConditionalOrder->SuspendTime)
				env->SetByteArrayRegion(SuspendTime , 0, 9, (const jbyte*)pErrorConditionalOrder->SuspendTime);
			jbyteArray UpdateTime = env->NewByteArray(9);
			if(pErrorConditionalOrder->UpdateTime)
				env->SetByteArrayRegion(UpdateTime , 0, 9, (const jbyte*)pErrorConditionalOrder->UpdateTime);
			jbyteArray CancelTime = env->NewByteArray(9);
			if(pErrorConditionalOrder->CancelTime)
				env->SetByteArrayRegion(CancelTime , 0, 9, (const jbyte*)pErrorConditionalOrder->CancelTime);
			jbyteArray ActiveTraderID = env->NewByteArray(21);
			if(pErrorConditionalOrder->ActiveTraderID)
				env->SetByteArrayRegion(ActiveTraderID , 0, 21, (const jbyte*)pErrorConditionalOrder->ActiveTraderID);
			jbyteArray ClearingPartID = env->NewByteArray(11);
			if(pErrorConditionalOrder->ClearingPartID)
				env->SetByteArrayRegion(ClearingPartID , 0, 11, (const jbyte*)pErrorConditionalOrder->ClearingPartID);
			jbyteArray UserProductInfo = env->NewByteArray(11);
			if(pErrorConditionalOrder->UserProductInfo)
				env->SetByteArrayRegion(UserProductInfo , 0, 11, (const jbyte*)pErrorConditionalOrder->UserProductInfo);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pErrorConditionalOrder->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pErrorConditionalOrder->StatusMsg);
			jbyteArray ActiveUserID = env->NewByteArray(16);
			if(pErrorConditionalOrder->ActiveUserID)
				env->SetByteArrayRegion(ActiveUserID , 0, 16, (const jbyte*)pErrorConditionalOrder->ActiveUserID);
			jbyteArray RelativeOrderSysID = env->NewByteArray(21);
			if(pErrorConditionalOrder->RelativeOrderSysID)
				env->SetByteArrayRegion(RelativeOrderSysID , 0, 21, (const jbyte*)pErrorConditionalOrder->RelativeOrderSysID);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pErrorConditionalOrder->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pErrorConditionalOrder->ErrorMsg);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pErrorConditionalOrder->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pErrorConditionalOrder->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pErrorConditionalOrder->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pErrorConditionalOrder->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pErrorConditionalOrder->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pErrorConditionalOrder->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pErrorConditionalOrder->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pErrorConditionalOrder->CurrencyID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pErrorConditionalOrder->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pErrorConditionalOrder->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pErrorConditionalOrder->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pErrorConditionalOrder->MacAddress);
			ErrorConditionalOrder = env->NewObject(jclazz, ctp_struct_methodIDs[251],BrokerID,InvestorID,InstrumentID,OrderRef,UserID,pErrorConditionalOrder->OrderPriceType,pErrorConditionalOrder->Direction,CombOffsetFlag,CombHedgeFlag,pErrorConditionalOrder->LimitPrice,pErrorConditionalOrder->VolumeTotalOriginal,pErrorConditionalOrder->TimeCondition,GTDDate,pErrorConditionalOrder->VolumeCondition,pErrorConditionalOrder->MinVolume,pErrorConditionalOrder->ContingentCondition,pErrorConditionalOrder->StopPrice,pErrorConditionalOrder->ForceCloseReason,pErrorConditionalOrder->IsAutoSuspend,BusinessUnit,pErrorConditionalOrder->RequestID,OrderLocalID,ExchangeID,ParticipantID,ClientID,ExchangeInstID,TraderID,pErrorConditionalOrder->InstallID,pErrorConditionalOrder->OrderSubmitStatus,pErrorConditionalOrder->NotifySequence,TradingDay,pErrorConditionalOrder->SettlementID,OrderSysID,pErrorConditionalOrder->OrderSource,pErrorConditionalOrder->OrderStatus,pErrorConditionalOrder->OrderType,pErrorConditionalOrder->VolumeTraded,pErrorConditionalOrder->VolumeTotal,InsertDate,InsertTime,ActiveTime,SuspendTime,UpdateTime,CancelTime,ActiveTraderID,ClearingPartID,pErrorConditionalOrder->SequenceNo,pErrorConditionalOrder->FrontID,pErrorConditionalOrder->SessionID,UserProductInfo,StatusMsg,pErrorConditionalOrder->UserForceClose,ActiveUserID,pErrorConditionalOrder->BrokerOrderSeq,RelativeOrderSysID,pErrorConditionalOrder->ZCETotalTradedVolume,pErrorConditionalOrder->ErrorID,ErrorMsg,pErrorConditionalOrder->IsSwapOrder,BranchID,InvestUnitID,AccountID,CurrencyID,IPAddress,MacAddress);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[80],ErrorConditionalOrder);
	}

	void OnRtnExecOrder(CThostFtdcExecOrderField * pExecOrder)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcExecOrderField;");
		jobject ExecOrder = env->AllocObject(jclazz);
		if(pExecOrder)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pExecOrder->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pExecOrder->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pExecOrder->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pExecOrder->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pExecOrder->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pExecOrder->InstrumentID);
			jbyteArray ExecOrderRef = env->NewByteArray(13);
			if(pExecOrder->ExecOrderRef)
				env->SetByteArrayRegion(ExecOrderRef , 0, 13, (const jbyte*)pExecOrder->ExecOrderRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pExecOrder->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pExecOrder->UserID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pExecOrder->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pExecOrder->BusinessUnit);
			jbyteArray ExecOrderLocalID = env->NewByteArray(13);
			if(pExecOrder->ExecOrderLocalID)
				env->SetByteArrayRegion(ExecOrderLocalID , 0, 13, (const jbyte*)pExecOrder->ExecOrderLocalID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pExecOrder->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pExecOrder->ExchangeID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pExecOrder->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pExecOrder->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pExecOrder->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pExecOrder->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pExecOrder->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pExecOrder->ExchangeInstID);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pExecOrder->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pExecOrder->TraderID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pExecOrder->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pExecOrder->TradingDay);
			jbyteArray ExecOrderSysID = env->NewByteArray(21);
			if(pExecOrder->ExecOrderSysID)
				env->SetByteArrayRegion(ExecOrderSysID , 0, 21, (const jbyte*)pExecOrder->ExecOrderSysID);
			jbyteArray InsertDate = env->NewByteArray(9);
			if(pExecOrder->InsertDate)
				env->SetByteArrayRegion(InsertDate , 0, 9, (const jbyte*)pExecOrder->InsertDate);
			jbyteArray InsertTime = env->NewByteArray(9);
			if(pExecOrder->InsertTime)
				env->SetByteArrayRegion(InsertTime , 0, 9, (const jbyte*)pExecOrder->InsertTime);
			jbyteArray CancelTime = env->NewByteArray(9);
			if(pExecOrder->CancelTime)
				env->SetByteArrayRegion(CancelTime , 0, 9, (const jbyte*)pExecOrder->CancelTime);
			jbyteArray ClearingPartID = env->NewByteArray(11);
			if(pExecOrder->ClearingPartID)
				env->SetByteArrayRegion(ClearingPartID , 0, 11, (const jbyte*)pExecOrder->ClearingPartID);
			jbyteArray UserProductInfo = env->NewByteArray(11);
			if(pExecOrder->UserProductInfo)
				env->SetByteArrayRegion(UserProductInfo , 0, 11, (const jbyte*)pExecOrder->UserProductInfo);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pExecOrder->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pExecOrder->StatusMsg);
			jbyteArray ActiveUserID = env->NewByteArray(16);
			if(pExecOrder->ActiveUserID)
				env->SetByteArrayRegion(ActiveUserID , 0, 16, (const jbyte*)pExecOrder->ActiveUserID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pExecOrder->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pExecOrder->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pExecOrder->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pExecOrder->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pExecOrder->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pExecOrder->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pExecOrder->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pExecOrder->CurrencyID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pExecOrder->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pExecOrder->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pExecOrder->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pExecOrder->MacAddress);
			ExecOrder = env->NewObject(jclazz, ctp_struct_methodIDs[119],BrokerID,InvestorID,InstrumentID,ExecOrderRef,UserID,pExecOrder->Volume,pExecOrder->RequestID,BusinessUnit,pExecOrder->OffsetFlag,pExecOrder->HedgeFlag,pExecOrder->ActionType,pExecOrder->PosiDirection,pExecOrder->ReservePositionFlag,pExecOrder->CloseFlag,ExecOrderLocalID,ExchangeID,ParticipantID,ClientID,ExchangeInstID,TraderID,pExecOrder->InstallID,pExecOrder->OrderSubmitStatus,pExecOrder->NotifySequence,TradingDay,pExecOrder->SettlementID,ExecOrderSysID,InsertDate,InsertTime,CancelTime,pExecOrder->ExecResult,ClearingPartID,pExecOrder->SequenceNo,pExecOrder->FrontID,pExecOrder->SessionID,UserProductInfo,StatusMsg,ActiveUserID,pExecOrder->BrokerExecOrderSeq,BranchID,InvestUnitID,AccountID,CurrencyID,IPAddress,MacAddress);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[81],ExecOrder);
	}

	void OnErrRtnExecOrderInsert(CThostFtdcInputExecOrderField * pInputExecOrder,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputExecOrderField;");
		jobject InputExecOrder = env->AllocObject(jclazz);
		if(pInputExecOrder)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputExecOrder->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputExecOrder->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputExecOrder->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputExecOrder->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputExecOrder->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputExecOrder->InstrumentID);
			jbyteArray ExecOrderRef = env->NewByteArray(13);
			if(pInputExecOrder->ExecOrderRef)
				env->SetByteArrayRegion(ExecOrderRef , 0, 13, (const jbyte*)pInputExecOrder->ExecOrderRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputExecOrder->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputExecOrder->UserID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pInputExecOrder->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pInputExecOrder->BusinessUnit);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputExecOrder->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputExecOrder->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputExecOrder->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputExecOrder->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pInputExecOrder->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pInputExecOrder->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pInputExecOrder->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pInputExecOrder->CurrencyID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pInputExecOrder->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pInputExecOrder->ClientID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputExecOrder->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputExecOrder->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputExecOrder->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputExecOrder->MacAddress);
			InputExecOrder = env->NewObject(jclazz, ctp_struct_methodIDs[117],BrokerID,InvestorID,InstrumentID,ExecOrderRef,UserID,pInputExecOrder->Volume,pInputExecOrder->RequestID,BusinessUnit,pInputExecOrder->OffsetFlag,pInputExecOrder->HedgeFlag,pInputExecOrder->ActionType,pInputExecOrder->PosiDirection,pInputExecOrder->ReservePositionFlag,pInputExecOrder->CloseFlag,ExchangeID,InvestUnitID,AccountID,CurrencyID,ClientID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[82],InputExecOrder, RspInfo);
	}

	void OnErrRtnExecOrderAction(CThostFtdcExecOrderActionField * pExecOrderAction,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcExecOrderActionField;");
		jobject ExecOrderAction = env->AllocObject(jclazz);
		if(pExecOrderAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pExecOrderAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pExecOrderAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pExecOrderAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pExecOrderAction->InvestorID);
			jbyteArray ExecOrderRef = env->NewByteArray(13);
			if(pExecOrderAction->ExecOrderRef)
				env->SetByteArrayRegion(ExecOrderRef , 0, 13, (const jbyte*)pExecOrderAction->ExecOrderRef);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pExecOrderAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pExecOrderAction->ExchangeID);
			jbyteArray ExecOrderSysID = env->NewByteArray(21);
			if(pExecOrderAction->ExecOrderSysID)
				env->SetByteArrayRegion(ExecOrderSysID , 0, 21, (const jbyte*)pExecOrderAction->ExecOrderSysID);
			jbyteArray ActionDate = env->NewByteArray(9);
			if(pExecOrderAction->ActionDate)
				env->SetByteArrayRegion(ActionDate , 0, 9, (const jbyte*)pExecOrderAction->ActionDate);
			jbyteArray ActionTime = env->NewByteArray(9);
			if(pExecOrderAction->ActionTime)
				env->SetByteArrayRegion(ActionTime , 0, 9, (const jbyte*)pExecOrderAction->ActionTime);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pExecOrderAction->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pExecOrderAction->TraderID);
			jbyteArray ExecOrderLocalID = env->NewByteArray(13);
			if(pExecOrderAction->ExecOrderLocalID)
				env->SetByteArrayRegion(ExecOrderLocalID , 0, 13, (const jbyte*)pExecOrderAction->ExecOrderLocalID);
			jbyteArray ActionLocalID = env->NewByteArray(13);
			if(pExecOrderAction->ActionLocalID)
				env->SetByteArrayRegion(ActionLocalID , 0, 13, (const jbyte*)pExecOrderAction->ActionLocalID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pExecOrderAction->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pExecOrderAction->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pExecOrderAction->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pExecOrderAction->ClientID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pExecOrderAction->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pExecOrderAction->BusinessUnit);
			jbyteArray UserID = env->NewByteArray(16);
			if(pExecOrderAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pExecOrderAction->UserID);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pExecOrderAction->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pExecOrderAction->StatusMsg);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pExecOrderAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pExecOrderAction->InstrumentID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pExecOrderAction->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pExecOrderAction->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pExecOrderAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pExecOrderAction->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pExecOrderAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pExecOrderAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pExecOrderAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pExecOrderAction->MacAddress);
			ExecOrderAction = env->NewObject(jclazz, ctp_struct_methodIDs[120],BrokerID,InvestorID,pExecOrderAction->ExecOrderActionRef,ExecOrderRef,pExecOrderAction->RequestID,pExecOrderAction->FrontID,pExecOrderAction->SessionID,ExchangeID,ExecOrderSysID,pExecOrderAction->ActionFlag,ActionDate,ActionTime,TraderID,pExecOrderAction->InstallID,ExecOrderLocalID,ActionLocalID,ParticipantID,ClientID,BusinessUnit,pExecOrderAction->OrderActionStatus,UserID,pExecOrderAction->ActionType,StatusMsg,InstrumentID,BranchID,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[83],ExecOrderAction, RspInfo);
	}

	void OnErrRtnForQuoteInsert(CThostFtdcInputForQuoteField * pInputForQuote,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputForQuoteField;");
		jobject InputForQuote = env->AllocObject(jclazz);
		if(pInputForQuote)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputForQuote->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputForQuote->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputForQuote->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputForQuote->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputForQuote->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputForQuote->InstrumentID);
			jbyteArray ForQuoteRef = env->NewByteArray(13);
			if(pInputForQuote->ForQuoteRef)
				env->SetByteArrayRegion(ForQuoteRef , 0, 13, (const jbyte*)pInputForQuote->ForQuoteRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputForQuote->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputForQuote->UserID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputForQuote->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputForQuote->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputForQuote->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputForQuote->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputForQuote->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputForQuote->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputForQuote->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputForQuote->MacAddress);
			InputForQuote = env->NewObject(jclazz, ctp_struct_methodIDs[133],BrokerID,InvestorID,InstrumentID,ForQuoteRef,UserID,ExchangeID,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[84],InputForQuote, RspInfo);
	}

	void OnRtnQuote(CThostFtdcQuoteField * pQuote)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcQuoteField;");
		jobject Quote = env->AllocObject(jclazz);
		if(pQuote)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pQuote->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pQuote->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pQuote->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pQuote->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pQuote->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pQuote->InstrumentID);
			jbyteArray QuoteRef = env->NewByteArray(13);
			if(pQuote->QuoteRef)
				env->SetByteArrayRegion(QuoteRef , 0, 13, (const jbyte*)pQuote->QuoteRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pQuote->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pQuote->UserID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pQuote->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pQuote->BusinessUnit);
			jbyteArray QuoteLocalID = env->NewByteArray(13);
			if(pQuote->QuoteLocalID)
				env->SetByteArrayRegion(QuoteLocalID , 0, 13, (const jbyte*)pQuote->QuoteLocalID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pQuote->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pQuote->ExchangeID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pQuote->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pQuote->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pQuote->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pQuote->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pQuote->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pQuote->ExchangeInstID);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pQuote->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pQuote->TraderID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pQuote->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pQuote->TradingDay);
			jbyteArray QuoteSysID = env->NewByteArray(21);
			if(pQuote->QuoteSysID)
				env->SetByteArrayRegion(QuoteSysID , 0, 21, (const jbyte*)pQuote->QuoteSysID);
			jbyteArray InsertDate = env->NewByteArray(9);
			if(pQuote->InsertDate)
				env->SetByteArrayRegion(InsertDate , 0, 9, (const jbyte*)pQuote->InsertDate);
			jbyteArray InsertTime = env->NewByteArray(9);
			if(pQuote->InsertTime)
				env->SetByteArrayRegion(InsertTime , 0, 9, (const jbyte*)pQuote->InsertTime);
			jbyteArray CancelTime = env->NewByteArray(9);
			if(pQuote->CancelTime)
				env->SetByteArrayRegion(CancelTime , 0, 9, (const jbyte*)pQuote->CancelTime);
			jbyteArray ClearingPartID = env->NewByteArray(11);
			if(pQuote->ClearingPartID)
				env->SetByteArrayRegion(ClearingPartID , 0, 11, (const jbyte*)pQuote->ClearingPartID);
			jbyteArray AskOrderSysID = env->NewByteArray(21);
			if(pQuote->AskOrderSysID)
				env->SetByteArrayRegion(AskOrderSysID , 0, 21, (const jbyte*)pQuote->AskOrderSysID);
			jbyteArray BidOrderSysID = env->NewByteArray(21);
			if(pQuote->BidOrderSysID)
				env->SetByteArrayRegion(BidOrderSysID , 0, 21, (const jbyte*)pQuote->BidOrderSysID);
			jbyteArray UserProductInfo = env->NewByteArray(11);
			if(pQuote->UserProductInfo)
				env->SetByteArrayRegion(UserProductInfo , 0, 11, (const jbyte*)pQuote->UserProductInfo);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pQuote->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pQuote->StatusMsg);
			jbyteArray ActiveUserID = env->NewByteArray(16);
			if(pQuote->ActiveUserID)
				env->SetByteArrayRegion(ActiveUserID , 0, 16, (const jbyte*)pQuote->ActiveUserID);
			jbyteArray AskOrderRef = env->NewByteArray(13);
			if(pQuote->AskOrderRef)
				env->SetByteArrayRegion(AskOrderRef , 0, 13, (const jbyte*)pQuote->AskOrderRef);
			jbyteArray BidOrderRef = env->NewByteArray(13);
			if(pQuote->BidOrderRef)
				env->SetByteArrayRegion(BidOrderRef , 0, 13, (const jbyte*)pQuote->BidOrderRef);
			jbyteArray ForQuoteSysID = env->NewByteArray(21);
			if(pQuote->ForQuoteSysID)
				env->SetByteArrayRegion(ForQuoteSysID , 0, 21, (const jbyte*)pQuote->ForQuoteSysID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pQuote->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pQuote->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pQuote->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pQuote->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pQuote->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pQuote->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pQuote->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pQuote->CurrencyID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pQuote->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pQuote->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pQuote->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pQuote->MacAddress);
			Quote = env->NewObject(jclazz, ctp_struct_methodIDs[140],BrokerID,InvestorID,InstrumentID,QuoteRef,UserID,pQuote->AskPrice,pQuote->BidPrice,pQuote->AskVolume,pQuote->BidVolume,pQuote->RequestID,BusinessUnit,pQuote->AskOffsetFlag,pQuote->BidOffsetFlag,pQuote->AskHedgeFlag,pQuote->BidHedgeFlag,QuoteLocalID,ExchangeID,ParticipantID,ClientID,ExchangeInstID,TraderID,pQuote->InstallID,pQuote->NotifySequence,pQuote->OrderSubmitStatus,TradingDay,pQuote->SettlementID,QuoteSysID,InsertDate,InsertTime,CancelTime,pQuote->QuoteStatus,ClearingPartID,pQuote->SequenceNo,AskOrderSysID,BidOrderSysID,pQuote->FrontID,pQuote->SessionID,UserProductInfo,StatusMsg,ActiveUserID,pQuote->BrokerQuoteSeq,AskOrderRef,BidOrderRef,ForQuoteSysID,BranchID,InvestUnitID,AccountID,CurrencyID,IPAddress,MacAddress);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[85],Quote);
	}

	void OnErrRtnQuoteInsert(CThostFtdcInputQuoteField * pInputQuote,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputQuoteField;");
		jobject InputQuote = env->AllocObject(jclazz);
		if(pInputQuote)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputQuote->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputQuote->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputQuote->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputQuote->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputQuote->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputQuote->InstrumentID);
			jbyteArray QuoteRef = env->NewByteArray(13);
			if(pInputQuote->QuoteRef)
				env->SetByteArrayRegion(QuoteRef , 0, 13, (const jbyte*)pInputQuote->QuoteRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputQuote->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputQuote->UserID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pInputQuote->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pInputQuote->BusinessUnit);
			jbyteArray AskOrderRef = env->NewByteArray(13);
			if(pInputQuote->AskOrderRef)
				env->SetByteArrayRegion(AskOrderRef , 0, 13, (const jbyte*)pInputQuote->AskOrderRef);
			jbyteArray BidOrderRef = env->NewByteArray(13);
			if(pInputQuote->BidOrderRef)
				env->SetByteArrayRegion(BidOrderRef , 0, 13, (const jbyte*)pInputQuote->BidOrderRef);
			jbyteArray ForQuoteSysID = env->NewByteArray(21);
			if(pInputQuote->ForQuoteSysID)
				env->SetByteArrayRegion(ForQuoteSysID , 0, 21, (const jbyte*)pInputQuote->ForQuoteSysID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputQuote->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputQuote->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputQuote->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputQuote->InvestUnitID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pInputQuote->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pInputQuote->ClientID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputQuote->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputQuote->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputQuote->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputQuote->MacAddress);
			InputQuote = env->NewObject(jclazz, ctp_struct_methodIDs[138],BrokerID,InvestorID,InstrumentID,QuoteRef,UserID,pInputQuote->AskPrice,pInputQuote->BidPrice,pInputQuote->AskVolume,pInputQuote->BidVolume,pInputQuote->RequestID,BusinessUnit,pInputQuote->AskOffsetFlag,pInputQuote->BidOffsetFlag,pInputQuote->AskHedgeFlag,pInputQuote->BidHedgeFlag,AskOrderRef,BidOrderRef,ForQuoteSysID,ExchangeID,InvestUnitID,ClientID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[86],InputQuote, RspInfo);
	}

	void OnErrRtnQuoteAction(CThostFtdcQuoteActionField * pQuoteAction,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcQuoteActionField;");
		jobject QuoteAction = env->AllocObject(jclazz);
		if(pQuoteAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pQuoteAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pQuoteAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pQuoteAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pQuoteAction->InvestorID);
			jbyteArray QuoteRef = env->NewByteArray(13);
			if(pQuoteAction->QuoteRef)
				env->SetByteArrayRegion(QuoteRef , 0, 13, (const jbyte*)pQuoteAction->QuoteRef);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pQuoteAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pQuoteAction->ExchangeID);
			jbyteArray QuoteSysID = env->NewByteArray(21);
			if(pQuoteAction->QuoteSysID)
				env->SetByteArrayRegion(QuoteSysID , 0, 21, (const jbyte*)pQuoteAction->QuoteSysID);
			jbyteArray ActionDate = env->NewByteArray(9);
			if(pQuoteAction->ActionDate)
				env->SetByteArrayRegion(ActionDate , 0, 9, (const jbyte*)pQuoteAction->ActionDate);
			jbyteArray ActionTime = env->NewByteArray(9);
			if(pQuoteAction->ActionTime)
				env->SetByteArrayRegion(ActionTime , 0, 9, (const jbyte*)pQuoteAction->ActionTime);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pQuoteAction->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pQuoteAction->TraderID);
			jbyteArray QuoteLocalID = env->NewByteArray(13);
			if(pQuoteAction->QuoteLocalID)
				env->SetByteArrayRegion(QuoteLocalID , 0, 13, (const jbyte*)pQuoteAction->QuoteLocalID);
			jbyteArray ActionLocalID = env->NewByteArray(13);
			if(pQuoteAction->ActionLocalID)
				env->SetByteArrayRegion(ActionLocalID , 0, 13, (const jbyte*)pQuoteAction->ActionLocalID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pQuoteAction->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pQuoteAction->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pQuoteAction->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pQuoteAction->ClientID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pQuoteAction->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pQuoteAction->BusinessUnit);
			jbyteArray UserID = env->NewByteArray(16);
			if(pQuoteAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pQuoteAction->UserID);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pQuoteAction->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pQuoteAction->StatusMsg);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pQuoteAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pQuoteAction->InstrumentID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pQuoteAction->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pQuoteAction->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pQuoteAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pQuoteAction->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pQuoteAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pQuoteAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pQuoteAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pQuoteAction->MacAddress);
			QuoteAction = env->NewObject(jclazz, ctp_struct_methodIDs[141],BrokerID,InvestorID,pQuoteAction->QuoteActionRef,QuoteRef,pQuoteAction->RequestID,pQuoteAction->FrontID,pQuoteAction->SessionID,ExchangeID,QuoteSysID,pQuoteAction->ActionFlag,ActionDate,ActionTime,TraderID,pQuoteAction->InstallID,QuoteLocalID,ActionLocalID,ParticipantID,ClientID,BusinessUnit,pQuoteAction->OrderActionStatus,UserID,StatusMsg,InstrumentID,BranchID,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[87],QuoteAction, RspInfo);
	}

	void OnRtnForQuoteRsp(CThostFtdcForQuoteRspField * pForQuoteRsp)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcForQuoteRspField;");
		jobject ForQuoteRsp = env->AllocObject(jclazz);
		if(pForQuoteRsp)
		{
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pForQuoteRsp->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pForQuoteRsp->TradingDay);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pForQuoteRsp->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pForQuoteRsp->InstrumentID);
			jbyteArray ForQuoteSysID = env->NewByteArray(21);
			if(pForQuoteRsp->ForQuoteSysID)
				env->SetByteArrayRegion(ForQuoteSysID , 0, 21, (const jbyte*)pForQuoteRsp->ForQuoteSysID);
			jbyteArray ForQuoteTime = env->NewByteArray(9);
			if(pForQuoteRsp->ForQuoteTime)
				env->SetByteArrayRegion(ForQuoteTime , 0, 9, (const jbyte*)pForQuoteRsp->ForQuoteTime);
			jbyteArray ActionDay = env->NewByteArray(9);
			if(pForQuoteRsp->ActionDay)
				env->SetByteArrayRegion(ActionDay , 0, 9, (const jbyte*)pForQuoteRsp->ActionDay);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pForQuoteRsp->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pForQuoteRsp->ExchangeID);
			ForQuoteRsp = env->NewObject(jclazz, ctp_struct_methodIDs[149],TradingDay,InstrumentID,ForQuoteSysID,ForQuoteTime,ActionDay,ExchangeID);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[88],ForQuoteRsp);
	}

	void OnRtnCFMMCTradingAccountToken(CThostFtdcCFMMCTradingAccountTokenField * pCFMMCTradingAccountToken)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcCFMMCTradingAccountTokenField;");
		jobject CFMMCTradingAccountToken = env->AllocObject(jclazz);
		if(pCFMMCTradingAccountToken)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pCFMMCTradingAccountToken->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pCFMMCTradingAccountToken->BrokerID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pCFMMCTradingAccountToken->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pCFMMCTradingAccountToken->ParticipantID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pCFMMCTradingAccountToken->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pCFMMCTradingAccountToken->AccountID);
			jbyteArray Token = env->NewByteArray(21);
			if(pCFMMCTradingAccountToken->Token)
				env->SetByteArrayRegion(Token , 0, 21, (const jbyte*)pCFMMCTradingAccountToken->Token);
			CFMMCTradingAccountToken = env->NewObject(jclazz, ctp_struct_methodIDs[278],BrokerID,ParticipantID,AccountID,pCFMMCTradingAccountToken->KeyID,Token);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[89],CFMMCTradingAccountToken);
	}

	void OnErrRtnBatchOrderAction(CThostFtdcBatchOrderActionField * pBatchOrderAction,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcBatchOrderActionField;");
		jobject BatchOrderAction = env->AllocObject(jclazz);
		if(pBatchOrderAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pBatchOrderAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pBatchOrderAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pBatchOrderAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pBatchOrderAction->InvestorID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pBatchOrderAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pBatchOrderAction->ExchangeID);
			jbyteArray ActionDate = env->NewByteArray(9);
			if(pBatchOrderAction->ActionDate)
				env->SetByteArrayRegion(ActionDate , 0, 9, (const jbyte*)pBatchOrderAction->ActionDate);
			jbyteArray ActionTime = env->NewByteArray(9);
			if(pBatchOrderAction->ActionTime)
				env->SetByteArrayRegion(ActionTime , 0, 9, (const jbyte*)pBatchOrderAction->ActionTime);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pBatchOrderAction->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pBatchOrderAction->TraderID);
			jbyteArray ActionLocalID = env->NewByteArray(13);
			if(pBatchOrderAction->ActionLocalID)
				env->SetByteArrayRegion(ActionLocalID , 0, 13, (const jbyte*)pBatchOrderAction->ActionLocalID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pBatchOrderAction->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pBatchOrderAction->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pBatchOrderAction->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pBatchOrderAction->ClientID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pBatchOrderAction->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pBatchOrderAction->BusinessUnit);
			jbyteArray UserID = env->NewByteArray(16);
			if(pBatchOrderAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pBatchOrderAction->UserID);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pBatchOrderAction->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pBatchOrderAction->StatusMsg);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pBatchOrderAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pBatchOrderAction->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pBatchOrderAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pBatchOrderAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pBatchOrderAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pBatchOrderAction->MacAddress);
			BatchOrderAction = env->NewObject(jclazz, ctp_struct_methodIDs[153],BrokerID,InvestorID,pBatchOrderAction->OrderActionRef,pBatchOrderAction->RequestID,pBatchOrderAction->FrontID,pBatchOrderAction->SessionID,ExchangeID,ActionDate,ActionTime,TraderID,pBatchOrderAction->InstallID,ActionLocalID,ParticipantID,ClientID,BusinessUnit,pBatchOrderAction->OrderActionStatus,UserID,StatusMsg,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[90],BatchOrderAction, RspInfo);
	}

	void OnRtnOptionSelfClose(CThostFtdcOptionSelfCloseField * pOptionSelfClose)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionSelfCloseField;");
		jobject OptionSelfClose = env->AllocObject(jclazz);
		if(pOptionSelfClose)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pOptionSelfClose->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pOptionSelfClose->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pOptionSelfClose->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pOptionSelfClose->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pOptionSelfClose->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pOptionSelfClose->InstrumentID);
			jbyteArray OptionSelfCloseRef = env->NewByteArray(13);
			if(pOptionSelfClose->OptionSelfCloseRef)
				env->SetByteArrayRegion(OptionSelfCloseRef , 0, 13, (const jbyte*)pOptionSelfClose->OptionSelfCloseRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pOptionSelfClose->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pOptionSelfClose->UserID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pOptionSelfClose->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pOptionSelfClose->BusinessUnit);
			jbyteArray OptionSelfCloseLocalID = env->NewByteArray(13);
			if(pOptionSelfClose->OptionSelfCloseLocalID)
				env->SetByteArrayRegion(OptionSelfCloseLocalID , 0, 13, (const jbyte*)pOptionSelfClose->OptionSelfCloseLocalID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pOptionSelfClose->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pOptionSelfClose->ExchangeID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pOptionSelfClose->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pOptionSelfClose->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pOptionSelfClose->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pOptionSelfClose->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pOptionSelfClose->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pOptionSelfClose->ExchangeInstID);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pOptionSelfClose->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pOptionSelfClose->TraderID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pOptionSelfClose->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pOptionSelfClose->TradingDay);
			jbyteArray OptionSelfCloseSysID = env->NewByteArray(21);
			if(pOptionSelfClose->OptionSelfCloseSysID)
				env->SetByteArrayRegion(OptionSelfCloseSysID , 0, 21, (const jbyte*)pOptionSelfClose->OptionSelfCloseSysID);
			jbyteArray InsertDate = env->NewByteArray(9);
			if(pOptionSelfClose->InsertDate)
				env->SetByteArrayRegion(InsertDate , 0, 9, (const jbyte*)pOptionSelfClose->InsertDate);
			jbyteArray InsertTime = env->NewByteArray(9);
			if(pOptionSelfClose->InsertTime)
				env->SetByteArrayRegion(InsertTime , 0, 9, (const jbyte*)pOptionSelfClose->InsertTime);
			jbyteArray CancelTime = env->NewByteArray(9);
			if(pOptionSelfClose->CancelTime)
				env->SetByteArrayRegion(CancelTime , 0, 9, (const jbyte*)pOptionSelfClose->CancelTime);
			jbyteArray ClearingPartID = env->NewByteArray(11);
			if(pOptionSelfClose->ClearingPartID)
				env->SetByteArrayRegion(ClearingPartID , 0, 11, (const jbyte*)pOptionSelfClose->ClearingPartID);
			jbyteArray UserProductInfo = env->NewByteArray(11);
			if(pOptionSelfClose->UserProductInfo)
				env->SetByteArrayRegion(UserProductInfo , 0, 11, (const jbyte*)pOptionSelfClose->UserProductInfo);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pOptionSelfClose->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pOptionSelfClose->StatusMsg);
			jbyteArray ActiveUserID = env->NewByteArray(16);
			if(pOptionSelfClose->ActiveUserID)
				env->SetByteArrayRegion(ActiveUserID , 0, 16, (const jbyte*)pOptionSelfClose->ActiveUserID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pOptionSelfClose->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pOptionSelfClose->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pOptionSelfClose->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pOptionSelfClose->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pOptionSelfClose->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pOptionSelfClose->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pOptionSelfClose->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pOptionSelfClose->CurrencyID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pOptionSelfClose->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pOptionSelfClose->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pOptionSelfClose->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pOptionSelfClose->MacAddress);
			OptionSelfClose = env->NewObject(jclazz, ctp_struct_methodIDs[180],BrokerID,InvestorID,InstrumentID,OptionSelfCloseRef,UserID,pOptionSelfClose->Volume,pOptionSelfClose->RequestID,BusinessUnit,pOptionSelfClose->HedgeFlag,pOptionSelfClose->OptSelfCloseFlag,OptionSelfCloseLocalID,ExchangeID,ParticipantID,ClientID,ExchangeInstID,TraderID,pOptionSelfClose->InstallID,pOptionSelfClose->OrderSubmitStatus,pOptionSelfClose->NotifySequence,TradingDay,pOptionSelfClose->SettlementID,OptionSelfCloseSysID,InsertDate,InsertTime,CancelTime,pOptionSelfClose->ExecResult,ClearingPartID,pOptionSelfClose->SequenceNo,pOptionSelfClose->FrontID,pOptionSelfClose->SessionID,UserProductInfo,StatusMsg,ActiveUserID,pOptionSelfClose->BrokerOptionSelfCloseSeq,BranchID,InvestUnitID,AccountID,CurrencyID,IPAddress,MacAddress);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[91],OptionSelfClose);
	}

	void OnErrRtnOptionSelfCloseInsert(CThostFtdcInputOptionSelfCloseField * pInputOptionSelfClose,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOptionSelfCloseField;");
		jobject InputOptionSelfClose = env->AllocObject(jclazz);
		if(pInputOptionSelfClose)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputOptionSelfClose->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputOptionSelfClose->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputOptionSelfClose->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputOptionSelfClose->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputOptionSelfClose->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputOptionSelfClose->InstrumentID);
			jbyteArray OptionSelfCloseRef = env->NewByteArray(13);
			if(pInputOptionSelfClose->OptionSelfCloseRef)
				env->SetByteArrayRegion(OptionSelfCloseRef , 0, 13, (const jbyte*)pInputOptionSelfClose->OptionSelfCloseRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputOptionSelfClose->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputOptionSelfClose->UserID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pInputOptionSelfClose->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pInputOptionSelfClose->BusinessUnit);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputOptionSelfClose->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputOptionSelfClose->ExchangeID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputOptionSelfClose->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputOptionSelfClose->InvestUnitID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pInputOptionSelfClose->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pInputOptionSelfClose->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pInputOptionSelfClose->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pInputOptionSelfClose->CurrencyID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pInputOptionSelfClose->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pInputOptionSelfClose->ClientID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputOptionSelfClose->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputOptionSelfClose->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputOptionSelfClose->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputOptionSelfClose->MacAddress);
			InputOptionSelfClose = env->NewObject(jclazz, ctp_struct_methodIDs[178],BrokerID,InvestorID,InstrumentID,OptionSelfCloseRef,UserID,pInputOptionSelfClose->Volume,pInputOptionSelfClose->RequestID,BusinessUnit,pInputOptionSelfClose->HedgeFlag,pInputOptionSelfClose->OptSelfCloseFlag,ExchangeID,InvestUnitID,AccountID,CurrencyID,ClientID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[92],InputOptionSelfClose, RspInfo);
	}

	void OnErrRtnOptionSelfCloseAction(CThostFtdcOptionSelfCloseActionField * pOptionSelfCloseAction,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionSelfCloseActionField;");
		jobject OptionSelfCloseAction = env->AllocObject(jclazz);
		if(pOptionSelfCloseAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pOptionSelfCloseAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pOptionSelfCloseAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pOptionSelfCloseAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pOptionSelfCloseAction->InvestorID);
			jbyteArray OptionSelfCloseRef = env->NewByteArray(13);
			if(pOptionSelfCloseAction->OptionSelfCloseRef)
				env->SetByteArrayRegion(OptionSelfCloseRef , 0, 13, (const jbyte*)pOptionSelfCloseAction->OptionSelfCloseRef);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pOptionSelfCloseAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pOptionSelfCloseAction->ExchangeID);
			jbyteArray OptionSelfCloseSysID = env->NewByteArray(21);
			if(pOptionSelfCloseAction->OptionSelfCloseSysID)
				env->SetByteArrayRegion(OptionSelfCloseSysID , 0, 21, (const jbyte*)pOptionSelfCloseAction->OptionSelfCloseSysID);
			jbyteArray ActionDate = env->NewByteArray(9);
			if(pOptionSelfCloseAction->ActionDate)
				env->SetByteArrayRegion(ActionDate , 0, 9, (const jbyte*)pOptionSelfCloseAction->ActionDate);
			jbyteArray ActionTime = env->NewByteArray(9);
			if(pOptionSelfCloseAction->ActionTime)
				env->SetByteArrayRegion(ActionTime , 0, 9, (const jbyte*)pOptionSelfCloseAction->ActionTime);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pOptionSelfCloseAction->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pOptionSelfCloseAction->TraderID);
			jbyteArray OptionSelfCloseLocalID = env->NewByteArray(13);
			if(pOptionSelfCloseAction->OptionSelfCloseLocalID)
				env->SetByteArrayRegion(OptionSelfCloseLocalID , 0, 13, (const jbyte*)pOptionSelfCloseAction->OptionSelfCloseLocalID);
			jbyteArray ActionLocalID = env->NewByteArray(13);
			if(pOptionSelfCloseAction->ActionLocalID)
				env->SetByteArrayRegion(ActionLocalID , 0, 13, (const jbyte*)pOptionSelfCloseAction->ActionLocalID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pOptionSelfCloseAction->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pOptionSelfCloseAction->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pOptionSelfCloseAction->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pOptionSelfCloseAction->ClientID);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pOptionSelfCloseAction->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pOptionSelfCloseAction->BusinessUnit);
			jbyteArray UserID = env->NewByteArray(16);
			if(pOptionSelfCloseAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pOptionSelfCloseAction->UserID);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pOptionSelfCloseAction->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pOptionSelfCloseAction->StatusMsg);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pOptionSelfCloseAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pOptionSelfCloseAction->InstrumentID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pOptionSelfCloseAction->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pOptionSelfCloseAction->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pOptionSelfCloseAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pOptionSelfCloseAction->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pOptionSelfCloseAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pOptionSelfCloseAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pOptionSelfCloseAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pOptionSelfCloseAction->MacAddress);
			OptionSelfCloseAction = env->NewObject(jclazz, ctp_struct_methodIDs[181],BrokerID,InvestorID,pOptionSelfCloseAction->OptionSelfCloseActionRef,OptionSelfCloseRef,pOptionSelfCloseAction->RequestID,pOptionSelfCloseAction->FrontID,pOptionSelfCloseAction->SessionID,ExchangeID,OptionSelfCloseSysID,pOptionSelfCloseAction->ActionFlag,ActionDate,ActionTime,TraderID,pOptionSelfCloseAction->InstallID,OptionSelfCloseLocalID,ActionLocalID,ParticipantID,ClientID,BusinessUnit,pOptionSelfCloseAction->OrderActionStatus,UserID,StatusMsg,InstrumentID,BranchID,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[93],OptionSelfCloseAction, RspInfo);
	}

	void OnRtnCombAction(CThostFtdcCombActionField * pCombAction)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcCombActionField;");
		jobject CombAction = env->AllocObject(jclazz);
		if(pCombAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pCombAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pCombAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pCombAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pCombAction->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pCombAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pCombAction->InstrumentID);
			jbyteArray CombActionRef = env->NewByteArray(13);
			if(pCombAction->CombActionRef)
				env->SetByteArrayRegion(CombActionRef , 0, 13, (const jbyte*)pCombAction->CombActionRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pCombAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pCombAction->UserID);
			jbyteArray ActionLocalID = env->NewByteArray(13);
			if(pCombAction->ActionLocalID)
				env->SetByteArrayRegion(ActionLocalID , 0, 13, (const jbyte*)pCombAction->ActionLocalID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pCombAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pCombAction->ExchangeID);
			jbyteArray ParticipantID = env->NewByteArray(11);
			if(pCombAction->ParticipantID)
				env->SetByteArrayRegion(ParticipantID , 0, 11, (const jbyte*)pCombAction->ParticipantID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pCombAction->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pCombAction->ClientID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pCombAction->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pCombAction->ExchangeInstID);
			jbyteArray TraderID = env->NewByteArray(21);
			if(pCombAction->TraderID)
				env->SetByteArrayRegion(TraderID , 0, 21, (const jbyte*)pCombAction->TraderID);
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pCombAction->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pCombAction->TradingDay);
			jbyteArray UserProductInfo = env->NewByteArray(11);
			if(pCombAction->UserProductInfo)
				env->SetByteArrayRegion(UserProductInfo , 0, 11, (const jbyte*)pCombAction->UserProductInfo);
			jbyteArray StatusMsg = env->NewByteArray(81);
			if(pCombAction->StatusMsg)
				env->SetByteArrayRegion(StatusMsg , 0, 81, (const jbyte*)pCombAction->StatusMsg);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pCombAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pCombAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pCombAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pCombAction->MacAddress);
			jbyteArray ComTradeID = env->NewByteArray(21);
			if(pCombAction->ComTradeID)
				env->SetByteArrayRegion(ComTradeID , 0, 21, (const jbyte*)pCombAction->ComTradeID);
			jbyteArray BranchID = env->NewByteArray(9);
			if(pCombAction->BranchID)
				env->SetByteArrayRegion(BranchID , 0, 9, (const jbyte*)pCombAction->BranchID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pCombAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pCombAction->InvestUnitID);
			CombAction = env->NewObject(jclazz, ctp_struct_methodIDs[159],BrokerID,InvestorID,InstrumentID,CombActionRef,UserID,pCombAction->Direction,pCombAction->Volume,pCombAction->CombDirection,pCombAction->HedgeFlag,ActionLocalID,ExchangeID,ParticipantID,ClientID,ExchangeInstID,TraderID,pCombAction->InstallID,pCombAction->ActionStatus,pCombAction->NotifySequence,TradingDay,pCombAction->SettlementID,pCombAction->SequenceNo,pCombAction->FrontID,pCombAction->SessionID,UserProductInfo,StatusMsg,IPAddress,MacAddress,ComTradeID,BranchID,InvestUnitID);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[94],CombAction);
	}

	void OnErrRtnCombActionInsert(CThostFtdcInputCombActionField * pInputCombAction,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcInputCombActionField;");
		jobject InputCombAction = env->AllocObject(jclazz);
		if(pInputCombAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pInputCombAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pInputCombAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pInputCombAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pInputCombAction->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pInputCombAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pInputCombAction->InstrumentID);
			jbyteArray CombActionRef = env->NewByteArray(13);
			if(pInputCombAction->CombActionRef)
				env->SetByteArrayRegion(CombActionRef , 0, 13, (const jbyte*)pInputCombAction->CombActionRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pInputCombAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pInputCombAction->UserID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pInputCombAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pInputCombAction->ExchangeID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pInputCombAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pInputCombAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pInputCombAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pInputCombAction->MacAddress);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pInputCombAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pInputCombAction->InvestUnitID);
			InputCombAction = env->NewObject(jclazz, ctp_struct_methodIDs[158],BrokerID,InvestorID,InstrumentID,CombActionRef,UserID,pInputCombAction->Direction,pInputCombAction->Volume,pInputCombAction->CombDirection,pInputCombAction->HedgeFlag,ExchangeID,IPAddress,MacAddress,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[95],InputCombAction, RspInfo);
	}

	void OnRspQryContractBank(CThostFtdcContractBankField * pContractBank,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcContractBankField;");
		jobject ContractBank = env->AllocObject(jclazz);
		if(pContractBank)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pContractBank->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pContractBank->BrokerID);
			jbyteArray BankID = env->NewByteArray(4);
			if(pContractBank->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pContractBank->BankID);
			jbyteArray BankBrchID = env->NewByteArray(5);
			if(pContractBank->BankBrchID)
				env->SetByteArrayRegion(BankBrchID , 0, 5, (const jbyte*)pContractBank->BankBrchID);
			jbyteArray BankName = env->NewByteArray(101);
			if(pContractBank->BankName)
				env->SetByteArrayRegion(BankName , 0, 101, (const jbyte*)pContractBank->BankName);
			ContractBank = env->NewObject(jclazz, ctp_struct_methodIDs[233],BrokerID,BankID,BankBrchID,BankName);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[96],ContractBank, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryParkedOrder(CThostFtdcParkedOrderField * pParkedOrder,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcParkedOrderField;");
		jobject ParkedOrder = env->AllocObject(jclazz);
		if(pParkedOrder)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pParkedOrder->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pParkedOrder->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pParkedOrder->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pParkedOrder->InvestorID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pParkedOrder->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pParkedOrder->InstrumentID);
			jbyteArray OrderRef = env->NewByteArray(13);
			if(pParkedOrder->OrderRef)
				env->SetByteArrayRegion(OrderRef , 0, 13, (const jbyte*)pParkedOrder->OrderRef);
			jbyteArray UserID = env->NewByteArray(16);
			if(pParkedOrder->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pParkedOrder->UserID);
			jbyteArray CombOffsetFlag = env->NewByteArray(5);
			if(pParkedOrder->CombOffsetFlag)
				env->SetByteArrayRegion(CombOffsetFlag , 0, 5, (const jbyte*)pParkedOrder->CombOffsetFlag);
			jbyteArray CombHedgeFlag = env->NewByteArray(5);
			if(pParkedOrder->CombHedgeFlag)
				env->SetByteArrayRegion(CombHedgeFlag , 0, 5, (const jbyte*)pParkedOrder->CombHedgeFlag);
			jbyteArray GTDDate = env->NewByteArray(9);
			if(pParkedOrder->GTDDate)
				env->SetByteArrayRegion(GTDDate , 0, 9, (const jbyte*)pParkedOrder->GTDDate);
			jbyteArray BusinessUnit = env->NewByteArray(21);
			if(pParkedOrder->BusinessUnit)
				env->SetByteArrayRegion(BusinessUnit , 0, 21, (const jbyte*)pParkedOrder->BusinessUnit);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pParkedOrder->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pParkedOrder->ExchangeID);
			jbyteArray ParkedOrderID = env->NewByteArray(13);
			if(pParkedOrder->ParkedOrderID)
				env->SetByteArrayRegion(ParkedOrderID , 0, 13, (const jbyte*)pParkedOrder->ParkedOrderID);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pParkedOrder->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pParkedOrder->ErrorMsg);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pParkedOrder->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pParkedOrder->AccountID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pParkedOrder->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pParkedOrder->CurrencyID);
			jbyteArray ClientID = env->NewByteArray(11);
			if(pParkedOrder->ClientID)
				env->SetByteArrayRegion(ClientID , 0, 11, (const jbyte*)pParkedOrder->ClientID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pParkedOrder->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pParkedOrder->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pParkedOrder->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pParkedOrder->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pParkedOrder->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pParkedOrder->MacAddress);
			ParkedOrder = env->NewObject(jclazz, ctp_struct_methodIDs[235],BrokerID,InvestorID,InstrumentID,OrderRef,UserID,pParkedOrder->OrderPriceType,pParkedOrder->Direction,CombOffsetFlag,CombHedgeFlag,pParkedOrder->LimitPrice,pParkedOrder->VolumeTotalOriginal,pParkedOrder->TimeCondition,GTDDate,pParkedOrder->VolumeCondition,pParkedOrder->MinVolume,pParkedOrder->ContingentCondition,pParkedOrder->StopPrice,pParkedOrder->ForceCloseReason,pParkedOrder->IsAutoSuspend,BusinessUnit,pParkedOrder->RequestID,pParkedOrder->UserForceClose,ExchangeID,ParkedOrderID,pParkedOrder->UserType,pParkedOrder->Status,pParkedOrder->ErrorID,ErrorMsg,pParkedOrder->IsSwapOrder,AccountID,CurrencyID,ClientID,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[97],ParkedOrder, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryParkedOrderAction(CThostFtdcParkedOrderActionField * pParkedOrderAction,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcParkedOrderActionField;");
		jobject ParkedOrderAction = env->AllocObject(jclazz);
		if(pParkedOrderAction)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pParkedOrderAction->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pParkedOrderAction->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pParkedOrderAction->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pParkedOrderAction->InvestorID);
			jbyteArray OrderRef = env->NewByteArray(13);
			if(pParkedOrderAction->OrderRef)
				env->SetByteArrayRegion(OrderRef , 0, 13, (const jbyte*)pParkedOrderAction->OrderRef);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pParkedOrderAction->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pParkedOrderAction->ExchangeID);
			jbyteArray OrderSysID = env->NewByteArray(21);
			if(pParkedOrderAction->OrderSysID)
				env->SetByteArrayRegion(OrderSysID , 0, 21, (const jbyte*)pParkedOrderAction->OrderSysID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pParkedOrderAction->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pParkedOrderAction->UserID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pParkedOrderAction->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pParkedOrderAction->InstrumentID);
			jbyteArray ParkedOrderActionID = env->NewByteArray(13);
			if(pParkedOrderAction->ParkedOrderActionID)
				env->SetByteArrayRegion(ParkedOrderActionID , 0, 13, (const jbyte*)pParkedOrderAction->ParkedOrderActionID);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pParkedOrderAction->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pParkedOrderAction->ErrorMsg);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pParkedOrderAction->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pParkedOrderAction->InvestUnitID);
			jbyteArray IPAddress = env->NewByteArray(16);
			if(pParkedOrderAction->IPAddress)
				env->SetByteArrayRegion(IPAddress , 0, 16, (const jbyte*)pParkedOrderAction->IPAddress);
			jbyteArray MacAddress = env->NewByteArray(21);
			if(pParkedOrderAction->MacAddress)
				env->SetByteArrayRegion(MacAddress , 0, 21, (const jbyte*)pParkedOrderAction->MacAddress);
			ParkedOrderAction = env->NewObject(jclazz, ctp_struct_methodIDs[236],BrokerID,InvestorID,pParkedOrderAction->OrderActionRef,OrderRef,pParkedOrderAction->RequestID,pParkedOrderAction->FrontID,pParkedOrderAction->SessionID,ExchangeID,OrderSysID,pParkedOrderAction->ActionFlag,pParkedOrderAction->LimitPrice,pParkedOrderAction->VolumeChange,UserID,InstrumentID,ParkedOrderActionID,pParkedOrderAction->UserType,pParkedOrderAction->Status,pParkedOrderAction->ErrorID,ErrorMsg,InvestUnitID,IPAddress,MacAddress);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[98],ParkedOrderAction, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryTradingNotice(CThostFtdcTradingNoticeField * pTradingNotice,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingNoticeField;");
		jobject TradingNotice = env->AllocObject(jclazz);
		if(pTradingNotice)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pTradingNotice->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pTradingNotice->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pTradingNotice->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pTradingNotice->InvestorID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pTradingNotice->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pTradingNotice->UserID);
			jbyteArray SendTime = env->NewByteArray(9);
			if(pTradingNotice->SendTime)
				env->SetByteArrayRegion(SendTime , 0, 9, (const jbyte*)pTradingNotice->SendTime);
			jbyteArray FieldContent = env->NewByteArray(501);
			if(pTradingNotice->FieldContent)
				env->SetByteArrayRegion(FieldContent , 0, 501, (const jbyte*)pTradingNotice->FieldContent);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pTradingNotice->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pTradingNotice->InvestUnitID);
			TradingNotice = env->NewObject(jclazz, ctp_struct_methodIDs[247],BrokerID,pTradingNotice->InvestorRange,InvestorID,pTradingNotice->SequenceSeries,UserID,SendTime,pTradingNotice->SequenceNo,FieldContent,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[99],TradingNotice, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryBrokerTradingParams(CThostFtdcBrokerTradingParamsField * pBrokerTradingParams,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerTradingParamsField;");
		jobject BrokerTradingParams = env->AllocObject(jclazz);
		if(pBrokerTradingParams)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pBrokerTradingParams->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pBrokerTradingParams->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pBrokerTradingParams->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pBrokerTradingParams->InvestorID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pBrokerTradingParams->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pBrokerTradingParams->CurrencyID);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pBrokerTradingParams->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pBrokerTradingParams->AccountID);
			BrokerTradingParams = env->NewObject(jclazz, ctp_struct_methodIDs[258],BrokerID,InvestorID,pBrokerTradingParams->MarginPriceType,pBrokerTradingParams->Algorithm,pBrokerTradingParams->AvailIncludeCloseProfit,CurrencyID,pBrokerTradingParams->OptionRoyaltyPriceType,AccountID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[100],BrokerTradingParams, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQryBrokerTradingAlgos(CThostFtdcBrokerTradingAlgosField * pBrokerTradingAlgos,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerTradingAlgosField;");
		jobject BrokerTradingAlgos = env->AllocObject(jclazz);
		if(pBrokerTradingAlgos)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pBrokerTradingAlgos->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pBrokerTradingAlgos->BrokerID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pBrokerTradingAlgos->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pBrokerTradingAlgos->ExchangeID);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pBrokerTradingAlgos->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pBrokerTradingAlgos->InstrumentID);
			BrokerTradingAlgos = env->NewObject(jclazz, ctp_struct_methodIDs[260],BrokerID,ExchangeID,InstrumentID,pBrokerTradingAlgos->HandlePositionAlgoID,pBrokerTradingAlgos->FindMarginRateAlgoID,pBrokerTradingAlgos->HandleTradingAccountAlgoID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[101],BrokerTradingAlgos, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQueryCFMMCTradingAccountToken(CThostFtdcQueryCFMMCTradingAccountTokenField * pQueryCFMMCTradingAccountToken,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcQueryCFMMCTradingAccountTokenField;");
		jobject QueryCFMMCTradingAccountToken = env->AllocObject(jclazz);
		if(pQueryCFMMCTradingAccountToken)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pQueryCFMMCTradingAccountToken->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pQueryCFMMCTradingAccountToken->BrokerID);
			jbyteArray InvestorID = env->NewByteArray(13);
			if(pQueryCFMMCTradingAccountToken->InvestorID)
				env->SetByteArrayRegion(InvestorID , 0, 13, (const jbyte*)pQueryCFMMCTradingAccountToken->InvestorID);
			jbyteArray InvestUnitID = env->NewByteArray(17);
			if(pQueryCFMMCTradingAccountToken->InvestUnitID)
				env->SetByteArrayRegion(InvestUnitID , 0, 17, (const jbyte*)pQueryCFMMCTradingAccountToken->InvestUnitID);
			QueryCFMMCTradingAccountToken = env->NewObject(jclazz, ctp_struct_methodIDs[277],BrokerID,InvestorID,InvestUnitID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[102],QueryCFMMCTradingAccountToken, RspInfo, nRequestID, bIsLast);
	}

	void OnRtnFromBankToFutureByBank(CThostFtdcRspTransferField * pRspTransfer)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspTransferField;");
		jobject RspTransfer = env->AllocObject(jclazz);
		if(pRspTransfer)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pRspTransfer->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pRspTransfer->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pRspTransfer->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pRspTransfer->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pRspTransfer->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pRspTransfer->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspTransfer->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspTransfer->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pRspTransfer->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pRspTransfer->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pRspTransfer->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pRspTransfer->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pRspTransfer->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pRspTransfer->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pRspTransfer->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pRspTransfer->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pRspTransfer->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pRspTransfer->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pRspTransfer->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pRspTransfer->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pRspTransfer->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pRspTransfer->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pRspTransfer->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pRspTransfer->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pRspTransfer->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pRspTransfer->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pRspTransfer->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pRspTransfer->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspTransfer->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspTransfer->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pRspTransfer->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pRspTransfer->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pRspTransfer->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pRspTransfer->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pRspTransfer->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pRspTransfer->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pRspTransfer->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pRspTransfer->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pRspTransfer->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pRspTransfer->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pRspTransfer->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pRspTransfer->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pRspTransfer->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pRspTransfer->OperNo);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspTransfer->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspTransfer->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pRspTransfer->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pRspTransfer->LongCustomerName);
			RspTransfer = env->NewObject(jclazz, ctp_struct_methodIDs[287],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pRspTransfer->PlateSerial,pRspTransfer->LastFragment,pRspTransfer->SessionID,CustomerName,pRspTransfer->IdCardType,IdentifiedCardNo,pRspTransfer->CustType,BankAccount,BankPassWord,AccountID,Password,pRspTransfer->InstallID,pRspTransfer->FutureSerial,UserID,pRspTransfer->VerifyCertNoFlag,CurrencyID,pRspTransfer->TradeAmount,pRspTransfer->FutureFetchAmount,pRspTransfer->FeePayFlag,pRspTransfer->CustFee,pRspTransfer->BrokerFee,Message,Digest,pRspTransfer->BankAccType,DeviceID,pRspTransfer->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pRspTransfer->BankPwdFlag,pRspTransfer->SecuPwdFlag,OperNo,pRspTransfer->RequestID,pRspTransfer->TID,pRspTransfer->TransferStatus,pRspTransfer->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[103],RspTransfer);
	}

	void OnRtnFromFutureToBankByBank(CThostFtdcRspTransferField * pRspTransfer)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspTransferField;");
		jobject RspTransfer = env->AllocObject(jclazz);
		if(pRspTransfer)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pRspTransfer->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pRspTransfer->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pRspTransfer->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pRspTransfer->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pRspTransfer->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pRspTransfer->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspTransfer->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspTransfer->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pRspTransfer->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pRspTransfer->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pRspTransfer->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pRspTransfer->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pRspTransfer->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pRspTransfer->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pRspTransfer->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pRspTransfer->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pRspTransfer->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pRspTransfer->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pRspTransfer->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pRspTransfer->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pRspTransfer->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pRspTransfer->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pRspTransfer->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pRspTransfer->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pRspTransfer->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pRspTransfer->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pRspTransfer->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pRspTransfer->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspTransfer->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspTransfer->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pRspTransfer->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pRspTransfer->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pRspTransfer->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pRspTransfer->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pRspTransfer->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pRspTransfer->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pRspTransfer->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pRspTransfer->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pRspTransfer->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pRspTransfer->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pRspTransfer->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pRspTransfer->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pRspTransfer->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pRspTransfer->OperNo);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspTransfer->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspTransfer->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pRspTransfer->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pRspTransfer->LongCustomerName);
			RspTransfer = env->NewObject(jclazz, ctp_struct_methodIDs[287],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pRspTransfer->PlateSerial,pRspTransfer->LastFragment,pRspTransfer->SessionID,CustomerName,pRspTransfer->IdCardType,IdentifiedCardNo,pRspTransfer->CustType,BankAccount,BankPassWord,AccountID,Password,pRspTransfer->InstallID,pRspTransfer->FutureSerial,UserID,pRspTransfer->VerifyCertNoFlag,CurrencyID,pRspTransfer->TradeAmount,pRspTransfer->FutureFetchAmount,pRspTransfer->FeePayFlag,pRspTransfer->CustFee,pRspTransfer->BrokerFee,Message,Digest,pRspTransfer->BankAccType,DeviceID,pRspTransfer->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pRspTransfer->BankPwdFlag,pRspTransfer->SecuPwdFlag,OperNo,pRspTransfer->RequestID,pRspTransfer->TID,pRspTransfer->TransferStatus,pRspTransfer->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[104],RspTransfer);
	}

	void OnRtnRepealFromBankToFutureByBank(CThostFtdcRspRepealField * pRspRepeal)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspRepealField;");
		jobject RspRepeal = env->AllocObject(jclazz);
		if(pRspRepeal)
		{
			jbyteArray BankRepealSerial = env->NewByteArray(13);
			if(pRspRepeal->BankRepealSerial)
				env->SetByteArrayRegion(BankRepealSerial , 0, 13, (const jbyte*)pRspRepeal->BankRepealSerial);
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pRspRepeal->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pRspRepeal->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pRspRepeal->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pRspRepeal->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pRspRepeal->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pRspRepeal->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspRepeal->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspRepeal->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pRspRepeal->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pRspRepeal->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pRspRepeal->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pRspRepeal->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pRspRepeal->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pRspRepeal->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pRspRepeal->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pRspRepeal->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pRspRepeal->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pRspRepeal->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pRspRepeal->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pRspRepeal->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pRspRepeal->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pRspRepeal->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pRspRepeal->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pRspRepeal->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pRspRepeal->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pRspRepeal->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pRspRepeal->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pRspRepeal->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspRepeal->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspRepeal->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pRspRepeal->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pRspRepeal->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pRspRepeal->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pRspRepeal->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pRspRepeal->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pRspRepeal->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pRspRepeal->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pRspRepeal->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pRspRepeal->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pRspRepeal->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pRspRepeal->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pRspRepeal->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pRspRepeal->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pRspRepeal->OperNo);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspRepeal->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspRepeal->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pRspRepeal->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pRspRepeal->LongCustomerName);
			RspRepeal = env->NewObject(jclazz, ctp_struct_methodIDs[289],pRspRepeal->RepealTimeInterval,pRspRepeal->RepealedTimes,pRspRepeal->BankRepealFlag,pRspRepeal->BrokerRepealFlag,pRspRepeal->PlateRepealSerial,BankRepealSerial,pRspRepeal->FutureRepealSerial,TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pRspRepeal->PlateSerial,pRspRepeal->LastFragment,pRspRepeal->SessionID,CustomerName,pRspRepeal->IdCardType,IdentifiedCardNo,pRspRepeal->CustType,BankAccount,BankPassWord,AccountID,Password,pRspRepeal->InstallID,pRspRepeal->FutureSerial,UserID,pRspRepeal->VerifyCertNoFlag,CurrencyID,pRspRepeal->TradeAmount,pRspRepeal->FutureFetchAmount,pRspRepeal->FeePayFlag,pRspRepeal->CustFee,pRspRepeal->BrokerFee,Message,Digest,pRspRepeal->BankAccType,DeviceID,pRspRepeal->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pRspRepeal->BankPwdFlag,pRspRepeal->SecuPwdFlag,OperNo,pRspRepeal->RequestID,pRspRepeal->TID,pRspRepeal->TransferStatus,pRspRepeal->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[105],RspRepeal);
	}

	void OnRtnRepealFromFutureToBankByBank(CThostFtdcRspRepealField * pRspRepeal)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspRepealField;");
		jobject RspRepeal = env->AllocObject(jclazz);
		if(pRspRepeal)
		{
			jbyteArray BankRepealSerial = env->NewByteArray(13);
			if(pRspRepeal->BankRepealSerial)
				env->SetByteArrayRegion(BankRepealSerial , 0, 13, (const jbyte*)pRspRepeal->BankRepealSerial);
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pRspRepeal->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pRspRepeal->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pRspRepeal->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pRspRepeal->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pRspRepeal->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pRspRepeal->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspRepeal->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspRepeal->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pRspRepeal->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pRspRepeal->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pRspRepeal->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pRspRepeal->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pRspRepeal->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pRspRepeal->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pRspRepeal->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pRspRepeal->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pRspRepeal->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pRspRepeal->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pRspRepeal->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pRspRepeal->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pRspRepeal->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pRspRepeal->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pRspRepeal->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pRspRepeal->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pRspRepeal->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pRspRepeal->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pRspRepeal->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pRspRepeal->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspRepeal->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspRepeal->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pRspRepeal->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pRspRepeal->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pRspRepeal->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pRspRepeal->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pRspRepeal->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pRspRepeal->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pRspRepeal->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pRspRepeal->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pRspRepeal->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pRspRepeal->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pRspRepeal->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pRspRepeal->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pRspRepeal->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pRspRepeal->OperNo);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspRepeal->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspRepeal->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pRspRepeal->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pRspRepeal->LongCustomerName);
			RspRepeal = env->NewObject(jclazz, ctp_struct_methodIDs[289],pRspRepeal->RepealTimeInterval,pRspRepeal->RepealedTimes,pRspRepeal->BankRepealFlag,pRspRepeal->BrokerRepealFlag,pRspRepeal->PlateRepealSerial,BankRepealSerial,pRspRepeal->FutureRepealSerial,TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pRspRepeal->PlateSerial,pRspRepeal->LastFragment,pRspRepeal->SessionID,CustomerName,pRspRepeal->IdCardType,IdentifiedCardNo,pRspRepeal->CustType,BankAccount,BankPassWord,AccountID,Password,pRspRepeal->InstallID,pRspRepeal->FutureSerial,UserID,pRspRepeal->VerifyCertNoFlag,CurrencyID,pRspRepeal->TradeAmount,pRspRepeal->FutureFetchAmount,pRspRepeal->FeePayFlag,pRspRepeal->CustFee,pRspRepeal->BrokerFee,Message,Digest,pRspRepeal->BankAccType,DeviceID,pRspRepeal->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pRspRepeal->BankPwdFlag,pRspRepeal->SecuPwdFlag,OperNo,pRspRepeal->RequestID,pRspRepeal->TID,pRspRepeal->TransferStatus,pRspRepeal->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[106],RspRepeal);
	}

	void OnRtnFromBankToFutureByFuture(CThostFtdcRspTransferField * pRspTransfer)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspTransferField;");
		jobject RspTransfer = env->AllocObject(jclazz);
		if(pRspTransfer)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pRspTransfer->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pRspTransfer->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pRspTransfer->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pRspTransfer->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pRspTransfer->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pRspTransfer->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspTransfer->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspTransfer->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pRspTransfer->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pRspTransfer->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pRspTransfer->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pRspTransfer->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pRspTransfer->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pRspTransfer->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pRspTransfer->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pRspTransfer->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pRspTransfer->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pRspTransfer->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pRspTransfer->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pRspTransfer->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pRspTransfer->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pRspTransfer->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pRspTransfer->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pRspTransfer->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pRspTransfer->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pRspTransfer->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pRspTransfer->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pRspTransfer->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspTransfer->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspTransfer->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pRspTransfer->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pRspTransfer->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pRspTransfer->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pRspTransfer->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pRspTransfer->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pRspTransfer->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pRspTransfer->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pRspTransfer->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pRspTransfer->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pRspTransfer->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pRspTransfer->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pRspTransfer->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pRspTransfer->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pRspTransfer->OperNo);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspTransfer->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspTransfer->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pRspTransfer->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pRspTransfer->LongCustomerName);
			RspTransfer = env->NewObject(jclazz, ctp_struct_methodIDs[287],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pRspTransfer->PlateSerial,pRspTransfer->LastFragment,pRspTransfer->SessionID,CustomerName,pRspTransfer->IdCardType,IdentifiedCardNo,pRspTransfer->CustType,BankAccount,BankPassWord,AccountID,Password,pRspTransfer->InstallID,pRspTransfer->FutureSerial,UserID,pRspTransfer->VerifyCertNoFlag,CurrencyID,pRspTransfer->TradeAmount,pRspTransfer->FutureFetchAmount,pRspTransfer->FeePayFlag,pRspTransfer->CustFee,pRspTransfer->BrokerFee,Message,Digest,pRspTransfer->BankAccType,DeviceID,pRspTransfer->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pRspTransfer->BankPwdFlag,pRspTransfer->SecuPwdFlag,OperNo,pRspTransfer->RequestID,pRspTransfer->TID,pRspTransfer->TransferStatus,pRspTransfer->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[107],RspTransfer);
	}

	void OnRtnFromFutureToBankByFuture(CThostFtdcRspTransferField * pRspTransfer)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspTransferField;");
		jobject RspTransfer = env->AllocObject(jclazz);
		if(pRspTransfer)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pRspTransfer->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pRspTransfer->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pRspTransfer->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pRspTransfer->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pRspTransfer->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pRspTransfer->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspTransfer->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspTransfer->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pRspTransfer->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pRspTransfer->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pRspTransfer->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pRspTransfer->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pRspTransfer->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pRspTransfer->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pRspTransfer->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pRspTransfer->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pRspTransfer->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pRspTransfer->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pRspTransfer->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pRspTransfer->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pRspTransfer->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pRspTransfer->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pRspTransfer->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pRspTransfer->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pRspTransfer->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pRspTransfer->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pRspTransfer->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pRspTransfer->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspTransfer->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspTransfer->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pRspTransfer->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pRspTransfer->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pRspTransfer->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pRspTransfer->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pRspTransfer->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pRspTransfer->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pRspTransfer->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pRspTransfer->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pRspTransfer->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pRspTransfer->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pRspTransfer->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pRspTransfer->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pRspTransfer->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pRspTransfer->OperNo);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspTransfer->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspTransfer->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pRspTransfer->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pRspTransfer->LongCustomerName);
			RspTransfer = env->NewObject(jclazz, ctp_struct_methodIDs[287],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pRspTransfer->PlateSerial,pRspTransfer->LastFragment,pRspTransfer->SessionID,CustomerName,pRspTransfer->IdCardType,IdentifiedCardNo,pRspTransfer->CustType,BankAccount,BankPassWord,AccountID,Password,pRspTransfer->InstallID,pRspTransfer->FutureSerial,UserID,pRspTransfer->VerifyCertNoFlag,CurrencyID,pRspTransfer->TradeAmount,pRspTransfer->FutureFetchAmount,pRspTransfer->FeePayFlag,pRspTransfer->CustFee,pRspTransfer->BrokerFee,Message,Digest,pRspTransfer->BankAccType,DeviceID,pRspTransfer->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pRspTransfer->BankPwdFlag,pRspTransfer->SecuPwdFlag,OperNo,pRspTransfer->RequestID,pRspTransfer->TID,pRspTransfer->TransferStatus,pRspTransfer->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[108],RspTransfer);
	}

	void OnRtnRepealFromBankToFutureByFutureManual(CThostFtdcRspRepealField * pRspRepeal)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspRepealField;");
		jobject RspRepeal = env->AllocObject(jclazz);
		if(pRspRepeal)
		{
			jbyteArray BankRepealSerial = env->NewByteArray(13);
			if(pRspRepeal->BankRepealSerial)
				env->SetByteArrayRegion(BankRepealSerial , 0, 13, (const jbyte*)pRspRepeal->BankRepealSerial);
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pRspRepeal->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pRspRepeal->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pRspRepeal->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pRspRepeal->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pRspRepeal->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pRspRepeal->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspRepeal->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspRepeal->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pRspRepeal->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pRspRepeal->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pRspRepeal->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pRspRepeal->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pRspRepeal->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pRspRepeal->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pRspRepeal->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pRspRepeal->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pRspRepeal->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pRspRepeal->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pRspRepeal->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pRspRepeal->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pRspRepeal->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pRspRepeal->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pRspRepeal->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pRspRepeal->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pRspRepeal->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pRspRepeal->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pRspRepeal->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pRspRepeal->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspRepeal->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspRepeal->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pRspRepeal->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pRspRepeal->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pRspRepeal->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pRspRepeal->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pRspRepeal->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pRspRepeal->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pRspRepeal->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pRspRepeal->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pRspRepeal->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pRspRepeal->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pRspRepeal->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pRspRepeal->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pRspRepeal->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pRspRepeal->OperNo);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspRepeal->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspRepeal->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pRspRepeal->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pRspRepeal->LongCustomerName);
			RspRepeal = env->NewObject(jclazz, ctp_struct_methodIDs[289],pRspRepeal->RepealTimeInterval,pRspRepeal->RepealedTimes,pRspRepeal->BankRepealFlag,pRspRepeal->BrokerRepealFlag,pRspRepeal->PlateRepealSerial,BankRepealSerial,pRspRepeal->FutureRepealSerial,TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pRspRepeal->PlateSerial,pRspRepeal->LastFragment,pRspRepeal->SessionID,CustomerName,pRspRepeal->IdCardType,IdentifiedCardNo,pRspRepeal->CustType,BankAccount,BankPassWord,AccountID,Password,pRspRepeal->InstallID,pRspRepeal->FutureSerial,UserID,pRspRepeal->VerifyCertNoFlag,CurrencyID,pRspRepeal->TradeAmount,pRspRepeal->FutureFetchAmount,pRspRepeal->FeePayFlag,pRspRepeal->CustFee,pRspRepeal->BrokerFee,Message,Digest,pRspRepeal->BankAccType,DeviceID,pRspRepeal->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pRspRepeal->BankPwdFlag,pRspRepeal->SecuPwdFlag,OperNo,pRspRepeal->RequestID,pRspRepeal->TID,pRspRepeal->TransferStatus,pRspRepeal->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[109],RspRepeal);
	}

	void OnRtnRepealFromFutureToBankByFutureManual(CThostFtdcRspRepealField * pRspRepeal)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspRepealField;");
		jobject RspRepeal = env->AllocObject(jclazz);
		if(pRspRepeal)
		{
			jbyteArray BankRepealSerial = env->NewByteArray(13);
			if(pRspRepeal->BankRepealSerial)
				env->SetByteArrayRegion(BankRepealSerial , 0, 13, (const jbyte*)pRspRepeal->BankRepealSerial);
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pRspRepeal->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pRspRepeal->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pRspRepeal->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pRspRepeal->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pRspRepeal->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pRspRepeal->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspRepeal->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspRepeal->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pRspRepeal->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pRspRepeal->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pRspRepeal->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pRspRepeal->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pRspRepeal->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pRspRepeal->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pRspRepeal->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pRspRepeal->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pRspRepeal->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pRspRepeal->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pRspRepeal->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pRspRepeal->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pRspRepeal->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pRspRepeal->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pRspRepeal->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pRspRepeal->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pRspRepeal->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pRspRepeal->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pRspRepeal->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pRspRepeal->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspRepeal->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspRepeal->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pRspRepeal->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pRspRepeal->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pRspRepeal->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pRspRepeal->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pRspRepeal->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pRspRepeal->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pRspRepeal->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pRspRepeal->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pRspRepeal->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pRspRepeal->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pRspRepeal->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pRspRepeal->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pRspRepeal->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pRspRepeal->OperNo);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspRepeal->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspRepeal->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pRspRepeal->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pRspRepeal->LongCustomerName);
			RspRepeal = env->NewObject(jclazz, ctp_struct_methodIDs[289],pRspRepeal->RepealTimeInterval,pRspRepeal->RepealedTimes,pRspRepeal->BankRepealFlag,pRspRepeal->BrokerRepealFlag,pRspRepeal->PlateRepealSerial,BankRepealSerial,pRspRepeal->FutureRepealSerial,TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pRspRepeal->PlateSerial,pRspRepeal->LastFragment,pRspRepeal->SessionID,CustomerName,pRspRepeal->IdCardType,IdentifiedCardNo,pRspRepeal->CustType,BankAccount,BankPassWord,AccountID,Password,pRspRepeal->InstallID,pRspRepeal->FutureSerial,UserID,pRspRepeal->VerifyCertNoFlag,CurrencyID,pRspRepeal->TradeAmount,pRspRepeal->FutureFetchAmount,pRspRepeal->FeePayFlag,pRspRepeal->CustFee,pRspRepeal->BrokerFee,Message,Digest,pRspRepeal->BankAccType,DeviceID,pRspRepeal->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pRspRepeal->BankPwdFlag,pRspRepeal->SecuPwdFlag,OperNo,pRspRepeal->RequestID,pRspRepeal->TID,pRspRepeal->TransferStatus,pRspRepeal->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[110],RspRepeal);
	}

	void OnRtnQueryBankBalanceByFuture(CThostFtdcNotifyQueryAccountField * pNotifyQueryAccount)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcNotifyQueryAccountField;");
		jobject NotifyQueryAccount = env->AllocObject(jclazz);
		if(pNotifyQueryAccount)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pNotifyQueryAccount->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pNotifyQueryAccount->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pNotifyQueryAccount->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pNotifyQueryAccount->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pNotifyQueryAccount->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pNotifyQueryAccount->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pNotifyQueryAccount->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pNotifyQueryAccount->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pNotifyQueryAccount->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pNotifyQueryAccount->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pNotifyQueryAccount->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pNotifyQueryAccount->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pNotifyQueryAccount->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pNotifyQueryAccount->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pNotifyQueryAccount->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pNotifyQueryAccount->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pNotifyQueryAccount->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pNotifyQueryAccount->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pNotifyQueryAccount->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pNotifyQueryAccount->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pNotifyQueryAccount->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pNotifyQueryAccount->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pNotifyQueryAccount->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pNotifyQueryAccount->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pNotifyQueryAccount->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pNotifyQueryAccount->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pNotifyQueryAccount->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pNotifyQueryAccount->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pNotifyQueryAccount->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pNotifyQueryAccount->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pNotifyQueryAccount->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pNotifyQueryAccount->CurrencyID);
			jbyteArray Digest = env->NewByteArray(36);
			if(pNotifyQueryAccount->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pNotifyQueryAccount->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pNotifyQueryAccount->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pNotifyQueryAccount->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pNotifyQueryAccount->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pNotifyQueryAccount->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pNotifyQueryAccount->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pNotifyQueryAccount->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pNotifyQueryAccount->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pNotifyQueryAccount->OperNo);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pNotifyQueryAccount->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pNotifyQueryAccount->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pNotifyQueryAccount->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pNotifyQueryAccount->LongCustomerName);
			NotifyQueryAccount = env->NewObject(jclazz, ctp_struct_methodIDs[306],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pNotifyQueryAccount->PlateSerial,pNotifyQueryAccount->LastFragment,pNotifyQueryAccount->SessionID,CustomerName,pNotifyQueryAccount->IdCardType,IdentifiedCardNo,pNotifyQueryAccount->CustType,BankAccount,BankPassWord,AccountID,Password,pNotifyQueryAccount->FutureSerial,pNotifyQueryAccount->InstallID,UserID,pNotifyQueryAccount->VerifyCertNoFlag,CurrencyID,Digest,pNotifyQueryAccount->BankAccType,DeviceID,pNotifyQueryAccount->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pNotifyQueryAccount->BankPwdFlag,pNotifyQueryAccount->SecuPwdFlag,OperNo,pNotifyQueryAccount->RequestID,pNotifyQueryAccount->TID,pNotifyQueryAccount->BankUseAmount,pNotifyQueryAccount->BankFetchAmount,pNotifyQueryAccount->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[111],NotifyQueryAccount);
	}

	void OnErrRtnBankToFutureByFuture(CThostFtdcReqTransferField * pReqTransfer,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcReqTransferField;");
		jobject ReqTransfer = env->AllocObject(jclazz);
		if(pReqTransfer)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pReqTransfer->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pReqTransfer->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pReqTransfer->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pReqTransfer->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pReqTransfer->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pReqTransfer->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pReqTransfer->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pReqTransfer->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pReqTransfer->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pReqTransfer->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pReqTransfer->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pReqTransfer->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pReqTransfer->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pReqTransfer->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pReqTransfer->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pReqTransfer->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pReqTransfer->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pReqTransfer->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pReqTransfer->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pReqTransfer->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pReqTransfer->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pReqTransfer->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pReqTransfer->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pReqTransfer->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pReqTransfer->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pReqTransfer->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pReqTransfer->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pReqTransfer->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pReqTransfer->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pReqTransfer->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pReqTransfer->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pReqTransfer->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pReqTransfer->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pReqTransfer->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pReqTransfer->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pReqTransfer->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pReqTransfer->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pReqTransfer->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pReqTransfer->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pReqTransfer->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pReqTransfer->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pReqTransfer->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pReqTransfer->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pReqTransfer->OperNo);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pReqTransfer->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pReqTransfer->LongCustomerName);
			ReqTransfer = env->NewObject(jclazz, ctp_struct_methodIDs[286],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pReqTransfer->PlateSerial,pReqTransfer->LastFragment,pReqTransfer->SessionID,CustomerName,pReqTransfer->IdCardType,IdentifiedCardNo,pReqTransfer->CustType,BankAccount,BankPassWord,AccountID,Password,pReqTransfer->InstallID,pReqTransfer->FutureSerial,UserID,pReqTransfer->VerifyCertNoFlag,CurrencyID,pReqTransfer->TradeAmount,pReqTransfer->FutureFetchAmount,pReqTransfer->FeePayFlag,pReqTransfer->CustFee,pReqTransfer->BrokerFee,Message,Digest,pReqTransfer->BankAccType,DeviceID,pReqTransfer->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pReqTransfer->BankPwdFlag,pReqTransfer->SecuPwdFlag,OperNo,pReqTransfer->RequestID,pReqTransfer->TID,pReqTransfer->TransferStatus,LongCustomerName);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[112],ReqTransfer, RspInfo);
	}

	void OnErrRtnFutureToBankByFuture(CThostFtdcReqTransferField * pReqTransfer,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcReqTransferField;");
		jobject ReqTransfer = env->AllocObject(jclazz);
		if(pReqTransfer)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pReqTransfer->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pReqTransfer->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pReqTransfer->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pReqTransfer->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pReqTransfer->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pReqTransfer->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pReqTransfer->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pReqTransfer->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pReqTransfer->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pReqTransfer->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pReqTransfer->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pReqTransfer->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pReqTransfer->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pReqTransfer->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pReqTransfer->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pReqTransfer->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pReqTransfer->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pReqTransfer->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pReqTransfer->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pReqTransfer->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pReqTransfer->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pReqTransfer->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pReqTransfer->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pReqTransfer->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pReqTransfer->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pReqTransfer->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pReqTransfer->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pReqTransfer->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pReqTransfer->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pReqTransfer->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pReqTransfer->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pReqTransfer->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pReqTransfer->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pReqTransfer->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pReqTransfer->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pReqTransfer->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pReqTransfer->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pReqTransfer->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pReqTransfer->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pReqTransfer->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pReqTransfer->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pReqTransfer->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pReqTransfer->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pReqTransfer->OperNo);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pReqTransfer->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pReqTransfer->LongCustomerName);
			ReqTransfer = env->NewObject(jclazz, ctp_struct_methodIDs[286],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pReqTransfer->PlateSerial,pReqTransfer->LastFragment,pReqTransfer->SessionID,CustomerName,pReqTransfer->IdCardType,IdentifiedCardNo,pReqTransfer->CustType,BankAccount,BankPassWord,AccountID,Password,pReqTransfer->InstallID,pReqTransfer->FutureSerial,UserID,pReqTransfer->VerifyCertNoFlag,CurrencyID,pReqTransfer->TradeAmount,pReqTransfer->FutureFetchAmount,pReqTransfer->FeePayFlag,pReqTransfer->CustFee,pReqTransfer->BrokerFee,Message,Digest,pReqTransfer->BankAccType,DeviceID,pReqTransfer->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pReqTransfer->BankPwdFlag,pReqTransfer->SecuPwdFlag,OperNo,pReqTransfer->RequestID,pReqTransfer->TID,pReqTransfer->TransferStatus,LongCustomerName);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[113],ReqTransfer, RspInfo);
	}

	void OnErrRtnRepealBankToFutureByFutureManual(CThostFtdcReqRepealField * pReqRepeal,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcReqRepealField;");
		jobject ReqRepeal = env->AllocObject(jclazz);
		if(pReqRepeal)
		{
			jbyteArray BankRepealSerial = env->NewByteArray(13);
			if(pReqRepeal->BankRepealSerial)
				env->SetByteArrayRegion(BankRepealSerial , 0, 13, (const jbyte*)pReqRepeal->BankRepealSerial);
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pReqRepeal->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pReqRepeal->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pReqRepeal->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pReqRepeal->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pReqRepeal->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pReqRepeal->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pReqRepeal->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pReqRepeal->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pReqRepeal->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pReqRepeal->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pReqRepeal->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pReqRepeal->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pReqRepeal->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pReqRepeal->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pReqRepeal->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pReqRepeal->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pReqRepeal->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pReqRepeal->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pReqRepeal->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pReqRepeal->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pReqRepeal->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pReqRepeal->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pReqRepeal->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pReqRepeal->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pReqRepeal->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pReqRepeal->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pReqRepeal->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pReqRepeal->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pReqRepeal->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pReqRepeal->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pReqRepeal->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pReqRepeal->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pReqRepeal->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pReqRepeal->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pReqRepeal->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pReqRepeal->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pReqRepeal->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pReqRepeal->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pReqRepeal->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pReqRepeal->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pReqRepeal->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pReqRepeal->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pReqRepeal->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pReqRepeal->OperNo);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pReqRepeal->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pReqRepeal->LongCustomerName);
			ReqRepeal = env->NewObject(jclazz, ctp_struct_methodIDs[288],pReqRepeal->RepealTimeInterval,pReqRepeal->RepealedTimes,pReqRepeal->BankRepealFlag,pReqRepeal->BrokerRepealFlag,pReqRepeal->PlateRepealSerial,BankRepealSerial,pReqRepeal->FutureRepealSerial,TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pReqRepeal->PlateSerial,pReqRepeal->LastFragment,pReqRepeal->SessionID,CustomerName,pReqRepeal->IdCardType,IdentifiedCardNo,pReqRepeal->CustType,BankAccount,BankPassWord,AccountID,Password,pReqRepeal->InstallID,pReqRepeal->FutureSerial,UserID,pReqRepeal->VerifyCertNoFlag,CurrencyID,pReqRepeal->TradeAmount,pReqRepeal->FutureFetchAmount,pReqRepeal->FeePayFlag,pReqRepeal->CustFee,pReqRepeal->BrokerFee,Message,Digest,pReqRepeal->BankAccType,DeviceID,pReqRepeal->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pReqRepeal->BankPwdFlag,pReqRepeal->SecuPwdFlag,OperNo,pReqRepeal->RequestID,pReqRepeal->TID,pReqRepeal->TransferStatus,LongCustomerName);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[114],ReqRepeal, RspInfo);
	}

	void OnErrRtnRepealFutureToBankByFutureManual(CThostFtdcReqRepealField * pReqRepeal,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcReqRepealField;");
		jobject ReqRepeal = env->AllocObject(jclazz);
		if(pReqRepeal)
		{
			jbyteArray BankRepealSerial = env->NewByteArray(13);
			if(pReqRepeal->BankRepealSerial)
				env->SetByteArrayRegion(BankRepealSerial , 0, 13, (const jbyte*)pReqRepeal->BankRepealSerial);
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pReqRepeal->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pReqRepeal->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pReqRepeal->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pReqRepeal->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pReqRepeal->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pReqRepeal->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pReqRepeal->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pReqRepeal->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pReqRepeal->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pReqRepeal->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pReqRepeal->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pReqRepeal->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pReqRepeal->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pReqRepeal->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pReqRepeal->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pReqRepeal->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pReqRepeal->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pReqRepeal->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pReqRepeal->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pReqRepeal->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pReqRepeal->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pReqRepeal->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pReqRepeal->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pReqRepeal->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pReqRepeal->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pReqRepeal->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pReqRepeal->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pReqRepeal->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pReqRepeal->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pReqRepeal->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pReqRepeal->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pReqRepeal->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pReqRepeal->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pReqRepeal->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pReqRepeal->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pReqRepeal->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pReqRepeal->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pReqRepeal->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pReqRepeal->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pReqRepeal->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pReqRepeal->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pReqRepeal->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pReqRepeal->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pReqRepeal->OperNo);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pReqRepeal->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pReqRepeal->LongCustomerName);
			ReqRepeal = env->NewObject(jclazz, ctp_struct_methodIDs[288],pReqRepeal->RepealTimeInterval,pReqRepeal->RepealedTimes,pReqRepeal->BankRepealFlag,pReqRepeal->BrokerRepealFlag,pReqRepeal->PlateRepealSerial,BankRepealSerial,pReqRepeal->FutureRepealSerial,TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pReqRepeal->PlateSerial,pReqRepeal->LastFragment,pReqRepeal->SessionID,CustomerName,pReqRepeal->IdCardType,IdentifiedCardNo,pReqRepeal->CustType,BankAccount,BankPassWord,AccountID,Password,pReqRepeal->InstallID,pReqRepeal->FutureSerial,UserID,pReqRepeal->VerifyCertNoFlag,CurrencyID,pReqRepeal->TradeAmount,pReqRepeal->FutureFetchAmount,pReqRepeal->FeePayFlag,pReqRepeal->CustFee,pReqRepeal->BrokerFee,Message,Digest,pReqRepeal->BankAccType,DeviceID,pReqRepeal->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pReqRepeal->BankPwdFlag,pReqRepeal->SecuPwdFlag,OperNo,pReqRepeal->RequestID,pReqRepeal->TID,pReqRepeal->TransferStatus,LongCustomerName);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[115],ReqRepeal, RspInfo);
	}

	void OnErrRtnQueryBankBalanceByFuture(CThostFtdcReqQueryAccountField * pReqQueryAccount,  CThostFtdcRspInfoField * pRspInfo)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcReqQueryAccountField;");
		jobject ReqQueryAccount = env->AllocObject(jclazz);
		if(pReqQueryAccount)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pReqQueryAccount->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pReqQueryAccount->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pReqQueryAccount->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pReqQueryAccount->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pReqQueryAccount->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pReqQueryAccount->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pReqQueryAccount->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pReqQueryAccount->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pReqQueryAccount->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pReqQueryAccount->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pReqQueryAccount->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pReqQueryAccount->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pReqQueryAccount->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pReqQueryAccount->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pReqQueryAccount->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pReqQueryAccount->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pReqQueryAccount->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pReqQueryAccount->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pReqQueryAccount->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pReqQueryAccount->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pReqQueryAccount->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pReqQueryAccount->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pReqQueryAccount->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pReqQueryAccount->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pReqQueryAccount->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pReqQueryAccount->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pReqQueryAccount->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pReqQueryAccount->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pReqQueryAccount->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pReqQueryAccount->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pReqQueryAccount->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pReqQueryAccount->CurrencyID);
			jbyteArray Digest = env->NewByteArray(36);
			if(pReqQueryAccount->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pReqQueryAccount->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pReqQueryAccount->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pReqQueryAccount->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pReqQueryAccount->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pReqQueryAccount->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pReqQueryAccount->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pReqQueryAccount->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pReqQueryAccount->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pReqQueryAccount->OperNo);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pReqQueryAccount->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pReqQueryAccount->LongCustomerName);
			ReqQueryAccount = env->NewObject(jclazz, ctp_struct_methodIDs[290],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pReqQueryAccount->PlateSerial,pReqQueryAccount->LastFragment,pReqQueryAccount->SessionID,CustomerName,pReqQueryAccount->IdCardType,IdentifiedCardNo,pReqQueryAccount->CustType,BankAccount,BankPassWord,AccountID,Password,pReqQueryAccount->FutureSerial,pReqQueryAccount->InstallID,UserID,pReqQueryAccount->VerifyCertNoFlag,CurrencyID,Digest,pReqQueryAccount->BankAccType,DeviceID,pReqQueryAccount->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pReqQueryAccount->BankPwdFlag,pReqQueryAccount->SecuPwdFlag,OperNo,pReqQueryAccount->RequestID,pReqQueryAccount->TID,LongCustomerName);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[116],ReqQueryAccount, RspInfo);
	}

	void OnRtnRepealFromBankToFutureByFuture(CThostFtdcRspRepealField * pRspRepeal)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspRepealField;");
		jobject RspRepeal = env->AllocObject(jclazz);
		if(pRspRepeal)
		{
			jbyteArray BankRepealSerial = env->NewByteArray(13);
			if(pRspRepeal->BankRepealSerial)
				env->SetByteArrayRegion(BankRepealSerial , 0, 13, (const jbyte*)pRspRepeal->BankRepealSerial);
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pRspRepeal->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pRspRepeal->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pRspRepeal->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pRspRepeal->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pRspRepeal->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pRspRepeal->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspRepeal->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspRepeal->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pRspRepeal->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pRspRepeal->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pRspRepeal->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pRspRepeal->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pRspRepeal->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pRspRepeal->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pRspRepeal->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pRspRepeal->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pRspRepeal->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pRspRepeal->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pRspRepeal->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pRspRepeal->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pRspRepeal->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pRspRepeal->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pRspRepeal->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pRspRepeal->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pRspRepeal->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pRspRepeal->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pRspRepeal->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pRspRepeal->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspRepeal->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspRepeal->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pRspRepeal->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pRspRepeal->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pRspRepeal->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pRspRepeal->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pRspRepeal->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pRspRepeal->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pRspRepeal->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pRspRepeal->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pRspRepeal->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pRspRepeal->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pRspRepeal->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pRspRepeal->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pRspRepeal->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pRspRepeal->OperNo);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspRepeal->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspRepeal->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pRspRepeal->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pRspRepeal->LongCustomerName);
			RspRepeal = env->NewObject(jclazz, ctp_struct_methodIDs[289],pRspRepeal->RepealTimeInterval,pRspRepeal->RepealedTimes,pRspRepeal->BankRepealFlag,pRspRepeal->BrokerRepealFlag,pRspRepeal->PlateRepealSerial,BankRepealSerial,pRspRepeal->FutureRepealSerial,TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pRspRepeal->PlateSerial,pRspRepeal->LastFragment,pRspRepeal->SessionID,CustomerName,pRspRepeal->IdCardType,IdentifiedCardNo,pRspRepeal->CustType,BankAccount,BankPassWord,AccountID,Password,pRspRepeal->InstallID,pRspRepeal->FutureSerial,UserID,pRspRepeal->VerifyCertNoFlag,CurrencyID,pRspRepeal->TradeAmount,pRspRepeal->FutureFetchAmount,pRspRepeal->FeePayFlag,pRspRepeal->CustFee,pRspRepeal->BrokerFee,Message,Digest,pRspRepeal->BankAccType,DeviceID,pRspRepeal->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pRspRepeal->BankPwdFlag,pRspRepeal->SecuPwdFlag,OperNo,pRspRepeal->RequestID,pRspRepeal->TID,pRspRepeal->TransferStatus,pRspRepeal->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[117],RspRepeal);
	}

	void OnRtnRepealFromFutureToBankByFuture(CThostFtdcRspRepealField * pRspRepeal)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspRepealField;");
		jobject RspRepeal = env->AllocObject(jclazz);
		if(pRspRepeal)
		{
			jbyteArray BankRepealSerial = env->NewByteArray(13);
			if(pRspRepeal->BankRepealSerial)
				env->SetByteArrayRegion(BankRepealSerial , 0, 13, (const jbyte*)pRspRepeal->BankRepealSerial);
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pRspRepeal->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pRspRepeal->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pRspRepeal->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pRspRepeal->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pRspRepeal->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pRspRepeal->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspRepeal->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspRepeal->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pRspRepeal->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pRspRepeal->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pRspRepeal->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pRspRepeal->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pRspRepeal->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pRspRepeal->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pRspRepeal->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pRspRepeal->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pRspRepeal->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pRspRepeal->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pRspRepeal->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pRspRepeal->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pRspRepeal->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pRspRepeal->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pRspRepeal->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pRspRepeal->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pRspRepeal->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pRspRepeal->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pRspRepeal->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pRspRepeal->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspRepeal->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspRepeal->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pRspRepeal->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pRspRepeal->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pRspRepeal->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pRspRepeal->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pRspRepeal->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pRspRepeal->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pRspRepeal->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pRspRepeal->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pRspRepeal->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pRspRepeal->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pRspRepeal->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pRspRepeal->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pRspRepeal->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pRspRepeal->OperNo);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspRepeal->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspRepeal->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pRspRepeal->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pRspRepeal->LongCustomerName);
			RspRepeal = env->NewObject(jclazz, ctp_struct_methodIDs[289],pRspRepeal->RepealTimeInterval,pRspRepeal->RepealedTimes,pRspRepeal->BankRepealFlag,pRspRepeal->BrokerRepealFlag,pRspRepeal->PlateRepealSerial,BankRepealSerial,pRspRepeal->FutureRepealSerial,TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pRspRepeal->PlateSerial,pRspRepeal->LastFragment,pRspRepeal->SessionID,CustomerName,pRspRepeal->IdCardType,IdentifiedCardNo,pRspRepeal->CustType,BankAccount,BankPassWord,AccountID,Password,pRspRepeal->InstallID,pRspRepeal->FutureSerial,UserID,pRspRepeal->VerifyCertNoFlag,CurrencyID,pRspRepeal->TradeAmount,pRspRepeal->FutureFetchAmount,pRspRepeal->FeePayFlag,pRspRepeal->CustFee,pRspRepeal->BrokerFee,Message,Digest,pRspRepeal->BankAccType,DeviceID,pRspRepeal->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pRspRepeal->BankPwdFlag,pRspRepeal->SecuPwdFlag,OperNo,pRspRepeal->RequestID,pRspRepeal->TID,pRspRepeal->TransferStatus,pRspRepeal->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[118],RspRepeal);
	}

	void OnRspFromBankToFutureByFuture(CThostFtdcReqTransferField * pReqTransfer,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcReqTransferField;");
		jobject ReqTransfer = env->AllocObject(jclazz);
		if(pReqTransfer)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pReqTransfer->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pReqTransfer->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pReqTransfer->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pReqTransfer->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pReqTransfer->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pReqTransfer->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pReqTransfer->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pReqTransfer->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pReqTransfer->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pReqTransfer->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pReqTransfer->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pReqTransfer->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pReqTransfer->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pReqTransfer->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pReqTransfer->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pReqTransfer->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pReqTransfer->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pReqTransfer->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pReqTransfer->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pReqTransfer->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pReqTransfer->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pReqTransfer->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pReqTransfer->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pReqTransfer->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pReqTransfer->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pReqTransfer->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pReqTransfer->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pReqTransfer->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pReqTransfer->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pReqTransfer->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pReqTransfer->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pReqTransfer->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pReqTransfer->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pReqTransfer->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pReqTransfer->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pReqTransfer->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pReqTransfer->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pReqTransfer->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pReqTransfer->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pReqTransfer->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pReqTransfer->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pReqTransfer->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pReqTransfer->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pReqTransfer->OperNo);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pReqTransfer->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pReqTransfer->LongCustomerName);
			ReqTransfer = env->NewObject(jclazz, ctp_struct_methodIDs[286],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pReqTransfer->PlateSerial,pReqTransfer->LastFragment,pReqTransfer->SessionID,CustomerName,pReqTransfer->IdCardType,IdentifiedCardNo,pReqTransfer->CustType,BankAccount,BankPassWord,AccountID,Password,pReqTransfer->InstallID,pReqTransfer->FutureSerial,UserID,pReqTransfer->VerifyCertNoFlag,CurrencyID,pReqTransfer->TradeAmount,pReqTransfer->FutureFetchAmount,pReqTransfer->FeePayFlag,pReqTransfer->CustFee,pReqTransfer->BrokerFee,Message,Digest,pReqTransfer->BankAccType,DeviceID,pReqTransfer->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pReqTransfer->BankPwdFlag,pReqTransfer->SecuPwdFlag,OperNo,pReqTransfer->RequestID,pReqTransfer->TID,pReqTransfer->TransferStatus,LongCustomerName);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[119],ReqTransfer, RspInfo, nRequestID, bIsLast);
	}

	void OnRspFromFutureToBankByFuture(CThostFtdcReqTransferField * pReqTransfer,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcReqTransferField;");
		jobject ReqTransfer = env->AllocObject(jclazz);
		if(pReqTransfer)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pReqTransfer->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pReqTransfer->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pReqTransfer->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pReqTransfer->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pReqTransfer->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pReqTransfer->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pReqTransfer->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pReqTransfer->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pReqTransfer->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pReqTransfer->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pReqTransfer->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pReqTransfer->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pReqTransfer->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pReqTransfer->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pReqTransfer->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pReqTransfer->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pReqTransfer->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pReqTransfer->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pReqTransfer->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pReqTransfer->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pReqTransfer->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pReqTransfer->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pReqTransfer->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pReqTransfer->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pReqTransfer->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pReqTransfer->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pReqTransfer->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pReqTransfer->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pReqTransfer->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pReqTransfer->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pReqTransfer->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pReqTransfer->CurrencyID);
			jbyteArray Message = env->NewByteArray(129);
			if(pReqTransfer->Message)
				env->SetByteArrayRegion(Message , 0, 129, (const jbyte*)pReqTransfer->Message);
			jbyteArray Digest = env->NewByteArray(36);
			if(pReqTransfer->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pReqTransfer->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pReqTransfer->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pReqTransfer->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pReqTransfer->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pReqTransfer->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pReqTransfer->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pReqTransfer->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pReqTransfer->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pReqTransfer->OperNo);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pReqTransfer->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pReqTransfer->LongCustomerName);
			ReqTransfer = env->NewObject(jclazz, ctp_struct_methodIDs[286],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pReqTransfer->PlateSerial,pReqTransfer->LastFragment,pReqTransfer->SessionID,CustomerName,pReqTransfer->IdCardType,IdentifiedCardNo,pReqTransfer->CustType,BankAccount,BankPassWord,AccountID,Password,pReqTransfer->InstallID,pReqTransfer->FutureSerial,UserID,pReqTransfer->VerifyCertNoFlag,CurrencyID,pReqTransfer->TradeAmount,pReqTransfer->FutureFetchAmount,pReqTransfer->FeePayFlag,pReqTransfer->CustFee,pReqTransfer->BrokerFee,Message,Digest,pReqTransfer->BankAccType,DeviceID,pReqTransfer->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pReqTransfer->BankPwdFlag,pReqTransfer->SecuPwdFlag,OperNo,pReqTransfer->RequestID,pReqTransfer->TID,pReqTransfer->TransferStatus,LongCustomerName);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[120],ReqTransfer, RspInfo, nRequestID, bIsLast);
	}

	void OnRspQueryBankAccountMoneyByFuture(CThostFtdcReqQueryAccountField * pReqQueryAccount,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcReqQueryAccountField;");
		jobject ReqQueryAccount = env->AllocObject(jclazz);
		if(pReqQueryAccount)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pReqQueryAccount->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pReqQueryAccount->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pReqQueryAccount->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pReqQueryAccount->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pReqQueryAccount->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pReqQueryAccount->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pReqQueryAccount->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pReqQueryAccount->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pReqQueryAccount->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pReqQueryAccount->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pReqQueryAccount->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pReqQueryAccount->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pReqQueryAccount->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pReqQueryAccount->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pReqQueryAccount->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pReqQueryAccount->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pReqQueryAccount->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pReqQueryAccount->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pReqQueryAccount->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pReqQueryAccount->IdentifiedCardNo);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pReqQueryAccount->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pReqQueryAccount->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pReqQueryAccount->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pReqQueryAccount->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pReqQueryAccount->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pReqQueryAccount->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pReqQueryAccount->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pReqQueryAccount->Password);
			jbyteArray UserID = env->NewByteArray(16);
			if(pReqQueryAccount->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pReqQueryAccount->UserID);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pReqQueryAccount->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pReqQueryAccount->CurrencyID);
			jbyteArray Digest = env->NewByteArray(36);
			if(pReqQueryAccount->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pReqQueryAccount->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pReqQueryAccount->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pReqQueryAccount->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pReqQueryAccount->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pReqQueryAccount->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pReqQueryAccount->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pReqQueryAccount->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pReqQueryAccount->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pReqQueryAccount->OperNo);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pReqQueryAccount->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pReqQueryAccount->LongCustomerName);
			ReqQueryAccount = env->NewObject(jclazz, ctp_struct_methodIDs[290],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pReqQueryAccount->PlateSerial,pReqQueryAccount->LastFragment,pReqQueryAccount->SessionID,CustomerName,pReqQueryAccount->IdCardType,IdentifiedCardNo,pReqQueryAccount->CustType,BankAccount,BankPassWord,AccountID,Password,pReqQueryAccount->FutureSerial,pReqQueryAccount->InstallID,UserID,pReqQueryAccount->VerifyCertNoFlag,CurrencyID,Digest,pReqQueryAccount->BankAccType,DeviceID,pReqQueryAccount->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pReqQueryAccount->BankPwdFlag,pReqQueryAccount->SecuPwdFlag,OperNo,pReqQueryAccount->RequestID,pReqQueryAccount->TID,LongCustomerName);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[121],ReqQueryAccount, RspInfo, nRequestID, bIsLast);
	}

	void OnRtnOpenAccountByBank(CThostFtdcOpenAccountField * pOpenAccount)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcOpenAccountField;");
		jobject OpenAccount = env->AllocObject(jclazz);
		if(pOpenAccount)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pOpenAccount->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pOpenAccount->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pOpenAccount->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pOpenAccount->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pOpenAccount->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pOpenAccount->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pOpenAccount->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pOpenAccount->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pOpenAccount->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pOpenAccount->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pOpenAccount->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pOpenAccount->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pOpenAccount->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pOpenAccount->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pOpenAccount->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pOpenAccount->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pOpenAccount->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pOpenAccount->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pOpenAccount->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pOpenAccount->IdentifiedCardNo);
			jbyteArray CountryCode = env->NewByteArray(21);
			if(pOpenAccount->CountryCode)
				env->SetByteArrayRegion(CountryCode , 0, 21, (const jbyte*)pOpenAccount->CountryCode);
			jbyteArray Address = env->NewByteArray(101);
			if(pOpenAccount->Address)
				env->SetByteArrayRegion(Address , 0, 101, (const jbyte*)pOpenAccount->Address);
			jbyteArray ZipCode = env->NewByteArray(7);
			if(pOpenAccount->ZipCode)
				env->SetByteArrayRegion(ZipCode , 0, 7, (const jbyte*)pOpenAccount->ZipCode);
			jbyteArray Telephone = env->NewByteArray(41);
			if(pOpenAccount->Telephone)
				env->SetByteArrayRegion(Telephone , 0, 41, (const jbyte*)pOpenAccount->Telephone);
			jbyteArray MobilePhone = env->NewByteArray(21);
			if(pOpenAccount->MobilePhone)
				env->SetByteArrayRegion(MobilePhone , 0, 21, (const jbyte*)pOpenAccount->MobilePhone);
			jbyteArray Fax = env->NewByteArray(41);
			if(pOpenAccount->Fax)
				env->SetByteArrayRegion(Fax , 0, 41, (const jbyte*)pOpenAccount->Fax);
			jbyteArray EMail = env->NewByteArray(41);
			if(pOpenAccount->EMail)
				env->SetByteArrayRegion(EMail , 0, 41, (const jbyte*)pOpenAccount->EMail);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pOpenAccount->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pOpenAccount->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pOpenAccount->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pOpenAccount->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pOpenAccount->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pOpenAccount->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pOpenAccount->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pOpenAccount->Password);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pOpenAccount->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pOpenAccount->CurrencyID);
			jbyteArray Digest = env->NewByteArray(36);
			if(pOpenAccount->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pOpenAccount->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pOpenAccount->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pOpenAccount->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pOpenAccount->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pOpenAccount->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pOpenAccount->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pOpenAccount->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pOpenAccount->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pOpenAccount->OperNo);
			jbyteArray UserID = env->NewByteArray(16);
			if(pOpenAccount->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pOpenAccount->UserID);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pOpenAccount->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pOpenAccount->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pOpenAccount->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pOpenAccount->LongCustomerName);
			OpenAccount = env->NewObject(jclazz, ctp_struct_methodIDs[314],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pOpenAccount->PlateSerial,pOpenAccount->LastFragment,pOpenAccount->SessionID,CustomerName,pOpenAccount->IdCardType,IdentifiedCardNo,pOpenAccount->Gender,CountryCode,pOpenAccount->CustType,Address,ZipCode,Telephone,MobilePhone,Fax,EMail,pOpenAccount->MoneyAccountStatus,BankAccount,BankPassWord,AccountID,Password,pOpenAccount->InstallID,pOpenAccount->VerifyCertNoFlag,CurrencyID,pOpenAccount->CashExchangeCode,Digest,pOpenAccount->BankAccType,DeviceID,pOpenAccount->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pOpenAccount->BankPwdFlag,pOpenAccount->SecuPwdFlag,OperNo,pOpenAccount->TID,UserID,pOpenAccount->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[122],OpenAccount);
	}

	void OnRtnCancelAccountByBank(CThostFtdcCancelAccountField * pCancelAccount)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcCancelAccountField;");
		jobject CancelAccount = env->AllocObject(jclazz);
		if(pCancelAccount)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pCancelAccount->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pCancelAccount->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pCancelAccount->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pCancelAccount->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pCancelAccount->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pCancelAccount->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pCancelAccount->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pCancelAccount->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pCancelAccount->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pCancelAccount->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pCancelAccount->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pCancelAccount->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pCancelAccount->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pCancelAccount->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pCancelAccount->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pCancelAccount->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pCancelAccount->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pCancelAccount->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pCancelAccount->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pCancelAccount->IdentifiedCardNo);
			jbyteArray CountryCode = env->NewByteArray(21);
			if(pCancelAccount->CountryCode)
				env->SetByteArrayRegion(CountryCode , 0, 21, (const jbyte*)pCancelAccount->CountryCode);
			jbyteArray Address = env->NewByteArray(101);
			if(pCancelAccount->Address)
				env->SetByteArrayRegion(Address , 0, 101, (const jbyte*)pCancelAccount->Address);
			jbyteArray ZipCode = env->NewByteArray(7);
			if(pCancelAccount->ZipCode)
				env->SetByteArrayRegion(ZipCode , 0, 7, (const jbyte*)pCancelAccount->ZipCode);
			jbyteArray Telephone = env->NewByteArray(41);
			if(pCancelAccount->Telephone)
				env->SetByteArrayRegion(Telephone , 0, 41, (const jbyte*)pCancelAccount->Telephone);
			jbyteArray MobilePhone = env->NewByteArray(21);
			if(pCancelAccount->MobilePhone)
				env->SetByteArrayRegion(MobilePhone , 0, 21, (const jbyte*)pCancelAccount->MobilePhone);
			jbyteArray Fax = env->NewByteArray(41);
			if(pCancelAccount->Fax)
				env->SetByteArrayRegion(Fax , 0, 41, (const jbyte*)pCancelAccount->Fax);
			jbyteArray EMail = env->NewByteArray(41);
			if(pCancelAccount->EMail)
				env->SetByteArrayRegion(EMail , 0, 41, (const jbyte*)pCancelAccount->EMail);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pCancelAccount->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pCancelAccount->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pCancelAccount->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pCancelAccount->BankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pCancelAccount->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pCancelAccount->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pCancelAccount->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pCancelAccount->Password);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pCancelAccount->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pCancelAccount->CurrencyID);
			jbyteArray Digest = env->NewByteArray(36);
			if(pCancelAccount->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pCancelAccount->Digest);
			jbyteArray DeviceID = env->NewByteArray(3);
			if(pCancelAccount->DeviceID)
				env->SetByteArrayRegion(DeviceID , 0, 3, (const jbyte*)pCancelAccount->DeviceID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pCancelAccount->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pCancelAccount->BrokerIDByBank);
			jbyteArray BankSecuAcc = env->NewByteArray(41);
			if(pCancelAccount->BankSecuAcc)
				env->SetByteArrayRegion(BankSecuAcc , 0, 41, (const jbyte*)pCancelAccount->BankSecuAcc);
			jbyteArray OperNo = env->NewByteArray(17);
			if(pCancelAccount->OperNo)
				env->SetByteArrayRegion(OperNo , 0, 17, (const jbyte*)pCancelAccount->OperNo);
			jbyteArray UserID = env->NewByteArray(16);
			if(pCancelAccount->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pCancelAccount->UserID);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pCancelAccount->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pCancelAccount->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pCancelAccount->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pCancelAccount->LongCustomerName);
			CancelAccount = env->NewObject(jclazz, ctp_struct_methodIDs[315],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pCancelAccount->PlateSerial,pCancelAccount->LastFragment,pCancelAccount->SessionID,CustomerName,pCancelAccount->IdCardType,IdentifiedCardNo,pCancelAccount->Gender,CountryCode,pCancelAccount->CustType,Address,ZipCode,Telephone,MobilePhone,Fax,EMail,pCancelAccount->MoneyAccountStatus,BankAccount,BankPassWord,AccountID,Password,pCancelAccount->InstallID,pCancelAccount->VerifyCertNoFlag,CurrencyID,pCancelAccount->CashExchangeCode,Digest,pCancelAccount->BankAccType,DeviceID,pCancelAccount->BankSecuAccType,BrokerIDByBank,BankSecuAcc,pCancelAccount->BankPwdFlag,pCancelAccount->SecuPwdFlag,OperNo,pCancelAccount->TID,UserID,pCancelAccount->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[123],CancelAccount);
	}

	void OnRtnChangeAccountByBank(CThostFtdcChangeAccountField * pChangeAccount)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcChangeAccountField;");
		jobject ChangeAccount = env->AllocObject(jclazz);
		if(pChangeAccount)
		{
			jbyteArray TradeCode = env->NewByteArray(7);
			if(pChangeAccount->TradeCode)
				env->SetByteArrayRegion(TradeCode , 0, 7, (const jbyte*)pChangeAccount->TradeCode);
			jbyteArray BankID = env->NewByteArray(4);
			if(pChangeAccount->BankID)
				env->SetByteArrayRegion(BankID , 0, 4, (const jbyte*)pChangeAccount->BankID);
			jbyteArray BankBranchID = env->NewByteArray(5);
			if(pChangeAccount->BankBranchID)
				env->SetByteArrayRegion(BankBranchID , 0, 5, (const jbyte*)pChangeAccount->BankBranchID);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pChangeAccount->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pChangeAccount->BrokerID);
			jbyteArray BrokerBranchID = env->NewByteArray(31);
			if(pChangeAccount->BrokerBranchID)
				env->SetByteArrayRegion(BrokerBranchID , 0, 31, (const jbyte*)pChangeAccount->BrokerBranchID);
			jbyteArray TradeDate = env->NewByteArray(9);
			if(pChangeAccount->TradeDate)
				env->SetByteArrayRegion(TradeDate , 0, 9, (const jbyte*)pChangeAccount->TradeDate);
			jbyteArray TradeTime = env->NewByteArray(9);
			if(pChangeAccount->TradeTime)
				env->SetByteArrayRegion(TradeTime , 0, 9, (const jbyte*)pChangeAccount->TradeTime);
			jbyteArray BankSerial = env->NewByteArray(13);
			if(pChangeAccount->BankSerial)
				env->SetByteArrayRegion(BankSerial , 0, 13, (const jbyte*)pChangeAccount->BankSerial);
			jbyteArray CustomerName = env->NewByteArray(51);
			if(pChangeAccount->CustomerName)
				env->SetByteArrayRegion(CustomerName , 0, 51, (const jbyte*)pChangeAccount->CustomerName);
			jbyteArray IdentifiedCardNo = env->NewByteArray(51);
			if(pChangeAccount->IdentifiedCardNo)
				env->SetByteArrayRegion(IdentifiedCardNo , 0, 51, (const jbyte*)pChangeAccount->IdentifiedCardNo);
			jbyteArray CountryCode = env->NewByteArray(21);
			if(pChangeAccount->CountryCode)
				env->SetByteArrayRegion(CountryCode , 0, 21, (const jbyte*)pChangeAccount->CountryCode);
			jbyteArray Address = env->NewByteArray(101);
			if(pChangeAccount->Address)
				env->SetByteArrayRegion(Address , 0, 101, (const jbyte*)pChangeAccount->Address);
			jbyteArray ZipCode = env->NewByteArray(7);
			if(pChangeAccount->ZipCode)
				env->SetByteArrayRegion(ZipCode , 0, 7, (const jbyte*)pChangeAccount->ZipCode);
			jbyteArray Telephone = env->NewByteArray(41);
			if(pChangeAccount->Telephone)
				env->SetByteArrayRegion(Telephone , 0, 41, (const jbyte*)pChangeAccount->Telephone);
			jbyteArray MobilePhone = env->NewByteArray(21);
			if(pChangeAccount->MobilePhone)
				env->SetByteArrayRegion(MobilePhone , 0, 21, (const jbyte*)pChangeAccount->MobilePhone);
			jbyteArray Fax = env->NewByteArray(41);
			if(pChangeAccount->Fax)
				env->SetByteArrayRegion(Fax , 0, 41, (const jbyte*)pChangeAccount->Fax);
			jbyteArray EMail = env->NewByteArray(41);
			if(pChangeAccount->EMail)
				env->SetByteArrayRegion(EMail , 0, 41, (const jbyte*)pChangeAccount->EMail);
			jbyteArray BankAccount = env->NewByteArray(41);
			if(pChangeAccount->BankAccount)
				env->SetByteArrayRegion(BankAccount , 0, 41, (const jbyte*)pChangeAccount->BankAccount);
			jbyteArray BankPassWord = env->NewByteArray(41);
			if(pChangeAccount->BankPassWord)
				env->SetByteArrayRegion(BankPassWord , 0, 41, (const jbyte*)pChangeAccount->BankPassWord);
			jbyteArray NewBankAccount = env->NewByteArray(41);
			if(pChangeAccount->NewBankAccount)
				env->SetByteArrayRegion(NewBankAccount , 0, 41, (const jbyte*)pChangeAccount->NewBankAccount);
			jbyteArray NewBankPassWord = env->NewByteArray(41);
			if(pChangeAccount->NewBankPassWord)
				env->SetByteArrayRegion(NewBankPassWord , 0, 41, (const jbyte*)pChangeAccount->NewBankPassWord);
			jbyteArray AccountID = env->NewByteArray(13);
			if(pChangeAccount->AccountID)
				env->SetByteArrayRegion(AccountID , 0, 13, (const jbyte*)pChangeAccount->AccountID);
			jbyteArray Password = env->NewByteArray(41);
			if(pChangeAccount->Password)
				env->SetByteArrayRegion(Password , 0, 41, (const jbyte*)pChangeAccount->Password);
			jbyteArray CurrencyID = env->NewByteArray(4);
			if(pChangeAccount->CurrencyID)
				env->SetByteArrayRegion(CurrencyID , 0, 4, (const jbyte*)pChangeAccount->CurrencyID);
			jbyteArray BrokerIDByBank = env->NewByteArray(33);
			if(pChangeAccount->BrokerIDByBank)
				env->SetByteArrayRegion(BrokerIDByBank , 0, 33, (const jbyte*)pChangeAccount->BrokerIDByBank);
			jbyteArray Digest = env->NewByteArray(36);
			if(pChangeAccount->Digest)
				env->SetByteArrayRegion(Digest , 0, 36, (const jbyte*)pChangeAccount->Digest);
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pChangeAccount->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pChangeAccount->ErrorMsg);
			jbyteArray LongCustomerName = env->NewByteArray(161);
			if(pChangeAccount->LongCustomerName)
				env->SetByteArrayRegion(LongCustomerName , 0, 161, (const jbyte*)pChangeAccount->LongCustomerName);
			ChangeAccount = env->NewObject(jclazz, ctp_struct_methodIDs[316],TradeCode,BankID,BankBranchID,BrokerID,BrokerBranchID,TradeDate,TradeTime,BankSerial,pChangeAccount->PlateSerial,pChangeAccount->LastFragment,pChangeAccount->SessionID,CustomerName,pChangeAccount->IdCardType,IdentifiedCardNo,pChangeAccount->Gender,CountryCode,pChangeAccount->CustType,Address,ZipCode,Telephone,MobilePhone,Fax,EMail,pChangeAccount->MoneyAccountStatus,BankAccount,BankPassWord,NewBankAccount,NewBankPassWord,AccountID,Password,pChangeAccount->BankAccType,pChangeAccount->InstallID,pChangeAccount->VerifyCertNoFlag,CurrencyID,BrokerIDByBank,pChangeAccount->BankPwdFlag,pChangeAccount->SecuPwdFlag,pChangeAccount->TID,Digest,pChangeAccount->ErrorID,ErrorMsg,LongCustomerName);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[124],ChangeAccount);
	}

};
#ifdef __cplusplus
extern "C" {
#endif
JNIEXPORT jlong JNICALL Java_ctp_CThostFtdcTraderSpi_newNativeSpiInstance(JNIEnv *env, jobject obj)
{
	JavaVM* jvm;
	jint ret = env->GetJavaVM(&jvm);
	if(ret!=0) return 0;
	jclass spiClazz = env->FindClass("Lctp/CThostFtdcTraderSpi;");
	spi_methodIDs[0] = env->GetMethodID(spiClazz, "OnFrontConnected", "()V");
	spi_methodIDs[1] = env->GetMethodID(spiClazz, "OnFrontDisconnected", "(I)V");
	spi_methodIDs[2] = env->GetMethodID(spiClazz, "OnHeartBeatWarning", "(I)V");
	spi_methodIDs[3] = env->GetMethodID(spiClazz, "OnRspAuthenticate", "(Lctp/apistruct/CThostFtdcRspAuthenticateField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[4] = env->GetMethodID(spiClazz, "OnRspUserLogin", "(Lctp/apistruct/CThostFtdcRspUserLoginField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[5] = env->GetMethodID(spiClazz, "OnRspUserLogout", "(Lctp/apistruct/CThostFtdcUserLogoutField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[6] = env->GetMethodID(spiClazz, "OnRspUserPasswordUpdate", "(Lctp/apistruct/CThostFtdcUserPasswordUpdateField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[7] = env->GetMethodID(spiClazz, "OnRspTradingAccountPasswordUpdate", "(Lctp/apistruct/CThostFtdcTradingAccountPasswordUpdateField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[8] = env->GetMethodID(spiClazz, "OnRspUserAuthMethod", "(Lctp/apistruct/CThostFtdcRspUserAuthMethodField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[9] = env->GetMethodID(spiClazz, "OnRspGenUserCaptcha", "(Lctp/apistruct/CThostFtdcRspGenUserCaptchaField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[10] = env->GetMethodID(spiClazz, "OnRspGenUserText", "(Lctp/apistruct/CThostFtdcRspGenUserTextField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[11] = env->GetMethodID(spiClazz, "OnRspOrderInsert", "(Lctp/apistruct/CThostFtdcInputOrderField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[12] = env->GetMethodID(spiClazz, "OnRspParkedOrderInsert", "(Lctp/apistruct/CThostFtdcParkedOrderField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[13] = env->GetMethodID(spiClazz, "OnRspParkedOrderAction", "(Lctp/apistruct/CThostFtdcParkedOrderActionField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[14] = env->GetMethodID(spiClazz, "OnRspOrderAction", "(Lctp/apistruct/CThostFtdcInputOrderActionField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[15] = env->GetMethodID(spiClazz, "OnRspQueryMaxOrderVolume", "(Lctp/apistruct/CThostFtdcQueryMaxOrderVolumeField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[16] = env->GetMethodID(spiClazz, "OnRspSettlementInfoConfirm", "(Lctp/apistruct/CThostFtdcSettlementInfoConfirmField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[17] = env->GetMethodID(spiClazz, "OnRspRemoveParkedOrder", "(Lctp/apistruct/CThostFtdcRemoveParkedOrderField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[18] = env->GetMethodID(spiClazz, "OnRspRemoveParkedOrderAction", "(Lctp/apistruct/CThostFtdcRemoveParkedOrderActionField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[19] = env->GetMethodID(spiClazz, "OnRspExecOrderInsert", "(Lctp/apistruct/CThostFtdcInputExecOrderField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[20] = env->GetMethodID(spiClazz, "OnRspExecOrderAction", "(Lctp/apistruct/CThostFtdcInputExecOrderActionField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[21] = env->GetMethodID(spiClazz, "OnRspForQuoteInsert", "(Lctp/apistruct/CThostFtdcInputForQuoteField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[22] = env->GetMethodID(spiClazz, "OnRspQuoteInsert", "(Lctp/apistruct/CThostFtdcInputQuoteField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[23] = env->GetMethodID(spiClazz, "OnRspQuoteAction", "(Lctp/apistruct/CThostFtdcInputQuoteActionField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[24] = env->GetMethodID(spiClazz, "OnRspBatchOrderAction", "(Lctp/apistruct/CThostFtdcInputBatchOrderActionField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[25] = env->GetMethodID(spiClazz, "OnRspOptionSelfCloseInsert", "(Lctp/apistruct/CThostFtdcInputOptionSelfCloseField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[26] = env->GetMethodID(spiClazz, "OnRspOptionSelfCloseAction", "(Lctp/apistruct/CThostFtdcInputOptionSelfCloseActionField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[27] = env->GetMethodID(spiClazz, "OnRspCombActionInsert", "(Lctp/apistruct/CThostFtdcInputCombActionField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[28] = env->GetMethodID(spiClazz, "OnRspQryOrder", "(Lctp/apistruct/CThostFtdcOrderField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[29] = env->GetMethodID(spiClazz, "OnRspQryTrade", "(Lctp/apistruct/CThostFtdcTradeField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[30] = env->GetMethodID(spiClazz, "OnRspQryInvestorPosition", "(Lctp/apistruct/CThostFtdcInvestorPositionField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[31] = env->GetMethodID(spiClazz, "OnRspQryTradingAccount", "(Lctp/apistruct/CThostFtdcTradingAccountField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[32] = env->GetMethodID(spiClazz, "OnRspQryInvestor", "(Lctp/apistruct/CThostFtdcInvestorField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[33] = env->GetMethodID(spiClazz, "OnRspQryTradingCode", "(Lctp/apistruct/CThostFtdcTradingCodeField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[34] = env->GetMethodID(spiClazz, "OnRspQryInstrumentMarginRate", "(Lctp/apistruct/CThostFtdcInstrumentMarginRateField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[35] = env->GetMethodID(spiClazz, "OnRspQryInstrumentCommissionRate", "(Lctp/apistruct/CThostFtdcInstrumentCommissionRateField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[36] = env->GetMethodID(spiClazz, "OnRspQryExchange", "(Lctp/apistruct/CThostFtdcExchangeField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[37] = env->GetMethodID(spiClazz, "OnRspQryProduct", "(Lctp/apistruct/CThostFtdcProductField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[38] = env->GetMethodID(spiClazz, "OnRspQryInstrument", "(Lctp/apistruct/CThostFtdcInstrumentField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[39] = env->GetMethodID(spiClazz, "OnRspQryDepthMarketData", "(Lctp/apistruct/CThostFtdcDepthMarketDataField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[40] = env->GetMethodID(spiClazz, "OnRspQrySettlementInfo", "(Lctp/apistruct/CThostFtdcSettlementInfoField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[41] = env->GetMethodID(spiClazz, "OnRspQryTransferBank", "(Lctp/apistruct/CThostFtdcTransferBankField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[42] = env->GetMethodID(spiClazz, "OnRspQryInvestorPositionDetail", "(Lctp/apistruct/CThostFtdcInvestorPositionDetailField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[43] = env->GetMethodID(spiClazz, "OnRspQryNotice", "(Lctp/apistruct/CThostFtdcNoticeField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[44] = env->GetMethodID(spiClazz, "OnRspQrySettlementInfoConfirm", "(Lctp/apistruct/CThostFtdcSettlementInfoConfirmField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[45] = env->GetMethodID(spiClazz, "OnRspQryInvestorPositionCombineDetail", "(Lctp/apistruct/CThostFtdcInvestorPositionCombineDetailField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[46] = env->GetMethodID(spiClazz, "OnRspQryCFMMCTradingAccountKey", "(Lctp/apistruct/CThostFtdcCFMMCTradingAccountKeyField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[47] = env->GetMethodID(spiClazz, "OnRspQryEWarrantOffset", "(Lctp/apistruct/CThostFtdcEWarrantOffsetField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[48] = env->GetMethodID(spiClazz, "OnRspQryInvestorProductGroupMargin", "(Lctp/apistruct/CThostFtdcInvestorProductGroupMarginField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[49] = env->GetMethodID(spiClazz, "OnRspQryExchangeMarginRate", "(Lctp/apistruct/CThostFtdcExchangeMarginRateField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[50] = env->GetMethodID(spiClazz, "OnRspQryExchangeMarginRateAdjust", "(Lctp/apistruct/CThostFtdcExchangeMarginRateAdjustField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[51] = env->GetMethodID(spiClazz, "OnRspQryExchangeRate", "(Lctp/apistruct/CThostFtdcExchangeRateField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[52] = env->GetMethodID(spiClazz, "OnRspQrySecAgentACIDMap", "(Lctp/apistruct/CThostFtdcSecAgentACIDMapField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[53] = env->GetMethodID(spiClazz, "OnRspQryProductExchRate", "(Lctp/apistruct/CThostFtdcProductExchRateField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[54] = env->GetMethodID(spiClazz, "OnRspQryProductGroup", "(Lctp/apistruct/CThostFtdcProductGroupField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[55] = env->GetMethodID(spiClazz, "OnRspQryMMInstrumentCommissionRate", "(Lctp/apistruct/CThostFtdcMMInstrumentCommissionRateField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[56] = env->GetMethodID(spiClazz, "OnRspQryMMOptionInstrCommRate", "(Lctp/apistruct/CThostFtdcMMOptionInstrCommRateField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[57] = env->GetMethodID(spiClazz, "OnRspQryInstrumentOrderCommRate", "(Lctp/apistruct/CThostFtdcInstrumentOrderCommRateField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[58] = env->GetMethodID(spiClazz, "OnRspQrySecAgentTradingAccount", "(Lctp/apistruct/CThostFtdcTradingAccountField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[59] = env->GetMethodID(spiClazz, "OnRspQrySecAgentCheckMode", "(Lctp/apistruct/CThostFtdcSecAgentCheckModeField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[60] = env->GetMethodID(spiClazz, "OnRspQrySecAgentTradeInfo", "(Lctp/apistruct/CThostFtdcSecAgentTradeInfoField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[61] = env->GetMethodID(spiClazz, "OnRspQryOptionInstrTradeCost", "(Lctp/apistruct/CThostFtdcOptionInstrTradeCostField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[62] = env->GetMethodID(spiClazz, "OnRspQryOptionInstrCommRate", "(Lctp/apistruct/CThostFtdcOptionInstrCommRateField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[63] = env->GetMethodID(spiClazz, "OnRspQryExecOrder", "(Lctp/apistruct/CThostFtdcExecOrderField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[64] = env->GetMethodID(spiClazz, "OnRspQryForQuote", "(Lctp/apistruct/CThostFtdcForQuoteField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[65] = env->GetMethodID(spiClazz, "OnRspQryQuote", "(Lctp/apistruct/CThostFtdcQuoteField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[66] = env->GetMethodID(spiClazz, "OnRspQryOptionSelfClose", "(Lctp/apistruct/CThostFtdcOptionSelfCloseField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[67] = env->GetMethodID(spiClazz, "OnRspQryInvestUnit", "(Lctp/apistruct/CThostFtdcInvestUnitField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[68] = env->GetMethodID(spiClazz, "OnRspQryCombInstrumentGuard", "(Lctp/apistruct/CThostFtdcCombInstrumentGuardField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[69] = env->GetMethodID(spiClazz, "OnRspQryCombAction", "(Lctp/apistruct/CThostFtdcCombActionField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[70] = env->GetMethodID(spiClazz, "OnRspQryTransferSerial", "(Lctp/apistruct/CThostFtdcTransferSerialField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[71] = env->GetMethodID(spiClazz, "OnRspQryAccountregister", "(Lctp/apistruct/CThostFtdcAccountregisterField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[72] = env->GetMethodID(spiClazz, "OnRspError", "(Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[73] = env->GetMethodID(spiClazz, "OnRtnOrder", "(Lctp/apistruct/CThostFtdcOrderField;)V");
	spi_methodIDs[74] = env->GetMethodID(spiClazz, "OnRtnTrade", "(Lctp/apistruct/CThostFtdcTradeField;)V");
	spi_methodIDs[75] = env->GetMethodID(spiClazz, "OnErrRtnOrderInsert", "(Lctp/apistruct/CThostFtdcInputOrderField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[76] = env->GetMethodID(spiClazz, "OnErrRtnOrderAction", "(Lctp/apistruct/CThostFtdcOrderActionField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[77] = env->GetMethodID(spiClazz, "OnRtnInstrumentStatus", "(Lctp/apistruct/CThostFtdcInstrumentStatusField;)V");
	spi_methodIDs[78] = env->GetMethodID(spiClazz, "OnRtnBulletin", "(Lctp/apistruct/CThostFtdcBulletinField;)V");
	spi_methodIDs[79] = env->GetMethodID(spiClazz, "OnRtnTradingNotice", "(Lctp/apistruct/CThostFtdcTradingNoticeInfoField;)V");
	spi_methodIDs[80] = env->GetMethodID(spiClazz, "OnRtnErrorConditionalOrder", "(Lctp/apistruct/CThostFtdcErrorConditionalOrderField;)V");
	spi_methodIDs[81] = env->GetMethodID(spiClazz, "OnRtnExecOrder", "(Lctp/apistruct/CThostFtdcExecOrderField;)V");
	spi_methodIDs[82] = env->GetMethodID(spiClazz, "OnErrRtnExecOrderInsert", "(Lctp/apistruct/CThostFtdcInputExecOrderField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[83] = env->GetMethodID(spiClazz, "OnErrRtnExecOrderAction", "(Lctp/apistruct/CThostFtdcExecOrderActionField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[84] = env->GetMethodID(spiClazz, "OnErrRtnForQuoteInsert", "(Lctp/apistruct/CThostFtdcInputForQuoteField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[85] = env->GetMethodID(spiClazz, "OnRtnQuote", "(Lctp/apistruct/CThostFtdcQuoteField;)V");
	spi_methodIDs[86] = env->GetMethodID(spiClazz, "OnErrRtnQuoteInsert", "(Lctp/apistruct/CThostFtdcInputQuoteField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[87] = env->GetMethodID(spiClazz, "OnErrRtnQuoteAction", "(Lctp/apistruct/CThostFtdcQuoteActionField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[88] = env->GetMethodID(spiClazz, "OnRtnForQuoteRsp", "(Lctp/apistruct/CThostFtdcForQuoteRspField;)V");
	spi_methodIDs[89] = env->GetMethodID(spiClazz, "OnRtnCFMMCTradingAccountToken", "(Lctp/apistruct/CThostFtdcCFMMCTradingAccountTokenField;)V");
	spi_methodIDs[90] = env->GetMethodID(spiClazz, "OnErrRtnBatchOrderAction", "(Lctp/apistruct/CThostFtdcBatchOrderActionField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[91] = env->GetMethodID(spiClazz, "OnRtnOptionSelfClose", "(Lctp/apistruct/CThostFtdcOptionSelfCloseField;)V");
	spi_methodIDs[92] = env->GetMethodID(spiClazz, "OnErrRtnOptionSelfCloseInsert", "(Lctp/apistruct/CThostFtdcInputOptionSelfCloseField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[93] = env->GetMethodID(spiClazz, "OnErrRtnOptionSelfCloseAction", "(Lctp/apistruct/CThostFtdcOptionSelfCloseActionField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[94] = env->GetMethodID(spiClazz, "OnRtnCombAction", "(Lctp/apistruct/CThostFtdcCombActionField;)V");
	spi_methodIDs[95] = env->GetMethodID(spiClazz, "OnErrRtnCombActionInsert", "(Lctp/apistruct/CThostFtdcInputCombActionField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[96] = env->GetMethodID(spiClazz, "OnRspQryContractBank", "(Lctp/apistruct/CThostFtdcContractBankField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[97] = env->GetMethodID(spiClazz, "OnRspQryParkedOrder", "(Lctp/apistruct/CThostFtdcParkedOrderField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[98] = env->GetMethodID(spiClazz, "OnRspQryParkedOrderAction", "(Lctp/apistruct/CThostFtdcParkedOrderActionField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[99] = env->GetMethodID(spiClazz, "OnRspQryTradingNotice", "(Lctp/apistruct/CThostFtdcTradingNoticeField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[100] = env->GetMethodID(spiClazz, "OnRspQryBrokerTradingParams", "(Lctp/apistruct/CThostFtdcBrokerTradingParamsField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[101] = env->GetMethodID(spiClazz, "OnRspQryBrokerTradingAlgos", "(Lctp/apistruct/CThostFtdcBrokerTradingAlgosField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[102] = env->GetMethodID(spiClazz, "OnRspQueryCFMMCTradingAccountToken", "(Lctp/apistruct/CThostFtdcQueryCFMMCTradingAccountTokenField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[103] = env->GetMethodID(spiClazz, "OnRtnFromBankToFutureByBank", "(Lctp/apistruct/CThostFtdcRspTransferField;)V");
	spi_methodIDs[104] = env->GetMethodID(spiClazz, "OnRtnFromFutureToBankByBank", "(Lctp/apistruct/CThostFtdcRspTransferField;)V");
	spi_methodIDs[105] = env->GetMethodID(spiClazz, "OnRtnRepealFromBankToFutureByBank", "(Lctp/apistruct/CThostFtdcRspRepealField;)V");
	spi_methodIDs[106] = env->GetMethodID(spiClazz, "OnRtnRepealFromFutureToBankByBank", "(Lctp/apistruct/CThostFtdcRspRepealField;)V");
	spi_methodIDs[107] = env->GetMethodID(spiClazz, "OnRtnFromBankToFutureByFuture", "(Lctp/apistruct/CThostFtdcRspTransferField;)V");
	spi_methodIDs[108] = env->GetMethodID(spiClazz, "OnRtnFromFutureToBankByFuture", "(Lctp/apistruct/CThostFtdcRspTransferField;)V");
	spi_methodIDs[109] = env->GetMethodID(spiClazz, "OnRtnRepealFromBankToFutureByFutureManual", "(Lctp/apistruct/CThostFtdcRspRepealField;)V");
	spi_methodIDs[110] = env->GetMethodID(spiClazz, "OnRtnRepealFromFutureToBankByFutureManual", "(Lctp/apistruct/CThostFtdcRspRepealField;)V");
	spi_methodIDs[111] = env->GetMethodID(spiClazz, "OnRtnQueryBankBalanceByFuture", "(Lctp/apistruct/CThostFtdcNotifyQueryAccountField;)V");
	spi_methodIDs[112] = env->GetMethodID(spiClazz, "OnErrRtnBankToFutureByFuture", "(Lctp/apistruct/CThostFtdcReqTransferField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[113] = env->GetMethodID(spiClazz, "OnErrRtnFutureToBankByFuture", "(Lctp/apistruct/CThostFtdcReqTransferField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[114] = env->GetMethodID(spiClazz, "OnErrRtnRepealBankToFutureByFutureManual", "(Lctp/apistruct/CThostFtdcReqRepealField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[115] = env->GetMethodID(spiClazz, "OnErrRtnRepealFutureToBankByFutureManual", "(Lctp/apistruct/CThostFtdcReqRepealField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[116] = env->GetMethodID(spiClazz, "OnErrRtnQueryBankBalanceByFuture", "(Lctp/apistruct/CThostFtdcReqQueryAccountField;Lctp/apistruct/CThostFtdcRspInfoField;)V");
	spi_methodIDs[117] = env->GetMethodID(spiClazz, "OnRtnRepealFromBankToFutureByFuture", "(Lctp/apistruct/CThostFtdcRspRepealField;)V");
	spi_methodIDs[118] = env->GetMethodID(spiClazz, "OnRtnRepealFromFutureToBankByFuture", "(Lctp/apistruct/CThostFtdcRspRepealField;)V");
	spi_methodIDs[119] = env->GetMethodID(spiClazz, "OnRspFromBankToFutureByFuture", "(Lctp/apistruct/CThostFtdcReqTransferField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[120] = env->GetMethodID(spiClazz, "OnRspFromFutureToBankByFuture", "(Lctp/apistruct/CThostFtdcReqTransferField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[121] = env->GetMethodID(spiClazz, "OnRspQueryBankAccountMoneyByFuture", "(Lctp/apistruct/CThostFtdcReqQueryAccountField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[122] = env->GetMethodID(spiClazz, "OnRtnOpenAccountByBank", "(Lctp/apistruct/CThostFtdcOpenAccountField;)V");
	spi_methodIDs[123] = env->GetMethodID(spiClazz, "OnRtnCancelAccountByBank", "(Lctp/apistruct/CThostFtdcCancelAccountField;)V");
	spi_methodIDs[124] = env->GetMethodID(spiClazz, "OnRtnChangeAccountByBank", "(Lctp/apistruct/CThostFtdcChangeAccountField;)V");
	jclass structClazz;
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcDisseminationField;");
	ctp_struct_methodIDs[0] = env->GetMethodID(structClazz, "<init>", "(SI)V");	/*CThostFtdcDisseminationField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqUserLoginField;");
	ctp_struct_methodIDs[1] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B[B[BI)V");	/*CThostFtdcReqUserLoginField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspUserLoginField;");
	ctp_struct_methodIDs[2] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[B[B[B[B[B[B)V");	/*CThostFtdcRspUserLoginField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserLogoutField;");
	ctp_struct_methodIDs[3] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcUserLogoutField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcForceUserLogoutField;");
	ctp_struct_methodIDs[4] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcForceUserLogoutField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqAuthenticateField;");
	ctp_struct_methodIDs[5] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcReqAuthenticateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspAuthenticateField;");
	ctp_struct_methodIDs[6] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BC)V");	/*CThostFtdcRspAuthenticateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcAuthenticationInfoField;");
	ctp_struct_methodIDs[7] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[BC)V");	/*CThostFtdcAuthenticationInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspUserLogin2Field;");
	ctp_struct_methodIDs[8] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[B[B[B[B[B[B[B)V");	/*CThostFtdcRspUserLogin2Field*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferHeaderField;");
	ctp_struct_methodIDs[9] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B[B[BII)V");	/*CThostFtdcTransferHeaderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferBankToFutureReqField;");
	ctp_struct_methodIDs[10] = env->GetMethodID(structClazz, "<init>", "([BC[BDD)V");	/*CThostFtdcTransferBankToFutureReqField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferBankToFutureRspField;");
	ctp_struct_methodIDs[11] = env->GetMethodID(structClazz, "<init>", "([B[B[BDD[B)V");	/*CThostFtdcTransferBankToFutureRspField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferFutureToBankReqField;");
	ctp_struct_methodIDs[12] = env->GetMethodID(structClazz, "<init>", "([BC[BDD)V");	/*CThostFtdcTransferFutureToBankReqField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferFutureToBankRspField;");
	ctp_struct_methodIDs[13] = env->GetMethodID(structClazz, "<init>", "([B[B[BDD[B)V");	/*CThostFtdcTransferFutureToBankRspField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferQryBankReqField;");
	ctp_struct_methodIDs[14] = env->GetMethodID(structClazz, "<init>", "([BC[B)V");	/*CThostFtdcTransferQryBankReqField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferQryBankRspField;");
	ctp_struct_methodIDs[15] = env->GetMethodID(structClazz, "<init>", "([B[B[BDDD[B)V");	/*CThostFtdcTransferQryBankRspField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferQryDetailReqField;");
	ctp_struct_methodIDs[16] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcTransferQryDetailReqField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferQryDetailRspField;");
	ctp_struct_methodIDs[17] = env->GetMethodID(structClazz, "<init>", "([B[B[BI[B[BI[B[B[B[B[BDC)V");	/*CThostFtdcTransferQryDetailRspField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
	ctp_struct_methodIDs[18] = env->GetMethodID(structClazz, "<init>", "(I[B)V");	/*CThostFtdcRspInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeField;");
	ctp_struct_methodIDs[19] = env->GetMethodID(structClazz, "<init>", "([B[BC)V");	/*CThostFtdcExchangeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcProductField;");
	ctp_struct_methodIDs[20] = env->GetMethodID(structClazz, "<init>", "([B[B[BCIDIIIICCC[BC[BD)V");	/*CThostFtdcProductField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentField;");
	ctp_struct_methodIDs[21] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCIIIIIIID[B[B[B[B[BCICCDDC[BDCDC)V");	/*CThostFtdcInstrumentField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerField;");
	ctp_struct_methodIDs[22] = env->GetMethodID(structClazz, "<init>", "([B[B[BI)V");	/*CThostFtdcBrokerField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTraderField;");
	ctp_struct_methodIDs[23] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[B)V");	/*CThostFtdcTraderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorField;");
	ctp_struct_methodIDs[24] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BC[BI[B[B[B[B[B[B)V");	/*CThostFtdcInvestorField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingCodeField;");
	ctp_struct_methodIDs[25] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BIC[BC[B)V");	/*CThostFtdcTradingCodeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcPartBrokerField;");
	ctp_struct_methodIDs[26] = env->GetMethodID(structClazz, "<init>", "([B[B[BI)V");	/*CThostFtdcPartBrokerField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSuperUserField;");
	ctp_struct_methodIDs[27] = env->GetMethodID(structClazz, "<init>", "([B[B[BI)V");	/*CThostFtdcSuperUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSuperUserFunctionField;");
	ctp_struct_methodIDs[28] = env->GetMethodID(structClazz, "<init>", "([BC)V");	/*CThostFtdcSuperUserFunctionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorGroupField;");
	ctp_struct_methodIDs[29] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcInvestorGroupField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountField;");
	ctp_struct_methodIDs[30] = env->GetMethodID(structClazz, "<init>", "([B[BDDDDDDDDDDDDDDDDDDDDD[BIDDDDDD[BDDDDDDDDDDDDDDCDD)V");	/*CThostFtdcTradingAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorPositionField;");
	ctp_struct_methodIDs[31] = env->GetMethodID(structClazz, "<init>", "([B[B[BCCCIIIIDDIIDDDDDDDDDDDDDD[BIDDIIIDDIDDIDI[BI[BD)V");	/*CThostFtdcInvestorPositionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentMarginRateField;");
	ctp_struct_methodIDs[32] = env->GetMethodID(structClazz, "<init>", "([BC[B[BCDDDDI[B[B)V");	/*CThostFtdcInstrumentMarginRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentCommissionRateField;");
	ctp_struct_methodIDs[33] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDDDDDD[BC[B)V");	/*CThostFtdcInstrumentCommissionRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcDepthMarketDataField;");
	ctp_struct_methodIDs[34] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BDDDDDDDIDDDDDDDD[BIDIDIDIDIDIDIDIDIDIDID[B)V");	/*CThostFtdcDepthMarketDataField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentTradingRightField;");
	ctp_struct_methodIDs[35] = env->GetMethodID(structClazz, "<init>", "([BC[B[BC)V");	/*CThostFtdcInstrumentTradingRightField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerUserField;");
	ctp_struct_methodIDs[36] = env->GetMethodID(structClazz, "<init>", "([B[B[BCIII)V");	/*CThostFtdcBrokerUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerUserPasswordField;");
	ctp_struct_methodIDs[37] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B)V");	/*CThostFtdcBrokerUserPasswordField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerUserFunctionField;");
	ctp_struct_methodIDs[38] = env->GetMethodID(structClazz, "<init>", "([B[BC)V");	/*CThostFtdcBrokerUserFunctionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTraderOfferField;");
	ctp_struct_methodIDs[39] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[BC[B[B[B[B[B[B[B[B[B[B[B[B)V");	/*CThostFtdcTraderOfferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSettlementInfoField;");
	ctp_struct_methodIDs[40] = env->GetMethodID(structClazz, "<init>", "([BI[B[BI[B[B[B)V");	/*CThostFtdcSettlementInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentMarginRateAdjustField;");
	ctp_struct_methodIDs[41] = env->GetMethodID(structClazz, "<init>", "([BC[B[BCDDDDI)V");	/*CThostFtdcInstrumentMarginRateAdjustField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeMarginRateField;");
	ctp_struct_methodIDs[42] = env->GetMethodID(structClazz, "<init>", "([B[BCDDDD[B)V");	/*CThostFtdcExchangeMarginRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeMarginRateAdjustField;");
	ctp_struct_methodIDs[43] = env->GetMethodID(structClazz, "<init>", "([B[BCDDDDDDDDDDDD)V");	/*CThostFtdcExchangeMarginRateAdjustField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeRateField;");
	ctp_struct_methodIDs[44] = env->GetMethodID(structClazz, "<init>", "([B[BD[BD)V");	/*CThostFtdcExchangeRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSettlementRefField;");
	ctp_struct_methodIDs[45] = env->GetMethodID(structClazz, "<init>", "([BI)V");	/*CThostFtdcSettlementRefField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCurrentTimeField;");
	ctp_struct_methodIDs[46] = env->GetMethodID(structClazz, "<init>", "([B[BI[B)V");	/*CThostFtdcCurrentTimeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCommPhaseField;");
	ctp_struct_methodIDs[47] = env->GetMethodID(structClazz, "<init>", "([BS[B)V");	/*CThostFtdcCommPhaseField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcLoginInfoField;");
	ctp_struct_methodIDs[48] = env->GetMethodID(structClazz, "<init>", "(II[B[B[B[B[B[B[B[B[B[B[B[B[B[B[B[B[B[BI[B[B)V");	/*CThostFtdcLoginInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcLogoutAllField;");
	ctp_struct_methodIDs[49] = env->GetMethodID(structClazz, "<init>", "(II[B)V");	/*CThostFtdcLogoutAllField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcFrontStatusField;");
	ctp_struct_methodIDs[50] = env->GetMethodID(structClazz, "<init>", "(I[B[BI)V");	/*CThostFtdcFrontStatusField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserPasswordUpdateField;");
	ctp_struct_methodIDs[51] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcUserPasswordUpdateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOrderField;");
	ctp_struct_methodIDs[52] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCC[B[BDIC[BCICDCI[BIII[B[B[B[B[B[B[B)V");	/*CThostFtdcInputOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOrderField;");
	ctp_struct_methodIDs[53] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCC[B[BDIC[BCICDCI[BI[B[B[B[B[B[BICI[BI[BCCCII[B[B[B[B[B[B[B[BIII[B[BI[BI[BII[B[B[B[B[B[B)V");	/*CThostFtdcOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeOrderField;");
	ctp_struct_methodIDs[54] = env->GetMethodID(structClazz, "<init>", "(CC[B[BDIC[BCICDCI[BI[B[B[B[B[B[BICI[BI[BCCCII[B[B[B[B[B[B[B[BI[B[B[B)V");	/*CThostFtdcExchangeOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeOrderInsertErrorField;");
	ctp_struct_methodIDs[55] = env->GetMethodID(structClazz, "<init>", "([B[B[BI[BI[B)V");	/*CThostFtdcExchangeOrderInsertErrorField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOrderActionField;");
	ctp_struct_methodIDs[56] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BCDI[B[B[B[B[B)V");	/*CThostFtdcInputOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOrderActionField;");
	ctp_struct_methodIDs[57] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BCDI[B[B[BI[B[B[B[B[BC[B[B[B[B[B[B[B)V");	/*CThostFtdcOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeOrderActionField;");
	ctp_struct_methodIDs[58] = env->GetMethodID(structClazz, "<init>", "([B[BCDI[B[B[BI[B[B[B[B[BC[B[B[B[B)V");	/*CThostFtdcExchangeOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeOrderActionErrorField;");
	ctp_struct_methodIDs[59] = env->GetMethodID(structClazz, "<init>", "([B[B[BI[B[BI[B)V");	/*CThostFtdcExchangeOrderActionErrorField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeTradeField;");
	ctp_struct_methodIDs[60] = env->GetMethodID(structClazz, "<init>", "([B[BC[B[B[BC[BCCDI[B[BCC[B[B[B[BIC)V");	/*CThostFtdcExchangeTradeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradeField;");
	ctp_struct_methodIDs[61] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[BC[B[B[BC[BCCDI[B[BCC[B[B[B[BI[BIIC[B)V");	/*CThostFtdcTradeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserSessionField;");
	ctp_struct_methodIDs[62] = env->GetMethodID(structClazz, "<init>", "(II[B[B[B[B[B[B[B[B[B[B)V");	/*CThostFtdcUserSessionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQueryMaxOrderVolumeField;");
	ctp_struct_methodIDs[63] = env->GetMethodID(structClazz, "<init>", "([B[B[BCCCI[B[B)V");	/*CThostFtdcQueryMaxOrderVolumeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSettlementInfoConfirmField;");
	ctp_struct_methodIDs[64] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[B[B)V");	/*CThostFtdcSettlementInfoConfirmField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncDepositField;");
	ctp_struct_methodIDs[65] = env->GetMethodID(structClazz, "<init>", "([B[B[BDI[B)V");	/*CThostFtdcSyncDepositField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncFundMortgageField;");
	ctp_struct_methodIDs[66] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BD[B)V");	/*CThostFtdcSyncFundMortgageField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerSyncField;");
	ctp_struct_methodIDs[67] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcBrokerSyncField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingInvestorField;");
	ctp_struct_methodIDs[68] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BC[BI[B[B[B[B[B[B)V");	/*CThostFtdcSyncingInvestorField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingTradingCodeField;");
	ctp_struct_methodIDs[69] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BIC)V");	/*CThostFtdcSyncingTradingCodeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingInvestorGroupField;");
	ctp_struct_methodIDs[70] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcSyncingInvestorGroupField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingTradingAccountField;");
	ctp_struct_methodIDs[71] = env->GetMethodID(structClazz, "<init>", "([B[BDDDDDDDDDDDDDDDDDDDDD[BIDDDDDD[BDDDDDDDDDDDDDDDD)V");	/*CThostFtdcSyncingTradingAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingInvestorPositionField;");
	ctp_struct_methodIDs[72] = env->GetMethodID(structClazz, "<init>", "([B[B[BCCCIIIIDDIIDDDDDDDDDDDDDD[BIDDIIIDDIDDIDI[BI[BD)V");	/*CThostFtdcSyncingInvestorPositionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingInstrumentMarginRateField;");
	ctp_struct_methodIDs[73] = env->GetMethodID(structClazz, "<init>", "([BC[B[BCDDDDI)V");	/*CThostFtdcSyncingInstrumentMarginRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingInstrumentCommissionRateField;");
	ctp_struct_methodIDs[74] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDDDDDD)V");	/*CThostFtdcSyncingInstrumentCommissionRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingInstrumentTradingRightField;");
	ctp_struct_methodIDs[75] = env->GetMethodID(structClazz, "<init>", "([BC[B[BC)V");	/*CThostFtdcSyncingInstrumentTradingRightField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOrderField;");
	ctp_struct_methodIDs[76] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B)V");	/*CThostFtdcQryOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTradeField;");
	ctp_struct_methodIDs[77] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B)V");	/*CThostFtdcQryTradeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorPositionField;");
	ctp_struct_methodIDs[78] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryInvestorPositionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTradingAccountField;");
	ctp_struct_methodIDs[79] = env->GetMethodID(structClazz, "<init>", "([B[B[BC[B)V");	/*CThostFtdcQryTradingAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorField;");
	ctp_struct_methodIDs[80] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryInvestorField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTradingCodeField;");
	ctp_struct_methodIDs[81] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BC[B)V");	/*CThostFtdcQryTradingCodeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorGroupField;");
	ctp_struct_methodIDs[82] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryInvestorGroupField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentMarginRateField;");
	ctp_struct_methodIDs[83] = env->GetMethodID(structClazz, "<init>", "([B[B[BC[B[B)V");	/*CThostFtdcQryInstrumentMarginRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentCommissionRateField;");
	ctp_struct_methodIDs[84] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryInstrumentCommissionRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentTradingRightField;");
	ctp_struct_methodIDs[85] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryInstrumentTradingRightField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerField;");
	ctp_struct_methodIDs[86] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryBrokerField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTraderField;");
	ctp_struct_methodIDs[87] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryTraderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySuperUserFunctionField;");
	ctp_struct_methodIDs[88] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQrySuperUserFunctionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryUserSessionField;");
	ctp_struct_methodIDs[89] = env->GetMethodID(structClazz, "<init>", "(II[B[B)V");	/*CThostFtdcQryUserSessionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryPartBrokerField;");
	ctp_struct_methodIDs[90] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryPartBrokerField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryFrontStatusField;");
	ctp_struct_methodIDs[91] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcQryFrontStatusField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeOrderField;");
	ctp_struct_methodIDs[92] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryExchangeOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOrderActionField;");
	ctp_struct_methodIDs[93] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeOrderActionField;");
	ctp_struct_methodIDs[94] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQryExchangeOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySuperUserField;");
	ctp_struct_methodIDs[95] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQrySuperUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeField;");
	ctp_struct_methodIDs[96] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryExchangeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryProductField;");
	ctp_struct_methodIDs[97] = env->GetMethodID(structClazz, "<init>", "([BC[B)V");	/*CThostFtdcQryProductField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentField;");
	ctp_struct_methodIDs[98] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQryInstrumentField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryDepthMarketDataField;");
	ctp_struct_methodIDs[99] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryDepthMarketDataField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerUserField;");
	ctp_struct_methodIDs[100] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryBrokerUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerUserFunctionField;");
	ctp_struct_methodIDs[101] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryBrokerUserFunctionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTraderOfferField;");
	ctp_struct_methodIDs[102] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryTraderOfferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySyncDepositField;");
	ctp_struct_methodIDs[103] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQrySyncDepositField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySettlementInfoField;");
	ctp_struct_methodIDs[104] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQrySettlementInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeMarginRateField;");
	ctp_struct_methodIDs[105] = env->GetMethodID(structClazz, "<init>", "([B[BC[B)V");	/*CThostFtdcQryExchangeMarginRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeMarginRateAdjustField;");
	ctp_struct_methodIDs[106] = env->GetMethodID(structClazz, "<init>", "([B[BC)V");	/*CThostFtdcQryExchangeMarginRateAdjustField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeRateField;");
	ctp_struct_methodIDs[107] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryExchangeRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySyncFundMortgageField;");
	ctp_struct_methodIDs[108] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQrySyncFundMortgageField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryHisOrderField;");
	ctp_struct_methodIDs[109] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BI)V");	/*CThostFtdcQryHisOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrMiniMarginField;");
	ctp_struct_methodIDs[110] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDCI)V");	/*CThostFtdcOptionInstrMiniMarginField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrMarginAdjustField;");
	ctp_struct_methodIDs[111] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDDDDDDIDD)V");	/*CThostFtdcOptionInstrMarginAdjustField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrCommRateField;");
	ctp_struct_methodIDs[112] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDDDDDDDD[B[B)V");	/*CThostFtdcOptionInstrCommRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrTradeCostField;");
	ctp_struct_methodIDs[113] = env->GetMethodID(structClazz, "<init>", "([B[B[BCDDDDD[B[B)V");	/*CThostFtdcOptionInstrTradeCostField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOptionInstrTradeCostField;");
	ctp_struct_methodIDs[114] = env->GetMethodID(structClazz, "<init>", "([B[B[BCDD[B[B)V");	/*CThostFtdcQryOptionInstrTradeCostField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOptionInstrCommRateField;");
	ctp_struct_methodIDs[115] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryOptionInstrCommRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcIndexPriceField;");
	ctp_struct_methodIDs[116] = env->GetMethodID(structClazz, "<init>", "([B[BD)V");	/*CThostFtdcIndexPriceField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputExecOrderField;");
	ctp_struct_methodIDs[117] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[BCCCCCC[B[B[B[B[B[B[B)V");	/*CThostFtdcInputExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputExecOrderActionField;");
	ctp_struct_methodIDs[118] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[B[B[B)V");	/*CThostFtdcInputExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExecOrderField;");
	ctp_struct_methodIDs[119] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[BCCCCCC[B[B[B[B[B[BICI[BI[B[B[B[BC[BIII[B[B[BI[B[B[B[B[B[B)V");	/*CThostFtdcExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExecOrderActionField;");
	ctp_struct_methodIDs[120] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[BI[B[B[B[B[BC[BC[B[B[B[B[B[B)V");	/*CThostFtdcExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExecOrderField;");
	ctp_struct_methodIDs[121] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B)V");	/*CThostFtdcQryExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeExecOrderField;");
	ctp_struct_methodIDs[122] = env->GetMethodID(structClazz, "<init>", "(II[BCCCCCC[B[B[B[B[B[BICI[BI[B[B[B[BC[BI[B[B[B)V");	/*CThostFtdcExchangeExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeExecOrderField;");
	ctp_struct_methodIDs[123] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryExchangeExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExecOrderActionField;");
	ctp_struct_methodIDs[124] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeExecOrderActionField;");
	ctp_struct_methodIDs[125] = env->GetMethodID(structClazz, "<init>", "([B[BC[B[B[BI[B[B[B[B[BC[BC[B[B[B[BI)V");	/*CThostFtdcExchangeExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeExecOrderActionField;");
	ctp_struct_methodIDs[126] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQryExchangeExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcErrExecOrderField;");
	ctp_struct_methodIDs[127] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[BCCCCCC[B[B[B[B[B[B[BI[B)V");	/*CThostFtdcErrExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryErrExecOrderField;");
	ctp_struct_methodIDs[128] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryErrExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcErrExecOrderActionField;");
	ctp_struct_methodIDs[129] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[B[B[BI[B)V");	/*CThostFtdcErrExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryErrExecOrderActionField;");
	ctp_struct_methodIDs[130] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryErrExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrTradingRightField;");
	ctp_struct_methodIDs[131] = env->GetMethodID(structClazz, "<init>", "([BC[B[BCC)V");	/*CThostFtdcOptionInstrTradingRightField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOptionInstrTradingRightField;");
	ctp_struct_methodIDs[132] = env->GetMethodID(structClazz, "<init>", "([B[B[BC)V");	/*CThostFtdcQryOptionInstrTradingRightField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputForQuoteField;");
	ctp_struct_methodIDs[133] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B)V");	/*CThostFtdcInputForQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcForQuoteField;");
	ctp_struct_methodIDs[134] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B[B[BI[B[BCII[B[BI[B[B[B)V");	/*CThostFtdcForQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryForQuoteField;");
	ctp_struct_methodIDs[135] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B)V");	/*CThostFtdcQryForQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeForQuoteField;");
	ctp_struct_methodIDs[136] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[BI[B[BC[B[B)V");	/*CThostFtdcExchangeForQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeForQuoteField;");
	ctp_struct_methodIDs[137] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryExchangeForQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputQuoteField;");
	ctp_struct_methodIDs[138] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BDDIII[BCCCC[B[B[B[B[B[B[B[B)V");	/*CThostFtdcInputQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputQuoteActionField;");
	ctp_struct_methodIDs[139] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[B[B[B[B)V");	/*CThostFtdcInputQuoteActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQuoteField;");
	ctp_struct_methodIDs[140] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BDDIII[BCCCC[B[B[B[B[B[BIIC[BI[B[B[B[BC[BI[B[BII[B[B[BI[B[B[B[B[B[B[B[B[B)V");	/*CThostFtdcQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQuoteActionField;");
	ctp_struct_methodIDs[141] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[BI[B[B[B[B[BC[B[B[B[B[B[B[B)V");	/*CThostFtdcQuoteActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryQuoteField;");
	ctp_struct_methodIDs[142] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B)V");	/*CThostFtdcQryQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeQuoteField;");
	ctp_struct_methodIDs[143] = env->GetMethodID(structClazz, "<init>", "(DDIII[BCCCC[B[B[B[B[B[BIIC[BI[B[B[B[BC[BI[B[B[B[B[B[B)V");	/*CThostFtdcExchangeQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeQuoteField;");
	ctp_struct_methodIDs[144] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryExchangeQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryQuoteActionField;");
	ctp_struct_methodIDs[145] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryQuoteActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeQuoteActionField;");
	ctp_struct_methodIDs[146] = env->GetMethodID(structClazz, "<init>", "([B[BC[B[B[BI[B[B[B[B[BC[B[B[B)V");	/*CThostFtdcExchangeQuoteActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeQuoteActionField;");
	ctp_struct_methodIDs[147] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQryExchangeQuoteActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrDeltaField;");
	ctp_struct_methodIDs[148] = env->GetMethodID(structClazz, "<init>", "([BC[B[BD)V");	/*CThostFtdcOptionInstrDeltaField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcForQuoteRspField;");
	ctp_struct_methodIDs[149] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B)V");	/*CThostFtdcForQuoteRspField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcStrikeOffsetField;");
	ctp_struct_methodIDs[150] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDC)V");	/*CThostFtdcStrikeOffsetField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryStrikeOffsetField;");
	ctp_struct_methodIDs[151] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryStrikeOffsetField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputBatchOrderActionField;");
	ctp_struct_methodIDs[152] = env->GetMethodID(structClazz, "<init>", "([B[BIIII[B[B[B[B[B)V");	/*CThostFtdcInputBatchOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBatchOrderActionField;");
	ctp_struct_methodIDs[153] = env->GetMethodID(structClazz, "<init>", "([B[BIIII[B[B[B[BI[B[B[B[BC[B[B[B[B[B)V");	/*CThostFtdcBatchOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeBatchOrderActionField;");
	ctp_struct_methodIDs[154] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[B[B[B[BC[B[B[B)V");	/*CThostFtdcExchangeBatchOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBatchOrderActionField;");
	ctp_struct_methodIDs[155] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryBatchOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCombInstrumentGuardField;");
	ctp_struct_methodIDs[156] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcCombInstrumentGuardField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCombInstrumentGuardField;");
	ctp_struct_methodIDs[157] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryCombInstrumentGuardField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputCombActionField;");
	ctp_struct_methodIDs[158] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCICC[B[B[B[B)V");	/*CThostFtdcInputCombActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCombActionField;");
	ctp_struct_methodIDs[159] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCICC[B[B[B[B[B[BICI[BIIII[B[B[B[B[B[B[B)V");	/*CThostFtdcCombActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCombActionField;");
	ctp_struct_methodIDs[160] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryCombActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeCombActionField;");
	ctp_struct_methodIDs[161] = env->GetMethodID(structClazz, "<init>", "(CICC[B[B[B[B[B[BICI[BII[B[B[B[B)V");	/*CThostFtdcExchangeCombActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeCombActionField;");
	ctp_struct_methodIDs[162] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryExchangeCombActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcProductExchRateField;");
	ctp_struct_methodIDs[163] = env->GetMethodID(structClazz, "<init>", "([B[BD[B)V");	/*CThostFtdcProductExchRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryProductExchRateField;");
	ctp_struct_methodIDs[164] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryProductExchRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryForQuoteParamField;");
	ctp_struct_methodIDs[165] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryForQuoteParamField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcForQuoteParamField;");
	ctp_struct_methodIDs[166] = env->GetMethodID(structClazz, "<init>", "([B[B[BDD)V");	/*CThostFtdcForQuoteParamField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMMOptionInstrCommRateField;");
	ctp_struct_methodIDs[167] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDDDDDDDD)V");	/*CThostFtdcMMOptionInstrCommRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryMMOptionInstrCommRateField;");
	ctp_struct_methodIDs[168] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryMMOptionInstrCommRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMMInstrumentCommissionRateField;");
	ctp_struct_methodIDs[169] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDDDDDD)V");	/*CThostFtdcMMInstrumentCommissionRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryMMInstrumentCommissionRateField;");
	ctp_struct_methodIDs[170] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryMMInstrumentCommissionRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentOrderCommRateField;");
	ctp_struct_methodIDs[171] = env->GetMethodID(structClazz, "<init>", "([BC[B[BCDD[B[B)V");	/*CThostFtdcInstrumentOrderCommRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentOrderCommRateField;");
	ctp_struct_methodIDs[172] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryInstrumentOrderCommRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradeParamField;");
	ctp_struct_methodIDs[173] = env->GetMethodID(structClazz, "<init>", "([BC[B[B)V");	/*CThostFtdcTradeParamField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentMarginRateULField;");
	ctp_struct_methodIDs[174] = env->GetMethodID(structClazz, "<init>", "([BC[B[BCDDDD)V");	/*CThostFtdcInstrumentMarginRateULField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcFutureLimitPosiParamField;");
	ctp_struct_methodIDs[175] = env->GetMethodID(structClazz, "<init>", "(C[B[B[BIII)V");	/*CThostFtdcFutureLimitPosiParamField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcLoginForbiddenIPField;");
	ctp_struct_methodIDs[176] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcLoginForbiddenIPField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcIPListField;");
	ctp_struct_methodIDs[177] = env->GetMethodID(structClazz, "<init>", "([BI)V");	/*CThostFtdcIPListField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOptionSelfCloseField;");
	ctp_struct_methodIDs[178] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[BCC[B[B[B[B[B[B[B)V");	/*CThostFtdcInputOptionSelfCloseField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOptionSelfCloseActionField;");
	ctp_struct_methodIDs[179] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[B[B[B)V");	/*CThostFtdcInputOptionSelfCloseActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionSelfCloseField;");
	ctp_struct_methodIDs[180] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[BCC[B[B[B[B[B[BICI[BI[B[B[B[BC[BIII[B[B[BI[B[B[B[B[B[B)V");	/*CThostFtdcOptionSelfCloseField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionSelfCloseActionField;");
	ctp_struct_methodIDs[181] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[BI[B[B[B[B[BC[B[B[B[B[B[B[B)V");	/*CThostFtdcOptionSelfCloseActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOptionSelfCloseField;");
	ctp_struct_methodIDs[182] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B)V");	/*CThostFtdcQryOptionSelfCloseField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeOptionSelfCloseField;");
	ctp_struct_methodIDs[183] = env->GetMethodID(structClazz, "<init>", "(II[BCC[B[B[B[B[B[BICI[BI[B[B[B[BC[BI[B[B[B)V");	/*CThostFtdcExchangeOptionSelfCloseField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOptionSelfCloseActionField;");
	ctp_struct_methodIDs[184] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryOptionSelfCloseActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeOptionSelfCloseActionField;");
	ctp_struct_methodIDs[185] = env->GetMethodID(structClazz, "<init>", "([B[BC[B[B[BI[B[B[B[B[BC[B[B[B[B[BC)V");	/*CThostFtdcExchangeOptionSelfCloseActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncDelaySwapField;");
	ctp_struct_methodIDs[186] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BDDD[BD)V");	/*CThostFtdcSyncDelaySwapField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySyncDelaySwapField;");
	ctp_struct_methodIDs[187] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQrySyncDelaySwapField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestUnitField;");
	ctp_struct_methodIDs[188] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B)V");	/*CThostFtdcInvestUnitField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestUnitField;");
	ctp_struct_methodIDs[189] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryInvestUnitField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSecAgentCheckModeField;");
	ctp_struct_methodIDs[190] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI)V");	/*CThostFtdcSecAgentCheckModeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSecAgentTradeInfoField;");
	ctp_struct_methodIDs[191] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcSecAgentTradeInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataField;");
	ctp_struct_methodIDs[192] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BDDDDDDDIDDDDDDDD[BI[B)V");	/*CThostFtdcMarketDataField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataBaseField;");
	ctp_struct_methodIDs[193] = env->GetMethodID(structClazz, "<init>", "([BDDDD)V");	/*CThostFtdcMarketDataBaseField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataStaticField;");
	ctp_struct_methodIDs[194] = env->GetMethodID(structClazz, "<init>", "(DDDDDDDD)V");	/*CThostFtdcMarketDataStaticField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataLastMatchField;");
	ctp_struct_methodIDs[195] = env->GetMethodID(structClazz, "<init>", "(DIDD)V");	/*CThostFtdcMarketDataLastMatchField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataBestPriceField;");
	ctp_struct_methodIDs[196] = env->GetMethodID(structClazz, "<init>", "(DIDI)V");	/*CThostFtdcMarketDataBestPriceField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataBid23Field;");
	ctp_struct_methodIDs[197] = env->GetMethodID(structClazz, "<init>", "(DIDI)V");	/*CThostFtdcMarketDataBid23Field*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataAsk23Field;");
	ctp_struct_methodIDs[198] = env->GetMethodID(structClazz, "<init>", "(DIDI)V");	/*CThostFtdcMarketDataAsk23Field*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataBid45Field;");
	ctp_struct_methodIDs[199] = env->GetMethodID(structClazz, "<init>", "(DIDI)V");	/*CThostFtdcMarketDataBid45Field*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataAsk45Field;");
	ctp_struct_methodIDs[200] = env->GetMethodID(structClazz, "<init>", "(DIDI)V");	/*CThostFtdcMarketDataAsk45Field*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataUpdateTimeField;");
	ctp_struct_methodIDs[201] = env->GetMethodID(structClazz, "<init>", "([B[BI[B)V");	/*CThostFtdcMarketDataUpdateTimeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataExchangeField;");
	ctp_struct_methodIDs[202] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcMarketDataExchangeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSpecificInstrumentField;");
	ctp_struct_methodIDs[203] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcSpecificInstrumentField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentStatusField;");
	ctp_struct_methodIDs[204] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BCI[BC)V");	/*CThostFtdcInstrumentStatusField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentStatusField;");
	ctp_struct_methodIDs[205] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryInstrumentStatusField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorAccountField;");
	ctp_struct_methodIDs[206] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcInvestorAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcPositionProfitAlgorithmField;");
	ctp_struct_methodIDs[207] = env->GetMethodID(structClazz, "<init>", "([B[BC[B[B)V");	/*CThostFtdcPositionProfitAlgorithmField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcDiscountField;");
	ctp_struct_methodIDs[208] = env->GetMethodID(structClazz, "<init>", "([BC[BD)V");	/*CThostFtdcDiscountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTransferBankField;");
	ctp_struct_methodIDs[209] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryTransferBankField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferBankField;");
	ctp_struct_methodIDs[210] = env->GetMethodID(structClazz, "<init>", "([B[B[BI)V");	/*CThostFtdcTransferBankField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorPositionDetailField;");
	ctp_struct_methodIDs[211] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryInvestorPositionDetailField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorPositionDetailField;");
	ctp_struct_methodIDs[212] = env->GetMethodID(structClazz, "<init>", "([B[B[BCC[B[BID[BIC[B[BDDDDDDDDDDIDI[B)V");	/*CThostFtdcInvestorPositionDetailField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountPasswordField;");
	ctp_struct_methodIDs[213] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcTradingAccountPasswordField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMDTraderOfferField;");
	ctp_struct_methodIDs[214] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[BC[B[B[B[B[B[B[B[B[B[B[B[B)V");	/*CThostFtdcMDTraderOfferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryMDTraderOfferField;");
	ctp_struct_methodIDs[215] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryMDTraderOfferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryNoticeField;");
	ctp_struct_methodIDs[216] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryNoticeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcNoticeField;");
	ctp_struct_methodIDs[217] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcNoticeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserRightField;");
	ctp_struct_methodIDs[218] = env->GetMethodID(structClazz, "<init>", "([B[BCI)V");	/*CThostFtdcUserRightField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySettlementInfoConfirmField;");
	ctp_struct_methodIDs[219] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQrySettlementInfoConfirmField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcLoadSettlementInfoField;");
	ctp_struct_methodIDs[220] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcLoadSettlementInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerWithdrawAlgorithmField;");
	ctp_struct_methodIDs[221] = env->GetMethodID(structClazz, "<init>", "([BCDCCCI[BDC)V");	/*CThostFtdcBrokerWithdrawAlgorithmField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountPasswordUpdateV1Field;");
	ctp_struct_methodIDs[222] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcTradingAccountPasswordUpdateV1Field*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountPasswordUpdateField;");
	ctp_struct_methodIDs[223] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcTradingAccountPasswordUpdateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCombinationLegField;");
	ctp_struct_methodIDs[224] = env->GetMethodID(structClazz, "<init>", "([BI[B)V");	/*CThostFtdcQryCombinationLegField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySyncStatusField;");
	ctp_struct_methodIDs[225] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQrySyncStatusField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCombinationLegField;");
	ctp_struct_methodIDs[226] = env->GetMethodID(structClazz, "<init>", "([BI[BCII)V");	/*CThostFtdcCombinationLegField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncStatusField;");
	ctp_struct_methodIDs[227] = env->GetMethodID(structClazz, "<init>", "([BC)V");	/*CThostFtdcSyncStatusField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryLinkManField;");
	ctp_struct_methodIDs[228] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryLinkManField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcLinkManField;");
	ctp_struct_methodIDs[229] = env->GetMethodID(structClazz, "<init>", "([B[BCC[B[B[B[B[BI[B[B)V");	/*CThostFtdcLinkManField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerUserEventField;");
	ctp_struct_methodIDs[230] = env->GetMethodID(structClazz, "<init>", "([B[BC)V");	/*CThostFtdcQryBrokerUserEventField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerUserEventField;");
	ctp_struct_methodIDs[231] = env->GetMethodID(structClazz, "<init>", "([B[BCI[B[B[B[B[B)V");	/*CThostFtdcBrokerUserEventField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryContractBankField;");
	ctp_struct_methodIDs[232] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryContractBankField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcContractBankField;");
	ctp_struct_methodIDs[233] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcContractBankField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorPositionCombineDetailField;");
	ctp_struct_methodIDs[234] = env->GetMethodID(structClazz, "<init>", "([B[B[BI[B[B[B[B[BCCIDDDDII[BI[B)V");	/*CThostFtdcInvestorPositionCombineDetailField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcParkedOrderField;");
	ctp_struct_methodIDs[235] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCC[B[BDIC[BCICDCI[BII[B[BCCI[BI[B[B[B[B[B[B)V");	/*CThostFtdcParkedOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcParkedOrderActionField;");
	ctp_struct_methodIDs[236] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BCDI[B[B[BCCI[B[B[B[B)V");	/*CThostFtdcParkedOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryParkedOrderField;");
	ctp_struct_methodIDs[237] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryParkedOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryParkedOrderActionField;");
	ctp_struct_methodIDs[238] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryParkedOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRemoveParkedOrderField;");
	ctp_struct_methodIDs[239] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcRemoveParkedOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRemoveParkedOrderActionField;");
	ctp_struct_methodIDs[240] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcRemoveParkedOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorWithdrawAlgorithmField;");
	ctp_struct_methodIDs[241] = env->GetMethodID(structClazz, "<init>", "([BC[BD[BD)V");	/*CThostFtdcInvestorWithdrawAlgorithmField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorPositionCombineDetailField;");
	ctp_struct_methodIDs[242] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryInvestorPositionCombineDetailField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataAveragePriceField;");
	ctp_struct_methodIDs[243] = env->GetMethodID(structClazz, "<init>", "(D)V");	/*CThostFtdcMarketDataAveragePriceField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcVerifyInvestorPasswordField;");
	ctp_struct_methodIDs[244] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcVerifyInvestorPasswordField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserIPField;");
	ctp_struct_methodIDs[245] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcUserIPField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingNoticeInfoField;");
	ctp_struct_methodIDs[246] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BSI[B)V");	/*CThostFtdcTradingNoticeInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingNoticeField;");
	ctp_struct_methodIDs[247] = env->GetMethodID(structClazz, "<init>", "([BC[BS[B[BI[B[B)V");	/*CThostFtdcTradingNoticeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTradingNoticeField;");
	ctp_struct_methodIDs[248] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryTradingNoticeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryErrOrderField;");
	ctp_struct_methodIDs[249] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryErrOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcErrOrderField;");
	ctp_struct_methodIDs[250] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCC[B[BDIC[BCICDCI[BIII[BI[B[B[B[B[B[B[B)V");	/*CThostFtdcErrOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcErrorConditionalOrderField;");
	ctp_struct_methodIDs[251] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCC[B[BDIC[BCICDCI[BI[B[B[B[B[B[BICI[BI[BCCCII[B[B[B[B[B[B[B[BIII[B[BI[BI[BII[BI[B[B[B[B[B[B)V");	/*CThostFtdcErrorConditionalOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryErrOrderActionField;");
	ctp_struct_methodIDs[252] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryErrOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcErrOrderActionField;");
	ctp_struct_methodIDs[253] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BCDI[B[B[BI[B[B[B[B[BC[B[B[B[B[B[B[BI[B)V");	/*CThostFtdcErrOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeSequenceField;");
	ctp_struct_methodIDs[254] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryExchangeSequenceField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeSequenceField;");
	ctp_struct_methodIDs[255] = env->GetMethodID(structClazz, "<init>", "([BIC)V");	/*CThostFtdcExchangeSequenceField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQueryMaxOrderVolumeWithPriceField;");
	ctp_struct_methodIDs[256] = env->GetMethodID(structClazz, "<init>", "([B[B[BCCCID[B[B)V");	/*CThostFtdcQueryMaxOrderVolumeWithPriceField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerTradingParamsField;");
	ctp_struct_methodIDs[257] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQryBrokerTradingParamsField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerTradingParamsField;");
	ctp_struct_methodIDs[258] = env->GetMethodID(structClazz, "<init>", "([B[BCCC[BC[B)V");	/*CThostFtdcBrokerTradingParamsField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerTradingAlgosField;");
	ctp_struct_methodIDs[259] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryBrokerTradingAlgosField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerTradingAlgosField;");
	ctp_struct_methodIDs[260] = env->GetMethodID(structClazz, "<init>", "([B[B[BCCC)V");	/*CThostFtdcBrokerTradingAlgosField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQueryBrokerDepositField;");
	ctp_struct_methodIDs[261] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQueryBrokerDepositField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerDepositField;");
	ctp_struct_methodIDs[262] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BDDDDDDDDD)V");	/*CThostFtdcBrokerDepositField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCFMMCBrokerKeyField;");
	ctp_struct_methodIDs[263] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryCFMMCBrokerKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCFMMCBrokerKeyField;");
	ctp_struct_methodIDs[264] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[BC)V");	/*CThostFtdcCFMMCBrokerKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCFMMCTradingAccountKeyField;");
	ctp_struct_methodIDs[265] = env->GetMethodID(structClazz, "<init>", "([B[B[BI[B)V");	/*CThostFtdcCFMMCTradingAccountKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCFMMCTradingAccountKeyField;");
	ctp_struct_methodIDs[266] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryCFMMCTradingAccountKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerUserOTPParamField;");
	ctp_struct_methodIDs[267] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BIIC)V");	/*CThostFtdcBrokerUserOTPParamField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcManualSyncBrokerUserOTPField;");
	ctp_struct_methodIDs[268] = env->GetMethodID(structClazz, "<init>", "([B[BC[B[B)V");	/*CThostFtdcManualSyncBrokerUserOTPField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCommRateModelField;");
	ctp_struct_methodIDs[269] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcCommRateModelField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCommRateModelField;");
	ctp_struct_methodIDs[270] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryCommRateModelField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarginModelField;");
	ctp_struct_methodIDs[271] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcMarginModelField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryMarginModelField;");
	ctp_struct_methodIDs[272] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryMarginModelField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcEWarrantOffsetField;");
	ctp_struct_methodIDs[273] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCCI[B)V");	/*CThostFtdcEWarrantOffsetField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryEWarrantOffsetField;");
	ctp_struct_methodIDs[274] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryEWarrantOffsetField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorProductGroupMarginField;");
	ctp_struct_methodIDs[275] = env->GetMethodID(structClazz, "<init>", "([B[B[BC[B[B)V");	/*CThostFtdcQryInvestorProductGroupMarginField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorProductGroupMarginField;");
	ctp_struct_methodIDs[276] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BIDDDDDDDDDDDDDDDDDDDDDC[B[B)V");	/*CThostFtdcInvestorProductGroupMarginField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQueryCFMMCTradingAccountTokenField;");
	ctp_struct_methodIDs[277] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQueryCFMMCTradingAccountTokenField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCFMMCTradingAccountTokenField;");
	ctp_struct_methodIDs[278] = env->GetMethodID(structClazz, "<init>", "([B[B[BI[B)V");	/*CThostFtdcCFMMCTradingAccountTokenField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryProductGroupField;");
	ctp_struct_methodIDs[279] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryProductGroupField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcProductGroupField;");
	ctp_struct_methodIDs[280] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcProductGroupField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBulletinField;");
	ctp_struct_methodIDs[281] = env->GetMethodID(structClazz, "<init>", "([B[BII[BC[B[B[B[B[B[B)V");	/*CThostFtdcBulletinField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBulletinField;");
	ctp_struct_methodIDs[282] = env->GetMethodID(structClazz, "<init>", "([BII[BC)V");	/*CThostFtdcQryBulletinField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqOpenAccountField;");
	ctp_struct_methodIDs[283] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[B[B[BIC[BC[BC[BC[B[BCC[BI[B[B)V");	/*CThostFtdcReqOpenAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqCancelAccountField;");
	ctp_struct_methodIDs[284] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[B[B[BIC[BC[BC[BC[B[BCC[BI[B[B)V");	/*CThostFtdcReqCancelAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqChangeAccountField;");
	ctp_struct_methodIDs[285] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[B[B[B[B[BCIC[B[BCCI[B[B)V");	/*CThostFtdcReqChangeAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqTransferField;");
	ctp_struct_methodIDs[286] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[BDDCDD[B[BC[BC[B[BCC[BIIC[B)V");	/*CThostFtdcReqTransferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspTransferField;");
	ctp_struct_methodIDs[287] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[BDDCDD[B[BC[BC[B[BCC[BIICI[B[B)V");	/*CThostFtdcRspTransferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqRepealField;");
	ctp_struct_methodIDs[288] = env->GetMethodID(structClazz, "<init>", "(IICCI[BI[B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[BDDCDD[B[BC[BC[B[BCC[BIIC[B)V");	/*CThostFtdcReqRepealField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspRepealField;");
	ctp_struct_methodIDs[289] = env->GetMethodID(structClazz, "<init>", "(IICCI[BI[B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[BDDCDD[B[BC[BC[B[BCC[BIICI[B[B)V");	/*CThostFtdcRspRepealField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqQueryAccountField;");
	ctp_struct_methodIDs[290] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[B[BC[BC[B[BCC[BII[B)V");	/*CThostFtdcReqQueryAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspQueryAccountField;");
	ctp_struct_methodIDs[291] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[B[BC[BC[B[BCC[BIIDD[B)V");	/*CThostFtdcRspQueryAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcFutureSignIOField;");
	ctp_struct_methodIDs[292] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[B[BII)V");	/*CThostFtdcFutureSignIOField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspFutureSignInField;");
	ctp_struct_methodIDs[293] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[B[BIII[B[B[B)V");	/*CThostFtdcRspFutureSignInField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqFutureSignOutField;");
	ctp_struct_methodIDs[294] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[B[BII)V");	/*CThostFtdcReqFutureSignOutField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspFutureSignOutField;");
	ctp_struct_methodIDs[295] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[B[BIII[B)V");	/*CThostFtdcRspFutureSignOutField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqQueryTradeResultBySerialField;");
	ctp_struct_methodIDs[296] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICIIC[B[BC[BC[B[B[B[B[BD[B[B)V");	/*CThostFtdcReqQueryTradeResultBySerialField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspQueryTradeResultBySerialField;");
	ctp_struct_methodIDs[297] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[BIC[B[B[B[B[B[B[B[BD[B)V");	/*CThostFtdcRspQueryTradeResultBySerialField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqDayEndFileReadyField;");
	ctp_struct_methodIDs[298] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICIC[B)V");	/*CThostFtdcReqDayEndFileReadyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReturnResultField;");
	ctp_struct_methodIDs[299] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcReturnResultField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcVerifyFuturePasswordField;");
	ctp_struct_methodIDs[300] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[B[B[B[BII[B)V");	/*CThostFtdcVerifyFuturePasswordField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcVerifyCustInfoField;");
	ctp_struct_methodIDs[301] = env->GetMethodID(structClazz, "<init>", "([BC[BC[B)V");	/*CThostFtdcVerifyCustInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcVerifyFuturePasswordAndCustInfoField;");
	ctp_struct_methodIDs[302] = env->GetMethodID(structClazz, "<init>", "([BC[BC[B[B[B[B)V");	/*CThostFtdcVerifyFuturePasswordAndCustInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcDepositResultInformField;");
	ctp_struct_methodIDs[303] = env->GetMethodID(structClazz, "<init>", "([B[B[BDI[B[B)V");	/*CThostFtdcDepositResultInformField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqSyncKeyField;");
	ctp_struct_methodIDs[304] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[BII)V");	/*CThostFtdcReqSyncKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspSyncKeyField;");
	ctp_struct_methodIDs[305] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[BIII[B)V");	/*CThostFtdcRspSyncKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcNotifyQueryAccountField;");
	ctp_struct_methodIDs[306] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[B[BC[BC[B[BCC[BIIDDI[B[B)V");	/*CThostFtdcNotifyQueryAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferSerialField;");
	ctp_struct_methodIDs[307] = env->GetMethodID(structClazz, "<init>", "(I[B[B[B[BI[B[BC[B[B[B[BC[B[BIC[B[BDDDC[B[BI[B)V");	/*CThostFtdcTransferSerialField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTransferSerialField;");
	ctp_struct_methodIDs[308] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQryTransferSerialField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcNotifyFutureSignInField;");
	ctp_struct_methodIDs[309] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[B[BIII[B[B[B)V");	/*CThostFtdcNotifyFutureSignInField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcNotifyFutureSignOutField;");
	ctp_struct_methodIDs[310] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[B[BIII[B)V");	/*CThostFtdcNotifyFutureSignOutField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcNotifySyncKeyField;");
	ctp_struct_methodIDs[311] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[BIII[B)V");	/*CThostFtdcNotifySyncKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryAccountregisterField;");
	ctp_struct_methodIDs[312] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryAccountregisterField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcAccountregisterField;");
	ctp_struct_methodIDs[313] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[BC[B[B[BC[B[BICC[B)V");	/*CThostFtdcAccountregisterField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOpenAccountField;");
	ctp_struct_methodIDs[314] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[B[B[BIC[BC[BC[BC[B[BCC[BI[BI[B[B)V");	/*CThostFtdcOpenAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCancelAccountField;");
	ctp_struct_methodIDs[315] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[B[B[BIC[BC[BC[BC[B[BCC[BI[BI[B[B)V");	/*CThostFtdcCancelAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcChangeAccountField;");
	ctp_struct_methodIDs[316] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[B[B[B[B[BCIC[B[BCCI[BI[B[B)V");	/*CThostFtdcChangeAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSecAgentACIDMapField;");
	ctp_struct_methodIDs[317] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcSecAgentACIDMapField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySecAgentACIDMapField;");
	ctp_struct_methodIDs[318] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQrySecAgentACIDMapField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserRightsAssignField;");
	ctp_struct_methodIDs[319] = env->GetMethodID(structClazz, "<init>", "([B[BI)V");	/*CThostFtdcUserRightsAssignField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerUserRightAssignField;");
	ctp_struct_methodIDs[320] = env->GetMethodID(structClazz, "<init>", "([BII)V");	/*CThostFtdcBrokerUserRightAssignField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcDRTransferField;");
	ctp_struct_methodIDs[321] = env->GetMethodID(structClazz, "<init>", "(II[B[B)V");	/*CThostFtdcDRTransferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcFensUserInfoField;");
	ctp_struct_methodIDs[322] = env->GetMethodID(structClazz, "<init>", "([B[BC)V");	/*CThostFtdcFensUserInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCurrTransferIdentityField;");
	ctp_struct_methodIDs[323] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcCurrTransferIdentityField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcLoginForbiddenUserField;");
	ctp_struct_methodIDs[324] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcLoginForbiddenUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryLoginForbiddenUserField;");
	ctp_struct_methodIDs[325] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryLoginForbiddenUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMulticastGroupInfoField;");
	ctp_struct_methodIDs[326] = env->GetMethodID(structClazz, "<init>", "([BI[B)V");	/*CThostFtdcMulticastGroupInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountReserveField;");
	ctp_struct_methodIDs[327] = env->GetMethodID(structClazz, "<init>", "([B[BD[B)V");	/*CThostFtdcTradingAccountReserveField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryLoginForbiddenIPField;");
	ctp_struct_methodIDs[328] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryLoginForbiddenIPField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryIPListField;");
	ctp_struct_methodIDs[329] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryIPListField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryUserRightsAssignField;");
	ctp_struct_methodIDs[330] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryUserRightsAssignField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReserveOpenAccountConfirmField;");
	ctp_struct_methodIDs[331] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[BIC[B[BC[BI[B[B[B[B[BI[B)V");	/*CThostFtdcReserveOpenAccountConfirmField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReserveOpenAccountField;");
	ctp_struct_methodIDs[332] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[BIC[B[BC[BICI[B)V");	/*CThostFtdcReserveOpenAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcAccountPropertyField;");
	ctp_struct_methodIDs[333] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[BIC[B[B[B[B[B[B)V");	/*CThostFtdcAccountPropertyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCurrDRIdentityField;");
	ctp_struct_methodIDs[334] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcQryCurrDRIdentityField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCurrDRIdentityField;");
	ctp_struct_methodIDs[335] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcCurrDRIdentityField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySecAgentCheckModeField;");
	ctp_struct_methodIDs[336] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQrySecAgentCheckModeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySecAgentTradeInfoField;");
	ctp_struct_methodIDs[337] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQrySecAgentTradeInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserSystemInfoField;");
	ctp_struct_methodIDs[338] = env->GetMethodID(structClazz, "<init>", "([B[BI[B[BI[B[B)V");	/*CThostFtdcUserSystemInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqUserAuthMethodField;");
	ctp_struct_methodIDs[339] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcReqUserAuthMethodField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspUserAuthMethodField;");
	ctp_struct_methodIDs[340] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcRspUserAuthMethodField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqGenUserCaptchaField;");
	ctp_struct_methodIDs[341] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcReqGenUserCaptchaField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspGenUserCaptchaField;");
	ctp_struct_methodIDs[342] = env->GetMethodID(structClazz, "<init>", "([B[BI[B)V");	/*CThostFtdcRspGenUserCaptchaField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqGenUserTextField;");
	ctp_struct_methodIDs[343] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcReqGenUserTextField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspGenUserTextField;");
	ctp_struct_methodIDs[344] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcRspGenUserTextField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqUserLoginWithCaptchaField;");
	ctp_struct_methodIDs[345] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B[B[BI)V");	/*CThostFtdcReqUserLoginWithCaptchaField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqUserLoginWithTextField;");
	ctp_struct_methodIDs[346] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B[B[BI)V");	/*CThostFtdcReqUserLoginWithTextField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqUserLoginWithOTPField;");
	ctp_struct_methodIDs[347] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B[B[BI)V");	/*CThostFtdcReqUserLoginWithOTPField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqApiHandshakeField;");
	ctp_struct_methodIDs[348] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcReqApiHandshakeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspApiHandshakeField;");
	ctp_struct_methodIDs[349] = env->GetMethodID(structClazz, "<init>", "(I[BI)V");	/*CThostFtdcRspApiHandshakeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqVerifyApiKeyField;");
	ctp_struct_methodIDs[350] = env->GetMethodID(structClazz, "<init>", "(I[B)V");	/*CThostFtdcReqVerifyApiKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcDepartmentUserField;");
	ctp_struct_methodIDs[351] = env->GetMethodID(structClazz, "<init>", "([B[BC[B)V");	/*CThostFtdcDepartmentUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQueryFreqField;");
	ctp_struct_methodIDs[352] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcQueryFreqField*/
	jobject global_java_spi_ref = env->NewGlobalRef(obj);
	MyTdSpi * ptrSpi = new MyTdSpi(jvm, global_java_spi_ref);
	return (jlong) ptrSpi;
}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcTraderSpi_deleteNativeSpiInstance(JNIEnv *env, jobject obj, jlong ptrSpi)
{
	MyTdSpi * ptrSpi2beDel = (MyTdSpi *)ptrSpi;
	if(ptrSpi) {env->DeleteGlobalRef(ptrSpi2beDel->jspi); delete ptrSpi2beDel;ptrSpi2beDel=NULL;}
}
#ifdef __cplusplus
}
#endif
#ifdef __cplusplus
extern "C" {
#endif
JNIEXPORT jobject JNICALL Java_ctp_CThostFtdcTraderApi_CreateFtdcTraderApi
(JNIEnv * env,jclass obj,jstring pszFlowPath)
{
	const char* cstr = env->GetStringUTFChars(pszFlowPath,NULL);
	CThostFtdcTraderApi* ptrApi;
	jobject javaApiRtn;
	jmethodID methodID = env->GetMethodID(obj,"<init>","(J)V");
	ptrApi = CThostFtdcTraderApi::CreateFtdcTraderApi((char*)cstr);
	env->ReleaseStringUTFChars(pszFlowPath,cstr);
	javaApiRtn = env->NewObject(obj, methodID, (jlong)ptrApi);
	return javaApiRtn;

}
JNIEXPORT jstring JNICALL Java_ctp_CThostFtdcTraderApi_GetApiVersion
(JNIEnv * env,jclass obj)
{

	jstring jstrRtn;
	const char* c_str = CThostFtdcTraderApi::GetApiVersion();
	jstrRtn = env->NewStringUTF(c_str);
	return jstrRtn;
}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcTraderApi_Release
(JNIEnv * env,jobject obj)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);

	ptrApi->Release();

}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcTraderApi_Init
(JNIEnv * env,jobject obj)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);

	ptrApi->Init();

}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_Join
(JNIEnv * env,jobject obj)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);

	jint iRtn = ptrApi->Join();
	return iRtn;
}
JNIEXPORT jstring JNICALL Java_ctp_CThostFtdcTraderApi_GetTradingDay
(JNIEnv * env,jobject obj)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);

	jstring jstrRtn;
	const char* c_str = ptrApi->GetTradingDay();
	jstrRtn = env->NewStringUTF(c_str);
	return jstrRtn;
}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcTraderApi_RegisterFront
(JNIEnv * env,jobject obj,jstring pszFrontAddress)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	const char* cstr = env->GetStringUTFChars(pszFrontAddress,NULL);
	ptrApi->RegisterFront((char*)cstr);
	env->ReleaseStringUTFChars(pszFrontAddress,cstr);

}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcTraderApi_RegisterNameServer
(JNIEnv * env,jobject obj,jstring pszNsAddress)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	const char* cstr = env->GetStringUTFChars(pszNsAddress,NULL);
	ptrApi->RegisterNameServer((char*)cstr);
	env->ReleaseStringUTFChars(pszNsAddress,cstr);

}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcTraderApi_RegisterFensUserInfo
(JNIEnv * env,jobject obj,jobject  pFensUserInfo)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcFensUserInfoField;");
	CThostFtdcFensUserInfoField FensUserInfo = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField( pFensUserInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(FensUserInfo.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField( pFensUserInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(FensUserInfo.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LoginMode", "C");
		FensUserInfo.LoginMode = env->GetCharField( pFensUserInfo,fid);
	}

	ptrApi->RegisterFensUserInfo(&FensUserInfo);

}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcTraderApi_RegisterSpi
(JNIEnv * env,jobject obj,jobject pSpi)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	CThostFtdcTraderSpi* ptrSpi = NULL;
	if(pSpi != NULL)
	{
		jclass clazz = env->FindClass("Lctp/CThostFtdcTraderSpi;");
		jfieldID fieldID = env->GetFieldID(clazz, "ptrSpi", "J");
		ptrSpi = (CThostFtdcTraderSpi*)env->GetLongField(pSpi,fieldID);
	}

	ptrApi->RegisterSpi(ptrSpi);

}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcTraderApi_SubscribePrivateTopic
(JNIEnv * env,jobject obj,jint nResumeType)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);

	ptrApi->SubscribePrivateTopic((THOST_TE_RESUME_TYPE ) nResumeType);

}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcTraderApi_SubscribePublicTopic
(JNIEnv * env,jobject obj,jint nResumeType)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);

	ptrApi->SubscribePublicTopic((THOST_TE_RESUME_TYPE ) nResumeType);

}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqAuthenticate
(JNIEnv * env,jobject obj,jobject pReqAuthenticateField,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcReqAuthenticateField;");
	CThostFtdcReqAuthenticateField ReqAuthenticateField = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqAuthenticateField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqAuthenticateField.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqAuthenticateField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqAuthenticateField.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserProductInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqAuthenticateField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqAuthenticateField.UserProductInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AuthCode", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqAuthenticateField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqAuthenticateField.AuthCode, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AppID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqAuthenticateField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqAuthenticateField.AppID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqAuthenticate(&ReqAuthenticateField, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_RegisterUserSystemInfo
(JNIEnv * env,jobject obj,jobject pUserSystemInfo)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcUserSystemInfoField;");
	CThostFtdcUserSystemInfoField UserSystemInfo = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserSystemInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserSystemInfo.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserSystemInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserSystemInfo.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientSystemInfoLen", "I");
		UserSystemInfo.ClientSystemInfoLen = env->GetIntField(pUserSystemInfo,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientSystemInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserSystemInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserSystemInfo.ClientSystemInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientPublicIP", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserSystemInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserSystemInfo.ClientPublicIP, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientIPPort", "I");
		UserSystemInfo.ClientIPPort = env->GetIntField(pUserSystemInfo,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientLoginTime", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserSystemInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserSystemInfo.ClientLoginTime, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientAppID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserSystemInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserSystemInfo.ClientAppID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->RegisterUserSystemInfo(&UserSystemInfo);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_SubmitUserSystemInfo
(JNIEnv * env,jobject obj,jobject pUserSystemInfo)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcUserSystemInfoField;");
	CThostFtdcUserSystemInfoField UserSystemInfo = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserSystemInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserSystemInfo.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserSystemInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserSystemInfo.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientSystemInfoLen", "I");
		UserSystemInfo.ClientSystemInfoLen = env->GetIntField(pUserSystemInfo,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientSystemInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserSystemInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserSystemInfo.ClientSystemInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientPublicIP", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserSystemInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserSystemInfo.ClientPublicIP, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientIPPort", "I");
		UserSystemInfo.ClientIPPort = env->GetIntField(pUserSystemInfo,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientLoginTime", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserSystemInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserSystemInfo.ClientLoginTime, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientAppID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserSystemInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserSystemInfo.ClientAppID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->SubmitUserSystemInfo(&UserSystemInfo);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqUserLogin
(JNIEnv * env,jobject obj,jobject pReqUserLoginField,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcReqUserLoginField;");
	CThostFtdcReqUserLoginField ReqUserLoginField = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradingDay", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.TradingDay, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Password", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.Password, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserProductInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.UserProductInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InterfaceProductInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.InterfaceProductInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ProtocolInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.ProtocolInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OneTimePassword", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.OneTimePassword, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientIPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.ClientIPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LoginRemark", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.LoginRemark, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientIPPort", "I");
		ReqUserLoginField.ClientIPPort = env->GetIntField(pReqUserLoginField,fid);
	}

	jint iRtn = ptrApi->ReqUserLogin(&ReqUserLoginField, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqUserLogout
(JNIEnv * env,jobject obj,jobject pUserLogout,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcUserLogoutField;");
	CThostFtdcUserLogoutField UserLogout = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserLogout,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserLogout.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserLogout,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserLogout.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqUserLogout(&UserLogout, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqUserPasswordUpdate
(JNIEnv * env,jobject obj,jobject pUserPasswordUpdate,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcUserPasswordUpdateField;");
	CThostFtdcUserPasswordUpdateField UserPasswordUpdate = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserPasswordUpdate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserPasswordUpdate.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserPasswordUpdate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserPasswordUpdate.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OldPassword", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserPasswordUpdate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserPasswordUpdate.OldPassword, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "NewPassword", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserPasswordUpdate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserPasswordUpdate.NewPassword, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqUserPasswordUpdate(&UserPasswordUpdate, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqTradingAccountPasswordUpdate
(JNIEnv * env,jobject obj,jobject pTradingAccountPasswordUpdate,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountPasswordUpdateField;");
	CThostFtdcTradingAccountPasswordUpdateField TradingAccountPasswordUpdate = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pTradingAccountPasswordUpdate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(TradingAccountPasswordUpdate.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pTradingAccountPasswordUpdate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(TradingAccountPasswordUpdate.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OldPassword", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pTradingAccountPasswordUpdate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(TradingAccountPasswordUpdate.OldPassword, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "NewPassword", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pTradingAccountPasswordUpdate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(TradingAccountPasswordUpdate.NewPassword, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pTradingAccountPasswordUpdate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(TradingAccountPasswordUpdate.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqTradingAccountPasswordUpdate(&TradingAccountPasswordUpdate, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqUserAuthMethod
(JNIEnv * env,jobject obj,jobject pReqUserAuthMethod,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcReqUserAuthMethodField;");
	CThostFtdcReqUserAuthMethodField ReqUserAuthMethod = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradingDay", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserAuthMethod,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserAuthMethod.TradingDay, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserAuthMethod,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserAuthMethod.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserAuthMethod,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserAuthMethod.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqUserAuthMethod(&ReqUserAuthMethod, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqGenUserCaptcha
(JNIEnv * env,jobject obj,jobject pReqGenUserCaptcha,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcReqGenUserCaptchaField;");
	CThostFtdcReqGenUserCaptchaField ReqGenUserCaptcha = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradingDay", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqGenUserCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqGenUserCaptcha.TradingDay, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqGenUserCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqGenUserCaptcha.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqGenUserCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqGenUserCaptcha.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqGenUserCaptcha(&ReqGenUserCaptcha, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqGenUserText
(JNIEnv * env,jobject obj,jobject pReqGenUserText,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcReqGenUserTextField;");
	CThostFtdcReqGenUserTextField ReqGenUserText = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradingDay", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqGenUserText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqGenUserText.TradingDay, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqGenUserText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqGenUserText.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqGenUserText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqGenUserText.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqGenUserText(&ReqGenUserText, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqUserLoginWithCaptcha
(JNIEnv * env,jobject obj,jobject pReqUserLoginWithCaptcha,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcReqUserLoginWithCaptchaField;");
	CThostFtdcReqUserLoginWithCaptchaField ReqUserLoginWithCaptcha = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradingDay", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithCaptcha.TradingDay, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithCaptcha.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithCaptcha.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Password", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithCaptcha.Password, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserProductInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithCaptcha.UserProductInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InterfaceProductInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithCaptcha.InterfaceProductInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ProtocolInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithCaptcha.ProtocolInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithCaptcha.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientIPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithCaptcha.ClientIPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LoginRemark", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithCaptcha.LoginRemark, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Captcha", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithCaptcha,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithCaptcha.Captcha, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientIPPort", "I");
		ReqUserLoginWithCaptcha.ClientIPPort = env->GetIntField(pReqUserLoginWithCaptcha,fid);
	}

	jint iRtn = ptrApi->ReqUserLoginWithCaptcha(&ReqUserLoginWithCaptcha, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqUserLoginWithText
(JNIEnv * env,jobject obj,jobject pReqUserLoginWithText,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcReqUserLoginWithTextField;");
	CThostFtdcReqUserLoginWithTextField ReqUserLoginWithText = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradingDay", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithText.TradingDay, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithText.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithText.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Password", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithText.Password, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserProductInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithText.UserProductInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InterfaceProductInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithText.InterfaceProductInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ProtocolInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithText.ProtocolInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithText.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientIPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithText.ClientIPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LoginRemark", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithText.LoginRemark, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Text", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithText,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithText.Text, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientIPPort", "I");
		ReqUserLoginWithText.ClientIPPort = env->GetIntField(pReqUserLoginWithText,fid);
	}

	jint iRtn = ptrApi->ReqUserLoginWithText(&ReqUserLoginWithText, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqUserLoginWithOTP
(JNIEnv * env,jobject obj,jobject pReqUserLoginWithOTP,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcReqUserLoginWithOTPField;");
	CThostFtdcReqUserLoginWithOTPField ReqUserLoginWithOTP = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradingDay", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithOTP,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithOTP.TradingDay, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithOTP,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithOTP.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithOTP,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithOTP.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Password", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithOTP,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithOTP.Password, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserProductInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithOTP,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithOTP.UserProductInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InterfaceProductInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithOTP,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithOTP.InterfaceProductInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ProtocolInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithOTP,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithOTP.ProtocolInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithOTP,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithOTP.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientIPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithOTP,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithOTP.ClientIPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LoginRemark", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithOTP,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithOTP.LoginRemark, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OTPPassword", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginWithOTP,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginWithOTP.OTPPassword, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientIPPort", "I");
		ReqUserLoginWithOTP.ClientIPPort = env->GetIntField(pReqUserLoginWithOTP,fid);
	}

	jint iRtn = ptrApi->ReqUserLoginWithOTP(&ReqUserLoginWithOTP, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqOrderInsert
(JNIEnv * env,jobject obj,jobject pInputOrder,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcInputOrderField;");
	CThostFtdcInputOrderField InputOrder = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OrderRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.OrderRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OrderPriceType", "C");
		InputOrder.OrderPriceType = env->GetCharField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Direction", "C");
		InputOrder.Direction = env->GetCharField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CombOffsetFlag", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.CombOffsetFlag, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CombHedgeFlag", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.CombHedgeFlag, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LimitPrice", "D");
		InputOrder.LimitPrice = env->GetDoubleField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "VolumeTotalOriginal", "I");
		InputOrder.VolumeTotalOriginal = env->GetIntField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TimeCondition", "C");
		InputOrder.TimeCondition = env->GetCharField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "GTDDate", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.GTDDate, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "VolumeCondition", "C");
		InputOrder.VolumeCondition = env->GetCharField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MinVolume", "I");
		InputOrder.MinVolume = env->GetIntField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ContingentCondition", "C");
		InputOrder.ContingentCondition = env->GetCharField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "StopPrice", "D");
		InputOrder.StopPrice = env->GetDoubleField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ForceCloseReason", "C");
		InputOrder.ForceCloseReason = env->GetCharField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IsAutoSuspend", "I");
		InputOrder.IsAutoSuspend = env->GetIntField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BusinessUnit", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.BusinessUnit, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		InputOrder.RequestID = env->GetIntField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserForceClose", "I");
		InputOrder.UserForceClose = env->GetIntField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IsSwapOrder", "I");
		InputOrder.IsSwapOrder = env->GetIntField(pInputOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.ClientID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.IPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrder.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqOrderInsert(&InputOrder, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqParkedOrderInsert
(JNIEnv * env,jobject obj,jobject pParkedOrder,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcParkedOrderField;");
	CThostFtdcParkedOrderField ParkedOrder = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OrderRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.OrderRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OrderPriceType", "C");
		ParkedOrder.OrderPriceType = env->GetCharField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Direction", "C");
		ParkedOrder.Direction = env->GetCharField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CombOffsetFlag", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.CombOffsetFlag, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CombHedgeFlag", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.CombHedgeFlag, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LimitPrice", "D");
		ParkedOrder.LimitPrice = env->GetDoubleField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "VolumeTotalOriginal", "I");
		ParkedOrder.VolumeTotalOriginal = env->GetIntField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TimeCondition", "C");
		ParkedOrder.TimeCondition = env->GetCharField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "GTDDate", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.GTDDate, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "VolumeCondition", "C");
		ParkedOrder.VolumeCondition = env->GetCharField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MinVolume", "I");
		ParkedOrder.MinVolume = env->GetIntField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ContingentCondition", "C");
		ParkedOrder.ContingentCondition = env->GetCharField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "StopPrice", "D");
		ParkedOrder.StopPrice = env->GetDoubleField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ForceCloseReason", "C");
		ParkedOrder.ForceCloseReason = env->GetCharField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IsAutoSuspend", "I");
		ParkedOrder.IsAutoSuspend = env->GetIntField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BusinessUnit", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.BusinessUnit, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		ParkedOrder.RequestID = env->GetIntField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserForceClose", "I");
		ParkedOrder.UserForceClose = env->GetIntField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ParkedOrderID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.ParkedOrderID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserType", "C");
		ParkedOrder.UserType = env->GetCharField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Status", "C");
		ParkedOrder.Status = env->GetCharField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ErrorID", "I");
		ParkedOrder.ErrorID = env->GetIntField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ErrorMsg", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.ErrorMsg, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IsSwapOrder", "I");
		ParkedOrder.IsSwapOrder = env->GetIntField(pParkedOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.ClientID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.IPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrder.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqParkedOrderInsert(&ParkedOrder, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqParkedOrderAction
(JNIEnv * env,jobject obj,jobject pParkedOrderAction,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcParkedOrderActionField;");
	CThostFtdcParkedOrderActionField ParkedOrderAction = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrderAction.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrderAction.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OrderActionRef", "I");
		ParkedOrderAction.OrderActionRef = env->GetIntField(pParkedOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OrderRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrderAction.OrderRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		ParkedOrderAction.RequestID = env->GetIntField(pParkedOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FrontID", "I");
		ParkedOrderAction.FrontID = env->GetIntField(pParkedOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "SessionID", "I");
		ParkedOrderAction.SessionID = env->GetIntField(pParkedOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrderAction.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OrderSysID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrderAction.OrderSysID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ActionFlag", "C");
		ParkedOrderAction.ActionFlag = env->GetCharField(pParkedOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LimitPrice", "D");
		ParkedOrderAction.LimitPrice = env->GetDoubleField(pParkedOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "VolumeChange", "I");
		ParkedOrderAction.VolumeChange = env->GetIntField(pParkedOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrderAction.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrderAction.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ParkedOrderActionID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrderAction.ParkedOrderActionID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserType", "C");
		ParkedOrderAction.UserType = env->GetCharField(pParkedOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Status", "C");
		ParkedOrderAction.Status = env->GetCharField(pParkedOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ErrorID", "I");
		ParkedOrderAction.ErrorID = env->GetIntField(pParkedOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ErrorMsg", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrderAction.ErrorMsg, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrderAction.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrderAction.IPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ParkedOrderAction.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqParkedOrderAction(&ParkedOrderAction, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqOrderAction
(JNIEnv * env,jobject obj,jobject pInputOrderAction,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcInputOrderActionField;");
	CThostFtdcInputOrderActionField InputOrderAction = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrderAction.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrderAction.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OrderActionRef", "I");
		InputOrderAction.OrderActionRef = env->GetIntField(pInputOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OrderRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrderAction.OrderRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		InputOrderAction.RequestID = env->GetIntField(pInputOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FrontID", "I");
		InputOrderAction.FrontID = env->GetIntField(pInputOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "SessionID", "I");
		InputOrderAction.SessionID = env->GetIntField(pInputOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrderAction.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OrderSysID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrderAction.OrderSysID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ActionFlag", "C");
		InputOrderAction.ActionFlag = env->GetCharField(pInputOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LimitPrice", "D");
		InputOrderAction.LimitPrice = env->GetDoubleField(pInputOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "VolumeChange", "I");
		InputOrderAction.VolumeChange = env->GetIntField(pInputOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrderAction.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrderAction.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrderAction.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrderAction.IPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOrderAction.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqOrderAction(&InputOrderAction, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQueryMaxOrderVolume
(JNIEnv * env,jobject obj,jobject pQueryMaxOrderVolume,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQueryMaxOrderVolumeField;");
	CThostFtdcQueryMaxOrderVolumeField QueryMaxOrderVolume = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQueryMaxOrderVolume,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QueryMaxOrderVolume.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQueryMaxOrderVolume,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QueryMaxOrderVolume.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQueryMaxOrderVolume,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QueryMaxOrderVolume.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Direction", "C");
		QueryMaxOrderVolume.Direction = env->GetCharField(pQueryMaxOrderVolume,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OffsetFlag", "C");
		QueryMaxOrderVolume.OffsetFlag = env->GetCharField(pQueryMaxOrderVolume,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "HedgeFlag", "C");
		QueryMaxOrderVolume.HedgeFlag = env->GetCharField(pQueryMaxOrderVolume,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MaxVolume", "I");
		QueryMaxOrderVolume.MaxVolume = env->GetIntField(pQueryMaxOrderVolume,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQueryMaxOrderVolume,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QueryMaxOrderVolume.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQueryMaxOrderVolume,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QueryMaxOrderVolume.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQueryMaxOrderVolume(&QueryMaxOrderVolume, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqSettlementInfoConfirm
(JNIEnv * env,jobject obj,jobject pSettlementInfoConfirm,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcSettlementInfoConfirmField;");
	CThostFtdcSettlementInfoConfirmField SettlementInfoConfirm = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pSettlementInfoConfirm,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(SettlementInfoConfirm.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pSettlementInfoConfirm,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(SettlementInfoConfirm.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ConfirmDate", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pSettlementInfoConfirm,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(SettlementInfoConfirm.ConfirmDate, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ConfirmTime", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pSettlementInfoConfirm,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(SettlementInfoConfirm.ConfirmTime, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "SettlementID", "I");
		SettlementInfoConfirm.SettlementID = env->GetIntField(pSettlementInfoConfirm,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pSettlementInfoConfirm,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(SettlementInfoConfirm.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pSettlementInfoConfirm,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(SettlementInfoConfirm.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqSettlementInfoConfirm(&SettlementInfoConfirm, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqRemoveParkedOrder
(JNIEnv * env,jobject obj,jobject pRemoveParkedOrder,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcRemoveParkedOrderField;");
	CThostFtdcRemoveParkedOrderField RemoveParkedOrder = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pRemoveParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(RemoveParkedOrder.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pRemoveParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(RemoveParkedOrder.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ParkedOrderID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pRemoveParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(RemoveParkedOrder.ParkedOrderID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pRemoveParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(RemoveParkedOrder.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqRemoveParkedOrder(&RemoveParkedOrder, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqRemoveParkedOrderAction
(JNIEnv * env,jobject obj,jobject pRemoveParkedOrderAction,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcRemoveParkedOrderActionField;");
	CThostFtdcRemoveParkedOrderActionField RemoveParkedOrderAction = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pRemoveParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(RemoveParkedOrderAction.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pRemoveParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(RemoveParkedOrderAction.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ParkedOrderActionID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pRemoveParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(RemoveParkedOrderAction.ParkedOrderActionID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pRemoveParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(RemoveParkedOrderAction.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqRemoveParkedOrderAction(&RemoveParkedOrderAction, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqExecOrderInsert
(JNIEnv * env,jobject obj,jobject pInputExecOrder,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcInputExecOrderField;");
	CThostFtdcInputExecOrderField InputExecOrder = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrder.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrder.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrder.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExecOrderRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrder.ExecOrderRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrder.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Volume", "I");
		InputExecOrder.Volume = env->GetIntField(pInputExecOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		InputExecOrder.RequestID = env->GetIntField(pInputExecOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BusinessUnit", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrder.BusinessUnit, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OffsetFlag", "C");
		InputExecOrder.OffsetFlag = env->GetCharField(pInputExecOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "HedgeFlag", "C");
		InputExecOrder.HedgeFlag = env->GetCharField(pInputExecOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ActionType", "C");
		InputExecOrder.ActionType = env->GetCharField(pInputExecOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "PosiDirection", "C");
		InputExecOrder.PosiDirection = env->GetCharField(pInputExecOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ReservePositionFlag", "C");
		InputExecOrder.ReservePositionFlag = env->GetCharField(pInputExecOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CloseFlag", "C");
		InputExecOrder.CloseFlag = env->GetCharField(pInputExecOrder,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrder.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrder.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrder.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrder.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrder.ClientID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrder.IPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrder.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqExecOrderInsert(&InputExecOrder, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqExecOrderAction
(JNIEnv * env,jobject obj,jobject pInputExecOrderAction,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcInputExecOrderActionField;");
	CThostFtdcInputExecOrderActionField InputExecOrderAction = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrderAction.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrderAction.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExecOrderActionRef", "I");
		InputExecOrderAction.ExecOrderActionRef = env->GetIntField(pInputExecOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExecOrderRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrderAction.ExecOrderRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		InputExecOrderAction.RequestID = env->GetIntField(pInputExecOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FrontID", "I");
		InputExecOrderAction.FrontID = env->GetIntField(pInputExecOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "SessionID", "I");
		InputExecOrderAction.SessionID = env->GetIntField(pInputExecOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrderAction.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExecOrderSysID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrderAction.ExecOrderSysID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ActionFlag", "C");
		InputExecOrderAction.ActionFlag = env->GetCharField(pInputExecOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrderAction.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrderAction.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrderAction.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrderAction.IPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputExecOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputExecOrderAction.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqExecOrderAction(&InputExecOrderAction, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqForQuoteInsert
(JNIEnv * env,jobject obj,jobject pInputForQuote,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcInputForQuoteField;");
	CThostFtdcInputForQuoteField InputForQuote = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputForQuote.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputForQuote.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputForQuote.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ForQuoteRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputForQuote.ForQuoteRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputForQuote.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputForQuote.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputForQuote.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputForQuote.IPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputForQuote.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqForQuoteInsert(&InputForQuote, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQuoteInsert
(JNIEnv * env,jobject obj,jobject pInputQuote,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcInputQuoteField;");
	CThostFtdcInputQuoteField InputQuote = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "QuoteRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.QuoteRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AskPrice", "D");
		InputQuote.AskPrice = env->GetDoubleField(pInputQuote,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BidPrice", "D");
		InputQuote.BidPrice = env->GetDoubleField(pInputQuote,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AskVolume", "I");
		InputQuote.AskVolume = env->GetIntField(pInputQuote,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BidVolume", "I");
		InputQuote.BidVolume = env->GetIntField(pInputQuote,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		InputQuote.RequestID = env->GetIntField(pInputQuote,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BusinessUnit", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.BusinessUnit, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AskOffsetFlag", "C");
		InputQuote.AskOffsetFlag = env->GetCharField(pInputQuote,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BidOffsetFlag", "C");
		InputQuote.BidOffsetFlag = env->GetCharField(pInputQuote,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AskHedgeFlag", "C");
		InputQuote.AskHedgeFlag = env->GetCharField(pInputQuote,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BidHedgeFlag", "C");
		InputQuote.BidHedgeFlag = env->GetCharField(pInputQuote,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AskOrderRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.AskOrderRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BidOrderRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.BidOrderRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ForQuoteSysID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.ForQuoteSysID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.ClientID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.IPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuote.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQuoteInsert(&InputQuote, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQuoteAction
(JNIEnv * env,jobject obj,jobject pInputQuoteAction,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcInputQuoteActionField;");
	CThostFtdcInputQuoteActionField InputQuoteAction = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuoteAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuoteAction.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuoteAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuoteAction.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "QuoteActionRef", "I");
		InputQuoteAction.QuoteActionRef = env->GetIntField(pInputQuoteAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "QuoteRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuoteAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuoteAction.QuoteRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		InputQuoteAction.RequestID = env->GetIntField(pInputQuoteAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FrontID", "I");
		InputQuoteAction.FrontID = env->GetIntField(pInputQuoteAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "SessionID", "I");
		InputQuoteAction.SessionID = env->GetIntField(pInputQuoteAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuoteAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuoteAction.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "QuoteSysID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuoteAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuoteAction.QuoteSysID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ActionFlag", "C");
		InputQuoteAction.ActionFlag = env->GetCharField(pInputQuoteAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuoteAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuoteAction.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuoteAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuoteAction.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuoteAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuoteAction.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuoteAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuoteAction.ClientID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuoteAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuoteAction.IPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputQuoteAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputQuoteAction.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQuoteAction(&InputQuoteAction, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqBatchOrderAction
(JNIEnv * env,jobject obj,jobject pInputBatchOrderAction,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcInputBatchOrderActionField;");
	CThostFtdcInputBatchOrderActionField InputBatchOrderAction = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputBatchOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputBatchOrderAction.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputBatchOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputBatchOrderAction.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OrderActionRef", "I");
		InputBatchOrderAction.OrderActionRef = env->GetIntField(pInputBatchOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		InputBatchOrderAction.RequestID = env->GetIntField(pInputBatchOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FrontID", "I");
		InputBatchOrderAction.FrontID = env->GetIntField(pInputBatchOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "SessionID", "I");
		InputBatchOrderAction.SessionID = env->GetIntField(pInputBatchOrderAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputBatchOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputBatchOrderAction.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputBatchOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputBatchOrderAction.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputBatchOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputBatchOrderAction.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputBatchOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputBatchOrderAction.IPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputBatchOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputBatchOrderAction.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqBatchOrderAction(&InputBatchOrderAction, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqOptionSelfCloseInsert
(JNIEnv * env,jobject obj,jobject pInputOptionSelfClose,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcInputOptionSelfCloseField;");
	CThostFtdcInputOptionSelfCloseField InputOptionSelfClose = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfClose.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfClose.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfClose.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OptionSelfCloseRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfClose.OptionSelfCloseRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfClose.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Volume", "I");
		InputOptionSelfClose.Volume = env->GetIntField(pInputOptionSelfClose,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		InputOptionSelfClose.RequestID = env->GetIntField(pInputOptionSelfClose,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BusinessUnit", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfClose.BusinessUnit, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "HedgeFlag", "C");
		InputOptionSelfClose.HedgeFlag = env->GetCharField(pInputOptionSelfClose,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OptSelfCloseFlag", "C");
		InputOptionSelfClose.OptSelfCloseFlag = env->GetCharField(pInputOptionSelfClose,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfClose.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfClose.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfClose.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfClose.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfClose.ClientID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfClose.IPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfClose.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqOptionSelfCloseInsert(&InputOptionSelfClose, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqOptionSelfCloseAction
(JNIEnv * env,jobject obj,jobject pInputOptionSelfCloseAction,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcInputOptionSelfCloseActionField;");
	CThostFtdcInputOptionSelfCloseActionField InputOptionSelfCloseAction = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfCloseAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfCloseAction.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfCloseAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfCloseAction.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OptionSelfCloseActionRef", "I");
		InputOptionSelfCloseAction.OptionSelfCloseActionRef = env->GetIntField(pInputOptionSelfCloseAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OptionSelfCloseRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfCloseAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfCloseAction.OptionSelfCloseRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		InputOptionSelfCloseAction.RequestID = env->GetIntField(pInputOptionSelfCloseAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FrontID", "I");
		InputOptionSelfCloseAction.FrontID = env->GetIntField(pInputOptionSelfCloseAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "SessionID", "I");
		InputOptionSelfCloseAction.SessionID = env->GetIntField(pInputOptionSelfCloseAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfCloseAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfCloseAction.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OptionSelfCloseSysID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfCloseAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfCloseAction.OptionSelfCloseSysID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ActionFlag", "C");
		InputOptionSelfCloseAction.ActionFlag = env->GetCharField(pInputOptionSelfCloseAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfCloseAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfCloseAction.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfCloseAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfCloseAction.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfCloseAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfCloseAction.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfCloseAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfCloseAction.IPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputOptionSelfCloseAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputOptionSelfCloseAction.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqOptionSelfCloseAction(&InputOptionSelfCloseAction, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqCombActionInsert
(JNIEnv * env,jobject obj,jobject pInputCombAction,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcInputCombActionField;");
	CThostFtdcInputCombActionField InputCombAction = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputCombAction.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputCombAction.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputCombAction.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CombActionRef", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputCombAction.CombActionRef, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputCombAction.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Direction", "C");
		InputCombAction.Direction = env->GetCharField(pInputCombAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Volume", "I");
		InputCombAction.Volume = env->GetIntField(pInputCombAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CombDirection", "C");
		InputCombAction.CombDirection = env->GetCharField(pInputCombAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "HedgeFlag", "C");
		InputCombAction.HedgeFlag = env->GetCharField(pInputCombAction,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputCombAction.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputCombAction.IPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputCombAction.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pInputCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(InputCombAction.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqCombActionInsert(&InputCombAction, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryOrder
(JNIEnv * env,jobject obj,jobject pQryOrder,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryOrderField;");
	CThostFtdcQryOrderField QryOrder = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOrder.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOrder.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOrder.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOrder.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OrderSysID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOrder.OrderSysID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InsertTimeStart", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOrder.InsertTimeStart, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InsertTimeEnd", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOrder.InsertTimeEnd, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOrder.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryOrder(&QryOrder, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryTrade
(JNIEnv * env,jobject obj,jobject pQryTrade,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryTradeField;");
	CThostFtdcQryTradeField QryTrade = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTrade,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTrade.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTrade,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTrade.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTrade,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTrade.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTrade,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTrade.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTrade,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTrade.TradeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeTimeStart", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTrade,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTrade.TradeTimeStart, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeTimeEnd", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTrade,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTrade.TradeTimeEnd, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTrade,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTrade.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryTrade(&QryTrade, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryInvestorPosition
(JNIEnv * env,jobject obj,jobject pQryInvestorPosition,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorPositionField;");
	CThostFtdcQryInvestorPositionField QryInvestorPosition = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPosition,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPosition.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPosition,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPosition.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPosition,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPosition.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPosition,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPosition.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPosition,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPosition.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryInvestorPosition(&QryInvestorPosition, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryTradingAccount
(JNIEnv * env,jobject obj,jobject pQryTradingAccount,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryTradingAccountField;");
	CThostFtdcQryTradingAccountField QryTradingAccount = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingAccount.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingAccount.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingAccount.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BizType", "C");
		QryTradingAccount.BizType = env->GetCharField(pQryTradingAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingAccount.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryTradingAccount(&QryTradingAccount, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryInvestor
(JNIEnv * env,jobject obj,jobject pQryInvestor,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorField;");
	CThostFtdcQryInvestorField QryInvestor = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestor,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestor.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestor,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestor.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryInvestor(&QryInvestor, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryTradingCode
(JNIEnv * env,jobject obj,jobject pQryTradingCode,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryTradingCodeField;");
	CThostFtdcQryTradingCodeField QryTradingCode = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingCode,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingCode.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingCode,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingCode.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingCode,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingCode.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingCode,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingCode.ClientID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientIDType", "C");
		QryTradingCode.ClientIDType = env->GetCharField(pQryTradingCode,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingCode,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingCode.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryTradingCode(&QryTradingCode, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryInstrumentMarginRate
(JNIEnv * env,jobject obj,jobject pQryInstrumentMarginRate,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentMarginRateField;");
	CThostFtdcQryInstrumentMarginRateField QryInstrumentMarginRate = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrumentMarginRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrumentMarginRate.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrumentMarginRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrumentMarginRate.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrumentMarginRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrumentMarginRate.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "HedgeFlag", "C");
		QryInstrumentMarginRate.HedgeFlag = env->GetCharField(pQryInstrumentMarginRate,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrumentMarginRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrumentMarginRate.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrumentMarginRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrumentMarginRate.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryInstrumentMarginRate(&QryInstrumentMarginRate, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryInstrumentCommissionRate
(JNIEnv * env,jobject obj,jobject pQryInstrumentCommissionRate,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentCommissionRateField;");
	CThostFtdcQryInstrumentCommissionRateField QryInstrumentCommissionRate = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrumentCommissionRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrumentCommissionRate.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrumentCommissionRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrumentCommissionRate.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrumentCommissionRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrumentCommissionRate.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrumentCommissionRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrumentCommissionRate.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrumentCommissionRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrumentCommissionRate.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryInstrumentCommissionRate(&QryInstrumentCommissionRate, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryExchange
(JNIEnv * env,jobject obj,jobject pQryExchange,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeField;");
	CThostFtdcQryExchangeField QryExchange = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExchange,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExchange.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryExchange(&QryExchange, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryProduct
(JNIEnv * env,jobject obj,jobject pQryProduct,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryProductField;");
	CThostFtdcQryProductField QryProduct = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "ProductID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryProduct,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryProduct.ProductID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ProductClass", "C");
		QryProduct.ProductClass = env->GetCharField(pQryProduct,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryProduct,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryProduct.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryProduct(&QryProduct, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryInstrument
(JNIEnv * env,jobject obj,jobject pQryInstrument,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentField;");
	CThostFtdcQryInstrumentField QryInstrument = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrument,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrument.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrument,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrument.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeInstID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrument,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrument.ExchangeInstID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ProductID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrument,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrument.ProductID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryInstrument(&QryInstrument, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryDepthMarketData
(JNIEnv * env,jobject obj,jobject pQryDepthMarketData,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryDepthMarketDataField;");
	CThostFtdcQryDepthMarketDataField QryDepthMarketData = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryDepthMarketData,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryDepthMarketData.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryDepthMarketData,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryDepthMarketData.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryDepthMarketData(&QryDepthMarketData, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQrySettlementInfo
(JNIEnv * env,jobject obj,jobject pQrySettlementInfo,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQrySettlementInfoField;");
	CThostFtdcQrySettlementInfoField QrySettlementInfo = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySettlementInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySettlementInfo.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySettlementInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySettlementInfo.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradingDay", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySettlementInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySettlementInfo.TradingDay, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySettlementInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySettlementInfo.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySettlementInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySettlementInfo.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQrySettlementInfo(&QrySettlementInfo, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryTransferBank
(JNIEnv * env,jobject obj,jobject pQryTransferBank,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryTransferBankField;");
	CThostFtdcQryTransferBankField QryTransferBank = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTransferBank,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTransferBank.BankID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankBrchID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTransferBank,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTransferBank.BankBrchID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryTransferBank(&QryTransferBank, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryInvestorPositionDetail
(JNIEnv * env,jobject obj,jobject pQryInvestorPositionDetail,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorPositionDetailField;");
	CThostFtdcQryInvestorPositionDetailField QryInvestorPositionDetail = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPositionDetail,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPositionDetail.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPositionDetail,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPositionDetail.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPositionDetail,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPositionDetail.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPositionDetail,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPositionDetail.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPositionDetail,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPositionDetail.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryInvestorPositionDetail(&QryInvestorPositionDetail, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryNotice
(JNIEnv * env,jobject obj,jobject pQryNotice,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryNoticeField;");
	CThostFtdcQryNoticeField QryNotice = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryNotice,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryNotice.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryNotice(&QryNotice, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQrySettlementInfoConfirm
(JNIEnv * env,jobject obj,jobject pQrySettlementInfoConfirm,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQrySettlementInfoConfirmField;");
	CThostFtdcQrySettlementInfoConfirmField QrySettlementInfoConfirm = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySettlementInfoConfirm,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySettlementInfoConfirm.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySettlementInfoConfirm,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySettlementInfoConfirm.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySettlementInfoConfirm,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySettlementInfoConfirm.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySettlementInfoConfirm,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySettlementInfoConfirm.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQrySettlementInfoConfirm(&QrySettlementInfoConfirm, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryInvestorPositionCombineDetail
(JNIEnv * env,jobject obj,jobject pQryInvestorPositionCombineDetail,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorPositionCombineDetailField;");
	CThostFtdcQryInvestorPositionCombineDetailField QryInvestorPositionCombineDetail = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPositionCombineDetail,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPositionCombineDetail.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPositionCombineDetail,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPositionCombineDetail.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CombInstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPositionCombineDetail,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPositionCombineDetail.CombInstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPositionCombineDetail,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPositionCombineDetail.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorPositionCombineDetail,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorPositionCombineDetail.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryInvestorPositionCombineDetail(&QryInvestorPositionCombineDetail, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryCFMMCTradingAccountKey
(JNIEnv * env,jobject obj,jobject pQryCFMMCTradingAccountKey,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryCFMMCTradingAccountKeyField;");
	CThostFtdcQryCFMMCTradingAccountKeyField QryCFMMCTradingAccountKey = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryCFMMCTradingAccountKey,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryCFMMCTradingAccountKey.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryCFMMCTradingAccountKey,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryCFMMCTradingAccountKey.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryCFMMCTradingAccountKey(&QryCFMMCTradingAccountKey, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryEWarrantOffset
(JNIEnv * env,jobject obj,jobject pQryEWarrantOffset,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryEWarrantOffsetField;");
	CThostFtdcQryEWarrantOffsetField QryEWarrantOffset = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryEWarrantOffset,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryEWarrantOffset.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryEWarrantOffset,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryEWarrantOffset.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryEWarrantOffset,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryEWarrantOffset.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryEWarrantOffset,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryEWarrantOffset.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryEWarrantOffset,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryEWarrantOffset.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryEWarrantOffset(&QryEWarrantOffset, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryInvestorProductGroupMargin
(JNIEnv * env,jobject obj,jobject pQryInvestorProductGroupMargin,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorProductGroupMarginField;");
	CThostFtdcQryInvestorProductGroupMarginField QryInvestorProductGroupMargin = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorProductGroupMargin,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorProductGroupMargin.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorProductGroupMargin,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorProductGroupMargin.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ProductGroupID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorProductGroupMargin,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorProductGroupMargin.ProductGroupID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "HedgeFlag", "C");
		QryInvestorProductGroupMargin.HedgeFlag = env->GetCharField(pQryInvestorProductGroupMargin,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorProductGroupMargin,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorProductGroupMargin.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestorProductGroupMargin,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestorProductGroupMargin.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryInvestorProductGroupMargin(&QryInvestorProductGroupMargin, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryExchangeMarginRate
(JNIEnv * env,jobject obj,jobject pQryExchangeMarginRate,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeMarginRateField;");
	CThostFtdcQryExchangeMarginRateField QryExchangeMarginRate = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExchangeMarginRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExchangeMarginRate.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExchangeMarginRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExchangeMarginRate.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "HedgeFlag", "C");
		QryExchangeMarginRate.HedgeFlag = env->GetCharField(pQryExchangeMarginRate,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExchangeMarginRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExchangeMarginRate.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryExchangeMarginRate(&QryExchangeMarginRate, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryExchangeMarginRateAdjust
(JNIEnv * env,jobject obj,jobject pQryExchangeMarginRateAdjust,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeMarginRateAdjustField;");
	CThostFtdcQryExchangeMarginRateAdjustField QryExchangeMarginRateAdjust = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExchangeMarginRateAdjust,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExchangeMarginRateAdjust.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExchangeMarginRateAdjust,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExchangeMarginRateAdjust.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "HedgeFlag", "C");
		QryExchangeMarginRateAdjust.HedgeFlag = env->GetCharField(pQryExchangeMarginRateAdjust,fid);
	}

	jint iRtn = ptrApi->ReqQryExchangeMarginRateAdjust(&QryExchangeMarginRateAdjust, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryExchangeRate
(JNIEnv * env,jobject obj,jobject pQryExchangeRate,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeRateField;");
	CThostFtdcQryExchangeRateField QryExchangeRate = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExchangeRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExchangeRate.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FromCurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExchangeRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExchangeRate.FromCurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ToCurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExchangeRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExchangeRate.ToCurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryExchangeRate(&QryExchangeRate, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQrySecAgentACIDMap
(JNIEnv * env,jobject obj,jobject pQrySecAgentACIDMap,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQrySecAgentACIDMapField;");
	CThostFtdcQrySecAgentACIDMapField QrySecAgentACIDMap = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySecAgentACIDMap,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySecAgentACIDMap.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySecAgentACIDMap,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySecAgentACIDMap.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySecAgentACIDMap,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySecAgentACIDMap.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySecAgentACIDMap,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySecAgentACIDMap.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQrySecAgentACIDMap(&QrySecAgentACIDMap, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryProductExchRate
(JNIEnv * env,jobject obj,jobject pQryProductExchRate,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryProductExchRateField;");
	CThostFtdcQryProductExchRateField QryProductExchRate = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "ProductID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryProductExchRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryProductExchRate.ProductID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryProductExchRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryProductExchRate.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryProductExchRate(&QryProductExchRate, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryProductGroup
(JNIEnv * env,jobject obj,jobject pQryProductGroup,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryProductGroupField;");
	CThostFtdcQryProductGroupField QryProductGroup = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "ProductID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryProductGroup,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryProductGroup.ProductID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryProductGroup,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryProductGroup.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryProductGroup(&QryProductGroup, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryMMInstrumentCommissionRate
(JNIEnv * env,jobject obj,jobject pQryMMInstrumentCommissionRate,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryMMInstrumentCommissionRateField;");
	CThostFtdcQryMMInstrumentCommissionRateField QryMMInstrumentCommissionRate = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryMMInstrumentCommissionRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryMMInstrumentCommissionRate.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryMMInstrumentCommissionRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryMMInstrumentCommissionRate.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryMMInstrumentCommissionRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryMMInstrumentCommissionRate.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryMMInstrumentCommissionRate(&QryMMInstrumentCommissionRate, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryMMOptionInstrCommRate
(JNIEnv * env,jobject obj,jobject pQryMMOptionInstrCommRate,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryMMOptionInstrCommRateField;");
	CThostFtdcQryMMOptionInstrCommRateField QryMMOptionInstrCommRate = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryMMOptionInstrCommRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryMMOptionInstrCommRate.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryMMOptionInstrCommRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryMMOptionInstrCommRate.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryMMOptionInstrCommRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryMMOptionInstrCommRate.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryMMOptionInstrCommRate(&QryMMOptionInstrCommRate, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryInstrumentOrderCommRate
(JNIEnv * env,jobject obj,jobject pQryInstrumentOrderCommRate,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentOrderCommRateField;");
	CThostFtdcQryInstrumentOrderCommRateField QryInstrumentOrderCommRate = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrumentOrderCommRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrumentOrderCommRate.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrumentOrderCommRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrumentOrderCommRate.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInstrumentOrderCommRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInstrumentOrderCommRate.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryInstrumentOrderCommRate(&QryInstrumentOrderCommRate, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQrySecAgentTradingAccount
(JNIEnv * env,jobject obj,jobject pQryTradingAccount,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryTradingAccountField;");
	CThostFtdcQryTradingAccountField QryTradingAccount = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingAccount.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingAccount.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingAccount.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BizType", "C");
		QryTradingAccount.BizType = env->GetCharField(pQryTradingAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingAccount.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQrySecAgentTradingAccount(&QryTradingAccount, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQrySecAgentCheckMode
(JNIEnv * env,jobject obj,jobject pQrySecAgentCheckMode,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQrySecAgentCheckModeField;");
	CThostFtdcQrySecAgentCheckModeField QrySecAgentCheckMode = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySecAgentCheckMode,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySecAgentCheckMode.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySecAgentCheckMode,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySecAgentCheckMode.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQrySecAgentCheckMode(&QrySecAgentCheckMode, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQrySecAgentTradeInfo
(JNIEnv * env,jobject obj,jobject pQrySecAgentTradeInfo,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQrySecAgentTradeInfoField;");
	CThostFtdcQrySecAgentTradeInfoField QrySecAgentTradeInfo = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySecAgentTradeInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySecAgentTradeInfo.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerSecAgentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQrySecAgentTradeInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QrySecAgentTradeInfo.BrokerSecAgentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQrySecAgentTradeInfo(&QrySecAgentTradeInfo, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryOptionInstrTradeCost
(JNIEnv * env,jobject obj,jobject pQryOptionInstrTradeCost,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryOptionInstrTradeCostField;");
	CThostFtdcQryOptionInstrTradeCostField QryOptionInstrTradeCost = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionInstrTradeCost,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionInstrTradeCost.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionInstrTradeCost,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionInstrTradeCost.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionInstrTradeCost,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionInstrTradeCost.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "HedgeFlag", "C");
		QryOptionInstrTradeCost.HedgeFlag = env->GetCharField(pQryOptionInstrTradeCost,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InputPrice", "D");
		QryOptionInstrTradeCost.InputPrice = env->GetDoubleField(pQryOptionInstrTradeCost,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UnderlyingPrice", "D");
		QryOptionInstrTradeCost.UnderlyingPrice = env->GetDoubleField(pQryOptionInstrTradeCost,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionInstrTradeCost,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionInstrTradeCost.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionInstrTradeCost,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionInstrTradeCost.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryOptionInstrTradeCost(&QryOptionInstrTradeCost, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryOptionInstrCommRate
(JNIEnv * env,jobject obj,jobject pQryOptionInstrCommRate,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryOptionInstrCommRateField;");
	CThostFtdcQryOptionInstrCommRateField QryOptionInstrCommRate = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionInstrCommRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionInstrCommRate.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionInstrCommRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionInstrCommRate.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionInstrCommRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionInstrCommRate.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionInstrCommRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionInstrCommRate.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionInstrCommRate,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionInstrCommRate.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryOptionInstrCommRate(&QryOptionInstrCommRate, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryExecOrder
(JNIEnv * env,jobject obj,jobject pQryExecOrder,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryExecOrderField;");
	CThostFtdcQryExecOrderField QryExecOrder = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExecOrder.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExecOrder.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExecOrder.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExecOrder.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExecOrderSysID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExecOrder.ExecOrderSysID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InsertTimeStart", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExecOrder.InsertTimeStart, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InsertTimeEnd", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryExecOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryExecOrder.InsertTimeEnd, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryExecOrder(&QryExecOrder, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryForQuote
(JNIEnv * env,jobject obj,jobject pQryForQuote,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryForQuoteField;");
	CThostFtdcQryForQuoteField QryForQuote = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryForQuote.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryForQuote.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryForQuote.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryForQuote.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InsertTimeStart", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryForQuote.InsertTimeStart, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InsertTimeEnd", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryForQuote.InsertTimeEnd, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryForQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryForQuote.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryForQuote(&QryForQuote, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryQuote
(JNIEnv * env,jobject obj,jobject pQryQuote,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryQuoteField;");
	CThostFtdcQryQuoteField QryQuote = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryQuote.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryQuote.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryQuote.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryQuote.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "QuoteSysID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryQuote.QuoteSysID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InsertTimeStart", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryQuote.InsertTimeStart, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InsertTimeEnd", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryQuote.InsertTimeEnd, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryQuote,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryQuote.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryQuote(&QryQuote, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryOptionSelfClose
(JNIEnv * env,jobject obj,jobject pQryOptionSelfClose,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryOptionSelfCloseField;");
	CThostFtdcQryOptionSelfCloseField QryOptionSelfClose = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionSelfClose.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionSelfClose.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionSelfClose.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionSelfClose.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OptionSelfCloseSysID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionSelfClose.OptionSelfCloseSysID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InsertTimeStart", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionSelfClose.InsertTimeStart, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InsertTimeEnd", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryOptionSelfClose,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryOptionSelfClose.InsertTimeEnd, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryOptionSelfClose(&QryOptionSelfClose, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryInvestUnit
(JNIEnv * env,jobject obj,jobject pQryInvestUnit,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestUnitField;");
	CThostFtdcQryInvestUnitField QryInvestUnit = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestUnit,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestUnit.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestUnit,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestUnit.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryInvestUnit,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryInvestUnit.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryInvestUnit(&QryInvestUnit, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryCombInstrumentGuard
(JNIEnv * env,jobject obj,jobject pQryCombInstrumentGuard,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryCombInstrumentGuardField;");
	CThostFtdcQryCombInstrumentGuardField QryCombInstrumentGuard = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryCombInstrumentGuard,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryCombInstrumentGuard.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryCombInstrumentGuard,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryCombInstrumentGuard.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryCombInstrumentGuard,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryCombInstrumentGuard.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryCombInstrumentGuard(&QryCombInstrumentGuard, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryCombAction
(JNIEnv * env,jobject obj,jobject pQryCombAction,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryCombActionField;");
	CThostFtdcQryCombActionField QryCombAction = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryCombAction.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryCombAction.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryCombAction.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryCombAction.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryCombAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryCombAction.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryCombAction(&QryCombAction, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryTransferSerial
(JNIEnv * env,jobject obj,jobject pQryTransferSerial,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryTransferSerialField;");
	CThostFtdcQryTransferSerialField QryTransferSerial = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTransferSerial,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTransferSerial.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTransferSerial,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTransferSerial.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTransferSerial,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTransferSerial.BankID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTransferSerial,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTransferSerial.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryTransferSerial(&QryTransferSerial, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryAccountregister
(JNIEnv * env,jobject obj,jobject pQryAccountregister,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryAccountregisterField;");
	CThostFtdcQryAccountregisterField QryAccountregister = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryAccountregister,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryAccountregister.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryAccountregister,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryAccountregister.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryAccountregister,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryAccountregister.BankID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankBranchID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryAccountregister,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryAccountregister.BankBranchID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryAccountregister,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryAccountregister.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryAccountregister(&QryAccountregister, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryContractBank
(JNIEnv * env,jobject obj,jobject pQryContractBank,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryContractBankField;");
	CThostFtdcQryContractBankField QryContractBank = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryContractBank,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryContractBank.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryContractBank,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryContractBank.BankID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankBrchID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryContractBank,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryContractBank.BankBrchID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryContractBank(&QryContractBank, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryParkedOrder
(JNIEnv * env,jobject obj,jobject pQryParkedOrder,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryParkedOrderField;");
	CThostFtdcQryParkedOrderField QryParkedOrder = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryParkedOrder.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryParkedOrder.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryParkedOrder.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryParkedOrder.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryParkedOrder,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryParkedOrder.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryParkedOrder(&QryParkedOrder, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryParkedOrderAction
(JNIEnv * env,jobject obj,jobject pQryParkedOrderAction,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryParkedOrderActionField;");
	CThostFtdcQryParkedOrderActionField QryParkedOrderAction = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryParkedOrderAction.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryParkedOrderAction.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryParkedOrderAction.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryParkedOrderAction.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryParkedOrderAction,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryParkedOrderAction.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryParkedOrderAction(&QryParkedOrderAction, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryTradingNotice
(JNIEnv * env,jobject obj,jobject pQryTradingNotice,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryTradingNoticeField;");
	CThostFtdcQryTradingNoticeField QryTradingNotice = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingNotice,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingNotice.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingNotice,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingNotice.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryTradingNotice,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryTradingNotice.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryTradingNotice(&QryTradingNotice, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryBrokerTradingParams
(JNIEnv * env,jobject obj,jobject pQryBrokerTradingParams,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerTradingParamsField;");
	CThostFtdcQryBrokerTradingParamsField QryBrokerTradingParams = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryBrokerTradingParams,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryBrokerTradingParams.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryBrokerTradingParams,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryBrokerTradingParams.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryBrokerTradingParams,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryBrokerTradingParams.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryBrokerTradingParams,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryBrokerTradingParams.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryBrokerTradingParams(&QryBrokerTradingParams, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQryBrokerTradingAlgos
(JNIEnv * env,jobject obj,jobject pQryBrokerTradingAlgos,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerTradingAlgosField;");
	CThostFtdcQryBrokerTradingAlgosField QryBrokerTradingAlgos = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryBrokerTradingAlgos,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryBrokerTradingAlgos.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ExchangeID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryBrokerTradingAlgos,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryBrokerTradingAlgos.ExchangeID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstrumentID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQryBrokerTradingAlgos,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QryBrokerTradingAlgos.InstrumentID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQryBrokerTradingAlgos(&QryBrokerTradingAlgos, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQueryCFMMCTradingAccountToken
(JNIEnv * env,jobject obj,jobject pQueryCFMMCTradingAccountToken,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcQueryCFMMCTradingAccountTokenField;");
	CThostFtdcQueryCFMMCTradingAccountTokenField QueryCFMMCTradingAccountToken = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQueryCFMMCTradingAccountToken,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QueryCFMMCTradingAccountToken.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestorID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQueryCFMMCTradingAccountToken,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QueryCFMMCTradingAccountToken.InvestorID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InvestUnitID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pQueryCFMMCTradingAccountToken,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(QueryCFMMCTradingAccountToken.InvestUnitID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQueryCFMMCTradingAccountToken(&QueryCFMMCTradingAccountToken, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqFromBankToFutureByFuture
(JNIEnv * env,jobject obj,jobject pReqTransfer,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcReqTransferField;");
	CThostFtdcReqTransferField ReqTransfer = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeCode", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.TradeCode, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BankID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankBranchID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BankBranchID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerBranchID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BrokerBranchID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeDate", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.TradeDate, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeTime", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.TradeTime, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankSerial", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BankSerial, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "PlateSerial", "I");
		ReqTransfer.PlateSerial = env->GetIntField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LastFragment", "C");
		ReqTransfer.LastFragment = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "SessionID", "I");
		ReqTransfer.SessionID = env->GetIntField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CustomerName", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.CustomerName, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IdCardType", "C");
		ReqTransfer.IdCardType = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IdentifiedCardNo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.IdentifiedCardNo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CustType", "C");
		ReqTransfer.CustType = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankAccount", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BankAccount, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankPassWord", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BankPassWord, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Password", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.Password, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstallID", "I");
		ReqTransfer.InstallID = env->GetIntField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FutureSerial", "I");
		ReqTransfer.FutureSerial = env->GetIntField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "VerifyCertNoFlag", "C");
		ReqTransfer.VerifyCertNoFlag = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeAmount", "D");
		ReqTransfer.TradeAmount = env->GetDoubleField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FutureFetchAmount", "D");
		ReqTransfer.FutureFetchAmount = env->GetDoubleField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FeePayFlag", "C");
		ReqTransfer.FeePayFlag = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CustFee", "D");
		ReqTransfer.CustFee = env->GetDoubleField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerFee", "D");
		ReqTransfer.BrokerFee = env->GetDoubleField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Message", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.Message, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Digest", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.Digest, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankAccType", "C");
		ReqTransfer.BankAccType = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "DeviceID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.DeviceID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankSecuAccType", "C");
		ReqTransfer.BankSecuAccType = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerIDByBank", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BrokerIDByBank, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankSecuAcc", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BankSecuAcc, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankPwdFlag", "C");
		ReqTransfer.BankPwdFlag = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "SecuPwdFlag", "C");
		ReqTransfer.SecuPwdFlag = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OperNo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.OperNo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		ReqTransfer.RequestID = env->GetIntField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TID", "I");
		ReqTransfer.TID = env->GetIntField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TransferStatus", "C");
		ReqTransfer.TransferStatus = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LongCustomerName", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.LongCustomerName, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqFromBankToFutureByFuture(&ReqTransfer, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqFromFutureToBankByFuture
(JNIEnv * env,jobject obj,jobject pReqTransfer,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcReqTransferField;");
	CThostFtdcReqTransferField ReqTransfer = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeCode", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.TradeCode, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BankID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankBranchID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BankBranchID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerBranchID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BrokerBranchID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeDate", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.TradeDate, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeTime", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.TradeTime, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankSerial", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BankSerial, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "PlateSerial", "I");
		ReqTransfer.PlateSerial = env->GetIntField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LastFragment", "C");
		ReqTransfer.LastFragment = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "SessionID", "I");
		ReqTransfer.SessionID = env->GetIntField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CustomerName", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.CustomerName, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IdCardType", "C");
		ReqTransfer.IdCardType = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IdentifiedCardNo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.IdentifiedCardNo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CustType", "C");
		ReqTransfer.CustType = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankAccount", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BankAccount, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankPassWord", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BankPassWord, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Password", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.Password, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstallID", "I");
		ReqTransfer.InstallID = env->GetIntField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FutureSerial", "I");
		ReqTransfer.FutureSerial = env->GetIntField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "VerifyCertNoFlag", "C");
		ReqTransfer.VerifyCertNoFlag = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeAmount", "D");
		ReqTransfer.TradeAmount = env->GetDoubleField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FutureFetchAmount", "D");
		ReqTransfer.FutureFetchAmount = env->GetDoubleField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FeePayFlag", "C");
		ReqTransfer.FeePayFlag = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CustFee", "D");
		ReqTransfer.CustFee = env->GetDoubleField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerFee", "D");
		ReqTransfer.BrokerFee = env->GetDoubleField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Message", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.Message, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Digest", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.Digest, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankAccType", "C");
		ReqTransfer.BankAccType = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "DeviceID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.DeviceID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankSecuAccType", "C");
		ReqTransfer.BankSecuAccType = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerIDByBank", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BrokerIDByBank, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankSecuAcc", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.BankSecuAcc, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankPwdFlag", "C");
		ReqTransfer.BankPwdFlag = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "SecuPwdFlag", "C");
		ReqTransfer.SecuPwdFlag = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OperNo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.OperNo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		ReqTransfer.RequestID = env->GetIntField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TID", "I");
		ReqTransfer.TID = env->GetIntField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TransferStatus", "C");
		ReqTransfer.TransferStatus = env->GetCharField(pReqTransfer,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LongCustomerName", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqTransfer,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqTransfer.LongCustomerName, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqFromFutureToBankByFuture(&ReqTransfer, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcTraderApi_ReqQueryBankAccountMoneyByFuture
(JNIEnv * env,jobject obj,jobject pReqQueryAccount,jint nRequestID)
{
	CThostFtdcTraderApi* ptrApi;
	jclass clazzTraderApi = env->FindClass("Lctp/CThostFtdcTraderApi;");
	jfieldID fidTraderApi = env->GetFieldID(clazzTraderApi, "ptrApi", "J");
	ptrApi = (CThostFtdcTraderApi*)env->GetLongField(obj,fidTraderApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcReqQueryAccountField;");
	CThostFtdcReqQueryAccountField ReqQueryAccount = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeCode", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.TradeCode, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.BankID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankBranchID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.BankBranchID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerBranchID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.BrokerBranchID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeDate", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.TradeDate, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradeTime", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.TradeTime, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankSerial", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.BankSerial, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "PlateSerial", "I");
		ReqQueryAccount.PlateSerial = env->GetIntField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LastFragment", "C");
		ReqQueryAccount.LastFragment = env->GetCharField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "SessionID", "I");
		ReqQueryAccount.SessionID = env->GetIntField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CustomerName", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.CustomerName, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IdCardType", "C");
		ReqQueryAccount.IdCardType = env->GetCharField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "IdentifiedCardNo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.IdentifiedCardNo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CustType", "C");
		ReqQueryAccount.CustType = env->GetCharField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankAccount", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.BankAccount, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankPassWord", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.BankPassWord, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "AccountID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.AccountID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Password", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.Password, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "FutureSerial", "I");
		ReqQueryAccount.FutureSerial = env->GetIntField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InstallID", "I");
		ReqQueryAccount.InstallID = env->GetIntField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "VerifyCertNoFlag", "C");
		ReqQueryAccount.VerifyCertNoFlag = env->GetCharField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "CurrencyID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.CurrencyID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Digest", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.Digest, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankAccType", "C");
		ReqQueryAccount.BankAccType = env->GetCharField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "DeviceID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.DeviceID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankSecuAccType", "C");
		ReqQueryAccount.BankSecuAccType = env->GetCharField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerIDByBank", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.BrokerIDByBank, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankSecuAcc", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.BankSecuAcc, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BankPwdFlag", "C");
		ReqQueryAccount.BankPwdFlag = env->GetCharField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "SecuPwdFlag", "C");
		ReqQueryAccount.SecuPwdFlag = env->GetCharField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OperNo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.OperNo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "RequestID", "I");
		ReqQueryAccount.RequestID = env->GetIntField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "TID", "I");
		ReqQueryAccount.TID = env->GetIntField(pReqQueryAccount,fid);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LongCustomerName", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqQueryAccount,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqQueryAccount.LongCustomerName, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqQueryBankAccountMoneyByFuture(&ReqQueryAccount, ( int ) nRequestID);
	return iRtn;
}
#ifdef __cplusplus
}
#endif
