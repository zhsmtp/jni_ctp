#include <string.h>
#include <jni.h>
#include "ThostFtdcMdApi.h"
jmethodID spi_methodIDs[12];
jmethodID ctp_struct_methodIDs[353];

//jni native methond to construct CThostFtdcMdSpi.java and MyMdSpi
class MyMdSpi: public CThostFtdcMdSpi
{
public:
	JavaVM* jvm;
	jobject jspi;//here the reference should be global from NewGlobalRef()
	MyMdSpi(JavaVM* jvm, jobject jspi):jvm(jvm), jspi(jspi)
	{
	}
	class JWrap
	{
		const MyMdSpi* myspi;
	public:
		JNIEnv *env;
		int env_status;
		JWrap(const MyMdSpi* myspi):myspi(myspi),env(0),env_status(0)
		{
			env_status = myspi->jvm->GetEnv((void**)&env, JNI_VERSION_1_8);
			myspi->jvm->AttachCurrentThread((void**)&env, NULL);
		}

		~JWrap()
		{
			if (JNI_EDETACHED == env_status)
			{
				myspi->jvm->DetachCurrentThread();
			}
		}
		JNIEnv * getEnv() {
			return env;
		}
	};
	void OnFrontConnected()
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		env->CallVoidMethod(jspi,spi_methodIDs[0]);
	}

	void OnFrontDisconnected(int  nReason)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		env->CallVoidMethod(jspi,spi_methodIDs[1],nReason);
	}

	void OnHeartBeatWarning(int  nTimeLapse)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		env->CallVoidMethod(jspi,spi_methodIDs[2],nTimeLapse);
	}

	void OnRspUserLogin(CThostFtdcRspUserLoginField * pRspUserLogin,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspUserLoginField;");
		jobject RspUserLogin = env->AllocObject(jclazz);
		if(pRspUserLogin)
		{
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pRspUserLogin->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pRspUserLogin->TradingDay);
			jbyteArray LoginTime = env->NewByteArray(9);
			if(pRspUserLogin->LoginTime)
				env->SetByteArrayRegion(LoginTime , 0, 9, (const jbyte*)pRspUserLogin->LoginTime);
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pRspUserLogin->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pRspUserLogin->BrokerID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pRspUserLogin->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pRspUserLogin->UserID);
			jbyteArray SystemName = env->NewByteArray(41);
			if(pRspUserLogin->SystemName)
				env->SetByteArrayRegion(SystemName , 0, 41, (const jbyte*)pRspUserLogin->SystemName);
			jbyteArray MaxOrderRef = env->NewByteArray(13);
			if(pRspUserLogin->MaxOrderRef)
				env->SetByteArrayRegion(MaxOrderRef , 0, 13, (const jbyte*)pRspUserLogin->MaxOrderRef);
			jbyteArray SHFETime = env->NewByteArray(9);
			if(pRspUserLogin->SHFETime)
				env->SetByteArrayRegion(SHFETime , 0, 9, (const jbyte*)pRspUserLogin->SHFETime);
			jbyteArray DCETime = env->NewByteArray(9);
			if(pRspUserLogin->DCETime)
				env->SetByteArrayRegion(DCETime , 0, 9, (const jbyte*)pRspUserLogin->DCETime);
			jbyteArray CZCETime = env->NewByteArray(9);
			if(pRspUserLogin->CZCETime)
				env->SetByteArrayRegion(CZCETime , 0, 9, (const jbyte*)pRspUserLogin->CZCETime);
			jbyteArray FFEXTime = env->NewByteArray(9);
			if(pRspUserLogin->FFEXTime)
				env->SetByteArrayRegion(FFEXTime , 0, 9, (const jbyte*)pRspUserLogin->FFEXTime);
			jbyteArray INETime = env->NewByteArray(9);
			if(pRspUserLogin->INETime)
				env->SetByteArrayRegion(INETime , 0, 9, (const jbyte*)pRspUserLogin->INETime);
			RspUserLogin = env->NewObject(jclazz, ctp_struct_methodIDs[2],TradingDay,LoginTime,BrokerID,UserID,SystemName,pRspUserLogin->FrontID,pRspUserLogin->SessionID,MaxOrderRef,SHFETime,DCETime,CZCETime,FFEXTime,INETime);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[3],RspUserLogin, RspInfo, nRequestID, bIsLast);
	}

	void OnRspUserLogout(CThostFtdcUserLogoutField * pUserLogout,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcUserLogoutField;");
		jobject UserLogout = env->AllocObject(jclazz);
		if(pUserLogout)
		{
			jbyteArray BrokerID = env->NewByteArray(11);
			if(pUserLogout->BrokerID)
				env->SetByteArrayRegion(BrokerID , 0, 11, (const jbyte*)pUserLogout->BrokerID);
			jbyteArray UserID = env->NewByteArray(16);
			if(pUserLogout->UserID)
				env->SetByteArrayRegion(UserID , 0, 16, (const jbyte*)pUserLogout->UserID);
			UserLogout = env->NewObject(jclazz, ctp_struct_methodIDs[3],BrokerID,UserID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[4],UserLogout, RspInfo, nRequestID, bIsLast);
	}

	void OnRspError(CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[5],RspInfo, nRequestID, bIsLast);
	}

	void OnRspSubMarketData(CThostFtdcSpecificInstrumentField * pSpecificInstrument,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcSpecificInstrumentField;");
		jobject SpecificInstrument = env->AllocObject(jclazz);
		if(pSpecificInstrument)
		{
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pSpecificInstrument->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pSpecificInstrument->InstrumentID);
			SpecificInstrument = env->NewObject(jclazz, ctp_struct_methodIDs[203],InstrumentID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[6],SpecificInstrument, RspInfo, nRequestID, bIsLast);
	}

	void OnRspUnSubMarketData(CThostFtdcSpecificInstrumentField * pSpecificInstrument,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcSpecificInstrumentField;");
		jobject SpecificInstrument = env->AllocObject(jclazz);
		if(pSpecificInstrument)
		{
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pSpecificInstrument->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pSpecificInstrument->InstrumentID);
			SpecificInstrument = env->NewObject(jclazz, ctp_struct_methodIDs[203],InstrumentID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[7],SpecificInstrument, RspInfo, nRequestID, bIsLast);
	}

	void OnRspSubForQuoteRsp(CThostFtdcSpecificInstrumentField * pSpecificInstrument,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcSpecificInstrumentField;");
		jobject SpecificInstrument = env->AllocObject(jclazz);
		if(pSpecificInstrument)
		{
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pSpecificInstrument->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pSpecificInstrument->InstrumentID);
			SpecificInstrument = env->NewObject(jclazz, ctp_struct_methodIDs[203],InstrumentID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[8],SpecificInstrument, RspInfo, nRequestID, bIsLast);
	}

	void OnRspUnSubForQuoteRsp(CThostFtdcSpecificInstrumentField * pSpecificInstrument,  CThostFtdcRspInfoField * pRspInfo,  int  nRequestID,  bool  bIsLast)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcSpecificInstrumentField;");
		jobject SpecificInstrument = env->AllocObject(jclazz);
		if(pSpecificInstrument)
		{
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pSpecificInstrument->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pSpecificInstrument->InstrumentID);
			SpecificInstrument = env->NewObject(jclazz, ctp_struct_methodIDs[203],InstrumentID);
		}
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
		jobject RspInfo = env->AllocObject(jclazz);
		if(pRspInfo)
		{
			jbyteArray ErrorMsg = env->NewByteArray(81);
			if(pRspInfo->ErrorMsg)
				env->SetByteArrayRegion(ErrorMsg , 0, 81, (const jbyte*)pRspInfo->ErrorMsg);
			RspInfo = env->NewObject(jclazz, ctp_struct_methodIDs[18],pRspInfo->ErrorID,ErrorMsg);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[9],SpecificInstrument, RspInfo, nRequestID, bIsLast);
	}

	void OnRtnDepthMarketData(CThostFtdcDepthMarketDataField * pDepthMarketData)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcDepthMarketDataField;");
		jobject DepthMarketData = env->AllocObject(jclazz);
		if(pDepthMarketData)
		{
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pDepthMarketData->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pDepthMarketData->TradingDay);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pDepthMarketData->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pDepthMarketData->InstrumentID);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pDepthMarketData->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pDepthMarketData->ExchangeID);
			jbyteArray ExchangeInstID = env->NewByteArray(31);
			if(pDepthMarketData->ExchangeInstID)
				env->SetByteArrayRegion(ExchangeInstID , 0, 31, (const jbyte*)pDepthMarketData->ExchangeInstID);
			jbyteArray UpdateTime = env->NewByteArray(9);
			if(pDepthMarketData->UpdateTime)
				env->SetByteArrayRegion(UpdateTime , 0, 9, (const jbyte*)pDepthMarketData->UpdateTime);
			jbyteArray ActionDay = env->NewByteArray(9);
			if(pDepthMarketData->ActionDay)
				env->SetByteArrayRegion(ActionDay , 0, 9, (const jbyte*)pDepthMarketData->ActionDay);
			DepthMarketData = env->NewObject(jclazz, ctp_struct_methodIDs[34],TradingDay,InstrumentID,ExchangeID,ExchangeInstID,pDepthMarketData->LastPrice,pDepthMarketData->PreSettlementPrice,pDepthMarketData->PreClosePrice,pDepthMarketData->PreOpenInterest,pDepthMarketData->OpenPrice,pDepthMarketData->HighestPrice,pDepthMarketData->LowestPrice,pDepthMarketData->Volume,pDepthMarketData->Turnover,pDepthMarketData->OpenInterest,pDepthMarketData->ClosePrice,pDepthMarketData->SettlementPrice,pDepthMarketData->UpperLimitPrice,pDepthMarketData->LowerLimitPrice,pDepthMarketData->PreDelta,pDepthMarketData->CurrDelta,UpdateTime,pDepthMarketData->UpdateMillisec,pDepthMarketData->BidPrice1,pDepthMarketData->BidVolume1,pDepthMarketData->AskPrice1,pDepthMarketData->AskVolume1,pDepthMarketData->BidPrice2,pDepthMarketData->BidVolume2,pDepthMarketData->AskPrice2,pDepthMarketData->AskVolume2,pDepthMarketData->BidPrice3,pDepthMarketData->BidVolume3,pDepthMarketData->AskPrice3,pDepthMarketData->AskVolume3,pDepthMarketData->BidPrice4,pDepthMarketData->BidVolume4,pDepthMarketData->AskPrice4,pDepthMarketData->AskVolume4,pDepthMarketData->BidPrice5,pDepthMarketData->BidVolume5,pDepthMarketData->AskPrice5,pDepthMarketData->AskVolume5,pDepthMarketData->AveragePrice,ActionDay);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[10],DepthMarketData);
	}

	void OnRtnForQuoteRsp(CThostFtdcForQuoteRspField * pForQuoteRsp)
	{
		jclass jclazz;
		JWrap jw(this);
		JNIEnv* env = jw.getEnv();
		jclazz = env->FindClass("Lctp/apistruct/CThostFtdcForQuoteRspField;");
		jobject ForQuoteRsp = env->AllocObject(jclazz);
		if(pForQuoteRsp)
		{
			jbyteArray TradingDay = env->NewByteArray(9);
			if(pForQuoteRsp->TradingDay)
				env->SetByteArrayRegion(TradingDay , 0, 9, (const jbyte*)pForQuoteRsp->TradingDay);
			jbyteArray InstrumentID = env->NewByteArray(31);
			if(pForQuoteRsp->InstrumentID)
				env->SetByteArrayRegion(InstrumentID , 0, 31, (const jbyte*)pForQuoteRsp->InstrumentID);
			jbyteArray ForQuoteSysID = env->NewByteArray(21);
			if(pForQuoteRsp->ForQuoteSysID)
				env->SetByteArrayRegion(ForQuoteSysID , 0, 21, (const jbyte*)pForQuoteRsp->ForQuoteSysID);
			jbyteArray ForQuoteTime = env->NewByteArray(9);
			if(pForQuoteRsp->ForQuoteTime)
				env->SetByteArrayRegion(ForQuoteTime , 0, 9, (const jbyte*)pForQuoteRsp->ForQuoteTime);
			jbyteArray ActionDay = env->NewByteArray(9);
			if(pForQuoteRsp->ActionDay)
				env->SetByteArrayRegion(ActionDay , 0, 9, (const jbyte*)pForQuoteRsp->ActionDay);
			jbyteArray ExchangeID = env->NewByteArray(9);
			if(pForQuoteRsp->ExchangeID)
				env->SetByteArrayRegion(ExchangeID , 0, 9, (const jbyte*)pForQuoteRsp->ExchangeID);
			ForQuoteRsp = env->NewObject(jclazz, ctp_struct_methodIDs[149],TradingDay,InstrumentID,ForQuoteSysID,ForQuoteTime,ActionDay,ExchangeID);
		}
		env->CallVoidMethod(jspi,spi_methodIDs[11],ForQuoteRsp);
	}

};
#ifdef __cplusplus
extern "C" {
#endif
JNIEXPORT jlong JNICALL Java_ctp_CThostFtdcMdSpi_newNativeSpiInstance(JNIEnv *env, jobject obj)
{
	JavaVM* jvm;
	jint ret = env->GetJavaVM(&jvm);
	if(ret!=0) return 0;
	jclass spiClazz = env->FindClass("Lctp/CThostFtdcMdSpi;");
	spi_methodIDs[0] = env->GetMethodID(spiClazz, "OnFrontConnected", "()V");
	spi_methodIDs[1] = env->GetMethodID(spiClazz, "OnFrontDisconnected", "(I)V");
	spi_methodIDs[2] = env->GetMethodID(spiClazz, "OnHeartBeatWarning", "(I)V");
	spi_methodIDs[3] = env->GetMethodID(spiClazz, "OnRspUserLogin", "(Lctp/apistruct/CThostFtdcRspUserLoginField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[4] = env->GetMethodID(spiClazz, "OnRspUserLogout", "(Lctp/apistruct/CThostFtdcUserLogoutField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[5] = env->GetMethodID(spiClazz, "OnRspError", "(Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[6] = env->GetMethodID(spiClazz, "OnRspSubMarketData", "(Lctp/apistruct/CThostFtdcSpecificInstrumentField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[7] = env->GetMethodID(spiClazz, "OnRspUnSubMarketData", "(Lctp/apistruct/CThostFtdcSpecificInstrumentField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[8] = env->GetMethodID(spiClazz, "OnRspSubForQuoteRsp", "(Lctp/apistruct/CThostFtdcSpecificInstrumentField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[9] = env->GetMethodID(spiClazz, "OnRspUnSubForQuoteRsp", "(Lctp/apistruct/CThostFtdcSpecificInstrumentField;Lctp/apistruct/CThostFtdcRspInfoField;IZ)V");
	spi_methodIDs[10] = env->GetMethodID(spiClazz, "OnRtnDepthMarketData", "(Lctp/apistruct/CThostFtdcDepthMarketDataField;)V");
	spi_methodIDs[11] = env->GetMethodID(spiClazz, "OnRtnForQuoteRsp", "(Lctp/apistruct/CThostFtdcForQuoteRspField;)V");
	jclass structClazz;
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcDisseminationField;");
	ctp_struct_methodIDs[0] = env->GetMethodID(structClazz, "<init>", "(SI)V");	/*CThostFtdcDisseminationField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqUserLoginField;");
	ctp_struct_methodIDs[1] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B[B[BI)V");	/*CThostFtdcReqUserLoginField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspUserLoginField;");
	ctp_struct_methodIDs[2] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[B[B[B[B[B[B)V");	/*CThostFtdcRspUserLoginField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserLogoutField;");
	ctp_struct_methodIDs[3] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcUserLogoutField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcForceUserLogoutField;");
	ctp_struct_methodIDs[4] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcForceUserLogoutField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqAuthenticateField;");
	ctp_struct_methodIDs[5] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcReqAuthenticateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspAuthenticateField;");
	ctp_struct_methodIDs[6] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BC)V");	/*CThostFtdcRspAuthenticateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcAuthenticationInfoField;");
	ctp_struct_methodIDs[7] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[BC)V");	/*CThostFtdcAuthenticationInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspUserLogin2Field;");
	ctp_struct_methodIDs[8] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[B[B[B[B[B[B[B)V");	/*CThostFtdcRspUserLogin2Field*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferHeaderField;");
	ctp_struct_methodIDs[9] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B[B[BII)V");	/*CThostFtdcTransferHeaderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferBankToFutureReqField;");
	ctp_struct_methodIDs[10] = env->GetMethodID(structClazz, "<init>", "([BC[BDD)V");	/*CThostFtdcTransferBankToFutureReqField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferBankToFutureRspField;");
	ctp_struct_methodIDs[11] = env->GetMethodID(structClazz, "<init>", "([B[B[BDD[B)V");	/*CThostFtdcTransferBankToFutureRspField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferFutureToBankReqField;");
	ctp_struct_methodIDs[12] = env->GetMethodID(structClazz, "<init>", "([BC[BDD)V");	/*CThostFtdcTransferFutureToBankReqField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferFutureToBankRspField;");
	ctp_struct_methodIDs[13] = env->GetMethodID(structClazz, "<init>", "([B[B[BDD[B)V");	/*CThostFtdcTransferFutureToBankRspField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferQryBankReqField;");
	ctp_struct_methodIDs[14] = env->GetMethodID(structClazz, "<init>", "([BC[B)V");	/*CThostFtdcTransferQryBankReqField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferQryBankRspField;");
	ctp_struct_methodIDs[15] = env->GetMethodID(structClazz, "<init>", "([B[B[BDDD[B)V");	/*CThostFtdcTransferQryBankRspField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferQryDetailReqField;");
	ctp_struct_methodIDs[16] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcTransferQryDetailReqField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferQryDetailRspField;");
	ctp_struct_methodIDs[17] = env->GetMethodID(structClazz, "<init>", "([B[B[BI[B[BI[B[B[B[B[BDC)V");	/*CThostFtdcTransferQryDetailRspField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspInfoField;");
	ctp_struct_methodIDs[18] = env->GetMethodID(structClazz, "<init>", "(I[B)V");	/*CThostFtdcRspInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeField;");
	ctp_struct_methodIDs[19] = env->GetMethodID(structClazz, "<init>", "([B[BC)V");	/*CThostFtdcExchangeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcProductField;");
	ctp_struct_methodIDs[20] = env->GetMethodID(structClazz, "<init>", "([B[B[BCIDIIIICCC[BC[BD)V");	/*CThostFtdcProductField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentField;");
	ctp_struct_methodIDs[21] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCIIIIIIID[B[B[B[B[BCICCDDC[BDCDC)V");	/*CThostFtdcInstrumentField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerField;");
	ctp_struct_methodIDs[22] = env->GetMethodID(structClazz, "<init>", "([B[B[BI)V");	/*CThostFtdcBrokerField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTraderField;");
	ctp_struct_methodIDs[23] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[B)V");	/*CThostFtdcTraderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorField;");
	ctp_struct_methodIDs[24] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BC[BI[B[B[B[B[B[B)V");	/*CThostFtdcInvestorField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingCodeField;");
	ctp_struct_methodIDs[25] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BIC[BC[B)V");	/*CThostFtdcTradingCodeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcPartBrokerField;");
	ctp_struct_methodIDs[26] = env->GetMethodID(structClazz, "<init>", "([B[B[BI)V");	/*CThostFtdcPartBrokerField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSuperUserField;");
	ctp_struct_methodIDs[27] = env->GetMethodID(structClazz, "<init>", "([B[B[BI)V");	/*CThostFtdcSuperUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSuperUserFunctionField;");
	ctp_struct_methodIDs[28] = env->GetMethodID(structClazz, "<init>", "([BC)V");	/*CThostFtdcSuperUserFunctionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorGroupField;");
	ctp_struct_methodIDs[29] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcInvestorGroupField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountField;");
	ctp_struct_methodIDs[30] = env->GetMethodID(structClazz, "<init>", "([B[BDDDDDDDDDDDDDDDDDDDDD[BIDDDDDD[BDDDDDDDDDDDDDDCDD)V");	/*CThostFtdcTradingAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorPositionField;");
	ctp_struct_methodIDs[31] = env->GetMethodID(structClazz, "<init>", "([B[B[BCCCIIIIDDIIDDDDDDDDDDDDDD[BIDDIIIDDIDDIDI[BI[BD)V");	/*CThostFtdcInvestorPositionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentMarginRateField;");
	ctp_struct_methodIDs[32] = env->GetMethodID(structClazz, "<init>", "([BC[B[BCDDDDI[B[B)V");	/*CThostFtdcInstrumentMarginRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentCommissionRateField;");
	ctp_struct_methodIDs[33] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDDDDDD[BC[B)V");	/*CThostFtdcInstrumentCommissionRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcDepthMarketDataField;");
	ctp_struct_methodIDs[34] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BDDDDDDDIDDDDDDDD[BIDIDIDIDIDIDIDIDIDIDID[B)V");	/*CThostFtdcDepthMarketDataField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentTradingRightField;");
	ctp_struct_methodIDs[35] = env->GetMethodID(structClazz, "<init>", "([BC[B[BC)V");	/*CThostFtdcInstrumentTradingRightField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerUserField;");
	ctp_struct_methodIDs[36] = env->GetMethodID(structClazz, "<init>", "([B[B[BCIII)V");	/*CThostFtdcBrokerUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerUserPasswordField;");
	ctp_struct_methodIDs[37] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B)V");	/*CThostFtdcBrokerUserPasswordField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerUserFunctionField;");
	ctp_struct_methodIDs[38] = env->GetMethodID(structClazz, "<init>", "([B[BC)V");	/*CThostFtdcBrokerUserFunctionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTraderOfferField;");
	ctp_struct_methodIDs[39] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[BC[B[B[B[B[B[B[B[B[B[B[B[B)V");	/*CThostFtdcTraderOfferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSettlementInfoField;");
	ctp_struct_methodIDs[40] = env->GetMethodID(structClazz, "<init>", "([BI[B[BI[B[B[B)V");	/*CThostFtdcSettlementInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentMarginRateAdjustField;");
	ctp_struct_methodIDs[41] = env->GetMethodID(structClazz, "<init>", "([BC[B[BCDDDDI)V");	/*CThostFtdcInstrumentMarginRateAdjustField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeMarginRateField;");
	ctp_struct_methodIDs[42] = env->GetMethodID(structClazz, "<init>", "([B[BCDDDD[B)V");	/*CThostFtdcExchangeMarginRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeMarginRateAdjustField;");
	ctp_struct_methodIDs[43] = env->GetMethodID(structClazz, "<init>", "([B[BCDDDDDDDDDDDD)V");	/*CThostFtdcExchangeMarginRateAdjustField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeRateField;");
	ctp_struct_methodIDs[44] = env->GetMethodID(structClazz, "<init>", "([B[BD[BD)V");	/*CThostFtdcExchangeRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSettlementRefField;");
	ctp_struct_methodIDs[45] = env->GetMethodID(structClazz, "<init>", "([BI)V");	/*CThostFtdcSettlementRefField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCurrentTimeField;");
	ctp_struct_methodIDs[46] = env->GetMethodID(structClazz, "<init>", "([B[BI[B)V");	/*CThostFtdcCurrentTimeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCommPhaseField;");
	ctp_struct_methodIDs[47] = env->GetMethodID(structClazz, "<init>", "([BS[B)V");	/*CThostFtdcCommPhaseField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcLoginInfoField;");
	ctp_struct_methodIDs[48] = env->GetMethodID(structClazz, "<init>", "(II[B[B[B[B[B[B[B[B[B[B[B[B[B[B[B[B[B[BI[B[B)V");	/*CThostFtdcLoginInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcLogoutAllField;");
	ctp_struct_methodIDs[49] = env->GetMethodID(structClazz, "<init>", "(II[B)V");	/*CThostFtdcLogoutAllField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcFrontStatusField;");
	ctp_struct_methodIDs[50] = env->GetMethodID(structClazz, "<init>", "(I[B[BI)V");	/*CThostFtdcFrontStatusField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserPasswordUpdateField;");
	ctp_struct_methodIDs[51] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcUserPasswordUpdateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOrderField;");
	ctp_struct_methodIDs[52] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCC[B[BDIC[BCICDCI[BIII[B[B[B[B[B[B[B)V");	/*CThostFtdcInputOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOrderField;");
	ctp_struct_methodIDs[53] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCC[B[BDIC[BCICDCI[BI[B[B[B[B[B[BICI[BI[BCCCII[B[B[B[B[B[B[B[BIII[B[BI[BI[BII[B[B[B[B[B[B)V");	/*CThostFtdcOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeOrderField;");
	ctp_struct_methodIDs[54] = env->GetMethodID(structClazz, "<init>", "(CC[B[BDIC[BCICDCI[BI[B[B[B[B[B[BICI[BI[BCCCII[B[B[B[B[B[B[B[BI[B[B[B)V");	/*CThostFtdcExchangeOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeOrderInsertErrorField;");
	ctp_struct_methodIDs[55] = env->GetMethodID(structClazz, "<init>", "([B[B[BI[BI[B)V");	/*CThostFtdcExchangeOrderInsertErrorField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOrderActionField;");
	ctp_struct_methodIDs[56] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BCDI[B[B[B[B[B)V");	/*CThostFtdcInputOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOrderActionField;");
	ctp_struct_methodIDs[57] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BCDI[B[B[BI[B[B[B[B[BC[B[B[B[B[B[B[B)V");	/*CThostFtdcOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeOrderActionField;");
	ctp_struct_methodIDs[58] = env->GetMethodID(structClazz, "<init>", "([B[BCDI[B[B[BI[B[B[B[B[BC[B[B[B[B)V");	/*CThostFtdcExchangeOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeOrderActionErrorField;");
	ctp_struct_methodIDs[59] = env->GetMethodID(structClazz, "<init>", "([B[B[BI[B[BI[B)V");	/*CThostFtdcExchangeOrderActionErrorField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeTradeField;");
	ctp_struct_methodIDs[60] = env->GetMethodID(structClazz, "<init>", "([B[BC[B[B[BC[BCCDI[B[BCC[B[B[B[BIC)V");	/*CThostFtdcExchangeTradeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradeField;");
	ctp_struct_methodIDs[61] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[BC[B[B[BC[BCCDI[B[BCC[B[B[B[BI[BIIC[B)V");	/*CThostFtdcTradeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserSessionField;");
	ctp_struct_methodIDs[62] = env->GetMethodID(structClazz, "<init>", "(II[B[B[B[B[B[B[B[B[B[B)V");	/*CThostFtdcUserSessionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQueryMaxOrderVolumeField;");
	ctp_struct_methodIDs[63] = env->GetMethodID(structClazz, "<init>", "([B[B[BCCCI[B[B)V");	/*CThostFtdcQueryMaxOrderVolumeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSettlementInfoConfirmField;");
	ctp_struct_methodIDs[64] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[B[B)V");	/*CThostFtdcSettlementInfoConfirmField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncDepositField;");
	ctp_struct_methodIDs[65] = env->GetMethodID(structClazz, "<init>", "([B[B[BDI[B)V");	/*CThostFtdcSyncDepositField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncFundMortgageField;");
	ctp_struct_methodIDs[66] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BD[B)V");	/*CThostFtdcSyncFundMortgageField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerSyncField;");
	ctp_struct_methodIDs[67] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcBrokerSyncField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingInvestorField;");
	ctp_struct_methodIDs[68] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BC[BI[B[B[B[B[B[B)V");	/*CThostFtdcSyncingInvestorField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingTradingCodeField;");
	ctp_struct_methodIDs[69] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BIC)V");	/*CThostFtdcSyncingTradingCodeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingInvestorGroupField;");
	ctp_struct_methodIDs[70] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcSyncingInvestorGroupField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingTradingAccountField;");
	ctp_struct_methodIDs[71] = env->GetMethodID(structClazz, "<init>", "([B[BDDDDDDDDDDDDDDDDDDDDD[BIDDDDDD[BDDDDDDDDDDDDDDDD)V");	/*CThostFtdcSyncingTradingAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingInvestorPositionField;");
	ctp_struct_methodIDs[72] = env->GetMethodID(structClazz, "<init>", "([B[B[BCCCIIIIDDIIDDDDDDDDDDDDDD[BIDDIIIDDIDDIDI[BI[BD)V");	/*CThostFtdcSyncingInvestorPositionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingInstrumentMarginRateField;");
	ctp_struct_methodIDs[73] = env->GetMethodID(structClazz, "<init>", "([BC[B[BCDDDDI)V");	/*CThostFtdcSyncingInstrumentMarginRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingInstrumentCommissionRateField;");
	ctp_struct_methodIDs[74] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDDDDDD)V");	/*CThostFtdcSyncingInstrumentCommissionRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncingInstrumentTradingRightField;");
	ctp_struct_methodIDs[75] = env->GetMethodID(structClazz, "<init>", "([BC[B[BC)V");	/*CThostFtdcSyncingInstrumentTradingRightField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOrderField;");
	ctp_struct_methodIDs[76] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B)V");	/*CThostFtdcQryOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTradeField;");
	ctp_struct_methodIDs[77] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B)V");	/*CThostFtdcQryTradeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorPositionField;");
	ctp_struct_methodIDs[78] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryInvestorPositionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTradingAccountField;");
	ctp_struct_methodIDs[79] = env->GetMethodID(structClazz, "<init>", "([B[B[BC[B)V");	/*CThostFtdcQryTradingAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorField;");
	ctp_struct_methodIDs[80] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryInvestorField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTradingCodeField;");
	ctp_struct_methodIDs[81] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BC[B)V");	/*CThostFtdcQryTradingCodeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorGroupField;");
	ctp_struct_methodIDs[82] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryInvestorGroupField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentMarginRateField;");
	ctp_struct_methodIDs[83] = env->GetMethodID(structClazz, "<init>", "([B[B[BC[B[B)V");	/*CThostFtdcQryInstrumentMarginRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentCommissionRateField;");
	ctp_struct_methodIDs[84] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryInstrumentCommissionRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentTradingRightField;");
	ctp_struct_methodIDs[85] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryInstrumentTradingRightField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerField;");
	ctp_struct_methodIDs[86] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryBrokerField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTraderField;");
	ctp_struct_methodIDs[87] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryTraderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySuperUserFunctionField;");
	ctp_struct_methodIDs[88] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQrySuperUserFunctionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryUserSessionField;");
	ctp_struct_methodIDs[89] = env->GetMethodID(structClazz, "<init>", "(II[B[B)V");	/*CThostFtdcQryUserSessionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryPartBrokerField;");
	ctp_struct_methodIDs[90] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryPartBrokerField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryFrontStatusField;");
	ctp_struct_methodIDs[91] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcQryFrontStatusField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeOrderField;");
	ctp_struct_methodIDs[92] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryExchangeOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOrderActionField;");
	ctp_struct_methodIDs[93] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeOrderActionField;");
	ctp_struct_methodIDs[94] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQryExchangeOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySuperUserField;");
	ctp_struct_methodIDs[95] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQrySuperUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeField;");
	ctp_struct_methodIDs[96] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryExchangeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryProductField;");
	ctp_struct_methodIDs[97] = env->GetMethodID(structClazz, "<init>", "([BC[B)V");	/*CThostFtdcQryProductField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentField;");
	ctp_struct_methodIDs[98] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQryInstrumentField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryDepthMarketDataField;");
	ctp_struct_methodIDs[99] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryDepthMarketDataField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerUserField;");
	ctp_struct_methodIDs[100] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryBrokerUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerUserFunctionField;");
	ctp_struct_methodIDs[101] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryBrokerUserFunctionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTraderOfferField;");
	ctp_struct_methodIDs[102] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryTraderOfferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySyncDepositField;");
	ctp_struct_methodIDs[103] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQrySyncDepositField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySettlementInfoField;");
	ctp_struct_methodIDs[104] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQrySettlementInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeMarginRateField;");
	ctp_struct_methodIDs[105] = env->GetMethodID(structClazz, "<init>", "([B[BC[B)V");	/*CThostFtdcQryExchangeMarginRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeMarginRateAdjustField;");
	ctp_struct_methodIDs[106] = env->GetMethodID(structClazz, "<init>", "([B[BC)V");	/*CThostFtdcQryExchangeMarginRateAdjustField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeRateField;");
	ctp_struct_methodIDs[107] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryExchangeRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySyncFundMortgageField;");
	ctp_struct_methodIDs[108] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQrySyncFundMortgageField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryHisOrderField;");
	ctp_struct_methodIDs[109] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BI)V");	/*CThostFtdcQryHisOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrMiniMarginField;");
	ctp_struct_methodIDs[110] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDCI)V");	/*CThostFtdcOptionInstrMiniMarginField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrMarginAdjustField;");
	ctp_struct_methodIDs[111] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDDDDDDIDD)V");	/*CThostFtdcOptionInstrMarginAdjustField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrCommRateField;");
	ctp_struct_methodIDs[112] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDDDDDDDD[B[B)V");	/*CThostFtdcOptionInstrCommRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrTradeCostField;");
	ctp_struct_methodIDs[113] = env->GetMethodID(structClazz, "<init>", "([B[B[BCDDDDD[B[B)V");	/*CThostFtdcOptionInstrTradeCostField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOptionInstrTradeCostField;");
	ctp_struct_methodIDs[114] = env->GetMethodID(structClazz, "<init>", "([B[B[BCDD[B[B)V");	/*CThostFtdcQryOptionInstrTradeCostField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOptionInstrCommRateField;");
	ctp_struct_methodIDs[115] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryOptionInstrCommRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcIndexPriceField;");
	ctp_struct_methodIDs[116] = env->GetMethodID(structClazz, "<init>", "([B[BD)V");	/*CThostFtdcIndexPriceField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputExecOrderField;");
	ctp_struct_methodIDs[117] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[BCCCCCC[B[B[B[B[B[B[B)V");	/*CThostFtdcInputExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputExecOrderActionField;");
	ctp_struct_methodIDs[118] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[B[B[B)V");	/*CThostFtdcInputExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExecOrderField;");
	ctp_struct_methodIDs[119] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[BCCCCCC[B[B[B[B[B[BICI[BI[B[B[B[BC[BIII[B[B[BI[B[B[B[B[B[B)V");	/*CThostFtdcExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExecOrderActionField;");
	ctp_struct_methodIDs[120] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[BI[B[B[B[B[BC[BC[B[B[B[B[B[B)V");	/*CThostFtdcExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExecOrderField;");
	ctp_struct_methodIDs[121] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B)V");	/*CThostFtdcQryExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeExecOrderField;");
	ctp_struct_methodIDs[122] = env->GetMethodID(structClazz, "<init>", "(II[BCCCCCC[B[B[B[B[B[BICI[BI[B[B[B[BC[BI[B[B[B)V");	/*CThostFtdcExchangeExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeExecOrderField;");
	ctp_struct_methodIDs[123] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryExchangeExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExecOrderActionField;");
	ctp_struct_methodIDs[124] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeExecOrderActionField;");
	ctp_struct_methodIDs[125] = env->GetMethodID(structClazz, "<init>", "([B[BC[B[B[BI[B[B[B[B[BC[BC[B[B[B[BI)V");	/*CThostFtdcExchangeExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeExecOrderActionField;");
	ctp_struct_methodIDs[126] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQryExchangeExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcErrExecOrderField;");
	ctp_struct_methodIDs[127] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[BCCCCCC[B[B[B[B[B[B[BI[B)V");	/*CThostFtdcErrExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryErrExecOrderField;");
	ctp_struct_methodIDs[128] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryErrExecOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcErrExecOrderActionField;");
	ctp_struct_methodIDs[129] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[B[B[BI[B)V");	/*CThostFtdcErrExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryErrExecOrderActionField;");
	ctp_struct_methodIDs[130] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryErrExecOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrTradingRightField;");
	ctp_struct_methodIDs[131] = env->GetMethodID(structClazz, "<init>", "([BC[B[BCC)V");	/*CThostFtdcOptionInstrTradingRightField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOptionInstrTradingRightField;");
	ctp_struct_methodIDs[132] = env->GetMethodID(structClazz, "<init>", "([B[B[BC)V");	/*CThostFtdcQryOptionInstrTradingRightField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputForQuoteField;");
	ctp_struct_methodIDs[133] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B)V");	/*CThostFtdcInputForQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcForQuoteField;");
	ctp_struct_methodIDs[134] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B[B[BI[B[BCII[B[BI[B[B[B)V");	/*CThostFtdcForQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryForQuoteField;");
	ctp_struct_methodIDs[135] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B)V");	/*CThostFtdcQryForQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeForQuoteField;");
	ctp_struct_methodIDs[136] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[BI[B[BC[B[B)V");	/*CThostFtdcExchangeForQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeForQuoteField;");
	ctp_struct_methodIDs[137] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryExchangeForQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputQuoteField;");
	ctp_struct_methodIDs[138] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BDDIII[BCCCC[B[B[B[B[B[B[B[B)V");	/*CThostFtdcInputQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputQuoteActionField;");
	ctp_struct_methodIDs[139] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[B[B[B[B)V");	/*CThostFtdcInputQuoteActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQuoteField;");
	ctp_struct_methodIDs[140] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BDDIII[BCCCC[B[B[B[B[B[BIIC[BI[B[B[B[BC[BI[B[BII[B[B[BI[B[B[B[B[B[B[B[B[B)V");	/*CThostFtdcQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQuoteActionField;");
	ctp_struct_methodIDs[141] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[BI[B[B[B[B[BC[B[B[B[B[B[B[B)V");	/*CThostFtdcQuoteActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryQuoteField;");
	ctp_struct_methodIDs[142] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B)V");	/*CThostFtdcQryQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeQuoteField;");
	ctp_struct_methodIDs[143] = env->GetMethodID(structClazz, "<init>", "(DDIII[BCCCC[B[B[B[B[B[BIIC[BI[B[B[B[BC[BI[B[B[B[B[B[B)V");	/*CThostFtdcExchangeQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeQuoteField;");
	ctp_struct_methodIDs[144] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryExchangeQuoteField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryQuoteActionField;");
	ctp_struct_methodIDs[145] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryQuoteActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeQuoteActionField;");
	ctp_struct_methodIDs[146] = env->GetMethodID(structClazz, "<init>", "([B[BC[B[B[BI[B[B[B[B[BC[B[B[B)V");	/*CThostFtdcExchangeQuoteActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeQuoteActionField;");
	ctp_struct_methodIDs[147] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQryExchangeQuoteActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionInstrDeltaField;");
	ctp_struct_methodIDs[148] = env->GetMethodID(structClazz, "<init>", "([BC[B[BD)V");	/*CThostFtdcOptionInstrDeltaField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcForQuoteRspField;");
	ctp_struct_methodIDs[149] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B)V");	/*CThostFtdcForQuoteRspField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcStrikeOffsetField;");
	ctp_struct_methodIDs[150] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDC)V");	/*CThostFtdcStrikeOffsetField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryStrikeOffsetField;");
	ctp_struct_methodIDs[151] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryStrikeOffsetField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputBatchOrderActionField;");
	ctp_struct_methodIDs[152] = env->GetMethodID(structClazz, "<init>", "([B[BIIII[B[B[B[B[B)V");	/*CThostFtdcInputBatchOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBatchOrderActionField;");
	ctp_struct_methodIDs[153] = env->GetMethodID(structClazz, "<init>", "([B[BIIII[B[B[B[BI[B[B[B[BC[B[B[B[B[B)V");	/*CThostFtdcBatchOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeBatchOrderActionField;");
	ctp_struct_methodIDs[154] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[B[B[B[BC[B[B[B)V");	/*CThostFtdcExchangeBatchOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBatchOrderActionField;");
	ctp_struct_methodIDs[155] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryBatchOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCombInstrumentGuardField;");
	ctp_struct_methodIDs[156] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcCombInstrumentGuardField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCombInstrumentGuardField;");
	ctp_struct_methodIDs[157] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryCombInstrumentGuardField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputCombActionField;");
	ctp_struct_methodIDs[158] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCICC[B[B[B[B)V");	/*CThostFtdcInputCombActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCombActionField;");
	ctp_struct_methodIDs[159] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCICC[B[B[B[B[B[BICI[BIIII[B[B[B[B[B[B[B)V");	/*CThostFtdcCombActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCombActionField;");
	ctp_struct_methodIDs[160] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryCombActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeCombActionField;");
	ctp_struct_methodIDs[161] = env->GetMethodID(structClazz, "<init>", "(CICC[B[B[B[B[B[BICI[BII[B[B[B[B)V");	/*CThostFtdcExchangeCombActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeCombActionField;");
	ctp_struct_methodIDs[162] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryExchangeCombActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcProductExchRateField;");
	ctp_struct_methodIDs[163] = env->GetMethodID(structClazz, "<init>", "([B[BD[B)V");	/*CThostFtdcProductExchRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryProductExchRateField;");
	ctp_struct_methodIDs[164] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryProductExchRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryForQuoteParamField;");
	ctp_struct_methodIDs[165] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryForQuoteParamField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcForQuoteParamField;");
	ctp_struct_methodIDs[166] = env->GetMethodID(structClazz, "<init>", "([B[B[BDD)V");	/*CThostFtdcForQuoteParamField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMMOptionInstrCommRateField;");
	ctp_struct_methodIDs[167] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDDDDDDDD)V");	/*CThostFtdcMMOptionInstrCommRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryMMOptionInstrCommRateField;");
	ctp_struct_methodIDs[168] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryMMOptionInstrCommRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMMInstrumentCommissionRateField;");
	ctp_struct_methodIDs[169] = env->GetMethodID(structClazz, "<init>", "([BC[B[BDDDDDD)V");	/*CThostFtdcMMInstrumentCommissionRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryMMInstrumentCommissionRateField;");
	ctp_struct_methodIDs[170] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryMMInstrumentCommissionRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentOrderCommRateField;");
	ctp_struct_methodIDs[171] = env->GetMethodID(structClazz, "<init>", "([BC[B[BCDD[B[B)V");	/*CThostFtdcInstrumentOrderCommRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentOrderCommRateField;");
	ctp_struct_methodIDs[172] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryInstrumentOrderCommRateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradeParamField;");
	ctp_struct_methodIDs[173] = env->GetMethodID(structClazz, "<init>", "([BC[B[B)V");	/*CThostFtdcTradeParamField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentMarginRateULField;");
	ctp_struct_methodIDs[174] = env->GetMethodID(structClazz, "<init>", "([BC[B[BCDDDD)V");	/*CThostFtdcInstrumentMarginRateULField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcFutureLimitPosiParamField;");
	ctp_struct_methodIDs[175] = env->GetMethodID(structClazz, "<init>", "(C[B[B[BIII)V");	/*CThostFtdcFutureLimitPosiParamField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcLoginForbiddenIPField;");
	ctp_struct_methodIDs[176] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcLoginForbiddenIPField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcIPListField;");
	ctp_struct_methodIDs[177] = env->GetMethodID(structClazz, "<init>", "([BI)V");	/*CThostFtdcIPListField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOptionSelfCloseField;");
	ctp_struct_methodIDs[178] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[BCC[B[B[B[B[B[B[B)V");	/*CThostFtdcInputOptionSelfCloseField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInputOptionSelfCloseActionField;");
	ctp_struct_methodIDs[179] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[B[B[B)V");	/*CThostFtdcInputOptionSelfCloseActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionSelfCloseField;");
	ctp_struct_methodIDs[180] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BII[BCC[B[B[B[B[B[BICI[BI[B[B[B[BC[BIII[B[B[BI[B[B[B[B[B[B)V");	/*CThostFtdcOptionSelfCloseField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOptionSelfCloseActionField;");
	ctp_struct_methodIDs[181] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BC[B[B[BI[B[B[B[B[BC[B[B[B[B[B[B[B)V");	/*CThostFtdcOptionSelfCloseActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOptionSelfCloseField;");
	ctp_struct_methodIDs[182] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B)V");	/*CThostFtdcQryOptionSelfCloseField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeOptionSelfCloseField;");
	ctp_struct_methodIDs[183] = env->GetMethodID(structClazz, "<init>", "(II[BCC[B[B[B[B[B[BICI[BI[B[B[B[BC[BI[B[B[B)V");	/*CThostFtdcExchangeOptionSelfCloseField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryOptionSelfCloseActionField;");
	ctp_struct_methodIDs[184] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryOptionSelfCloseActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeOptionSelfCloseActionField;");
	ctp_struct_methodIDs[185] = env->GetMethodID(structClazz, "<init>", "([B[BC[B[B[BI[B[B[B[B[BC[B[B[B[B[BC)V");	/*CThostFtdcExchangeOptionSelfCloseActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncDelaySwapField;");
	ctp_struct_methodIDs[186] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BDDD[BD)V");	/*CThostFtdcSyncDelaySwapField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySyncDelaySwapField;");
	ctp_struct_methodIDs[187] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQrySyncDelaySwapField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestUnitField;");
	ctp_struct_methodIDs[188] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B)V");	/*CThostFtdcInvestUnitField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestUnitField;");
	ctp_struct_methodIDs[189] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryInvestUnitField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSecAgentCheckModeField;");
	ctp_struct_methodIDs[190] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI)V");	/*CThostFtdcSecAgentCheckModeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSecAgentTradeInfoField;");
	ctp_struct_methodIDs[191] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcSecAgentTradeInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataField;");
	ctp_struct_methodIDs[192] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BDDDDDDDIDDDDDDDD[BI[B)V");	/*CThostFtdcMarketDataField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataBaseField;");
	ctp_struct_methodIDs[193] = env->GetMethodID(structClazz, "<init>", "([BDDDD)V");	/*CThostFtdcMarketDataBaseField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataStaticField;");
	ctp_struct_methodIDs[194] = env->GetMethodID(structClazz, "<init>", "(DDDDDDDD)V");	/*CThostFtdcMarketDataStaticField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataLastMatchField;");
	ctp_struct_methodIDs[195] = env->GetMethodID(structClazz, "<init>", "(DIDD)V");	/*CThostFtdcMarketDataLastMatchField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataBestPriceField;");
	ctp_struct_methodIDs[196] = env->GetMethodID(structClazz, "<init>", "(DIDI)V");	/*CThostFtdcMarketDataBestPriceField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataBid23Field;");
	ctp_struct_methodIDs[197] = env->GetMethodID(structClazz, "<init>", "(DIDI)V");	/*CThostFtdcMarketDataBid23Field*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataAsk23Field;");
	ctp_struct_methodIDs[198] = env->GetMethodID(structClazz, "<init>", "(DIDI)V");	/*CThostFtdcMarketDataAsk23Field*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataBid45Field;");
	ctp_struct_methodIDs[199] = env->GetMethodID(structClazz, "<init>", "(DIDI)V");	/*CThostFtdcMarketDataBid45Field*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataAsk45Field;");
	ctp_struct_methodIDs[200] = env->GetMethodID(structClazz, "<init>", "(DIDI)V");	/*CThostFtdcMarketDataAsk45Field*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataUpdateTimeField;");
	ctp_struct_methodIDs[201] = env->GetMethodID(structClazz, "<init>", "([B[BI[B)V");	/*CThostFtdcMarketDataUpdateTimeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataExchangeField;");
	ctp_struct_methodIDs[202] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcMarketDataExchangeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSpecificInstrumentField;");
	ctp_struct_methodIDs[203] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcSpecificInstrumentField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInstrumentStatusField;");
	ctp_struct_methodIDs[204] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BCI[BC)V");	/*CThostFtdcInstrumentStatusField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInstrumentStatusField;");
	ctp_struct_methodIDs[205] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryInstrumentStatusField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorAccountField;");
	ctp_struct_methodIDs[206] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcInvestorAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcPositionProfitAlgorithmField;");
	ctp_struct_methodIDs[207] = env->GetMethodID(structClazz, "<init>", "([B[BC[B[B)V");	/*CThostFtdcPositionProfitAlgorithmField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcDiscountField;");
	ctp_struct_methodIDs[208] = env->GetMethodID(structClazz, "<init>", "([BC[BD)V");	/*CThostFtdcDiscountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTransferBankField;");
	ctp_struct_methodIDs[209] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryTransferBankField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferBankField;");
	ctp_struct_methodIDs[210] = env->GetMethodID(structClazz, "<init>", "([B[B[BI)V");	/*CThostFtdcTransferBankField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorPositionDetailField;");
	ctp_struct_methodIDs[211] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryInvestorPositionDetailField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorPositionDetailField;");
	ctp_struct_methodIDs[212] = env->GetMethodID(structClazz, "<init>", "([B[B[BCC[B[BID[BIC[B[BDDDDDDDDDDIDI[B)V");	/*CThostFtdcInvestorPositionDetailField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountPasswordField;");
	ctp_struct_methodIDs[213] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcTradingAccountPasswordField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMDTraderOfferField;");
	ctp_struct_methodIDs[214] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[BC[B[B[B[B[B[B[B[B[B[B[B[B)V");	/*CThostFtdcMDTraderOfferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryMDTraderOfferField;");
	ctp_struct_methodIDs[215] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryMDTraderOfferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryNoticeField;");
	ctp_struct_methodIDs[216] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryNoticeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcNoticeField;");
	ctp_struct_methodIDs[217] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcNoticeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserRightField;");
	ctp_struct_methodIDs[218] = env->GetMethodID(structClazz, "<init>", "([B[BCI)V");	/*CThostFtdcUserRightField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySettlementInfoConfirmField;");
	ctp_struct_methodIDs[219] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQrySettlementInfoConfirmField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcLoadSettlementInfoField;");
	ctp_struct_methodIDs[220] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcLoadSettlementInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerWithdrawAlgorithmField;");
	ctp_struct_methodIDs[221] = env->GetMethodID(structClazz, "<init>", "([BCDCCCI[BDC)V");	/*CThostFtdcBrokerWithdrawAlgorithmField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountPasswordUpdateV1Field;");
	ctp_struct_methodIDs[222] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcTradingAccountPasswordUpdateV1Field*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountPasswordUpdateField;");
	ctp_struct_methodIDs[223] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcTradingAccountPasswordUpdateField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCombinationLegField;");
	ctp_struct_methodIDs[224] = env->GetMethodID(structClazz, "<init>", "([BI[B)V");	/*CThostFtdcQryCombinationLegField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySyncStatusField;");
	ctp_struct_methodIDs[225] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQrySyncStatusField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCombinationLegField;");
	ctp_struct_methodIDs[226] = env->GetMethodID(structClazz, "<init>", "([BI[BCII)V");	/*CThostFtdcCombinationLegField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSyncStatusField;");
	ctp_struct_methodIDs[227] = env->GetMethodID(structClazz, "<init>", "([BC)V");	/*CThostFtdcSyncStatusField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryLinkManField;");
	ctp_struct_methodIDs[228] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryLinkManField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcLinkManField;");
	ctp_struct_methodIDs[229] = env->GetMethodID(structClazz, "<init>", "([B[BCC[B[B[B[B[BI[B[B)V");	/*CThostFtdcLinkManField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerUserEventField;");
	ctp_struct_methodIDs[230] = env->GetMethodID(structClazz, "<init>", "([B[BC)V");	/*CThostFtdcQryBrokerUserEventField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerUserEventField;");
	ctp_struct_methodIDs[231] = env->GetMethodID(structClazz, "<init>", "([B[BCI[B[B[B[B[B)V");	/*CThostFtdcBrokerUserEventField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryContractBankField;");
	ctp_struct_methodIDs[232] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryContractBankField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcContractBankField;");
	ctp_struct_methodIDs[233] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcContractBankField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorPositionCombineDetailField;");
	ctp_struct_methodIDs[234] = env->GetMethodID(structClazz, "<init>", "([B[B[BI[B[B[B[B[BCCIDDDDII[BI[B)V");	/*CThostFtdcInvestorPositionCombineDetailField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcParkedOrderField;");
	ctp_struct_methodIDs[235] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCC[B[BDIC[BCICDCI[BII[B[BCCI[BI[B[B[B[B[B[B)V");	/*CThostFtdcParkedOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcParkedOrderActionField;");
	ctp_struct_methodIDs[236] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BCDI[B[B[BCCI[B[B[B[B)V");	/*CThostFtdcParkedOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryParkedOrderField;");
	ctp_struct_methodIDs[237] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryParkedOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryParkedOrderActionField;");
	ctp_struct_methodIDs[238] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryParkedOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRemoveParkedOrderField;");
	ctp_struct_methodIDs[239] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcRemoveParkedOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRemoveParkedOrderActionField;");
	ctp_struct_methodIDs[240] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcRemoveParkedOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorWithdrawAlgorithmField;");
	ctp_struct_methodIDs[241] = env->GetMethodID(structClazz, "<init>", "([BC[BD[BD)V");	/*CThostFtdcInvestorWithdrawAlgorithmField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorPositionCombineDetailField;");
	ctp_struct_methodIDs[242] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryInvestorPositionCombineDetailField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarketDataAveragePriceField;");
	ctp_struct_methodIDs[243] = env->GetMethodID(structClazz, "<init>", "(D)V");	/*CThostFtdcMarketDataAveragePriceField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcVerifyInvestorPasswordField;");
	ctp_struct_methodIDs[244] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcVerifyInvestorPasswordField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserIPField;");
	ctp_struct_methodIDs[245] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcUserIPField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingNoticeInfoField;");
	ctp_struct_methodIDs[246] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BSI[B)V");	/*CThostFtdcTradingNoticeInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingNoticeField;");
	ctp_struct_methodIDs[247] = env->GetMethodID(structClazz, "<init>", "([BC[BS[B[BI[B[B)V");	/*CThostFtdcTradingNoticeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTradingNoticeField;");
	ctp_struct_methodIDs[248] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryTradingNoticeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryErrOrderField;");
	ctp_struct_methodIDs[249] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryErrOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcErrOrderField;");
	ctp_struct_methodIDs[250] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCC[B[BDIC[BCICDCI[BIII[BI[B[B[B[B[B[B[B)V");	/*CThostFtdcErrOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcErrorConditionalOrderField;");
	ctp_struct_methodIDs[251] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCC[B[BDIC[BCICDCI[BI[B[B[B[B[B[BICI[BI[BCCCII[B[B[B[B[B[B[B[BIII[B[BI[BI[BII[BI[B[B[B[B[B[B)V");	/*CThostFtdcErrorConditionalOrderField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryErrOrderActionField;");
	ctp_struct_methodIDs[252] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryErrOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcErrOrderActionField;");
	ctp_struct_methodIDs[253] = env->GetMethodID(structClazz, "<init>", "([B[BI[BIII[B[BCDI[B[B[BI[B[B[B[B[BC[B[B[B[B[B[B[BI[B)V");	/*CThostFtdcErrOrderActionField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryExchangeSequenceField;");
	ctp_struct_methodIDs[254] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryExchangeSequenceField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcExchangeSequenceField;");
	ctp_struct_methodIDs[255] = env->GetMethodID(structClazz, "<init>", "([BIC)V");	/*CThostFtdcExchangeSequenceField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQueryMaxOrderVolumeWithPriceField;");
	ctp_struct_methodIDs[256] = env->GetMethodID(structClazz, "<init>", "([B[B[BCCCID[B[B)V");	/*CThostFtdcQueryMaxOrderVolumeWithPriceField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerTradingParamsField;");
	ctp_struct_methodIDs[257] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQryBrokerTradingParamsField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerTradingParamsField;");
	ctp_struct_methodIDs[258] = env->GetMethodID(structClazz, "<init>", "([B[BCCC[BC[B)V");	/*CThostFtdcBrokerTradingParamsField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBrokerTradingAlgosField;");
	ctp_struct_methodIDs[259] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQryBrokerTradingAlgosField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerTradingAlgosField;");
	ctp_struct_methodIDs[260] = env->GetMethodID(structClazz, "<init>", "([B[B[BCCC)V");	/*CThostFtdcBrokerTradingAlgosField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQueryBrokerDepositField;");
	ctp_struct_methodIDs[261] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQueryBrokerDepositField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerDepositField;");
	ctp_struct_methodIDs[262] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BDDDDDDDDD)V");	/*CThostFtdcBrokerDepositField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCFMMCBrokerKeyField;");
	ctp_struct_methodIDs[263] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryCFMMCBrokerKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCFMMCBrokerKeyField;");
	ctp_struct_methodIDs[264] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BI[BC)V");	/*CThostFtdcCFMMCBrokerKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCFMMCTradingAccountKeyField;");
	ctp_struct_methodIDs[265] = env->GetMethodID(structClazz, "<init>", "([B[B[BI[B)V");	/*CThostFtdcCFMMCTradingAccountKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCFMMCTradingAccountKeyField;");
	ctp_struct_methodIDs[266] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryCFMMCTradingAccountKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerUserOTPParamField;");
	ctp_struct_methodIDs[267] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BIIC)V");	/*CThostFtdcBrokerUserOTPParamField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcManualSyncBrokerUserOTPField;");
	ctp_struct_methodIDs[268] = env->GetMethodID(structClazz, "<init>", "([B[BC[B[B)V");	/*CThostFtdcManualSyncBrokerUserOTPField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCommRateModelField;");
	ctp_struct_methodIDs[269] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcCommRateModelField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCommRateModelField;");
	ctp_struct_methodIDs[270] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryCommRateModelField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMarginModelField;");
	ctp_struct_methodIDs[271] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcMarginModelField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryMarginModelField;");
	ctp_struct_methodIDs[272] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryMarginModelField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcEWarrantOffsetField;");
	ctp_struct_methodIDs[273] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[BCCI[B)V");	/*CThostFtdcEWarrantOffsetField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryEWarrantOffsetField;");
	ctp_struct_methodIDs[274] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryEWarrantOffsetField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryInvestorProductGroupMarginField;");
	ctp_struct_methodIDs[275] = env->GetMethodID(structClazz, "<init>", "([B[B[BC[B[B)V");	/*CThostFtdcQryInvestorProductGroupMarginField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcInvestorProductGroupMarginField;");
	ctp_struct_methodIDs[276] = env->GetMethodID(structClazz, "<init>", "([B[B[B[BIDDDDDDDDDDDDDDDDDDDDDC[B[B)V");	/*CThostFtdcInvestorProductGroupMarginField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQueryCFMMCTradingAccountTokenField;");
	ctp_struct_methodIDs[277] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcQueryCFMMCTradingAccountTokenField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCFMMCTradingAccountTokenField;");
	ctp_struct_methodIDs[278] = env->GetMethodID(structClazz, "<init>", "([B[B[BI[B)V");	/*CThostFtdcCFMMCTradingAccountTokenField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryProductGroupField;");
	ctp_struct_methodIDs[279] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryProductGroupField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcProductGroupField;");
	ctp_struct_methodIDs[280] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcProductGroupField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBulletinField;");
	ctp_struct_methodIDs[281] = env->GetMethodID(structClazz, "<init>", "([B[BII[BC[B[B[B[B[B[B)V");	/*CThostFtdcBulletinField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryBulletinField;");
	ctp_struct_methodIDs[282] = env->GetMethodID(structClazz, "<init>", "([BII[BC)V");	/*CThostFtdcQryBulletinField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqOpenAccountField;");
	ctp_struct_methodIDs[283] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[B[B[BIC[BC[BC[BC[B[BCC[BI[B[B)V");	/*CThostFtdcReqOpenAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqCancelAccountField;");
	ctp_struct_methodIDs[284] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[B[B[BIC[BC[BC[BC[B[BCC[BI[B[B)V");	/*CThostFtdcReqCancelAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqChangeAccountField;");
	ctp_struct_methodIDs[285] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[B[B[B[B[BCIC[B[BCCI[B[B)V");	/*CThostFtdcReqChangeAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqTransferField;");
	ctp_struct_methodIDs[286] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[BDDCDD[B[BC[BC[B[BCC[BIIC[B)V");	/*CThostFtdcReqTransferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspTransferField;");
	ctp_struct_methodIDs[287] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[BDDCDD[B[BC[BC[B[BCC[BIICI[B[B)V");	/*CThostFtdcRspTransferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqRepealField;");
	ctp_struct_methodIDs[288] = env->GetMethodID(structClazz, "<init>", "(IICCI[BI[B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[BDDCDD[B[BC[BC[B[BCC[BIIC[B)V");	/*CThostFtdcReqRepealField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspRepealField;");
	ctp_struct_methodIDs[289] = env->GetMethodID(structClazz, "<init>", "(IICCI[BI[B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[BDDCDD[B[BC[BC[B[BCC[BIICI[B[B)V");	/*CThostFtdcRspRepealField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqQueryAccountField;");
	ctp_struct_methodIDs[290] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[B[BC[BC[B[BCC[BII[B)V");	/*CThostFtdcReqQueryAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspQueryAccountField;");
	ctp_struct_methodIDs[291] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[B[BC[BC[B[BCC[BIIDD[B)V");	/*CThostFtdcRspQueryAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcFutureSignIOField;");
	ctp_struct_methodIDs[292] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[B[BII)V");	/*CThostFtdcFutureSignIOField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspFutureSignInField;");
	ctp_struct_methodIDs[293] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[B[BIII[B[B[B)V");	/*CThostFtdcRspFutureSignInField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqFutureSignOutField;");
	ctp_struct_methodIDs[294] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[B[BII)V");	/*CThostFtdcReqFutureSignOutField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspFutureSignOutField;");
	ctp_struct_methodIDs[295] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[B[BIII[B)V");	/*CThostFtdcRspFutureSignOutField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqQueryTradeResultBySerialField;");
	ctp_struct_methodIDs[296] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICIIC[B[BC[BC[B[B[B[B[BD[B[B)V");	/*CThostFtdcReqQueryTradeResultBySerialField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspQueryTradeResultBySerialField;");
	ctp_struct_methodIDs[297] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[BIC[B[B[B[B[B[B[B[BD[B)V");	/*CThostFtdcRspQueryTradeResultBySerialField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqDayEndFileReadyField;");
	ctp_struct_methodIDs[298] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICIC[B)V");	/*CThostFtdcReqDayEndFileReadyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReturnResultField;");
	ctp_struct_methodIDs[299] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcReturnResultField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcVerifyFuturePasswordField;");
	ctp_struct_methodIDs[300] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[B[B[B[BII[B)V");	/*CThostFtdcVerifyFuturePasswordField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcVerifyCustInfoField;");
	ctp_struct_methodIDs[301] = env->GetMethodID(structClazz, "<init>", "([BC[BC[B)V");	/*CThostFtdcVerifyCustInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcVerifyFuturePasswordAndCustInfoField;");
	ctp_struct_methodIDs[302] = env->GetMethodID(structClazz, "<init>", "([BC[BC[B[B[B[B)V");	/*CThostFtdcVerifyFuturePasswordAndCustInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcDepositResultInformField;");
	ctp_struct_methodIDs[303] = env->GetMethodID(structClazz, "<init>", "([B[B[BDI[B[B)V");	/*CThostFtdcDepositResultInformField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqSyncKeyField;");
	ctp_struct_methodIDs[304] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[BII)V");	/*CThostFtdcReqSyncKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspSyncKeyField;");
	ctp_struct_methodIDs[305] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[BIII[B)V");	/*CThostFtdcRspSyncKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcNotifyQueryAccountField;");
	ctp_struct_methodIDs[306] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[B[B[B[BII[BC[B[BC[BC[B[BCC[BIIDDI[B[B)V");	/*CThostFtdcNotifyQueryAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTransferSerialField;");
	ctp_struct_methodIDs[307] = env->GetMethodID(structClazz, "<init>", "(I[B[B[B[BI[B[BC[B[B[B[BC[B[BIC[B[BDDDC[B[BI[B)V");	/*CThostFtdcTransferSerialField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryTransferSerialField;");
	ctp_struct_methodIDs[308] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQryTransferSerialField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcNotifyFutureSignInField;");
	ctp_struct_methodIDs[309] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[B[BIII[B[B[B)V");	/*CThostFtdcNotifyFutureSignInField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcNotifyFutureSignOutField;");
	ctp_struct_methodIDs[310] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[B[BIII[B)V");	/*CThostFtdcNotifyFutureSignOutField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcNotifySyncKeyField;");
	ctp_struct_methodIDs[311] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICII[B[B[B[B[BIII[B)V");	/*CThostFtdcNotifySyncKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryAccountregisterField;");
	ctp_struct_methodIDs[312] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcQryAccountregisterField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcAccountregisterField;");
	ctp_struct_methodIDs[313] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[BC[B[B[BC[B[BICC[B)V");	/*CThostFtdcAccountregisterField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcOpenAccountField;");
	ctp_struct_methodIDs[314] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[B[B[BIC[BC[BC[BC[B[BCC[BI[BI[B[B)V");	/*CThostFtdcOpenAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCancelAccountField;");
	ctp_struct_methodIDs[315] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[B[B[BIC[BC[BC[BC[B[BCC[BI[BI[B[B)V");	/*CThostFtdcCancelAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcChangeAccountField;");
	ctp_struct_methodIDs[316] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[B[B[B[B[BCIC[B[BCCI[BI[B[B)V");	/*CThostFtdcChangeAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcSecAgentACIDMapField;");
	ctp_struct_methodIDs[317] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B)V");	/*CThostFtdcSecAgentACIDMapField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySecAgentACIDMapField;");
	ctp_struct_methodIDs[318] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B)V");	/*CThostFtdcQrySecAgentACIDMapField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserRightsAssignField;");
	ctp_struct_methodIDs[319] = env->GetMethodID(structClazz, "<init>", "([B[BI)V");	/*CThostFtdcUserRightsAssignField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcBrokerUserRightAssignField;");
	ctp_struct_methodIDs[320] = env->GetMethodID(structClazz, "<init>", "([BII)V");	/*CThostFtdcBrokerUserRightAssignField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcDRTransferField;");
	ctp_struct_methodIDs[321] = env->GetMethodID(structClazz, "<init>", "(II[B[B)V");	/*CThostFtdcDRTransferField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcFensUserInfoField;");
	ctp_struct_methodIDs[322] = env->GetMethodID(structClazz, "<init>", "([B[BC)V");	/*CThostFtdcFensUserInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCurrTransferIdentityField;");
	ctp_struct_methodIDs[323] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcCurrTransferIdentityField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcLoginForbiddenUserField;");
	ctp_struct_methodIDs[324] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcLoginForbiddenUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryLoginForbiddenUserField;");
	ctp_struct_methodIDs[325] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryLoginForbiddenUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcMulticastGroupInfoField;");
	ctp_struct_methodIDs[326] = env->GetMethodID(structClazz, "<init>", "([BI[B)V");	/*CThostFtdcMulticastGroupInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcTradingAccountReserveField;");
	ctp_struct_methodIDs[327] = env->GetMethodID(structClazz, "<init>", "([B[BD[B)V");	/*CThostFtdcTradingAccountReserveField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryLoginForbiddenIPField;");
	ctp_struct_methodIDs[328] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryLoginForbiddenIPField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryIPListField;");
	ctp_struct_methodIDs[329] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcQryIPListField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryUserRightsAssignField;");
	ctp_struct_methodIDs[330] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQryUserRightsAssignField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReserveOpenAccountConfirmField;");
	ctp_struct_methodIDs[331] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[BIC[B[BC[BI[B[B[B[B[BI[B)V");	/*CThostFtdcReserveOpenAccountConfirmField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReserveOpenAccountField;");
	ctp_struct_methodIDs[332] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[BICI[BC[BC[BC[B[B[B[B[B[BC[B[BIC[B[BC[BICI[B)V");	/*CThostFtdcReserveOpenAccountField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcAccountPropertyField;");
	ctp_struct_methodIDs[333] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[BIC[B[B[B[B[B[B)V");	/*CThostFtdcAccountPropertyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQryCurrDRIdentityField;");
	ctp_struct_methodIDs[334] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcQryCurrDRIdentityField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcCurrDRIdentityField;");
	ctp_struct_methodIDs[335] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcCurrDRIdentityField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySecAgentCheckModeField;");
	ctp_struct_methodIDs[336] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQrySecAgentCheckModeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQrySecAgentTradeInfoField;");
	ctp_struct_methodIDs[337] = env->GetMethodID(structClazz, "<init>", "([B[B)V");	/*CThostFtdcQrySecAgentTradeInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcUserSystemInfoField;");
	ctp_struct_methodIDs[338] = env->GetMethodID(structClazz, "<init>", "([B[BI[B[BI[B[B)V");	/*CThostFtdcUserSystemInfoField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqUserAuthMethodField;");
	ctp_struct_methodIDs[339] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcReqUserAuthMethodField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspUserAuthMethodField;");
	ctp_struct_methodIDs[340] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcRspUserAuthMethodField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqGenUserCaptchaField;");
	ctp_struct_methodIDs[341] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcReqGenUserCaptchaField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspGenUserCaptchaField;");
	ctp_struct_methodIDs[342] = env->GetMethodID(structClazz, "<init>", "([B[BI[B)V");	/*CThostFtdcRspGenUserCaptchaField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqGenUserTextField;");
	ctp_struct_methodIDs[343] = env->GetMethodID(structClazz, "<init>", "([B[B[B)V");	/*CThostFtdcReqGenUserTextField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspGenUserTextField;");
	ctp_struct_methodIDs[344] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcRspGenUserTextField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqUserLoginWithCaptchaField;");
	ctp_struct_methodIDs[345] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B[B[BI)V");	/*CThostFtdcReqUserLoginWithCaptchaField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqUserLoginWithTextField;");
	ctp_struct_methodIDs[346] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B[B[BI)V");	/*CThostFtdcReqUserLoginWithTextField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqUserLoginWithOTPField;");
	ctp_struct_methodIDs[347] = env->GetMethodID(structClazz, "<init>", "([B[B[B[B[B[B[B[B[B[B[BI)V");	/*CThostFtdcReqUserLoginWithOTPField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqApiHandshakeField;");
	ctp_struct_methodIDs[348] = env->GetMethodID(structClazz, "<init>", "([B)V");	/*CThostFtdcReqApiHandshakeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcRspApiHandshakeField;");
	ctp_struct_methodIDs[349] = env->GetMethodID(structClazz, "<init>", "(I[BI)V");	/*CThostFtdcRspApiHandshakeField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcReqVerifyApiKeyField;");
	ctp_struct_methodIDs[350] = env->GetMethodID(structClazz, "<init>", "(I[B)V");	/*CThostFtdcReqVerifyApiKeyField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcDepartmentUserField;");
	ctp_struct_methodIDs[351] = env->GetMethodID(structClazz, "<init>", "([B[BC[B)V");	/*CThostFtdcDepartmentUserField*/
	structClazz = env->FindClass("Lctp/apistruct/CThostFtdcQueryFreqField;");
	ctp_struct_methodIDs[352] = env->GetMethodID(structClazz, "<init>", "(I)V");	/*CThostFtdcQueryFreqField*/
	jobject global_java_spi_ref = env->NewGlobalRef(obj);
	MyMdSpi * ptrSpi = new MyMdSpi(jvm, global_java_spi_ref);
	return (jlong) ptrSpi;
}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcMdSpi_deleteNativeSpiInstance(JNIEnv *env, jobject obj, jlong ptrSpi)
{
	MyMdSpi * ptrSpi2beDel = (MyMdSpi *)ptrSpi;
	if(ptrSpi) {env->DeleteGlobalRef(ptrSpi2beDel->jspi); delete ptrSpi2beDel;ptrSpi2beDel=NULL;}
}
#ifdef __cplusplus
}
#endif
#ifdef __cplusplus
extern "C" {
#endif
JNIEXPORT jobject JNICALL Java_ctp_CThostFtdcMdApi_CreateFtdcMdApi
(JNIEnv * env,jclass obj,jstring pszFlowPath,jboolean bIsUsingUdp,jboolean bIsMulticast)
{
	const char* cstr = env->GetStringUTFChars(pszFlowPath,NULL);
	CThostFtdcMdApi* ptrApi;
	jobject javaApiRtn;
	jmethodID methodID = env->GetMethodID(obj,"<init>","(J)V");
	ptrApi = CThostFtdcMdApi::CreateFtdcMdApi((char*)cstr, (bool ) bIsUsingUdp, (bool ) bIsMulticast);
	env->ReleaseStringUTFChars(pszFlowPath,cstr);
	javaApiRtn = env->NewObject(obj, methodID, (jlong)ptrApi);
	return javaApiRtn;

}
JNIEXPORT jstring JNICALL Java_ctp_CThostFtdcMdApi_GetApiVersion
(JNIEnv * env,jclass obj)
{

	jstring jstrRtn;
	const char* c_str = CThostFtdcMdApi::GetApiVersion();
	jstrRtn = env->NewStringUTF(c_str);
	return jstrRtn;
}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcMdApi_Release
(JNIEnv * env,jobject obj)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);

	ptrApi->Release();

}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcMdApi_Init
(JNIEnv * env,jobject obj)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);

	ptrApi->Init();

}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcMdApi_Join
(JNIEnv * env,jobject obj)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);

	jint iRtn = ptrApi->Join();
	return iRtn;
}
JNIEXPORT jstring JNICALL Java_ctp_CThostFtdcMdApi_GetTradingDay
(JNIEnv * env,jobject obj)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);

	jstring jstrRtn;
	const char* c_str = ptrApi->GetTradingDay();
	jstrRtn = env->NewStringUTF(c_str);
	return jstrRtn;
}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcMdApi_RegisterFront
(JNIEnv * env,jobject obj,jstring pszFrontAddress)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);
	const char* cstr = env->GetStringUTFChars(pszFrontAddress,NULL);
	ptrApi->RegisterFront((char*)cstr);
	env->ReleaseStringUTFChars(pszFrontAddress,cstr);

}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcMdApi_RegisterNameServer
(JNIEnv * env,jobject obj,jstring pszNsAddress)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);
	const char* cstr = env->GetStringUTFChars(pszNsAddress,NULL);
	ptrApi->RegisterNameServer((char*)cstr);
	env->ReleaseStringUTFChars(pszNsAddress,cstr);

}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcMdApi_RegisterFensUserInfo
(JNIEnv * env,jobject obj,jobject  pFensUserInfo)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcFensUserInfoField;");
	CThostFtdcFensUserInfoField FensUserInfo = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField( pFensUserInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(FensUserInfo.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField( pFensUserInfo,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(FensUserInfo.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LoginMode", "C");
		FensUserInfo.LoginMode = env->GetCharField( pFensUserInfo,fid);
	}

	ptrApi->RegisterFensUserInfo(&FensUserInfo);

}
JNIEXPORT void JNICALL Java_ctp_CThostFtdcMdApi_RegisterSpi
(JNIEnv * env,jobject obj,jobject pSpi)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);
	CThostFtdcMdSpi* ptrSpi = NULL;
	if(pSpi != NULL)
	{
		jclass clazz = env->FindClass("Lctp/CThostFtdcMdSpi;");
		jfieldID fieldID = env->GetFieldID(clazz, "ptrSpi", "J");
		ptrSpi = (CThostFtdcMdSpi*)env->GetLongField(pSpi,fieldID);
	}

	ptrApi->RegisterSpi(ptrSpi);

}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcMdApi_SubscribeMarketData
(JNIEnv * env,jobject obj,jobjectArray ppInstrumentID,jint nCount)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);
	int cnt = env->GetArrayLength(ppInstrumentID); //cnt should == nCount
	const char* cstr_fromJ;
	char** _ppInstrumentID = new char*[cnt];
	for(int i=0; i<cnt; i++)
	{
		jstring jstr = (jstring) env->GetObjectArrayElement(ppInstrumentID, i);
		cstr_fromJ = env->GetStringUTFChars(jstr, NULL);
		char* cstr_native = new char[31];
		strcpy(cstr_native, cstr_fromJ);
		env->ReleaseStringUTFChars(jstr, cstr_fromJ);
		_ppInstrumentID[i] = cstr_native;
	}

	jint iRtn = ptrApi->SubscribeMarketData(_ppInstrumentID, ( int ) nCount);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcMdApi_UnSubscribeMarketData
(JNIEnv * env,jobject obj,jobjectArray ppInstrumentID,jint nCount)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);
	int cnt = env->GetArrayLength(ppInstrumentID); //cnt should == nCount
	const char* cstr_fromJ;
	char** _ppInstrumentID = new char*[cnt];
	for(int i=0; i<cnt; i++)
	{
		jstring jstr = (jstring) env->GetObjectArrayElement(ppInstrumentID, i);
		cstr_fromJ = env->GetStringUTFChars(jstr, NULL);
		char* cstr_native = new char[31];
		strcpy(cstr_native, cstr_fromJ);
		env->ReleaseStringUTFChars(jstr, cstr_fromJ);
		_ppInstrumentID[i] = cstr_native;
	}

	jint iRtn = ptrApi->UnSubscribeMarketData(_ppInstrumentID, ( int ) nCount);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcMdApi_SubscribeForQuoteRsp
(JNIEnv * env,jobject obj,jobjectArray ppInstrumentID,jint nCount)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);
	int cnt = env->GetArrayLength(ppInstrumentID); //cnt should == nCount
	const char* cstr_fromJ;
	char** _ppInstrumentID = new char*[cnt];
	for(int i=0; i<cnt; i++)
	{
		jstring jstr = (jstring) env->GetObjectArrayElement(ppInstrumentID, i);
		cstr_fromJ = env->GetStringUTFChars(jstr, NULL);
		char* cstr_native = new char[31];
		strcpy(cstr_native, cstr_fromJ);
		env->ReleaseStringUTFChars(jstr, cstr_fromJ);
		_ppInstrumentID[i] = cstr_native;
	}

	jint iRtn = ptrApi->SubscribeForQuoteRsp(_ppInstrumentID, ( int ) nCount);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcMdApi_UnSubscribeForQuoteRsp
(JNIEnv * env,jobject obj,jobjectArray ppInstrumentID,jint nCount)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);
	int cnt = env->GetArrayLength(ppInstrumentID); //cnt should == nCount
	const char* cstr_fromJ;
	char** _ppInstrumentID = new char*[cnt];
	for(int i=0; i<cnt; i++)
	{
		jstring jstr = (jstring) env->GetObjectArrayElement(ppInstrumentID, i);
		cstr_fromJ = env->GetStringUTFChars(jstr, NULL);
		char* cstr_native = new char[31];
		strcpy(cstr_native, cstr_fromJ);
		env->ReleaseStringUTFChars(jstr, cstr_fromJ);
		_ppInstrumentID[i] = cstr_native;
	}

	jint iRtn = ptrApi->UnSubscribeForQuoteRsp(_ppInstrumentID, ( int ) nCount);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcMdApi_ReqUserLogin
(JNIEnv * env,jobject obj,jobject pReqUserLoginField,jint nRequestID)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcReqUserLoginField;");
	CThostFtdcReqUserLoginField ReqUserLoginField = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "TradingDay", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.TradingDay, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "Password", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.Password, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserProductInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.UserProductInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "InterfaceProductInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.InterfaceProductInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ProtocolInfo", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.ProtocolInfo, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "MacAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.MacAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "OneTimePassword", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.OneTimePassword, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientIPAddress", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.ClientIPAddress, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "LoginRemark", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pReqUserLoginField,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(ReqUserLoginField.LoginRemark, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "ClientIPPort", "I");
		ReqUserLoginField.ClientIPPort = env->GetIntField(pReqUserLoginField,fid);
	}

	jint iRtn = ptrApi->ReqUserLogin(&ReqUserLoginField, ( int ) nRequestID);
	return iRtn;
}
JNIEXPORT jint JNICALL Java_ctp_CThostFtdcMdApi_ReqUserLogout
(JNIEnv * env,jobject obj,jobject pUserLogout,jint nRequestID)
{
	CThostFtdcMdApi* ptrApi;
	jclass clazzMdApi = env->FindClass("Lctp/CThostFtdcMdApi;");
	jfieldID fidMdApi = env->GetFieldID(clazzMdApi, "ptrApi", "J");
	ptrApi = (CThostFtdcMdApi*)env->GetLongField(obj,fidMdApi);
	jclass clzparam = env->FindClass("Lctp/apistruct/CThostFtdcUserLogoutField;");
	CThostFtdcUserLogoutField UserLogout = { 0 };
	{
		jfieldID fid = env->GetFieldID(clzparam, "BrokerID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserLogout,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserLogout.BrokerID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}
	{
		jfieldID fid = env->GetFieldID(clzparam, "UserID", "Ljava/lang/String;");
		jstring jstr = (jstring) env->GetObjectField(pUserLogout,fid);
		const char* cstr;
		if(jstr)		{
			cstr = env->GetStringUTFChars(jstr, NULL);
			strcpy(UserLogout.UserID, (char *) cstr);
		}
		env->ReleaseStringUTFChars((jstring)jstr, cstr);
	}

	jint iRtn = ptrApi->ReqUserLogout(&UserLogout, ( int ) nRequestID);
	return iRtn;
}
#ifdef __cplusplus
}
#endif
