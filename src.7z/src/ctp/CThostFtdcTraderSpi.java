package ctp;
import ctp.apistruct.*;
public class CThostFtdcTraderSpi {
	public long ptrSpi; // point to c++ SPI clase instance
	public native long newNativeSpiInstance();
	public native void deleteNativeSpiInstance(long ptrSpi);
	public CThostFtdcTraderSpi(){
		ptrSpi = newNativeSpiInstance();
	}
	public void OnFrontConnected(){}
	public void OnFrontDisconnected(int nReason){}
	public void OnHeartBeatWarning(int nTimeLapse){}
	public void OnRspAuthenticate(CThostFtdcRspAuthenticateField pRspAuthenticateField,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspUserLogin(CThostFtdcRspUserLoginField pRspUserLogin,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspUserLogout(CThostFtdcUserLogoutField pUserLogout,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspUserPasswordUpdate(CThostFtdcUserPasswordUpdateField pUserPasswordUpdate,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspTradingAccountPasswordUpdate(CThostFtdcTradingAccountPasswordUpdateField pTradingAccountPasswordUpdate,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspUserAuthMethod(CThostFtdcRspUserAuthMethodField pRspUserAuthMethod,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspGenUserCaptcha(CThostFtdcRspGenUserCaptchaField pRspGenUserCaptcha,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspGenUserText(CThostFtdcRspGenUserTextField pRspGenUserText,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspOrderInsert(CThostFtdcInputOrderField pInputOrder,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspParkedOrderInsert(CThostFtdcParkedOrderField pParkedOrder,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspParkedOrderAction(CThostFtdcParkedOrderActionField pParkedOrderAction,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspOrderAction(CThostFtdcInputOrderActionField pInputOrderAction,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQueryMaxOrderVolume(CThostFtdcQueryMaxOrderVolumeField pQueryMaxOrderVolume,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspSettlementInfoConfirm(CThostFtdcSettlementInfoConfirmField pSettlementInfoConfirm,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspRemoveParkedOrder(CThostFtdcRemoveParkedOrderField pRemoveParkedOrder,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspRemoveParkedOrderAction(CThostFtdcRemoveParkedOrderActionField pRemoveParkedOrderAction,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspExecOrderInsert(CThostFtdcInputExecOrderField pInputExecOrder,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspExecOrderAction(CThostFtdcInputExecOrderActionField pInputExecOrderAction,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspForQuoteInsert(CThostFtdcInputForQuoteField pInputForQuote,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQuoteInsert(CThostFtdcInputQuoteField pInputQuote,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQuoteAction(CThostFtdcInputQuoteActionField pInputQuoteAction,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspBatchOrderAction(CThostFtdcInputBatchOrderActionField pInputBatchOrderAction,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspOptionSelfCloseInsert(CThostFtdcInputOptionSelfCloseField pInputOptionSelfClose,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspOptionSelfCloseAction(CThostFtdcInputOptionSelfCloseActionField pInputOptionSelfCloseAction,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspCombActionInsert(CThostFtdcInputCombActionField pInputCombAction,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryOrder(CThostFtdcOrderField pOrder,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryTrade(CThostFtdcTradeField pTrade,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryInvestorPosition(CThostFtdcInvestorPositionField pInvestorPosition,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryTradingAccount(CThostFtdcTradingAccountField pTradingAccount,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryInvestor(CThostFtdcInvestorField pInvestor,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryTradingCode(CThostFtdcTradingCodeField pTradingCode,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryInstrumentMarginRate(CThostFtdcInstrumentMarginRateField pInstrumentMarginRate,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryInstrumentCommissionRate(CThostFtdcInstrumentCommissionRateField pInstrumentCommissionRate,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryExchange(CThostFtdcExchangeField pExchange,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryProduct(CThostFtdcProductField pProduct,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryInstrument(CThostFtdcInstrumentField pInstrument,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryDepthMarketData(CThostFtdcDepthMarketDataField pDepthMarketData,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQrySettlementInfo(CThostFtdcSettlementInfoField pSettlementInfo,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryTransferBank(CThostFtdcTransferBankField pTransferBank,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryInvestorPositionDetail(CThostFtdcInvestorPositionDetailField pInvestorPositionDetail,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryNotice(CThostFtdcNoticeField pNotice,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQrySettlementInfoConfirm(CThostFtdcSettlementInfoConfirmField pSettlementInfoConfirm,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryInvestorPositionCombineDetail(CThostFtdcInvestorPositionCombineDetailField pInvestorPositionCombineDetail,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryCFMMCTradingAccountKey(CThostFtdcCFMMCTradingAccountKeyField pCFMMCTradingAccountKey,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryEWarrantOffset(CThostFtdcEWarrantOffsetField pEWarrantOffset,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryInvestorProductGroupMargin(CThostFtdcInvestorProductGroupMarginField pInvestorProductGroupMargin,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryExchangeMarginRate(CThostFtdcExchangeMarginRateField pExchangeMarginRate,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryExchangeMarginRateAdjust(CThostFtdcExchangeMarginRateAdjustField pExchangeMarginRateAdjust,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryExchangeRate(CThostFtdcExchangeRateField pExchangeRate,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQrySecAgentACIDMap(CThostFtdcSecAgentACIDMapField pSecAgentACIDMap,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryProductExchRate(CThostFtdcProductExchRateField pProductExchRate,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryProductGroup(CThostFtdcProductGroupField pProductGroup,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryMMInstrumentCommissionRate(CThostFtdcMMInstrumentCommissionRateField pMMInstrumentCommissionRate,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryMMOptionInstrCommRate(CThostFtdcMMOptionInstrCommRateField pMMOptionInstrCommRate,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryInstrumentOrderCommRate(CThostFtdcInstrumentOrderCommRateField pInstrumentOrderCommRate,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQrySecAgentTradingAccount(CThostFtdcTradingAccountField pTradingAccount,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQrySecAgentCheckMode(CThostFtdcSecAgentCheckModeField pSecAgentCheckMode,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQrySecAgentTradeInfo(CThostFtdcSecAgentTradeInfoField pSecAgentTradeInfo,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryOptionInstrTradeCost(CThostFtdcOptionInstrTradeCostField pOptionInstrTradeCost,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryOptionInstrCommRate(CThostFtdcOptionInstrCommRateField pOptionInstrCommRate,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryExecOrder(CThostFtdcExecOrderField pExecOrder,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryForQuote(CThostFtdcForQuoteField pForQuote,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryQuote(CThostFtdcQuoteField pQuote,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryOptionSelfClose(CThostFtdcOptionSelfCloseField pOptionSelfClose,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryInvestUnit(CThostFtdcInvestUnitField pInvestUnit,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryCombInstrumentGuard(CThostFtdcCombInstrumentGuardField pCombInstrumentGuard,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryCombAction(CThostFtdcCombActionField pCombAction,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryTransferSerial(CThostFtdcTransferSerialField pTransferSerial,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryAccountregister(CThostFtdcAccountregisterField pAccountregister,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspError(CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRtnOrder(CThostFtdcOrderField pOrder){}
	public void OnRtnTrade(CThostFtdcTradeField pTrade){}
	public void OnErrRtnOrderInsert(CThostFtdcInputOrderField pInputOrder,CThostFtdcRspInfoField pRspInfo){}
	public void OnErrRtnOrderAction(CThostFtdcOrderActionField pOrderAction,CThostFtdcRspInfoField pRspInfo){}
	public void OnRtnInstrumentStatus(CThostFtdcInstrumentStatusField pInstrumentStatus){}
	public void OnRtnBulletin(CThostFtdcBulletinField pBulletin){}
	public void OnRtnTradingNotice(CThostFtdcTradingNoticeInfoField pTradingNoticeInfo){}
	public void OnRtnErrorConditionalOrder(CThostFtdcErrorConditionalOrderField pErrorConditionalOrder){}
	public void OnRtnExecOrder(CThostFtdcExecOrderField pExecOrder){}
	public void OnErrRtnExecOrderInsert(CThostFtdcInputExecOrderField pInputExecOrder,CThostFtdcRspInfoField pRspInfo){}
	public void OnErrRtnExecOrderAction(CThostFtdcExecOrderActionField pExecOrderAction,CThostFtdcRspInfoField pRspInfo){}
	public void OnErrRtnForQuoteInsert(CThostFtdcInputForQuoteField pInputForQuote,CThostFtdcRspInfoField pRspInfo){}
	public void OnRtnQuote(CThostFtdcQuoteField pQuote){}
	public void OnErrRtnQuoteInsert(CThostFtdcInputQuoteField pInputQuote,CThostFtdcRspInfoField pRspInfo){}
	public void OnErrRtnQuoteAction(CThostFtdcQuoteActionField pQuoteAction,CThostFtdcRspInfoField pRspInfo){}
	public void OnRtnForQuoteRsp(CThostFtdcForQuoteRspField pForQuoteRsp){}
	public void OnRtnCFMMCTradingAccountToken(CThostFtdcCFMMCTradingAccountTokenField pCFMMCTradingAccountToken){}
	public void OnErrRtnBatchOrderAction(CThostFtdcBatchOrderActionField pBatchOrderAction,CThostFtdcRspInfoField pRspInfo){}
	public void OnRtnOptionSelfClose(CThostFtdcOptionSelfCloseField pOptionSelfClose){}
	public void OnErrRtnOptionSelfCloseInsert(CThostFtdcInputOptionSelfCloseField pInputOptionSelfClose,CThostFtdcRspInfoField pRspInfo){}
	public void OnErrRtnOptionSelfCloseAction(CThostFtdcOptionSelfCloseActionField pOptionSelfCloseAction,CThostFtdcRspInfoField pRspInfo){}
	public void OnRtnCombAction(CThostFtdcCombActionField pCombAction){}
	public void OnErrRtnCombActionInsert(CThostFtdcInputCombActionField pInputCombAction,CThostFtdcRspInfoField pRspInfo){}
	public void OnRspQryContractBank(CThostFtdcContractBankField pContractBank,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryParkedOrder(CThostFtdcParkedOrderField pParkedOrder,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryParkedOrderAction(CThostFtdcParkedOrderActionField pParkedOrderAction,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryTradingNotice(CThostFtdcTradingNoticeField pTradingNotice,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryBrokerTradingParams(CThostFtdcBrokerTradingParamsField pBrokerTradingParams,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQryBrokerTradingAlgos(CThostFtdcBrokerTradingAlgosField pBrokerTradingAlgos,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQueryCFMMCTradingAccountToken(CThostFtdcQueryCFMMCTradingAccountTokenField pQueryCFMMCTradingAccountToken,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRtnFromBankToFutureByBank(CThostFtdcRspTransferField pRspTransfer){}
	public void OnRtnFromFutureToBankByBank(CThostFtdcRspTransferField pRspTransfer){}
	public void OnRtnRepealFromBankToFutureByBank(CThostFtdcRspRepealField pRspRepeal){}
	public void OnRtnRepealFromFutureToBankByBank(CThostFtdcRspRepealField pRspRepeal){}
	public void OnRtnFromBankToFutureByFuture(CThostFtdcRspTransferField pRspTransfer){}
	public void OnRtnFromFutureToBankByFuture(CThostFtdcRspTransferField pRspTransfer){}
	public void OnRtnRepealFromBankToFutureByFutureManual(CThostFtdcRspRepealField pRspRepeal){}
	public void OnRtnRepealFromFutureToBankByFutureManual(CThostFtdcRspRepealField pRspRepeal){}
	public void OnRtnQueryBankBalanceByFuture(CThostFtdcNotifyQueryAccountField pNotifyQueryAccount){}
	public void OnErrRtnBankToFutureByFuture(CThostFtdcReqTransferField pReqTransfer,CThostFtdcRspInfoField pRspInfo){}
	public void OnErrRtnFutureToBankByFuture(CThostFtdcReqTransferField pReqTransfer,CThostFtdcRspInfoField pRspInfo){}
	public void OnErrRtnRepealBankToFutureByFutureManual(CThostFtdcReqRepealField pReqRepeal,CThostFtdcRspInfoField pRspInfo){}
	public void OnErrRtnRepealFutureToBankByFutureManual(CThostFtdcReqRepealField pReqRepeal,CThostFtdcRspInfoField pRspInfo){}
	public void OnErrRtnQueryBankBalanceByFuture(CThostFtdcReqQueryAccountField pReqQueryAccount,CThostFtdcRspInfoField pRspInfo){}
	public void OnRtnRepealFromBankToFutureByFuture(CThostFtdcRspRepealField pRspRepeal){}
	public void OnRtnRepealFromFutureToBankByFuture(CThostFtdcRspRepealField pRspRepeal){}
	public void OnRspFromBankToFutureByFuture(CThostFtdcReqTransferField pReqTransfer,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspFromFutureToBankByFuture(CThostFtdcReqTransferField pReqTransfer,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspQueryBankAccountMoneyByFuture(CThostFtdcReqQueryAccountField pReqQueryAccount,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRtnOpenAccountByBank(CThostFtdcOpenAccountField pOpenAccount){}
	public void OnRtnCancelAccountByBank(CThostFtdcCancelAccountField pCancelAccount){}
	public void OnRtnChangeAccountByBank(CThostFtdcChangeAccountField pChangeAccount){}
}
