package ctp;
import ctp.apistruct.*;
public class CThostFtdcMdSpi {
	public long ptrSpi; // point to c++ SPI clase instance
	public native long newNativeSpiInstance();
	public native void deleteNativeSpiInstance(long ptrSpi);
	public CThostFtdcMdSpi(){
		ptrSpi = newNativeSpiInstance();
	}
	public void OnFrontConnected(){}
	public void OnFrontDisconnected(int nReason){}
	public void OnHeartBeatWarning(int nTimeLapse){}
	public void OnRspUserLogin(CThostFtdcRspUserLoginField pRspUserLogin,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspUserLogout(CThostFtdcUserLogoutField pUserLogout,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspError(CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspSubMarketData(CThostFtdcSpecificInstrumentField pSpecificInstrument,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspUnSubMarketData(CThostFtdcSpecificInstrumentField pSpecificInstrument,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspSubForQuoteRsp(CThostFtdcSpecificInstrumentField pSpecificInstrument,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRspUnSubForQuoteRsp(CThostFtdcSpecificInstrumentField pSpecificInstrument,CThostFtdcRspInfoField pRspInfo,int nRequestID,boolean bIsLast){}
	public void OnRtnDepthMarketData(CThostFtdcDepthMarketDataField pDepthMarketData){}
	public void OnRtnForQuoteRsp(CThostFtdcForQuoteRspField pForQuoteRsp){}
}
