package ctp;
import ctp.apistruct.*;
import ctp.CThostFtdcMdSpi;
public class CThostFtdcMdApi {
	public long ptrApi; // point to c++ API clase instance
	/**this class can only created by CreateFtdcMdApi()*/
	private CThostFtdcMdApi(long ptrApi){
		this.ptrApi = ptrApi;
	}
	public native static CThostFtdcMdApi CreateFtdcMdApi(String pszFlowPath,boolean bIsUsingUdp,boolean bIsMulticast);
	public native static String GetApiVersion();
	public native void Release();
	public native void Init();
	public native int Join();
	public native String GetTradingDay();
	public native void RegisterFront(String pszFrontAddress);
	public native void RegisterNameServer(String pszNsAddress);
	public native void RegisterFensUserInfo(CThostFtdcFensUserInfoField  pFensUserInfo);
	public native void RegisterSpi(CThostFtdcMdSpi pSpi);
	public native int SubscribeMarketData(String[] ppInstrumentID,int nCount);
	public native int UnSubscribeMarketData(String[] ppInstrumentID,int nCount);
	public native int SubscribeForQuoteRsp(String[] ppInstrumentID,int nCount);
	public native int UnSubscribeForQuoteRsp(String[] ppInstrumentID,int nCount);
	public native int ReqUserLogin(CThostFtdcReqUserLoginField pReqUserLoginField,int nRequestID);
	public native int ReqUserLogout(CThostFtdcUserLogoutField pUserLogout,int nRequestID);
}
