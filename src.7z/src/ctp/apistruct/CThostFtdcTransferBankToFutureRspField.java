package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTransferBankToFutureRspField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String RetCode = "";	 //char[5]	(TThostFtdcRetCodeType)
	public String RetInfo = "";	 //char[129]	(TThostFtdcRetInfoType)
	public String FutureAccount = "";	 //char[13]	(TThostFtdcAccountIDType)
	public double TradeAmt;
	public double CustFee;
	public String CurrencyCode = "";	 //char[4]	(TThostFtdcCurrencyCodeType)

	public CThostFtdcTransferBankToFutureRspField(){}

	public CThostFtdcTransferBankToFutureRspField(byte[] RetCode,byte[] RetInfo,byte[] FutureAccount,double TradeAmt,double CustFee,byte[] CurrencyCode){
		try{	if(RetCode !=null)	this.RetCode= new String(RetCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.RetCode = "";}
		try{	if(RetInfo !=null)	this.RetInfo= new String(RetInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.RetInfo = "";}
		try{	if(FutureAccount !=null)	this.FutureAccount= new String(FutureAccount, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FutureAccount = "";}
		this.TradeAmt=TradeAmt;
		this.CustFee=CustFee;
		try{	if(CurrencyCode !=null)	this.CurrencyCode= new String(CurrencyCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyCode = "";}
	}
}
