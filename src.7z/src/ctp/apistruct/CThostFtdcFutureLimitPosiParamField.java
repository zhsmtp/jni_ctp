package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcFutureLimitPosiParamField implements Serializable {
	private static final long serialVersionUID = 1L;
	public char InvestorRange;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String ProductID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public int SpecOpenVolume;
	public int ArbiOpenVolume;
	public int OpenVolume;

	public CThostFtdcFutureLimitPosiParamField(){}

	public CThostFtdcFutureLimitPosiParamField(char InvestorRange,byte[] BrokerID,byte[] InvestorID,byte[] ProductID,int SpecOpenVolume,int ArbiOpenVolume,int OpenVolume){
		this.InvestorRange=InvestorRange;
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(ProductID !=null)	this.ProductID= new String(ProductID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ProductID = "";}
		this.SpecOpenVolume=SpecOpenVolume;
		this.ArbiOpenVolume=ArbiOpenVolume;
		this.OpenVolume=OpenVolume;
	}
}
