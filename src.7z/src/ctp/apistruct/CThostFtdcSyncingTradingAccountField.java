package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcSyncingTradingAccountField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public double PreMortgage;
	public double PreCredit;
	public double PreDeposit;
	public double PreBalance;
	public double PreMargin;
	public double InterestBase;
	public double Interest;
	public double Deposit;
	public double Withdraw;
	public double FrozenMargin;
	public double FrozenCash;
	public double FrozenCommission;
	public double CurrMargin;
	public double CashIn;
	public double Commission;
	public double CloseProfit;
	public double PositionProfit;
	public double Balance;
	public double Available;
	public double WithdrawQuota;
	public double Reserve;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public int SettlementID;
	public double Credit;
	public double Mortgage;
	public double ExchangeMargin;
	public double DeliveryMargin;
	public double ExchangeDeliveryMargin;
	public double ReserveBalance;
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public double PreFundMortgageIn;
	public double PreFundMortgageOut;
	public double FundMortgageIn;
	public double FundMortgageOut;
	public double FundMortgageAvailable;
	public double MortgageableFund;
	public double SpecProductMargin;
	public double SpecProductFrozenMargin;
	public double SpecProductCommission;
	public double SpecProductFrozenCommission;
	public double SpecProductPositionProfit;
	public double SpecProductCloseProfit;
	public double SpecProductPositionProfitByAlg;
	public double SpecProductExchangeMargin;
	public double FrozenSwap;
	public double RemainSwap;

	public CThostFtdcSyncingTradingAccountField(){}

	public CThostFtdcSyncingTradingAccountField(byte[] BrokerID,byte[] AccountID,double PreMortgage,double PreCredit,double PreDeposit,double PreBalance,double PreMargin,double InterestBase,double Interest,double Deposit,double Withdraw,double FrozenMargin,double FrozenCash,double FrozenCommission,double CurrMargin,double CashIn,double Commission,double CloseProfit,double PositionProfit,double Balance,double Available,double WithdrawQuota,double Reserve,byte[] TradingDay,int SettlementID,double Credit,double Mortgage,double ExchangeMargin,double DeliveryMargin,double ExchangeDeliveryMargin,double ReserveBalance,byte[] CurrencyID,double PreFundMortgageIn,double PreFundMortgageOut,double FundMortgageIn,double FundMortgageOut,double FundMortgageAvailable,double MortgageableFund,double SpecProductMargin,double SpecProductFrozenMargin,double SpecProductCommission,double SpecProductFrozenCommission,double SpecProductPositionProfit,double SpecProductCloseProfit,double SpecProductPositionProfitByAlg,double SpecProductExchangeMargin,double FrozenSwap,double RemainSwap){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		this.PreMortgage=PreMortgage;
		this.PreCredit=PreCredit;
		this.PreDeposit=PreDeposit;
		this.PreBalance=PreBalance;
		this.PreMargin=PreMargin;
		this.InterestBase=InterestBase;
		this.Interest=Interest;
		this.Deposit=Deposit;
		this.Withdraw=Withdraw;
		this.FrozenMargin=FrozenMargin;
		this.FrozenCash=FrozenCash;
		this.FrozenCommission=FrozenCommission;
		this.CurrMargin=CurrMargin;
		this.CashIn=CashIn;
		this.Commission=Commission;
		this.CloseProfit=CloseProfit;
		this.PositionProfit=PositionProfit;
		this.Balance=Balance;
		this.Available=Available;
		this.WithdrawQuota=WithdrawQuota;
		this.Reserve=Reserve;
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.SettlementID=SettlementID;
		this.Credit=Credit;
		this.Mortgage=Mortgage;
		this.ExchangeMargin=ExchangeMargin;
		this.DeliveryMargin=DeliveryMargin;
		this.ExchangeDeliveryMargin=ExchangeDeliveryMargin;
		this.ReserveBalance=ReserveBalance;
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		this.PreFundMortgageIn=PreFundMortgageIn;
		this.PreFundMortgageOut=PreFundMortgageOut;
		this.FundMortgageIn=FundMortgageIn;
		this.FundMortgageOut=FundMortgageOut;
		this.FundMortgageAvailable=FundMortgageAvailable;
		this.MortgageableFund=MortgageableFund;
		this.SpecProductMargin=SpecProductMargin;
		this.SpecProductFrozenMargin=SpecProductFrozenMargin;
		this.SpecProductCommission=SpecProductCommission;
		this.SpecProductFrozenCommission=SpecProductFrozenCommission;
		this.SpecProductPositionProfit=SpecProductPositionProfit;
		this.SpecProductCloseProfit=SpecProductCloseProfit;
		this.SpecProductPositionProfitByAlg=SpecProductPositionProfitByAlg;
		this.SpecProductExchangeMargin=SpecProductExchangeMargin;
		this.FrozenSwap=FrozenSwap;
		this.RemainSwap=RemainSwap;
	}
}
