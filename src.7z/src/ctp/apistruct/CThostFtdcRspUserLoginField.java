package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcRspUserLoginField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public String LoginTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String SystemName = "";	 //char[41]	(TThostFtdcSystemNameType)
	public int FrontID;
	public int SessionID;
	public String MaxOrderRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String SHFETime = "";	 //char[9]	(TThostFtdcTimeType)
	public String DCETime = "";	 //char[9]	(TThostFtdcTimeType)
	public String CZCETime = "";	 //char[9]	(TThostFtdcTimeType)
	public String FFEXTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String INETime = "";	 //char[9]	(TThostFtdcTimeType)

	public CThostFtdcRspUserLoginField(){}

	public CThostFtdcRspUserLoginField(byte[] TradingDay,byte[] LoginTime,byte[] BrokerID,byte[] UserID,byte[] SystemName,int FrontID,int SessionID,byte[] MaxOrderRef,byte[] SHFETime,byte[] DCETime,byte[] CZCETime,byte[] FFEXTime,byte[] INETime){
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		try{	if(LoginTime !=null)	this.LoginTime= new String(LoginTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LoginTime = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(SystemName !=null)	this.SystemName= new String(SystemName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.SystemName = "";}
		this.FrontID=FrontID;
		this.SessionID=SessionID;
		try{	if(MaxOrderRef !=null)	this.MaxOrderRef= new String(MaxOrderRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MaxOrderRef = "";}
		try{	if(SHFETime !=null)	this.SHFETime= new String(SHFETime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.SHFETime = "";}
		try{	if(DCETime !=null)	this.DCETime= new String(DCETime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.DCETime = "";}
		try{	if(CZCETime !=null)	this.CZCETime= new String(CZCETime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CZCETime = "";}
		try{	if(FFEXTime !=null)	this.FFEXTime= new String(FFEXTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FFEXTime = "";}
		try{	if(INETime !=null)	this.INETime= new String(INETime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.INETime = "";}
	}
}
