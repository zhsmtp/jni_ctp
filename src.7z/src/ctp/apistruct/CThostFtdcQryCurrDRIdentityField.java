package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryCurrDRIdentityField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int DRIdentityID;

	public CThostFtdcQryCurrDRIdentityField(){}

	public CThostFtdcQryCurrDRIdentityField(int DRIdentityID){
		this.DRIdentityID=DRIdentityID;
	}
}
