package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcBrokerWithdrawAlgorithmField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public char WithdrawAlgorithm;
	public double UsingRatio;
	public char IncludeCloseProfit;
	public char AllWithoutTrade;
	public char AvailIncludeCloseProfit;
	public int IsBrokerUserEvent;
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public double FundMortgageRatio;
	public char BalanceAlgorithm;

	public CThostFtdcBrokerWithdrawAlgorithmField(){}

	public CThostFtdcBrokerWithdrawAlgorithmField(byte[] BrokerID,char WithdrawAlgorithm,double UsingRatio,char IncludeCloseProfit,char AllWithoutTrade,char AvailIncludeCloseProfit,int IsBrokerUserEvent,byte[] CurrencyID,double FundMortgageRatio,char BalanceAlgorithm){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		this.WithdrawAlgorithm=WithdrawAlgorithm;
		this.UsingRatio=UsingRatio;
		this.IncludeCloseProfit=IncludeCloseProfit;
		this.AllWithoutTrade=AllWithoutTrade;
		this.AvailIncludeCloseProfit=AvailIncludeCloseProfit;
		this.IsBrokerUserEvent=IsBrokerUserEvent;
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		this.FundMortgageRatio=FundMortgageRatio;
		this.BalanceAlgorithm=BalanceAlgorithm;
	}
}
