package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcReqApiHandshakeField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String CryptoKeyVersion = "";	 //char[31]	(TThostFtdcCryptoKeyVersionType)

	public CThostFtdcReqApiHandshakeField(){}

	public CThostFtdcReqApiHandshakeField(byte[] CryptoKeyVersion){
		try{	if(CryptoKeyVersion !=null)	this.CryptoKeyVersion= new String(CryptoKeyVersion, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CryptoKeyVersion = "";}
	}
}
