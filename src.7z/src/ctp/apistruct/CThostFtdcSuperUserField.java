package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcSuperUserField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String UserName = "";	 //char[81]	(TThostFtdcUserNameType)
	public String Password = "";	 //char[41]	(TThostFtdcPasswordType)
	public int IsActive;

	public CThostFtdcSuperUserField(){}

	public CThostFtdcSuperUserField(byte[] UserID,byte[] UserName,byte[] Password,int IsActive){
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(UserName !=null)	this.UserName= new String(UserName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserName = "";}
		try{	if(Password !=null)	this.Password= new String(Password, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Password = "";}
		this.IsActive=IsActive;
	}
}
