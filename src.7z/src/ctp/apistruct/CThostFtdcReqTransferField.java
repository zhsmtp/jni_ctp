package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcReqTransferField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradeCode = "";	 //char[7]	(TThostFtdcTradeCodeType)
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankBranchID = "";	 //char[5]	(TThostFtdcBankBrchIDType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String BrokerBranchID = "";	 //char[31]	(TThostFtdcFutureBranchIDType)
	public String TradeDate = "";	 //char[9]	(TThostFtdcTradeDateType)
	public String TradeTime = "";	 //char[9]	(TThostFtdcTradeTimeType)
	public String BankSerial = "";	 //char[13]	(TThostFtdcBankSerialType)
	public int PlateSerial;
	public char LastFragment;
	public int SessionID;
	public String CustomerName = "";	 //char[51]	(TThostFtdcIndividualNameType)
	public char IdCardType;
	public String IdentifiedCardNo = "";	 //char[51]	(TThostFtdcIdentifiedCardNoType)
	public char CustType;
	public String BankAccount = "";	 //char[41]	(TThostFtdcBankAccountType)
	public String BankPassWord = "";	 //char[41]	(TThostFtdcPasswordType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String Password = "";	 //char[41]	(TThostFtdcPasswordType)
	public int InstallID;
	public int FutureSerial;
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public char VerifyCertNoFlag;
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public double TradeAmount;
	public double FutureFetchAmount;
	public char FeePayFlag;
	public double CustFee;
	public double BrokerFee;
	public String Message = "";	 //char[129]	(TThostFtdcAddInfoType)
	public String Digest = "";	 //char[36]	(TThostFtdcDigestType)
	public char BankAccType;
	public String DeviceID = "";	 //char[3]	(TThostFtdcDeviceIDType)
	public char BankSecuAccType;
	public String BrokerIDByBank = "";	 //char[33]	(TThostFtdcBankCodingForFutureType)
	public String BankSecuAcc = "";	 //char[41]	(TThostFtdcBankAccountType)
	public char BankPwdFlag;
	public char SecuPwdFlag;
	public String OperNo = "";	 //char[17]	(TThostFtdcOperNoType)
	public int RequestID;
	public int TID;
	public char TransferStatus;
	public String LongCustomerName = "";	 //char[161]	(TThostFtdcLongIndividualNameType)

	public CThostFtdcReqTransferField(){}

	public CThostFtdcReqTransferField(byte[] TradeCode,byte[] BankID,byte[] BankBranchID,byte[] BrokerID,byte[] BrokerBranchID,byte[] TradeDate,byte[] TradeTime,byte[] BankSerial,int PlateSerial,char LastFragment,int SessionID,byte[] CustomerName,char IdCardType,byte[] IdentifiedCardNo,char CustType,byte[] BankAccount,byte[] BankPassWord,byte[] AccountID,byte[] Password,int InstallID,int FutureSerial,byte[] UserID,char VerifyCertNoFlag,byte[] CurrencyID,double TradeAmount,double FutureFetchAmount,char FeePayFlag,double CustFee,double BrokerFee,byte[] Message,byte[] Digest,char BankAccType,byte[] DeviceID,char BankSecuAccType,byte[] BrokerIDByBank,byte[] BankSecuAcc,char BankPwdFlag,char SecuPwdFlag,byte[] OperNo,int RequestID,int TID,char TransferStatus,byte[] LongCustomerName){
		try{	if(TradeCode !=null)	this.TradeCode= new String(TradeCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeCode = "";}
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankBranchID !=null)	this.BankBranchID= new String(BankBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankBranchID = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(BrokerBranchID !=null)	this.BrokerBranchID= new String(BrokerBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerBranchID = "";}
		try{	if(TradeDate !=null)	this.TradeDate= new String(TradeDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeDate = "";}
		try{	if(TradeTime !=null)	this.TradeTime= new String(TradeTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeTime = "";}
		try{	if(BankSerial !=null)	this.BankSerial= new String(BankSerial, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankSerial = "";}
		this.PlateSerial=PlateSerial;
		this.LastFragment=LastFragment;
		this.SessionID=SessionID;
		try{	if(CustomerName !=null)	this.CustomerName= new String(CustomerName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CustomerName = "";}
		this.IdCardType=IdCardType;
		try{	if(IdentifiedCardNo !=null)	this.IdentifiedCardNo= new String(IdentifiedCardNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IdentifiedCardNo = "";}
		this.CustType=CustType;
		try{	if(BankAccount !=null)	this.BankAccount= new String(BankAccount, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankAccount = "";}
		try{	if(BankPassWord !=null)	this.BankPassWord= new String(BankPassWord, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankPassWord = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(Password !=null)	this.Password= new String(Password, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Password = "";}
		this.InstallID=InstallID;
		this.FutureSerial=FutureSerial;
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.VerifyCertNoFlag=VerifyCertNoFlag;
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		this.TradeAmount=TradeAmount;
		this.FutureFetchAmount=FutureFetchAmount;
		this.FeePayFlag=FeePayFlag;
		this.CustFee=CustFee;
		this.BrokerFee=BrokerFee;
		try{	if(Message !=null)	this.Message= new String(Message, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Message = "";}
		try{	if(Digest !=null)	this.Digest= new String(Digest, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Digest = "";}
		this.BankAccType=BankAccType;
		try{	if(DeviceID !=null)	this.DeviceID= new String(DeviceID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.DeviceID = "";}
		this.BankSecuAccType=BankSecuAccType;
		try{	if(BrokerIDByBank !=null)	this.BrokerIDByBank= new String(BrokerIDByBank, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerIDByBank = "";}
		try{	if(BankSecuAcc !=null)	this.BankSecuAcc= new String(BankSecuAcc, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankSecuAcc = "";}
		this.BankPwdFlag=BankPwdFlag;
		this.SecuPwdFlag=SecuPwdFlag;
		try{	if(OperNo !=null)	this.OperNo= new String(OperNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OperNo = "";}
		this.RequestID=RequestID;
		this.TID=TID;
		this.TransferStatus=TransferStatus;
		try{	if(LongCustomerName !=null)	this.LongCustomerName= new String(LongCustomerName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LongCustomerName = "";}
	}
}
