package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcInstrumentField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String InstrumentName = "";	 //char[21]	(TThostFtdcInstrumentNameType)
	public String ExchangeInstID = "";	 //char[31]	(TThostFtdcExchangeInstIDType)
	public String ProductID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public char ProductClass;
	public int DeliveryYear;
	public int DeliveryMonth;
	public int MaxMarketOrderVolume;
	public int MinMarketOrderVolume;
	public int MaxLimitOrderVolume;
	public int MinLimitOrderVolume;
	public int VolumeMultiple;
	public double PriceTick;
	public String CreateDate = "";	 //char[9]	(TThostFtdcDateType)
	public String OpenDate = "";	 //char[9]	(TThostFtdcDateType)
	public String ExpireDate = "";	 //char[9]	(TThostFtdcDateType)
	public String StartDelivDate = "";	 //char[9]	(TThostFtdcDateType)
	public String EndDelivDate = "";	 //char[9]	(TThostFtdcDateType)
	public char InstLifePhase;
	public int IsTrading;
	public char PositionType;
	public char PositionDateType;
	public double LongMarginRatio;
	public double ShortMarginRatio;
	public char MaxMarginSideAlgorithm;
	public String UnderlyingInstrID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public double StrikePrice;
	public char OptionsType;
	public double UnderlyingMultiple;
	public char CombinationType;

	public CThostFtdcInstrumentField(){}

	public CThostFtdcInstrumentField(byte[] InstrumentID,byte[] ExchangeID,byte[] InstrumentName,byte[] ExchangeInstID,byte[] ProductID,char ProductClass,int DeliveryYear,int DeliveryMonth,int MaxMarketOrderVolume,int MinMarketOrderVolume,int MaxLimitOrderVolume,int MinLimitOrderVolume,int VolumeMultiple,double PriceTick,byte[] CreateDate,byte[] OpenDate,byte[] ExpireDate,byte[] StartDelivDate,byte[] EndDelivDate,char InstLifePhase,int IsTrading,char PositionType,char PositionDateType,double LongMarginRatio,double ShortMarginRatio,char MaxMarginSideAlgorithm,byte[] UnderlyingInstrID,double StrikePrice,char OptionsType,double UnderlyingMultiple,char CombinationType){
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(InstrumentName !=null)	this.InstrumentName= new String(InstrumentName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentName = "";}
		try{	if(ExchangeInstID !=null)	this.ExchangeInstID= new String(ExchangeInstID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeInstID = "";}
		try{	if(ProductID !=null)	this.ProductID= new String(ProductID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ProductID = "";}
		this.ProductClass=ProductClass;
		this.DeliveryYear=DeliveryYear;
		this.DeliveryMonth=DeliveryMonth;
		this.MaxMarketOrderVolume=MaxMarketOrderVolume;
		this.MinMarketOrderVolume=MinMarketOrderVolume;
		this.MaxLimitOrderVolume=MaxLimitOrderVolume;
		this.MinLimitOrderVolume=MinLimitOrderVolume;
		this.VolumeMultiple=VolumeMultiple;
		this.PriceTick=PriceTick;
		try{	if(CreateDate !=null)	this.CreateDate= new String(CreateDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CreateDate = "";}
		try{	if(OpenDate !=null)	this.OpenDate= new String(OpenDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OpenDate = "";}
		try{	if(ExpireDate !=null)	this.ExpireDate= new String(ExpireDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExpireDate = "";}
		try{	if(StartDelivDate !=null)	this.StartDelivDate= new String(StartDelivDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.StartDelivDate = "";}
		try{	if(EndDelivDate !=null)	this.EndDelivDate= new String(EndDelivDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.EndDelivDate = "";}
		this.InstLifePhase=InstLifePhase;
		this.IsTrading=IsTrading;
		this.PositionType=PositionType;
		this.PositionDateType=PositionDateType;
		this.LongMarginRatio=LongMarginRatio;
		this.ShortMarginRatio=ShortMarginRatio;
		this.MaxMarginSideAlgorithm=MaxMarginSideAlgorithm;
		try{	if(UnderlyingInstrID !=null)	this.UnderlyingInstrID= new String(UnderlyingInstrID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UnderlyingInstrID = "";}
		this.StrikePrice=StrikePrice;
		this.OptionsType=OptionsType;
		this.UnderlyingMultiple=UnderlyingMultiple;
		this.CombinationType=CombinationType;
	}
}
