package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcSettlementRefField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public int SettlementID;

	public CThostFtdcSettlementRefField(){}

	public CThostFtdcSettlementRefField(byte[] TradingDay,int SettlementID){
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.SettlementID=SettlementID;
	}
}
