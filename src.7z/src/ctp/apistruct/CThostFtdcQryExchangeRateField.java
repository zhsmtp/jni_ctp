package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryExchangeRateField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String FromCurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public String ToCurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)

	public CThostFtdcQryExchangeRateField(){}

	public CThostFtdcQryExchangeRateField(byte[] BrokerID,byte[] FromCurrencyID,byte[] ToCurrencyID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(FromCurrencyID !=null)	this.FromCurrencyID= new String(FromCurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FromCurrencyID = "";}
		try{	if(ToCurrencyID !=null)	this.ToCurrencyID= new String(ToCurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ToCurrencyID = "";}
	}
}
