package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcReqAuthenticateField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String UserProductInfo = "";	 //char[11]	(TThostFtdcProductInfoType)
	public String AuthCode = "";	 //char[17]	(TThostFtdcAuthCodeType)
	public String AppID = "";	 //char[33]	(TThostFtdcAppIDType)

	public CThostFtdcReqAuthenticateField(){}

	public CThostFtdcReqAuthenticateField(byte[] BrokerID,byte[] UserID,byte[] UserProductInfo,byte[] AuthCode,byte[] AppID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(UserProductInfo !=null)	this.UserProductInfo= new String(UserProductInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserProductInfo = "";}
		try{	if(AuthCode !=null)	this.AuthCode= new String(AuthCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AuthCode = "";}
		try{	if(AppID !=null)	this.AppID= new String(AppID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AppID = "";}
	}
}
