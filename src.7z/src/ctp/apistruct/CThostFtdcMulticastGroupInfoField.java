package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMulticastGroupInfoField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String GroupIP = "";	 //char[16]	(TThostFtdcIPAddressType)
	public int GroupPort;
	public String SourceIP = "";	 //char[16]	(TThostFtdcIPAddressType)

	public CThostFtdcMulticastGroupInfoField(){}

	public CThostFtdcMulticastGroupInfoField(byte[] GroupIP,int GroupPort,byte[] SourceIP){
		try{	if(GroupIP !=null)	this.GroupIP= new String(GroupIP, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.GroupIP = "";}
		this.GroupPort=GroupPort;
		try{	if(SourceIP !=null)	this.SourceIP= new String(SourceIP, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.SourceIP = "";}
	}
}
