package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcDRTransferField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int OrigDRIdentityID;
	public int DestDRIdentityID;
	public String OrigBrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String DestBrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)

	public CThostFtdcDRTransferField(){}

	public CThostFtdcDRTransferField(int OrigDRIdentityID,int DestDRIdentityID,byte[] OrigBrokerID,byte[] DestBrokerID){
		this.OrigDRIdentityID=OrigDRIdentityID;
		this.DestDRIdentityID=DestDRIdentityID;
		try{	if(OrigBrokerID !=null)	this.OrigBrokerID= new String(OrigBrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrigBrokerID = "";}
		try{	if(DestBrokerID !=null)	this.DestBrokerID= new String(DestBrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.DestBrokerID = "";}
	}
}
