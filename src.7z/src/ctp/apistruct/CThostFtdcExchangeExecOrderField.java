package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcExchangeExecOrderField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int Volume;
	public int RequestID;
	public String BusinessUnit = "";	 //char[21]	(TThostFtdcBusinessUnitType)
	public char OffsetFlag;
	public char HedgeFlag;
	public char ActionType;
	public char PosiDirection;
	public char ReservePositionFlag;
	public char CloseFlag;
	public String ExecOrderLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String ClientID = "";	 //char[11]	(TThostFtdcClientIDType)
	public String ExchangeInstID = "";	 //char[31]	(TThostFtdcExchangeInstIDType)
	public String TraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public int InstallID;
	public char OrderSubmitStatus;
	public int NotifySequence;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public int SettlementID;
	public String ExecOrderSysID = "";	 //char[21]	(TThostFtdcExecOrderSysIDType)
	public String InsertDate = "";	 //char[9]	(TThostFtdcDateType)
	public String InsertTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String CancelTime = "";	 //char[9]	(TThostFtdcTimeType)
	public char ExecResult;
	public String ClearingPartID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public int SequenceNo;
	public String BranchID = "";	 //char[9]	(TThostFtdcBranchIDType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)

	public CThostFtdcExchangeExecOrderField(){}

	public CThostFtdcExchangeExecOrderField(int Volume,int RequestID,byte[] BusinessUnit,char OffsetFlag,char HedgeFlag,char ActionType,char PosiDirection,char ReservePositionFlag,char CloseFlag,byte[] ExecOrderLocalID,byte[] ExchangeID,byte[] ParticipantID,byte[] ClientID,byte[] ExchangeInstID,byte[] TraderID,int InstallID,char OrderSubmitStatus,int NotifySequence,byte[] TradingDay,int SettlementID,byte[] ExecOrderSysID,byte[] InsertDate,byte[] InsertTime,byte[] CancelTime,char ExecResult,byte[] ClearingPartID,int SequenceNo,byte[] BranchID,byte[] IPAddress,byte[] MacAddress){
		this.Volume=Volume;
		this.RequestID=RequestID;
		try{	if(BusinessUnit !=null)	this.BusinessUnit= new String(BusinessUnit, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BusinessUnit = "";}
		this.OffsetFlag=OffsetFlag;
		this.HedgeFlag=HedgeFlag;
		this.ActionType=ActionType;
		this.PosiDirection=PosiDirection;
		this.ReservePositionFlag=ReservePositionFlag;
		this.CloseFlag=CloseFlag;
		try{	if(ExecOrderLocalID !=null)	this.ExecOrderLocalID= new String(ExecOrderLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExecOrderLocalID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(ClientID !=null)	this.ClientID= new String(ClientID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientID = "";}
		try{	if(ExchangeInstID !=null)	this.ExchangeInstID= new String(ExchangeInstID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeInstID = "";}
		try{	if(TraderID !=null)	this.TraderID= new String(TraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TraderID = "";}
		this.InstallID=InstallID;
		this.OrderSubmitStatus=OrderSubmitStatus;
		this.NotifySequence=NotifySequence;
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.SettlementID=SettlementID;
		try{	if(ExecOrderSysID !=null)	this.ExecOrderSysID= new String(ExecOrderSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExecOrderSysID = "";}
		try{	if(InsertDate !=null)	this.InsertDate= new String(InsertDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InsertDate = "";}
		try{	if(InsertTime !=null)	this.InsertTime= new String(InsertTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InsertTime = "";}
		try{	if(CancelTime !=null)	this.CancelTime= new String(CancelTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CancelTime = "";}
		this.ExecResult=ExecResult;
		try{	if(ClearingPartID !=null)	this.ClearingPartID= new String(ClearingPartID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClearingPartID = "";}
		this.SequenceNo=SequenceNo;
		try{	if(BranchID !=null)	this.BranchID= new String(BranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BranchID = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
	}
}
