package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcRspInfoField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int ErrorID;
	public String ErrorMsg = "";	 //char[81]	(TThostFtdcErrorMsgType)

	public CThostFtdcRspInfoField(){}

	public CThostFtdcRspInfoField(int ErrorID,byte[] ErrorMsg){
		this.ErrorID=ErrorID;
		try{	if(ErrorMsg !=null)	this.ErrorMsg= new String(ErrorMsg, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ErrorMsg = "";}
	}
}
