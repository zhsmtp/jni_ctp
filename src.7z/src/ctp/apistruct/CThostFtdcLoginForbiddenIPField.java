package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcLoginForbiddenIPField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)

	public CThostFtdcLoginForbiddenIPField(){}

	public CThostFtdcLoginForbiddenIPField(byte[] IPAddress){
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
	}
}
