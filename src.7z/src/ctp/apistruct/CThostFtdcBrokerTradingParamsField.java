package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcBrokerTradingParamsField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public char MarginPriceType;
	public char Algorithm;
	public char AvailIncludeCloseProfit;
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public char OptionRoyaltyPriceType;
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)

	public CThostFtdcBrokerTradingParamsField(){}

	public CThostFtdcBrokerTradingParamsField(byte[] BrokerID,byte[] InvestorID,char MarginPriceType,char Algorithm,char AvailIncludeCloseProfit,byte[] CurrencyID,char OptionRoyaltyPriceType,byte[] AccountID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.MarginPriceType=MarginPriceType;
		this.Algorithm=Algorithm;
		this.AvailIncludeCloseProfit=AvailIncludeCloseProfit;
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		this.OptionRoyaltyPriceType=OptionRoyaltyPriceType;
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
	}
}
