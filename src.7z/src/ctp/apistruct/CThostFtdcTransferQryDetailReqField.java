package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTransferQryDetailReqField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String FutureAccount = "";	 //char[13]	(TThostFtdcAccountIDType)

	public CThostFtdcTransferQryDetailReqField(){}

	public CThostFtdcTransferQryDetailReqField(byte[] FutureAccount){
		try{	if(FutureAccount !=null)	this.FutureAccount= new String(FutureAccount, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FutureAccount = "";}
	}
}
