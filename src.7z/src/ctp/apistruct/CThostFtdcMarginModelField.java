package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMarginModelField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String MarginModelID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String MarginModelName = "";	 //char[161]	(TThostFtdcCommModelNameType)

	public CThostFtdcMarginModelField(){}

	public CThostFtdcMarginModelField(byte[] BrokerID,byte[] MarginModelID,byte[] MarginModelName){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(MarginModelID !=null)	this.MarginModelID= new String(MarginModelID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MarginModelID = "";}
		try{	if(MarginModelName !=null)	this.MarginModelName= new String(MarginModelName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MarginModelName = "";}
	}
}
