package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcInstrumentCommissionRateField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public char InvestorRange;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public double OpenRatioByMoney;
	public double OpenRatioByVolume;
	public double CloseRatioByMoney;
	public double CloseRatioByVolume;
	public double CloseTodayRatioByMoney;
	public double CloseTodayRatioByVolume;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public char BizType;
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)

	public CThostFtdcInstrumentCommissionRateField(){}

	public CThostFtdcInstrumentCommissionRateField(byte[] InstrumentID,char InvestorRange,byte[] BrokerID,byte[] InvestorID,double OpenRatioByMoney,double OpenRatioByVolume,double CloseRatioByMoney,double CloseRatioByVolume,double CloseTodayRatioByMoney,double CloseTodayRatioByVolume,byte[] ExchangeID,char BizType,byte[] InvestUnitID){
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		this.InvestorRange=InvestorRange;
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.OpenRatioByMoney=OpenRatioByMoney;
		this.OpenRatioByVolume=OpenRatioByVolume;
		this.CloseRatioByMoney=CloseRatioByMoney;
		this.CloseRatioByVolume=CloseRatioByVolume;
		this.CloseTodayRatioByMoney=CloseTodayRatioByMoney;
		this.CloseTodayRatioByVolume=CloseTodayRatioByVolume;
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		this.BizType=BizType;
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
	}
}
