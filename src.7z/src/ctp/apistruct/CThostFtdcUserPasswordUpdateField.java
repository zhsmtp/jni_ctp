package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcUserPasswordUpdateField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String OldPassword = "";	 //char[41]	(TThostFtdcPasswordType)
	public String NewPassword = "";	 //char[41]	(TThostFtdcPasswordType)

	public CThostFtdcUserPasswordUpdateField(){}

	public CThostFtdcUserPasswordUpdateField(byte[] BrokerID,byte[] UserID,byte[] OldPassword,byte[] NewPassword){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(OldPassword !=null)	this.OldPassword= new String(OldPassword, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OldPassword = "";}
		try{	if(NewPassword !=null)	this.NewPassword= new String(NewPassword, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.NewPassword = "";}
	}
}
