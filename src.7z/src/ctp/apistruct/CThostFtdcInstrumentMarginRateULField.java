package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcInstrumentMarginRateULField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public char InvestorRange;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public char HedgeFlag;
	public double LongMarginRatioByMoney;
	public double LongMarginRatioByVolume;
	public double ShortMarginRatioByMoney;
	public double ShortMarginRatioByVolume;

	public CThostFtdcInstrumentMarginRateULField(){}

	public CThostFtdcInstrumentMarginRateULField(byte[] InstrumentID,char InvestorRange,byte[] BrokerID,byte[] InvestorID,char HedgeFlag,double LongMarginRatioByMoney,double LongMarginRatioByVolume,double ShortMarginRatioByMoney,double ShortMarginRatioByVolume){
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		this.InvestorRange=InvestorRange;
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.HedgeFlag=HedgeFlag;
		this.LongMarginRatioByMoney=LongMarginRatioByMoney;
		this.LongMarginRatioByVolume=LongMarginRatioByVolume;
		this.ShortMarginRatioByMoney=ShortMarginRatioByMoney;
		this.ShortMarginRatioByVolume=ShortMarginRatioByVolume;
	}
}
