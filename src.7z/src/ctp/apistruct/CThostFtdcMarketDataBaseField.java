package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMarketDataBaseField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public double PreSettlementPrice;
	public double PreClosePrice;
	public double PreOpenInterest;
	public double PreDelta;

	public CThostFtdcMarketDataBaseField(){}

	public CThostFtdcMarketDataBaseField(byte[] TradingDay,double PreSettlementPrice,double PreClosePrice,double PreOpenInterest,double PreDelta){
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.PreSettlementPrice=PreSettlementPrice;
		this.PreClosePrice=PreClosePrice;
		this.PreOpenInterest=PreOpenInterest;
		this.PreDelta=PreDelta;
	}
}
