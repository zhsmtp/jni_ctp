package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcErrExecOrderActionField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public int ExecOrderActionRef;
	public String ExecOrderRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public int RequestID;
	public int FrontID;
	public int SessionID;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ExecOrderSysID = "";	 //char[21]	(TThostFtdcExecOrderSysIDType)
	public char ActionFlag;
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)
	public int ErrorID;
	public String ErrorMsg = "";	 //char[81]	(TThostFtdcErrorMsgType)

	public CThostFtdcErrExecOrderActionField(){}

	public CThostFtdcErrExecOrderActionField(byte[] BrokerID,byte[] InvestorID,int ExecOrderActionRef,byte[] ExecOrderRef,int RequestID,int FrontID,int SessionID,byte[] ExchangeID,byte[] ExecOrderSysID,char ActionFlag,byte[] UserID,byte[] InstrumentID,byte[] InvestUnitID,byte[] IPAddress,byte[] MacAddress,int ErrorID,byte[] ErrorMsg){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.ExecOrderActionRef=ExecOrderActionRef;
		try{	if(ExecOrderRef !=null)	this.ExecOrderRef= new String(ExecOrderRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExecOrderRef = "";}
		this.RequestID=RequestID;
		this.FrontID=FrontID;
		this.SessionID=SessionID;
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ExecOrderSysID !=null)	this.ExecOrderSysID= new String(ExecOrderSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExecOrderSysID = "";}
		this.ActionFlag=ActionFlag;
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
		this.ErrorID=ErrorID;
		try{	if(ErrorMsg !=null)	this.ErrorMsg= new String(ErrorMsg, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ErrorMsg = "";}
	}
}
