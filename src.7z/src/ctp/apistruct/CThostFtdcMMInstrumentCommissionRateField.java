package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMMInstrumentCommissionRateField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public char InvestorRange;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public double OpenRatioByMoney;
	public double OpenRatioByVolume;
	public double CloseRatioByMoney;
	public double CloseRatioByVolume;
	public double CloseTodayRatioByMoney;
	public double CloseTodayRatioByVolume;

	public CThostFtdcMMInstrumentCommissionRateField(){}

	public CThostFtdcMMInstrumentCommissionRateField(byte[] InstrumentID,char InvestorRange,byte[] BrokerID,byte[] InvestorID,double OpenRatioByMoney,double OpenRatioByVolume,double CloseRatioByMoney,double CloseRatioByVolume,double CloseTodayRatioByMoney,double CloseTodayRatioByVolume){
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		this.InvestorRange=InvestorRange;
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.OpenRatioByMoney=OpenRatioByMoney;
		this.OpenRatioByVolume=OpenRatioByVolume;
		this.CloseRatioByMoney=CloseRatioByMoney;
		this.CloseRatioByVolume=CloseRatioByVolume;
		this.CloseTodayRatioByMoney=CloseTodayRatioByMoney;
		this.CloseTodayRatioByVolume=CloseTodayRatioByVolume;
	}
}
