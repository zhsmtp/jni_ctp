package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQrySyncDelaySwapField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String DelaySwapSeqNo = "";	 //char[15]	(TThostFtdcDepositSeqNoType)

	public CThostFtdcQrySyncDelaySwapField(){}

	public CThostFtdcQrySyncDelaySwapField(byte[] BrokerID,byte[] DelaySwapSeqNo){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(DelaySwapSeqNo !=null)	this.DelaySwapSeqNo= new String(DelaySwapSeqNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.DelaySwapSeqNo = "";}
	}
}
