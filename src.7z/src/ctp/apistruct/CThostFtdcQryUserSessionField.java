package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryUserSessionField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int FrontID;
	public int SessionID;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)

	public CThostFtdcQryUserSessionField(){}

	public CThostFtdcQryUserSessionField(int FrontID,int SessionID,byte[] BrokerID,byte[] UserID){
		this.FrontID=FrontID;
		this.SessionID=SessionID;
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
	}
}
