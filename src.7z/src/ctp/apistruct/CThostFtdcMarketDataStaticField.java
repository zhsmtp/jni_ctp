package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMarketDataStaticField implements Serializable {
	private static final long serialVersionUID = 1L;
	public double OpenPrice;
	public double HighestPrice;
	public double LowestPrice;
	public double ClosePrice;
	public double UpperLimitPrice;
	public double LowerLimitPrice;
	public double SettlementPrice;
	public double CurrDelta;

	public CThostFtdcMarketDataStaticField(){}

	public CThostFtdcMarketDataStaticField(double OpenPrice,double HighestPrice,double LowestPrice,double ClosePrice,double UpperLimitPrice,double LowerLimitPrice,double SettlementPrice,double CurrDelta){
		this.OpenPrice=OpenPrice;
		this.HighestPrice=HighestPrice;
		this.LowestPrice=LowestPrice;
		this.ClosePrice=ClosePrice;
		this.UpperLimitPrice=UpperLimitPrice;
		this.LowerLimitPrice=LowerLimitPrice;
		this.SettlementPrice=SettlementPrice;
		this.CurrDelta=CurrDelta;
	}
}
