package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcPositionProfitAlgorithmField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public char Algorithm;
	public String Memo = "";	 //char[161]	(TThostFtdcMemoType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)

	public CThostFtdcPositionProfitAlgorithmField(){}

	public CThostFtdcPositionProfitAlgorithmField(byte[] BrokerID,byte[] AccountID,char Algorithm,byte[] Memo,byte[] CurrencyID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		this.Algorithm=Algorithm;
		try{	if(Memo !=null)	this.Memo= new String(Memo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Memo = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
	}
}
