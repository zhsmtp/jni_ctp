package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcInvestorGroupField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorGroupID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String InvestorGroupName = "";	 //char[41]	(TThostFtdcInvestorGroupNameType)

	public CThostFtdcInvestorGroupField(){}

	public CThostFtdcInvestorGroupField(byte[] BrokerID,byte[] InvestorGroupID,byte[] InvestorGroupName){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorGroupID !=null)	this.InvestorGroupID= new String(InvestorGroupID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorGroupID = "";}
		try{	if(InvestorGroupName !=null)	this.InvestorGroupName= new String(InvestorGroupName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorGroupName = "";}
	}
}
