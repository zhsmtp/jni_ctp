package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcProductGroupField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ProductID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ProductGroupID = "";	 //char[31]	(TThostFtdcInstrumentIDType)

	public CThostFtdcProductGroupField(){}

	public CThostFtdcProductGroupField(byte[] ProductID,byte[] ExchangeID,byte[] ProductGroupID){
		try{	if(ProductID !=null)	this.ProductID= new String(ProductID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ProductID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ProductGroupID !=null)	this.ProductGroupID= new String(ProductGroupID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ProductGroupID = "";}
	}
}
