package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTradingAccountPasswordUpdateField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String OldPassword = "";	 //char[41]	(TThostFtdcPasswordType)
	public String NewPassword = "";	 //char[41]	(TThostFtdcPasswordType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)

	public CThostFtdcTradingAccountPasswordUpdateField(){}

	public CThostFtdcTradingAccountPasswordUpdateField(byte[] BrokerID,byte[] AccountID,byte[] OldPassword,byte[] NewPassword,byte[] CurrencyID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(OldPassword !=null)	this.OldPassword= new String(OldPassword, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OldPassword = "";}
		try{	if(NewPassword !=null)	this.NewPassword= new String(NewPassword, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.NewPassword = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
	}
}
