package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcRemoveParkedOrderField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String ParkedOrderID = "";	 //char[13]	(TThostFtdcParkedOrderIDType)
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)

	public CThostFtdcRemoveParkedOrderField(){}

	public CThostFtdcRemoveParkedOrderField(byte[] BrokerID,byte[] InvestorID,byte[] ParkedOrderID,byte[] InvestUnitID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(ParkedOrderID !=null)	this.ParkedOrderID= new String(ParkedOrderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParkedOrderID = "";}
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
	}
}
