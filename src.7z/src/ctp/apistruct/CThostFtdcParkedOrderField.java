package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcParkedOrderField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String OrderRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public char OrderPriceType;
	public char Direction;
	public String CombOffsetFlag = "";	 //char[5]	(TThostFtdcCombOffsetFlagType)
	public String CombHedgeFlag = "";	 //char[5]	(TThostFtdcCombHedgeFlagType)
	public double LimitPrice;
	public int VolumeTotalOriginal;
	public char TimeCondition;
	public String GTDDate = "";	 //char[9]	(TThostFtdcDateType)
	public char VolumeCondition;
	public int MinVolume;
	public char ContingentCondition;
	public double StopPrice;
	public char ForceCloseReason;
	public int IsAutoSuspend;
	public String BusinessUnit = "";	 //char[21]	(TThostFtdcBusinessUnitType)
	public int RequestID;
	public int UserForceClose;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ParkedOrderID = "";	 //char[13]	(TThostFtdcParkedOrderIDType)
	public char UserType;
	public char Status;
	public int ErrorID;
	public String ErrorMsg = "";	 //char[81]	(TThostFtdcErrorMsgType)
	public int IsSwapOrder;
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public String ClientID = "";	 //char[11]	(TThostFtdcClientIDType)
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)

	public CThostFtdcParkedOrderField(){}

	public CThostFtdcParkedOrderField(byte[] BrokerID,byte[] InvestorID,byte[] InstrumentID,byte[] OrderRef,byte[] UserID,char OrderPriceType,char Direction,byte[] CombOffsetFlag,byte[] CombHedgeFlag,double LimitPrice,int VolumeTotalOriginal,char TimeCondition,byte[] GTDDate,char VolumeCondition,int MinVolume,char ContingentCondition,double StopPrice,char ForceCloseReason,int IsAutoSuspend,byte[] BusinessUnit,int RequestID,int UserForceClose,byte[] ExchangeID,byte[] ParkedOrderID,char UserType,char Status,int ErrorID,byte[] ErrorMsg,int IsSwapOrder,byte[] AccountID,byte[] CurrencyID,byte[] ClientID,byte[] InvestUnitID,byte[] IPAddress,byte[] MacAddress){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(OrderRef !=null)	this.OrderRef= new String(OrderRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderRef = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.OrderPriceType=OrderPriceType;
		this.Direction=Direction;
		try{	if(CombOffsetFlag !=null)	this.CombOffsetFlag= new String(CombOffsetFlag, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CombOffsetFlag = "";}
		try{	if(CombHedgeFlag !=null)	this.CombHedgeFlag= new String(CombHedgeFlag, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CombHedgeFlag = "";}
		this.LimitPrice=LimitPrice;
		this.VolumeTotalOriginal=VolumeTotalOriginal;
		this.TimeCondition=TimeCondition;
		try{	if(GTDDate !=null)	this.GTDDate= new String(GTDDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.GTDDate = "";}
		this.VolumeCondition=VolumeCondition;
		this.MinVolume=MinVolume;
		this.ContingentCondition=ContingentCondition;
		this.StopPrice=StopPrice;
		this.ForceCloseReason=ForceCloseReason;
		this.IsAutoSuspend=IsAutoSuspend;
		try{	if(BusinessUnit !=null)	this.BusinessUnit= new String(BusinessUnit, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BusinessUnit = "";}
		this.RequestID=RequestID;
		this.UserForceClose=UserForceClose;
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ParkedOrderID !=null)	this.ParkedOrderID= new String(ParkedOrderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParkedOrderID = "";}
		this.UserType=UserType;
		this.Status=Status;
		this.ErrorID=ErrorID;
		try{	if(ErrorMsg !=null)	this.ErrorMsg= new String(ErrorMsg, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ErrorMsg = "";}
		this.IsSwapOrder=IsSwapOrder;
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		try{	if(ClientID !=null)	this.ClientID= new String(ClientID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientID = "";}
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
	}
}
