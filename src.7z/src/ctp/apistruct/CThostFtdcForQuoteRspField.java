package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcForQuoteRspField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String ForQuoteSysID = "";	 //char[21]	(TThostFtdcOrderSysIDType)
	public String ForQuoteTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String ActionDay = "";	 //char[9]	(TThostFtdcDateType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)

	public CThostFtdcForQuoteRspField(){}

	public CThostFtdcForQuoteRspField(byte[] TradingDay,byte[] InstrumentID,byte[] ForQuoteSysID,byte[] ForQuoteTime,byte[] ActionDay,byte[] ExchangeID){
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(ForQuoteSysID !=null)	this.ForQuoteSysID= new String(ForQuoteSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ForQuoteSysID = "";}
		try{	if(ForQuoteTime !=null)	this.ForQuoteTime= new String(ForQuoteTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ForQuoteTime = "";}
		try{	if(ActionDay !=null)	this.ActionDay= new String(ActionDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActionDay = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
	}
}
