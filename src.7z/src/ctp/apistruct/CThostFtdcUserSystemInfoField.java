package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcUserSystemInfoField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public int ClientSystemInfoLen;
	public String ClientSystemInfo = "";	 //char[273]	(TThostFtdcClientSystemInfoType)
	public String ClientPublicIP = "";	 //char[16]	(TThostFtdcIPAddressType)
	public int ClientIPPort;
	public String ClientLoginTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String ClientAppID = "";	 //char[33]	(TThostFtdcAppIDType)

	public CThostFtdcUserSystemInfoField(){}

	public CThostFtdcUserSystemInfoField(byte[] BrokerID,byte[] UserID,int ClientSystemInfoLen,byte[] ClientSystemInfo,byte[] ClientPublicIP,int ClientIPPort,byte[] ClientLoginTime,byte[] ClientAppID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.ClientSystemInfoLen=ClientSystemInfoLen;
		try{	if(ClientSystemInfo !=null)	this.ClientSystemInfo= new String(ClientSystemInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientSystemInfo = "";}
		try{	if(ClientPublicIP !=null)	this.ClientPublicIP= new String(ClientPublicIP, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientPublicIP = "";}
		this.ClientIPPort=ClientIPPort;
		try{	if(ClientLoginTime !=null)	this.ClientLoginTime= new String(ClientLoginTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientLoginTime = "";}
		try{	if(ClientAppID !=null)	this.ClientAppID= new String(ClientAppID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientAppID = "";}
	}
}
