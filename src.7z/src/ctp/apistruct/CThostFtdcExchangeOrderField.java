package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcExchangeOrderField implements Serializable {
	private static final long serialVersionUID = 1L;
	public char OrderPriceType;
	public char Direction;
	public String CombOffsetFlag = "";	 //char[5]	(TThostFtdcCombOffsetFlagType)
	public String CombHedgeFlag = "";	 //char[5]	(TThostFtdcCombHedgeFlagType)
	public double LimitPrice;
	public int VolumeTotalOriginal;
	public char TimeCondition;
	public String GTDDate = "";	 //char[9]	(TThostFtdcDateType)
	public char VolumeCondition;
	public int MinVolume;
	public char ContingentCondition;
	public double StopPrice;
	public char ForceCloseReason;
	public int IsAutoSuspend;
	public String BusinessUnit = "";	 //char[21]	(TThostFtdcBusinessUnitType)
	public int RequestID;
	public String OrderLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String ClientID = "";	 //char[11]	(TThostFtdcClientIDType)
	public String ExchangeInstID = "";	 //char[31]	(TThostFtdcExchangeInstIDType)
	public String TraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public int InstallID;
	public char OrderSubmitStatus;
	public int NotifySequence;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public int SettlementID;
	public String OrderSysID = "";	 //char[21]	(TThostFtdcOrderSysIDType)
	public char OrderSource;
	public char OrderStatus;
	public char OrderType;
	public int VolumeTraded;
	public int VolumeTotal;
	public String InsertDate = "";	 //char[9]	(TThostFtdcDateType)
	public String InsertTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String ActiveTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String SuspendTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String UpdateTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String CancelTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String ActiveTraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public String ClearingPartID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public int SequenceNo;
	public String BranchID = "";	 //char[9]	(TThostFtdcBranchIDType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)

	public CThostFtdcExchangeOrderField(){}

	public CThostFtdcExchangeOrderField(char OrderPriceType,char Direction,byte[] CombOffsetFlag,byte[] CombHedgeFlag,double LimitPrice,int VolumeTotalOriginal,char TimeCondition,byte[] GTDDate,char VolumeCondition,int MinVolume,char ContingentCondition,double StopPrice,char ForceCloseReason,int IsAutoSuspend,byte[] BusinessUnit,int RequestID,byte[] OrderLocalID,byte[] ExchangeID,byte[] ParticipantID,byte[] ClientID,byte[] ExchangeInstID,byte[] TraderID,int InstallID,char OrderSubmitStatus,int NotifySequence,byte[] TradingDay,int SettlementID,byte[] OrderSysID,char OrderSource,char OrderStatus,char OrderType,int VolumeTraded,int VolumeTotal,byte[] InsertDate,byte[] InsertTime,byte[] ActiveTime,byte[] SuspendTime,byte[] UpdateTime,byte[] CancelTime,byte[] ActiveTraderID,byte[] ClearingPartID,int SequenceNo,byte[] BranchID,byte[] IPAddress,byte[] MacAddress){
		this.OrderPriceType=OrderPriceType;
		this.Direction=Direction;
		try{	if(CombOffsetFlag !=null)	this.CombOffsetFlag= new String(CombOffsetFlag, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CombOffsetFlag = "";}
		try{	if(CombHedgeFlag !=null)	this.CombHedgeFlag= new String(CombHedgeFlag, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CombHedgeFlag = "";}
		this.LimitPrice=LimitPrice;
		this.VolumeTotalOriginal=VolumeTotalOriginal;
		this.TimeCondition=TimeCondition;
		try{	if(GTDDate !=null)	this.GTDDate= new String(GTDDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.GTDDate = "";}
		this.VolumeCondition=VolumeCondition;
		this.MinVolume=MinVolume;
		this.ContingentCondition=ContingentCondition;
		this.StopPrice=StopPrice;
		this.ForceCloseReason=ForceCloseReason;
		this.IsAutoSuspend=IsAutoSuspend;
		try{	if(BusinessUnit !=null)	this.BusinessUnit= new String(BusinessUnit, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BusinessUnit = "";}
		this.RequestID=RequestID;
		try{	if(OrderLocalID !=null)	this.OrderLocalID= new String(OrderLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderLocalID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(ClientID !=null)	this.ClientID= new String(ClientID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientID = "";}
		try{	if(ExchangeInstID !=null)	this.ExchangeInstID= new String(ExchangeInstID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeInstID = "";}
		try{	if(TraderID !=null)	this.TraderID= new String(TraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TraderID = "";}
		this.InstallID=InstallID;
		this.OrderSubmitStatus=OrderSubmitStatus;
		this.NotifySequence=NotifySequence;
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.SettlementID=SettlementID;
		try{	if(OrderSysID !=null)	this.OrderSysID= new String(OrderSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderSysID = "";}
		this.OrderSource=OrderSource;
		this.OrderStatus=OrderStatus;
		this.OrderType=OrderType;
		this.VolumeTraded=VolumeTraded;
		this.VolumeTotal=VolumeTotal;
		try{	if(InsertDate !=null)	this.InsertDate= new String(InsertDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InsertDate = "";}
		try{	if(InsertTime !=null)	this.InsertTime= new String(InsertTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InsertTime = "";}
		try{	if(ActiveTime !=null)	this.ActiveTime= new String(ActiveTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActiveTime = "";}
		try{	if(SuspendTime !=null)	this.SuspendTime= new String(SuspendTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.SuspendTime = "";}
		try{	if(UpdateTime !=null)	this.UpdateTime= new String(UpdateTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UpdateTime = "";}
		try{	if(CancelTime !=null)	this.CancelTime= new String(CancelTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CancelTime = "";}
		try{	if(ActiveTraderID !=null)	this.ActiveTraderID= new String(ActiveTraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActiveTraderID = "";}
		try{	if(ClearingPartID !=null)	this.ClearingPartID= new String(ClearingPartID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClearingPartID = "";}
		this.SequenceNo=SequenceNo;
		try{	if(BranchID !=null)	this.BranchID= new String(BranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BranchID = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
	}
}
