package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMarketDataAsk45Field implements Serializable {
	private static final long serialVersionUID = 1L;
	public double AskPrice4;
	public int AskVolume4;
	public double AskPrice5;
	public int AskVolume5;

	public CThostFtdcMarketDataAsk45Field(){}

	public CThostFtdcMarketDataAsk45Field(double AskPrice4,int AskVolume4,double AskPrice5,int AskVolume5){
		this.AskPrice4=AskPrice4;
		this.AskVolume4=AskVolume4;
		this.AskPrice5=AskPrice5;
		this.AskVolume5=AskVolume5;
	}
}
