package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcInputQuoteField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String QuoteRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public double AskPrice;
	public double BidPrice;
	public int AskVolume;
	public int BidVolume;
	public int RequestID;
	public String BusinessUnit = "";	 //char[21]	(TThostFtdcBusinessUnitType)
	public char AskOffsetFlag;
	public char BidOffsetFlag;
	public char AskHedgeFlag;
	public char BidHedgeFlag;
	public String AskOrderRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String BidOrderRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String ForQuoteSysID = "";	 //char[21]	(TThostFtdcOrderSysIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)
	public String ClientID = "";	 //char[11]	(TThostFtdcClientIDType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)

	public CThostFtdcInputQuoteField(){}

	public CThostFtdcInputQuoteField(byte[] BrokerID,byte[] InvestorID,byte[] InstrumentID,byte[] QuoteRef,byte[] UserID,double AskPrice,double BidPrice,int AskVolume,int BidVolume,int RequestID,byte[] BusinessUnit,char AskOffsetFlag,char BidOffsetFlag,char AskHedgeFlag,char BidHedgeFlag,byte[] AskOrderRef,byte[] BidOrderRef,byte[] ForQuoteSysID,byte[] ExchangeID,byte[] InvestUnitID,byte[] ClientID,byte[] IPAddress,byte[] MacAddress){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(QuoteRef !=null)	this.QuoteRef= new String(QuoteRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.QuoteRef = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.AskPrice=AskPrice;
		this.BidPrice=BidPrice;
		this.AskVolume=AskVolume;
		this.BidVolume=BidVolume;
		this.RequestID=RequestID;
		try{	if(BusinessUnit !=null)	this.BusinessUnit= new String(BusinessUnit, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BusinessUnit = "";}
		this.AskOffsetFlag=AskOffsetFlag;
		this.BidOffsetFlag=BidOffsetFlag;
		this.AskHedgeFlag=AskHedgeFlag;
		this.BidHedgeFlag=BidHedgeFlag;
		try{	if(AskOrderRef !=null)	this.AskOrderRef= new String(AskOrderRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AskOrderRef = "";}
		try{	if(BidOrderRef !=null)	this.BidOrderRef= new String(BidOrderRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BidOrderRef = "";}
		try{	if(ForQuoteSysID !=null)	this.ForQuoteSysID= new String(ForQuoteSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ForQuoteSysID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
		try{	if(ClientID !=null)	this.ClientID= new String(ClientID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientID = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
	}
}
