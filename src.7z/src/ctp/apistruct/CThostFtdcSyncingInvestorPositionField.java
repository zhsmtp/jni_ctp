package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcSyncingInvestorPositionField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public char PosiDirection;
	public char HedgeFlag;
	public char PositionDate;
	public int YdPosition;
	public int Position;
	public int LongFrozen;
	public int ShortFrozen;
	public double LongFrozenAmount;
	public double ShortFrozenAmount;
	public int OpenVolume;
	public int CloseVolume;
	public double OpenAmount;
	public double CloseAmount;
	public double PositionCost;
	public double PreMargin;
	public double UseMargin;
	public double FrozenMargin;
	public double FrozenCash;
	public double FrozenCommission;
	public double CashIn;
	public double Commission;
	public double CloseProfit;
	public double PositionProfit;
	public double PreSettlementPrice;
	public double SettlementPrice;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public int SettlementID;
	public double OpenCost;
	public double ExchangeMargin;
	public int CombPosition;
	public int CombLongFrozen;
	public int CombShortFrozen;
	public double CloseProfitByDate;
	public double CloseProfitByTrade;
	public int TodayPosition;
	public double MarginRateByMoney;
	public double MarginRateByVolume;
	public int StrikeFrozen;
	public double StrikeFrozenAmount;
	public int AbandonFrozen;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public int YdStrikeFrozen;
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)
	public double PositionCostOffset;

	public CThostFtdcSyncingInvestorPositionField(){}

	public CThostFtdcSyncingInvestorPositionField(byte[] InstrumentID,byte[] BrokerID,byte[] InvestorID,char PosiDirection,char HedgeFlag,char PositionDate,int YdPosition,int Position,int LongFrozen,int ShortFrozen,double LongFrozenAmount,double ShortFrozenAmount,int OpenVolume,int CloseVolume,double OpenAmount,double CloseAmount,double PositionCost,double PreMargin,double UseMargin,double FrozenMargin,double FrozenCash,double FrozenCommission,double CashIn,double Commission,double CloseProfit,double PositionProfit,double PreSettlementPrice,double SettlementPrice,byte[] TradingDay,int SettlementID,double OpenCost,double ExchangeMargin,int CombPosition,int CombLongFrozen,int CombShortFrozen,double CloseProfitByDate,double CloseProfitByTrade,int TodayPosition,double MarginRateByMoney,double MarginRateByVolume,int StrikeFrozen,double StrikeFrozenAmount,int AbandonFrozen,byte[] ExchangeID,int YdStrikeFrozen,byte[] InvestUnitID,double PositionCostOffset){
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.PosiDirection=PosiDirection;
		this.HedgeFlag=HedgeFlag;
		this.PositionDate=PositionDate;
		this.YdPosition=YdPosition;
		this.Position=Position;
		this.LongFrozen=LongFrozen;
		this.ShortFrozen=ShortFrozen;
		this.LongFrozenAmount=LongFrozenAmount;
		this.ShortFrozenAmount=ShortFrozenAmount;
		this.OpenVolume=OpenVolume;
		this.CloseVolume=CloseVolume;
		this.OpenAmount=OpenAmount;
		this.CloseAmount=CloseAmount;
		this.PositionCost=PositionCost;
		this.PreMargin=PreMargin;
		this.UseMargin=UseMargin;
		this.FrozenMargin=FrozenMargin;
		this.FrozenCash=FrozenCash;
		this.FrozenCommission=FrozenCommission;
		this.CashIn=CashIn;
		this.Commission=Commission;
		this.CloseProfit=CloseProfit;
		this.PositionProfit=PositionProfit;
		this.PreSettlementPrice=PreSettlementPrice;
		this.SettlementPrice=SettlementPrice;
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.SettlementID=SettlementID;
		this.OpenCost=OpenCost;
		this.ExchangeMargin=ExchangeMargin;
		this.CombPosition=CombPosition;
		this.CombLongFrozen=CombLongFrozen;
		this.CombShortFrozen=CombShortFrozen;
		this.CloseProfitByDate=CloseProfitByDate;
		this.CloseProfitByTrade=CloseProfitByTrade;
		this.TodayPosition=TodayPosition;
		this.MarginRateByMoney=MarginRateByMoney;
		this.MarginRateByVolume=MarginRateByVolume;
		this.StrikeFrozen=StrikeFrozen;
		this.StrikeFrozenAmount=StrikeFrozenAmount;
		this.AbandonFrozen=AbandonFrozen;
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		this.YdStrikeFrozen=YdStrikeFrozen;
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
		this.PositionCostOffset=PositionCostOffset;
	}
}
