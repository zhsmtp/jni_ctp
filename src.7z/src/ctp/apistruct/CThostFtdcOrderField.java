package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcOrderField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String OrderRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public char OrderPriceType;
	public char Direction;
	public String CombOffsetFlag = "";	 //char[5]	(TThostFtdcCombOffsetFlagType)
	public String CombHedgeFlag = "";	 //char[5]	(TThostFtdcCombHedgeFlagType)
	public double LimitPrice;
	public int VolumeTotalOriginal;
	public char TimeCondition;
	public String GTDDate = "";	 //char[9]	(TThostFtdcDateType)
	public char VolumeCondition;
	public int MinVolume;
	public char ContingentCondition;
	public double StopPrice;
	public char ForceCloseReason;
	public int IsAutoSuspend;
	public String BusinessUnit = "";	 //char[21]	(TThostFtdcBusinessUnitType)
	public int RequestID;
	public String OrderLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String ClientID = "";	 //char[11]	(TThostFtdcClientIDType)
	public String ExchangeInstID = "";	 //char[31]	(TThostFtdcExchangeInstIDType)
	public String TraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public int InstallID;
	public char OrderSubmitStatus;
	public int NotifySequence;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public int SettlementID;
	public String OrderSysID = "";	 //char[21]	(TThostFtdcOrderSysIDType)
	public char OrderSource;
	public char OrderStatus;
	public char OrderType;
	public int VolumeTraded;
	public int VolumeTotal;
	public String InsertDate = "";	 //char[9]	(TThostFtdcDateType)
	public String InsertTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String ActiveTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String SuspendTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String UpdateTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String CancelTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String ActiveTraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public String ClearingPartID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public int SequenceNo;
	public int FrontID;
	public int SessionID;
	public String UserProductInfo = "";	 //char[11]	(TThostFtdcProductInfoType)
	public String StatusMsg = "";	 //char[81]	(TThostFtdcErrorMsgType)
	public int UserForceClose;
	public String ActiveUserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public int BrokerOrderSeq;
	public String RelativeOrderSysID = "";	 //char[21]	(TThostFtdcOrderSysIDType)
	public int ZCETotalTradedVolume;
	public int IsSwapOrder;
	public String BranchID = "";	 //char[9]	(TThostFtdcBranchIDType)
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)

	public CThostFtdcOrderField(){}

	public CThostFtdcOrderField(byte[] BrokerID,byte[] InvestorID,byte[] InstrumentID,byte[] OrderRef,byte[] UserID,char OrderPriceType,char Direction,byte[] CombOffsetFlag,byte[] CombHedgeFlag,double LimitPrice,int VolumeTotalOriginal,char TimeCondition,byte[] GTDDate,char VolumeCondition,int MinVolume,char ContingentCondition,double StopPrice,char ForceCloseReason,int IsAutoSuspend,byte[] BusinessUnit,int RequestID,byte[] OrderLocalID,byte[] ExchangeID,byte[] ParticipantID,byte[] ClientID,byte[] ExchangeInstID,byte[] TraderID,int InstallID,char OrderSubmitStatus,int NotifySequence,byte[] TradingDay,int SettlementID,byte[] OrderSysID,char OrderSource,char OrderStatus,char OrderType,int VolumeTraded,int VolumeTotal,byte[] InsertDate,byte[] InsertTime,byte[] ActiveTime,byte[] SuspendTime,byte[] UpdateTime,byte[] CancelTime,byte[] ActiveTraderID,byte[] ClearingPartID,int SequenceNo,int FrontID,int SessionID,byte[] UserProductInfo,byte[] StatusMsg,int UserForceClose,byte[] ActiveUserID,int BrokerOrderSeq,byte[] RelativeOrderSysID,int ZCETotalTradedVolume,int IsSwapOrder,byte[] BranchID,byte[] InvestUnitID,byte[] AccountID,byte[] CurrencyID,byte[] IPAddress,byte[] MacAddress){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(OrderRef !=null)	this.OrderRef= new String(OrderRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderRef = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.OrderPriceType=OrderPriceType;
		this.Direction=Direction;
		try{	if(CombOffsetFlag !=null)	this.CombOffsetFlag= new String(CombOffsetFlag, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CombOffsetFlag = "";}
		try{	if(CombHedgeFlag !=null)	this.CombHedgeFlag= new String(CombHedgeFlag, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CombHedgeFlag = "";}
		this.LimitPrice=LimitPrice;
		this.VolumeTotalOriginal=VolumeTotalOriginal;
		this.TimeCondition=TimeCondition;
		try{	if(GTDDate !=null)	this.GTDDate= new String(GTDDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.GTDDate = "";}
		this.VolumeCondition=VolumeCondition;
		this.MinVolume=MinVolume;
		this.ContingentCondition=ContingentCondition;
		this.StopPrice=StopPrice;
		this.ForceCloseReason=ForceCloseReason;
		this.IsAutoSuspend=IsAutoSuspend;
		try{	if(BusinessUnit !=null)	this.BusinessUnit= new String(BusinessUnit, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BusinessUnit = "";}
		this.RequestID=RequestID;
		try{	if(OrderLocalID !=null)	this.OrderLocalID= new String(OrderLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderLocalID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(ClientID !=null)	this.ClientID= new String(ClientID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientID = "";}
		try{	if(ExchangeInstID !=null)	this.ExchangeInstID= new String(ExchangeInstID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeInstID = "";}
		try{	if(TraderID !=null)	this.TraderID= new String(TraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TraderID = "";}
		this.InstallID=InstallID;
		this.OrderSubmitStatus=OrderSubmitStatus;
		this.NotifySequence=NotifySequence;
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.SettlementID=SettlementID;
		try{	if(OrderSysID !=null)	this.OrderSysID= new String(OrderSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderSysID = "";}
		this.OrderSource=OrderSource;
		this.OrderStatus=OrderStatus;
		this.OrderType=OrderType;
		this.VolumeTraded=VolumeTraded;
		this.VolumeTotal=VolumeTotal;
		try{	if(InsertDate !=null)	this.InsertDate= new String(InsertDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InsertDate = "";}
		try{	if(InsertTime !=null)	this.InsertTime= new String(InsertTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InsertTime = "";}
		try{	if(ActiveTime !=null)	this.ActiveTime= new String(ActiveTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActiveTime = "";}
		try{	if(SuspendTime !=null)	this.SuspendTime= new String(SuspendTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.SuspendTime = "";}
		try{	if(UpdateTime !=null)	this.UpdateTime= new String(UpdateTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UpdateTime = "";}
		try{	if(CancelTime !=null)	this.CancelTime= new String(CancelTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CancelTime = "";}
		try{	if(ActiveTraderID !=null)	this.ActiveTraderID= new String(ActiveTraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActiveTraderID = "";}
		try{	if(ClearingPartID !=null)	this.ClearingPartID= new String(ClearingPartID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClearingPartID = "";}
		this.SequenceNo=SequenceNo;
		this.FrontID=FrontID;
		this.SessionID=SessionID;
		try{	if(UserProductInfo !=null)	this.UserProductInfo= new String(UserProductInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserProductInfo = "";}
		try{	if(StatusMsg !=null)	this.StatusMsg= new String(StatusMsg, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.StatusMsg = "";}
		this.UserForceClose=UserForceClose;
		try{	if(ActiveUserID !=null)	this.ActiveUserID= new String(ActiveUserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActiveUserID = "";}
		this.BrokerOrderSeq=BrokerOrderSeq;
		try{	if(RelativeOrderSysID !=null)	this.RelativeOrderSysID= new String(RelativeOrderSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.RelativeOrderSysID = "";}
		this.ZCETotalTradedVolume=ZCETotalTradedVolume;
		this.IsSwapOrder=IsSwapOrder;
		try{	if(BranchID !=null)	this.BranchID= new String(BranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BranchID = "";}
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
	}
}
