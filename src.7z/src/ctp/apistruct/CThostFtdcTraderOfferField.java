package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTraderOfferField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String TraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String Password = "";	 //char[41]	(TThostFtdcPasswordType)
	public int InstallID;
	public String OrderLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public char TraderConnectStatus;
	public String ConnectRequestDate = "";	 //char[9]	(TThostFtdcDateType)
	public String ConnectRequestTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String LastReportDate = "";	 //char[9]	(TThostFtdcDateType)
	public String LastReportTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String ConnectDate = "";	 //char[9]	(TThostFtdcDateType)
	public String ConnectTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String StartDate = "";	 //char[9]	(TThostFtdcDateType)
	public String StartTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String MaxTradeID = "";	 //char[21]	(TThostFtdcTradeIDType)
	public String MaxOrderMessageReference = "";	 //char[7]	(TThostFtdcReturnCodeType)

	public CThostFtdcTraderOfferField(){}

	public CThostFtdcTraderOfferField(byte[] ExchangeID,byte[] TraderID,byte[] ParticipantID,byte[] Password,int InstallID,byte[] OrderLocalID,char TraderConnectStatus,byte[] ConnectRequestDate,byte[] ConnectRequestTime,byte[] LastReportDate,byte[] LastReportTime,byte[] ConnectDate,byte[] ConnectTime,byte[] StartDate,byte[] StartTime,byte[] TradingDay,byte[] BrokerID,byte[] MaxTradeID,byte[] MaxOrderMessageReference){
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(TraderID !=null)	this.TraderID= new String(TraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TraderID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(Password !=null)	this.Password= new String(Password, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Password = "";}
		this.InstallID=InstallID;
		try{	if(OrderLocalID !=null)	this.OrderLocalID= new String(OrderLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderLocalID = "";}
		this.TraderConnectStatus=TraderConnectStatus;
		try{	if(ConnectRequestDate !=null)	this.ConnectRequestDate= new String(ConnectRequestDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ConnectRequestDate = "";}
		try{	if(ConnectRequestTime !=null)	this.ConnectRequestTime= new String(ConnectRequestTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ConnectRequestTime = "";}
		try{	if(LastReportDate !=null)	this.LastReportDate= new String(LastReportDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LastReportDate = "";}
		try{	if(LastReportTime !=null)	this.LastReportTime= new String(LastReportTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LastReportTime = "";}
		try{	if(ConnectDate !=null)	this.ConnectDate= new String(ConnectDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ConnectDate = "";}
		try{	if(ConnectTime !=null)	this.ConnectTime= new String(ConnectTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ConnectTime = "";}
		try{	if(StartDate !=null)	this.StartDate= new String(StartDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.StartDate = "";}
		try{	if(StartTime !=null)	this.StartTime= new String(StartTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.StartTime = "";}
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(MaxTradeID !=null)	this.MaxTradeID= new String(MaxTradeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MaxTradeID = "";}
		try{	if(MaxOrderMessageReference !=null)	this.MaxOrderMessageReference= new String(MaxOrderMessageReference, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MaxOrderMessageReference = "";}
	}
}
