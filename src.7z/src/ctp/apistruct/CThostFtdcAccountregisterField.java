package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcAccountregisterField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradeDay = "";	 //char[9]	(TThostFtdcTradeDateType)
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankBranchID = "";	 //char[5]	(TThostFtdcBankBrchIDType)
	public String BankAccount = "";	 //char[41]	(TThostFtdcBankAccountType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String BrokerBranchID = "";	 //char[31]	(TThostFtdcFutureBranchIDType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public char IdCardType;
	public String IdentifiedCardNo = "";	 //char[51]	(TThostFtdcIdentifiedCardNoType)
	public String CustomerName = "";	 //char[51]	(TThostFtdcIndividualNameType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public char OpenOrDestroy;
	public String RegDate = "";	 //char[9]	(TThostFtdcTradeDateType)
	public String OutDate = "";	 //char[9]	(TThostFtdcTradeDateType)
	public int TID;
	public char CustType;
	public char BankAccType;
	public String LongCustomerName = "";	 //char[161]	(TThostFtdcLongIndividualNameType)

	public CThostFtdcAccountregisterField(){}

	public CThostFtdcAccountregisterField(byte[] TradeDay,byte[] BankID,byte[] BankBranchID,byte[] BankAccount,byte[] BrokerID,byte[] BrokerBranchID,byte[] AccountID,char IdCardType,byte[] IdentifiedCardNo,byte[] CustomerName,byte[] CurrencyID,char OpenOrDestroy,byte[] RegDate,byte[] OutDate,int TID,char CustType,char BankAccType,byte[] LongCustomerName){
		try{	if(TradeDay !=null)	this.TradeDay= new String(TradeDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeDay = "";}
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankBranchID !=null)	this.BankBranchID= new String(BankBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankBranchID = "";}
		try{	if(BankAccount !=null)	this.BankAccount= new String(BankAccount, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankAccount = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(BrokerBranchID !=null)	this.BrokerBranchID= new String(BrokerBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerBranchID = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		this.IdCardType=IdCardType;
		try{	if(IdentifiedCardNo !=null)	this.IdentifiedCardNo= new String(IdentifiedCardNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IdentifiedCardNo = "";}
		try{	if(CustomerName !=null)	this.CustomerName= new String(CustomerName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CustomerName = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		this.OpenOrDestroy=OpenOrDestroy;
		try{	if(RegDate !=null)	this.RegDate= new String(RegDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.RegDate = "";}
		try{	if(OutDate !=null)	this.OutDate= new String(OutDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OutDate = "";}
		this.TID=TID;
		this.CustType=CustType;
		this.BankAccType=BankAccType;
		try{	if(LongCustomerName !=null)	this.LongCustomerName= new String(LongCustomerName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LongCustomerName = "";}
	}
}
