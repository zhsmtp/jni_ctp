package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTransferQryDetailRspField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradeDate = "";	 //char[9]	(TThostFtdcDateType)
	public String TradeTime = "";	 //char[9]	(TThostFtdcTradeTimeType)
	public String TradeCode = "";	 //char[7]	(TThostFtdcTradeCodeType)
	public int FutureSerial;
	public String FutureID = "";	 //char[11]	(TThostFtdcFutureIDType)
	public String FutureAccount = "";	 //char[22]	(TThostFtdcFutureAccountType)
	public int BankSerial;
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankBrchID = "";	 //char[5]	(TThostFtdcBankBrchIDType)
	public String BankAccount = "";	 //char[41]	(TThostFtdcBankAccountType)
	public String CertCode = "";	 //char[21]	(TThostFtdcCertCodeType)
	public String CurrencyCode = "";	 //char[4]	(TThostFtdcCurrencyCodeType)
	public double TxAmount;
	public char Flag;

	public CThostFtdcTransferQryDetailRspField(){}

	public CThostFtdcTransferQryDetailRspField(byte[] TradeDate,byte[] TradeTime,byte[] TradeCode,int FutureSerial,byte[] FutureID,byte[] FutureAccount,int BankSerial,byte[] BankID,byte[] BankBrchID,byte[] BankAccount,byte[] CertCode,byte[] CurrencyCode,double TxAmount,char Flag){
		try{	if(TradeDate !=null)	this.TradeDate= new String(TradeDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeDate = "";}
		try{	if(TradeTime !=null)	this.TradeTime= new String(TradeTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeTime = "";}
		try{	if(TradeCode !=null)	this.TradeCode= new String(TradeCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeCode = "";}
		this.FutureSerial=FutureSerial;
		try{	if(FutureID !=null)	this.FutureID= new String(FutureID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FutureID = "";}
		try{	if(FutureAccount !=null)	this.FutureAccount= new String(FutureAccount, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FutureAccount = "";}
		this.BankSerial=BankSerial;
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankBrchID !=null)	this.BankBrchID= new String(BankBrchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankBrchID = "";}
		try{	if(BankAccount !=null)	this.BankAccount= new String(BankAccount, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankAccount = "";}
		try{	if(CertCode !=null)	this.CertCode= new String(CertCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CertCode = "";}
		try{	if(CurrencyCode !=null)	this.CurrencyCode= new String(CurrencyCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyCode = "";}
		this.TxAmount=TxAmount;
		this.Flag=Flag;
	}
}
