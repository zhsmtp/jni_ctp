package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMarketDataAsk23Field implements Serializable {
	private static final long serialVersionUID = 1L;
	public double AskPrice2;
	public int AskVolume2;
	public double AskPrice3;
	public int AskVolume3;

	public CThostFtdcMarketDataAsk23Field(){}

	public CThostFtdcMarketDataAsk23Field(double AskPrice2,int AskVolume2,double AskPrice3,int AskVolume3){
		this.AskPrice2=AskPrice2;
		this.AskVolume2=AskVolume2;
		this.AskPrice3=AskPrice3;
		this.AskVolume3=AskVolume3;
	}
}
