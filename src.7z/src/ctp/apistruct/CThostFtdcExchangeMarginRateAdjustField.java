package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcExchangeMarginRateAdjustField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public char HedgeFlag;
	public double LongMarginRatioByMoney;
	public double LongMarginRatioByVolume;
	public double ShortMarginRatioByMoney;
	public double ShortMarginRatioByVolume;
	public double ExchLongMarginRatioByMoney;
	public double ExchLongMarginRatioByVolume;
	public double ExchShortMarginRatioByMoney;
	public double ExchShortMarginRatioByVolume;
	public double NoLongMarginRatioByMoney;
	public double NoLongMarginRatioByVolume;
	public double NoShortMarginRatioByMoney;
	public double NoShortMarginRatioByVolume;

	public CThostFtdcExchangeMarginRateAdjustField(){}

	public CThostFtdcExchangeMarginRateAdjustField(byte[] BrokerID,byte[] InstrumentID,char HedgeFlag,double LongMarginRatioByMoney,double LongMarginRatioByVolume,double ShortMarginRatioByMoney,double ShortMarginRatioByVolume,double ExchLongMarginRatioByMoney,double ExchLongMarginRatioByVolume,double ExchShortMarginRatioByMoney,double ExchShortMarginRatioByVolume,double NoLongMarginRatioByMoney,double NoLongMarginRatioByVolume,double NoShortMarginRatioByMoney,double NoShortMarginRatioByVolume){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		this.HedgeFlag=HedgeFlag;
		this.LongMarginRatioByMoney=LongMarginRatioByMoney;
		this.LongMarginRatioByVolume=LongMarginRatioByVolume;
		this.ShortMarginRatioByMoney=ShortMarginRatioByMoney;
		this.ShortMarginRatioByVolume=ShortMarginRatioByVolume;
		this.ExchLongMarginRatioByMoney=ExchLongMarginRatioByMoney;
		this.ExchLongMarginRatioByVolume=ExchLongMarginRatioByVolume;
		this.ExchShortMarginRatioByMoney=ExchShortMarginRatioByMoney;
		this.ExchShortMarginRatioByVolume=ExchShortMarginRatioByVolume;
		this.NoLongMarginRatioByMoney=NoLongMarginRatioByMoney;
		this.NoLongMarginRatioByVolume=NoLongMarginRatioByVolume;
		this.NoShortMarginRatioByMoney=NoShortMarginRatioByMoney;
		this.NoShortMarginRatioByVolume=NoShortMarginRatioByVolume;
	}
}
