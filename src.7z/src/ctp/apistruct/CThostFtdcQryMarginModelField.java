package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryMarginModelField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String MarginModelID = "";	 //char[13]	(TThostFtdcInvestorIDType)

	public CThostFtdcQryMarginModelField(){}

	public CThostFtdcQryMarginModelField(byte[] BrokerID,byte[] MarginModelID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(MarginModelID !=null)	this.MarginModelID= new String(MarginModelID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MarginModelID = "";}
	}
}
