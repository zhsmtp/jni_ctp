package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcVerifyFuturePasswordAndCustInfoField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String CustomerName = "";	 //char[51]	(TThostFtdcIndividualNameType)
	public char IdCardType;
	public String IdentifiedCardNo = "";	 //char[51]	(TThostFtdcIdentifiedCardNoType)
	public char CustType;
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String Password = "";	 //char[41]	(TThostFtdcPasswordType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public String LongCustomerName = "";	 //char[161]	(TThostFtdcLongIndividualNameType)

	public CThostFtdcVerifyFuturePasswordAndCustInfoField(){}

	public CThostFtdcVerifyFuturePasswordAndCustInfoField(byte[] CustomerName,char IdCardType,byte[] IdentifiedCardNo,char CustType,byte[] AccountID,byte[] Password,byte[] CurrencyID,byte[] LongCustomerName){
		try{	if(CustomerName !=null)	this.CustomerName= new String(CustomerName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CustomerName = "";}
		this.IdCardType=IdCardType;
		try{	if(IdentifiedCardNo !=null)	this.IdentifiedCardNo= new String(IdentifiedCardNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IdentifiedCardNo = "";}
		this.CustType=CustType;
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(Password !=null)	this.Password= new String(Password, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Password = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		try{	if(LongCustomerName !=null)	this.LongCustomerName= new String(LongCustomerName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LongCustomerName = "";}
	}
}
