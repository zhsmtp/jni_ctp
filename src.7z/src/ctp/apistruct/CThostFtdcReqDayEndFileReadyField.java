package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcReqDayEndFileReadyField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradeCode = "";	 //char[7]	(TThostFtdcTradeCodeType)
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankBranchID = "";	 //char[5]	(TThostFtdcBankBrchIDType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String BrokerBranchID = "";	 //char[31]	(TThostFtdcFutureBranchIDType)
	public String TradeDate = "";	 //char[9]	(TThostFtdcTradeDateType)
	public String TradeTime = "";	 //char[9]	(TThostFtdcTradeTimeType)
	public String BankSerial = "";	 //char[13]	(TThostFtdcBankSerialType)
	public int PlateSerial;
	public char LastFragment;
	public int SessionID;
	public char FileBusinessCode;
	public String Digest = "";	 //char[36]	(TThostFtdcDigestType)

	public CThostFtdcReqDayEndFileReadyField(){}

	public CThostFtdcReqDayEndFileReadyField(byte[] TradeCode,byte[] BankID,byte[] BankBranchID,byte[] BrokerID,byte[] BrokerBranchID,byte[] TradeDate,byte[] TradeTime,byte[] BankSerial,int PlateSerial,char LastFragment,int SessionID,char FileBusinessCode,byte[] Digest){
		try{	if(TradeCode !=null)	this.TradeCode= new String(TradeCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeCode = "";}
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankBranchID !=null)	this.BankBranchID= new String(BankBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankBranchID = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(BrokerBranchID !=null)	this.BrokerBranchID= new String(BrokerBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerBranchID = "";}
		try{	if(TradeDate !=null)	this.TradeDate= new String(TradeDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeDate = "";}
		try{	if(TradeTime !=null)	this.TradeTime= new String(TradeTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeTime = "";}
		try{	if(BankSerial !=null)	this.BankSerial= new String(BankSerial, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankSerial = "";}
		this.PlateSerial=PlateSerial;
		this.LastFragment=LastFragment;
		this.SessionID=SessionID;
		this.FileBusinessCode=FileBusinessCode;
		try{	if(Digest !=null)	this.Digest= new String(Digest, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Digest = "";}
	}
}
