package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcFrontStatusField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int FrontID;
	public String LastReportDate = "";	 //char[9]	(TThostFtdcDateType)
	public String LastReportTime = "";	 //char[9]	(TThostFtdcTimeType)
	public int IsActive;

	public CThostFtdcFrontStatusField(){}

	public CThostFtdcFrontStatusField(int FrontID,byte[] LastReportDate,byte[] LastReportTime,int IsActive){
		this.FrontID=FrontID;
		try{	if(LastReportDate !=null)	this.LastReportDate= new String(LastReportDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LastReportDate = "";}
		try{	if(LastReportTime !=null)	this.LastReportTime= new String(LastReportTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LastReportTime = "";}
		this.IsActive=IsActive;
	}
}
