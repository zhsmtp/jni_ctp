package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcInputCombActionField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String CombActionRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public char Direction;
	public int Volume;
	public char CombDirection;
	public char HedgeFlag;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)

	public CThostFtdcInputCombActionField(){}

	public CThostFtdcInputCombActionField(byte[] BrokerID,byte[] InvestorID,byte[] InstrumentID,byte[] CombActionRef,byte[] UserID,char Direction,int Volume,char CombDirection,char HedgeFlag,byte[] ExchangeID,byte[] IPAddress,byte[] MacAddress,byte[] InvestUnitID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(CombActionRef !=null)	this.CombActionRef= new String(CombActionRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CombActionRef = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.Direction=Direction;
		this.Volume=Volume;
		this.CombDirection=CombDirection;
		this.HedgeFlag=HedgeFlag;
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
	}
}
