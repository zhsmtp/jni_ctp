package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcBulletinField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public int BulletinID;
	public int SequenceNo;
	public String NewsType = "";	 //char[3]	(TThostFtdcNewsTypeType)
	public char NewsUrgency;
	public String SendTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String Abstract = "";	 //char[81]	(TThostFtdcAbstractType)
	public String ComeFrom = "";	 //char[21]	(TThostFtdcComeFromType)
	public String Content = "";	 //char[501]	(TThostFtdcContentType)
	public String URLLink = "";	 //char[201]	(TThostFtdcURLLinkType)
	public String MarketID = "";	 //char[31]	(TThostFtdcMarketIDType)

	public CThostFtdcBulletinField(){}

	public CThostFtdcBulletinField(byte[] ExchangeID,byte[] TradingDay,int BulletinID,int SequenceNo,byte[] NewsType,char NewsUrgency,byte[] SendTime,byte[] Abstract,byte[] ComeFrom,byte[] Content,byte[] URLLink,byte[] MarketID){
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.BulletinID=BulletinID;
		this.SequenceNo=SequenceNo;
		try{	if(NewsType !=null)	this.NewsType= new String(NewsType, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.NewsType = "";}
		this.NewsUrgency=NewsUrgency;
		try{	if(SendTime !=null)	this.SendTime= new String(SendTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.SendTime = "";}
		try{	if(Abstract !=null)	this.Abstract= new String(Abstract, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Abstract = "";}
		try{	if(ComeFrom !=null)	this.ComeFrom= new String(ComeFrom, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ComeFrom = "";}
		try{	if(Content !=null)	this.Content= new String(Content, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Content = "";}
		try{	if(URLLink !=null)	this.URLLink= new String(URLLink, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.URLLink = "";}
		try{	if(MarketID !=null)	this.MarketID= new String(MarketID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MarketID = "";}
	}
}
