package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcCFMMCTradingAccountKeyField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public int KeyID;
	public String CurrentKey = "";	 //char[21]	(TThostFtdcCFMMCKeyType)

	public CThostFtdcCFMMCTradingAccountKeyField(){}

	public CThostFtdcCFMMCTradingAccountKeyField(byte[] BrokerID,byte[] ParticipantID,byte[] AccountID,int KeyID,byte[] CurrentKey){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		this.KeyID=KeyID;
		try{	if(CurrentKey !=null)	this.CurrentKey= new String(CurrentKey, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrentKey = "";}
	}
}
