package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcBrokerDepositField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradingDay = "";	 //char[9]	(TThostFtdcTradeDateType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public double PreBalance;
	public double CurrMargin;
	public double CloseProfit;
	public double Balance;
	public double Deposit;
	public double Withdraw;
	public double Available;
	public double Reserve;
	public double FrozenMargin;

	public CThostFtdcBrokerDepositField(){}

	public CThostFtdcBrokerDepositField(byte[] TradingDay,byte[] BrokerID,byte[] ParticipantID,byte[] ExchangeID,double PreBalance,double CurrMargin,double CloseProfit,double Balance,double Deposit,double Withdraw,double Available,double Reserve,double FrozenMargin){
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		this.PreBalance=PreBalance;
		this.CurrMargin=CurrMargin;
		this.CloseProfit=CloseProfit;
		this.Balance=Balance;
		this.Deposit=Deposit;
		this.Withdraw=Withdraw;
		this.Available=Available;
		this.Reserve=Reserve;
		this.FrozenMargin=FrozenMargin;
	}
}
