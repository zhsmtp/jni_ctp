package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcDiscountField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public char InvestorRange;
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public double Discount;

	public CThostFtdcDiscountField(){}

	public CThostFtdcDiscountField(byte[] BrokerID,char InvestorRange,byte[] InvestorID,double Discount){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		this.InvestorRange=InvestorRange;
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.Discount=Discount;
	}
}
