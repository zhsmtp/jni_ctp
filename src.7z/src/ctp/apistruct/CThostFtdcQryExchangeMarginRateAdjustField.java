package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryExchangeMarginRateAdjustField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public char HedgeFlag;

	public CThostFtdcQryExchangeMarginRateAdjustField(){}

	public CThostFtdcQryExchangeMarginRateAdjustField(byte[] BrokerID,byte[] InstrumentID,char HedgeFlag){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		this.HedgeFlag=HedgeFlag;
	}
}
