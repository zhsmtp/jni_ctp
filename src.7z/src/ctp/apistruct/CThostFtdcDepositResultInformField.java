package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcDepositResultInformField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String DepositSeqNo = "";	 //char[15]	(TThostFtdcDepositSeqNoType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public double Deposit;
	public int RequestID;
	public String ReturnCode = "";	 //char[7]	(TThostFtdcReturnCodeType)
	public String DescrInfoForReturnCode = "";	 //char[129]	(TThostFtdcDescrInfoForReturnCodeType)

	public CThostFtdcDepositResultInformField(){}

	public CThostFtdcDepositResultInformField(byte[] DepositSeqNo,byte[] BrokerID,byte[] InvestorID,double Deposit,int RequestID,byte[] ReturnCode,byte[] DescrInfoForReturnCode){
		try{	if(DepositSeqNo !=null)	this.DepositSeqNo= new String(DepositSeqNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.DepositSeqNo = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.Deposit=Deposit;
		this.RequestID=RequestID;
		try{	if(ReturnCode !=null)	this.ReturnCode= new String(ReturnCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ReturnCode = "";}
		try{	if(DescrInfoForReturnCode !=null)	this.DescrInfoForReturnCode= new String(DescrInfoForReturnCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.DescrInfoForReturnCode = "";}
	}
}
