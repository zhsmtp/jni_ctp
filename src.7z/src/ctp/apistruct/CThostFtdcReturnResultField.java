package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcReturnResultField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ReturnCode = "";	 //char[7]	(TThostFtdcReturnCodeType)
	public String DescrInfoForReturnCode = "";	 //char[129]	(TThostFtdcDescrInfoForReturnCodeType)

	public CThostFtdcReturnResultField(){}

	public CThostFtdcReturnResultField(byte[] ReturnCode,byte[] DescrInfoForReturnCode){
		try{	if(ReturnCode !=null)	this.ReturnCode= new String(ReturnCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ReturnCode = "";}
		try{	if(DescrInfoForReturnCode !=null)	this.DescrInfoForReturnCode= new String(DescrInfoForReturnCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.DescrInfoForReturnCode = "";}
	}
}
