package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcVerifyCustInfoField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String CustomerName = "";	 //char[51]	(TThostFtdcIndividualNameType)
	public char IdCardType;
	public String IdentifiedCardNo = "";	 //char[51]	(TThostFtdcIdentifiedCardNoType)
	public char CustType;
	public String LongCustomerName = "";	 //char[161]	(TThostFtdcLongIndividualNameType)

	public CThostFtdcVerifyCustInfoField(){}

	public CThostFtdcVerifyCustInfoField(byte[] CustomerName,char IdCardType,byte[] IdentifiedCardNo,char CustType,byte[] LongCustomerName){
		try{	if(CustomerName !=null)	this.CustomerName= new String(CustomerName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CustomerName = "";}
		this.IdCardType=IdCardType;
		try{	if(IdentifiedCardNo !=null)	this.IdentifiedCardNo= new String(IdentifiedCardNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IdentifiedCardNo = "";}
		this.CustType=CustType;
		try{	if(LongCustomerName !=null)	this.LongCustomerName= new String(LongCustomerName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LongCustomerName = "";}
	}
}
