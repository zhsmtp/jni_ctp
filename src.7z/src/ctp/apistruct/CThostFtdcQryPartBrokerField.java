package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryPartBrokerField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)

	public CThostFtdcQryPartBrokerField(){}

	public CThostFtdcQryPartBrokerField(byte[] ExchangeID,byte[] BrokerID,byte[] ParticipantID){
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
	}
}
