package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcVerifyFuturePasswordField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradeCode = "";	 //char[7]	(TThostFtdcTradeCodeType)
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankBranchID = "";	 //char[5]	(TThostFtdcBankBrchIDType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String BrokerBranchID = "";	 //char[31]	(TThostFtdcFutureBranchIDType)
	public String TradeDate = "";	 //char[9]	(TThostFtdcTradeDateType)
	public String TradeTime = "";	 //char[9]	(TThostFtdcTradeTimeType)
	public String BankSerial = "";	 //char[13]	(TThostFtdcBankSerialType)
	public int PlateSerial;
	public char LastFragment;
	public int SessionID;
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String Password = "";	 //char[41]	(TThostFtdcPasswordType)
	public String BankAccount = "";	 //char[41]	(TThostFtdcBankAccountType)
	public String BankPassWord = "";	 //char[41]	(TThostFtdcPasswordType)
	public int InstallID;
	public int TID;
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)

	public CThostFtdcVerifyFuturePasswordField(){}

	public CThostFtdcVerifyFuturePasswordField(byte[] TradeCode,byte[] BankID,byte[] BankBranchID,byte[] BrokerID,byte[] BrokerBranchID,byte[] TradeDate,byte[] TradeTime,byte[] BankSerial,int PlateSerial,char LastFragment,int SessionID,byte[] AccountID,byte[] Password,byte[] BankAccount,byte[] BankPassWord,int InstallID,int TID,byte[] CurrencyID){
		try{	if(TradeCode !=null)	this.TradeCode= new String(TradeCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeCode = "";}
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankBranchID !=null)	this.BankBranchID= new String(BankBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankBranchID = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(BrokerBranchID !=null)	this.BrokerBranchID= new String(BrokerBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerBranchID = "";}
		try{	if(TradeDate !=null)	this.TradeDate= new String(TradeDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeDate = "";}
		try{	if(TradeTime !=null)	this.TradeTime= new String(TradeTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeTime = "";}
		try{	if(BankSerial !=null)	this.BankSerial= new String(BankSerial, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankSerial = "";}
		this.PlateSerial=PlateSerial;
		this.LastFragment=LastFragment;
		this.SessionID=SessionID;
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(Password !=null)	this.Password= new String(Password, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Password = "";}
		try{	if(BankAccount !=null)	this.BankAccount= new String(BankAccount, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankAccount = "";}
		try{	if(BankPassWord !=null)	this.BankPassWord= new String(BankPassWord, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankPassWord = "";}
		this.InstallID=InstallID;
		this.TID=TID;
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
	}
}
