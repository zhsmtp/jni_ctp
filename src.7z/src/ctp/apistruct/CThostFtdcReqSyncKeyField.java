package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcReqSyncKeyField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradeCode = "";	 //char[7]	(TThostFtdcTradeCodeType)
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankBranchID = "";	 //char[5]	(TThostFtdcBankBrchIDType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String BrokerBranchID = "";	 //char[31]	(TThostFtdcFutureBranchIDType)
	public String TradeDate = "";	 //char[9]	(TThostFtdcTradeDateType)
	public String TradeTime = "";	 //char[9]	(TThostFtdcTradeTimeType)
	public String BankSerial = "";	 //char[13]	(TThostFtdcBankSerialType)
	public int PlateSerial;
	public char LastFragment;
	public int SessionID;
	public int InstallID;
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String Message = "";	 //char[129]	(TThostFtdcAddInfoType)
	public String DeviceID = "";	 //char[3]	(TThostFtdcDeviceIDType)
	public String BrokerIDByBank = "";	 //char[33]	(TThostFtdcBankCodingForFutureType)
	public String OperNo = "";	 //char[17]	(TThostFtdcOperNoType)
	public int RequestID;
	public int TID;

	public CThostFtdcReqSyncKeyField(){}

	public CThostFtdcReqSyncKeyField(byte[] TradeCode,byte[] BankID,byte[] BankBranchID,byte[] BrokerID,byte[] BrokerBranchID,byte[] TradeDate,byte[] TradeTime,byte[] BankSerial,int PlateSerial,char LastFragment,int SessionID,int InstallID,byte[] UserID,byte[] Message,byte[] DeviceID,byte[] BrokerIDByBank,byte[] OperNo,int RequestID,int TID){
		try{	if(TradeCode !=null)	this.TradeCode= new String(TradeCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeCode = "";}
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankBranchID !=null)	this.BankBranchID= new String(BankBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankBranchID = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(BrokerBranchID !=null)	this.BrokerBranchID= new String(BrokerBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerBranchID = "";}
		try{	if(TradeDate !=null)	this.TradeDate= new String(TradeDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeDate = "";}
		try{	if(TradeTime !=null)	this.TradeTime= new String(TradeTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeTime = "";}
		try{	if(BankSerial !=null)	this.BankSerial= new String(BankSerial, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankSerial = "";}
		this.PlateSerial=PlateSerial;
		this.LastFragment=LastFragment;
		this.SessionID=SessionID;
		this.InstallID=InstallID;
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(Message !=null)	this.Message= new String(Message, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Message = "";}
		try{	if(DeviceID !=null)	this.DeviceID= new String(DeviceID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.DeviceID = "";}
		try{	if(BrokerIDByBank !=null)	this.BrokerIDByBank= new String(BrokerIDByBank, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerIDByBank = "";}
		try{	if(OperNo !=null)	this.OperNo= new String(OperNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OperNo = "";}
		this.RequestID=RequestID;
		this.TID=TID;
	}
}
