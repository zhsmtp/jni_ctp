package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcNoticeField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String Content = "";	 //char[501]	(TThostFtdcContentType)
	public String SequenceLabel = "";	 //char[2]	(TThostFtdcSequenceLabelType)

	public CThostFtdcNoticeField(){}

	public CThostFtdcNoticeField(byte[] BrokerID,byte[] Content,byte[] SequenceLabel){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(Content !=null)	this.Content= new String(Content, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Content = "";}
		try{	if(SequenceLabel !=null)	this.SequenceLabel= new String(SequenceLabel, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.SequenceLabel = "";}
	}
}
