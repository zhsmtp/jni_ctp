package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcBrokerUserPasswordField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String Password = "";	 //char[41]	(TThostFtdcPasswordType)
	public String LastUpdateTime = "";	 //char[17]	(TThostFtdcDateTimeType)
	public String LastLoginTime = "";	 //char[17]	(TThostFtdcDateTimeType)
	public String ExpireDate = "";	 //char[9]	(TThostFtdcDateType)
	public String WeakExpireDate = "";	 //char[9]	(TThostFtdcDateType)

	public CThostFtdcBrokerUserPasswordField(){}

	public CThostFtdcBrokerUserPasswordField(byte[] BrokerID,byte[] UserID,byte[] Password,byte[] LastUpdateTime,byte[] LastLoginTime,byte[] ExpireDate,byte[] WeakExpireDate){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(Password !=null)	this.Password= new String(Password, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Password = "";}
		try{	if(LastUpdateTime !=null)	this.LastUpdateTime= new String(LastUpdateTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LastUpdateTime = "";}
		try{	if(LastLoginTime !=null)	this.LastLoginTime= new String(LastLoginTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LastLoginTime = "";}
		try{	if(ExpireDate !=null)	this.ExpireDate= new String(ExpireDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExpireDate = "";}
		try{	if(WeakExpireDate !=null)	this.WeakExpireDate= new String(WeakExpireDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.WeakExpireDate = "";}
	}
}
