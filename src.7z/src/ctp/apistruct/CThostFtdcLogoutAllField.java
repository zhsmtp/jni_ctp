package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcLogoutAllField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int FrontID;
	public int SessionID;
	public String SystemName = "";	 //char[41]	(TThostFtdcSystemNameType)

	public CThostFtdcLogoutAllField(){}

	public CThostFtdcLogoutAllField(int FrontID,int SessionID,byte[] SystemName){
		this.FrontID=FrontID;
		this.SessionID=SessionID;
		try{	if(SystemName !=null)	this.SystemName= new String(SystemName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.SystemName = "";}
	}
}
