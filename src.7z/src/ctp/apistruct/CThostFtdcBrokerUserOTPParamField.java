package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcBrokerUserOTPParamField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String OTPVendorsID = "";	 //char[2]	(TThostFtdcOTPVendorsIDType)
	public String SerialNumber = "";	 //char[17]	(TThostFtdcSerialNumberType)
	public String AuthKey = "";	 //char[41]	(TThostFtdcAuthKeyType)
	public int LastDrift;
	public int LastSuccess;
	public char OTPType;

	public CThostFtdcBrokerUserOTPParamField(){}

	public CThostFtdcBrokerUserOTPParamField(byte[] BrokerID,byte[] UserID,byte[] OTPVendorsID,byte[] SerialNumber,byte[] AuthKey,int LastDrift,int LastSuccess,char OTPType){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(OTPVendorsID !=null)	this.OTPVendorsID= new String(OTPVendorsID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OTPVendorsID = "";}
		try{	if(SerialNumber !=null)	this.SerialNumber= new String(SerialNumber, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.SerialNumber = "";}
		try{	if(AuthKey !=null)	this.AuthKey= new String(AuthKey, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AuthKey = "";}
		this.LastDrift=LastDrift;
		this.LastSuccess=LastSuccess;
		this.OTPType=OTPType;
	}
}
