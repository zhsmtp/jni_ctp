package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcExchangeSequenceField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public int SequenceNo;
	public char MarketStatus;

	public CThostFtdcExchangeSequenceField(){}

	public CThostFtdcExchangeSequenceField(byte[] ExchangeID,int SequenceNo,char MarketStatus){
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		this.SequenceNo=SequenceNo;
		this.MarketStatus=MarketStatus;
	}
}
