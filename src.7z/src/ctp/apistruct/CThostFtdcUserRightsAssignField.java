package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcUserRightsAssignField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public int DRIdentityID;

	public CThostFtdcUserRightsAssignField(){}

	public CThostFtdcUserRightsAssignField(byte[] BrokerID,byte[] UserID,int DRIdentityID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.DRIdentityID=DRIdentityID;
	}
}
