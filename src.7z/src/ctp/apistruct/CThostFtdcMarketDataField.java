package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMarketDataField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ExchangeInstID = "";	 //char[31]	(TThostFtdcExchangeInstIDType)
	public double LastPrice;
	public double PreSettlementPrice;
	public double PreClosePrice;
	public double PreOpenInterest;
	public double OpenPrice;
	public double HighestPrice;
	public double LowestPrice;
	public int Volume;
	public double Turnover;
	public double OpenInterest;
	public double ClosePrice;
	public double SettlementPrice;
	public double UpperLimitPrice;
	public double LowerLimitPrice;
	public double PreDelta;
	public double CurrDelta;
	public String UpdateTime = "";	 //char[9]	(TThostFtdcTimeType)
	public int UpdateMillisec;
	public String ActionDay = "";	 //char[9]	(TThostFtdcDateType)

	public CThostFtdcMarketDataField(){}

	public CThostFtdcMarketDataField(byte[] TradingDay,byte[] InstrumentID,byte[] ExchangeID,byte[] ExchangeInstID,double LastPrice,double PreSettlementPrice,double PreClosePrice,double PreOpenInterest,double OpenPrice,double HighestPrice,double LowestPrice,int Volume,double Turnover,double OpenInterest,double ClosePrice,double SettlementPrice,double UpperLimitPrice,double LowerLimitPrice,double PreDelta,double CurrDelta,byte[] UpdateTime,int UpdateMillisec,byte[] ActionDay){
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ExchangeInstID !=null)	this.ExchangeInstID= new String(ExchangeInstID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeInstID = "";}
		this.LastPrice=LastPrice;
		this.PreSettlementPrice=PreSettlementPrice;
		this.PreClosePrice=PreClosePrice;
		this.PreOpenInterest=PreOpenInterest;
		this.OpenPrice=OpenPrice;
		this.HighestPrice=HighestPrice;
		this.LowestPrice=LowestPrice;
		this.Volume=Volume;
		this.Turnover=Turnover;
		this.OpenInterest=OpenInterest;
		this.ClosePrice=ClosePrice;
		this.SettlementPrice=SettlementPrice;
		this.UpperLimitPrice=UpperLimitPrice;
		this.LowerLimitPrice=LowerLimitPrice;
		this.PreDelta=PreDelta;
		this.CurrDelta=CurrDelta;
		try{	if(UpdateTime !=null)	this.UpdateTime= new String(UpdateTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UpdateTime = "";}
		this.UpdateMillisec=UpdateMillisec;
		try{	if(ActionDay !=null)	this.ActionDay= new String(ActionDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActionDay = "";}
	}
}
