package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTraderField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String TraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String Password = "";	 //char[41]	(TThostFtdcPasswordType)
	public int InstallCount;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)

	public CThostFtdcTraderField(){}

	public CThostFtdcTraderField(byte[] ExchangeID,byte[] TraderID,byte[] ParticipantID,byte[] Password,int InstallCount,byte[] BrokerID){
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(TraderID !=null)	this.TraderID= new String(TraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TraderID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(Password !=null)	this.Password= new String(Password, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Password = "";}
		this.InstallCount=InstallCount;
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
	}
}
