package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcExchangeCombActionField implements Serializable {
	private static final long serialVersionUID = 1L;
	public char Direction;
	public int Volume;
	public char CombDirection;
	public char HedgeFlag;
	public String ActionLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String ClientID = "";	 //char[11]	(TThostFtdcClientIDType)
	public String ExchangeInstID = "";	 //char[31]	(TThostFtdcExchangeInstIDType)
	public String TraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public int InstallID;
	public char ActionStatus;
	public int NotifySequence;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public int SettlementID;
	public int SequenceNo;
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)
	public String ComTradeID = "";	 //char[21]	(TThostFtdcTradeIDType)
	public String BranchID = "";	 //char[9]	(TThostFtdcBranchIDType)

	public CThostFtdcExchangeCombActionField(){}

	public CThostFtdcExchangeCombActionField(char Direction,int Volume,char CombDirection,char HedgeFlag,byte[] ActionLocalID,byte[] ExchangeID,byte[] ParticipantID,byte[] ClientID,byte[] ExchangeInstID,byte[] TraderID,int InstallID,char ActionStatus,int NotifySequence,byte[] TradingDay,int SettlementID,int SequenceNo,byte[] IPAddress,byte[] MacAddress,byte[] ComTradeID,byte[] BranchID){
		this.Direction=Direction;
		this.Volume=Volume;
		this.CombDirection=CombDirection;
		this.HedgeFlag=HedgeFlag;
		try{	if(ActionLocalID !=null)	this.ActionLocalID= new String(ActionLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActionLocalID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(ClientID !=null)	this.ClientID= new String(ClientID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientID = "";}
		try{	if(ExchangeInstID !=null)	this.ExchangeInstID= new String(ExchangeInstID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeInstID = "";}
		try{	if(TraderID !=null)	this.TraderID= new String(TraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TraderID = "";}
		this.InstallID=InstallID;
		this.ActionStatus=ActionStatus;
		this.NotifySequence=NotifySequence;
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.SettlementID=SettlementID;
		this.SequenceNo=SequenceNo;
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
		try{	if(ComTradeID !=null)	this.ComTradeID= new String(ComTradeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ComTradeID = "";}
		try{	if(BranchID !=null)	this.BranchID= new String(BranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BranchID = "";}
	}
}
