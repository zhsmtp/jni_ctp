package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcRspGenUserCaptchaField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public int CaptchaInfoLen;
	public String CaptchaInfo = "";	 //char[2561]	(TThostFtdcCaptchaInfoType)

	public CThostFtdcRspGenUserCaptchaField(){}

	public CThostFtdcRspGenUserCaptchaField(byte[] BrokerID,byte[] UserID,int CaptchaInfoLen,byte[] CaptchaInfo){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.CaptchaInfoLen=CaptchaInfoLen;
		try{	if(CaptchaInfo !=null)	this.CaptchaInfo= new String(CaptchaInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CaptchaInfo = "";}
	}
}
