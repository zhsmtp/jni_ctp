package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMarketDataUpdateTimeField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String UpdateTime = "";	 //char[9]	(TThostFtdcTimeType)
	public int UpdateMillisec;
	public String ActionDay = "";	 //char[9]	(TThostFtdcDateType)

	public CThostFtdcMarketDataUpdateTimeField(){}

	public CThostFtdcMarketDataUpdateTimeField(byte[] InstrumentID,byte[] UpdateTime,int UpdateMillisec,byte[] ActionDay){
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(UpdateTime !=null)	this.UpdateTime= new String(UpdateTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UpdateTime = "";}
		this.UpdateMillisec=UpdateMillisec;
		try{	if(ActionDay !=null)	this.ActionDay= new String(ActionDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActionDay = "";}
	}
}
