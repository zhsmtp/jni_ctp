package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcLoginInfoField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int FrontID;
	public int SessionID;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String LoginDate = "";	 //char[9]	(TThostFtdcDateType)
	public String LoginTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String UserProductInfo = "";	 //char[11]	(TThostFtdcProductInfoType)
	public String InterfaceProductInfo = "";	 //char[11]	(TThostFtdcProductInfoType)
	public String ProtocolInfo = "";	 //char[11]	(TThostFtdcProtocolInfoType)
	public String SystemName = "";	 //char[41]	(TThostFtdcSystemNameType)
	public String PasswordDeprecated = "";	 //char[41]	(TThostFtdcPasswordType)
	public String MaxOrderRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String SHFETime = "";	 //char[9]	(TThostFtdcTimeType)
	public String DCETime = "";	 //char[9]	(TThostFtdcTimeType)
	public String CZCETime = "";	 //char[9]	(TThostFtdcTimeType)
	public String FFEXTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)
	public String OneTimePassword = "";	 //char[41]	(TThostFtdcPasswordType)
	public String INETime = "";	 //char[9]	(TThostFtdcTimeType)
	public int IsQryControl;
	public String LoginRemark = "";	 //char[36]	(TThostFtdcLoginRemarkType)
	public String Password = "";	 //char[41]	(TThostFtdcPasswordType)

	public CThostFtdcLoginInfoField(){}

	public CThostFtdcLoginInfoField(int FrontID,int SessionID,byte[] BrokerID,byte[] UserID,byte[] LoginDate,byte[] LoginTime,byte[] IPAddress,byte[] UserProductInfo,byte[] InterfaceProductInfo,byte[] ProtocolInfo,byte[] SystemName,byte[] PasswordDeprecated,byte[] MaxOrderRef,byte[] SHFETime,byte[] DCETime,byte[] CZCETime,byte[] FFEXTime,byte[] MacAddress,byte[] OneTimePassword,byte[] INETime,int IsQryControl,byte[] LoginRemark,byte[] Password){
		this.FrontID=FrontID;
		this.SessionID=SessionID;
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(LoginDate !=null)	this.LoginDate= new String(LoginDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LoginDate = "";}
		try{	if(LoginTime !=null)	this.LoginTime= new String(LoginTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LoginTime = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(UserProductInfo !=null)	this.UserProductInfo= new String(UserProductInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserProductInfo = "";}
		try{	if(InterfaceProductInfo !=null)	this.InterfaceProductInfo= new String(InterfaceProductInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InterfaceProductInfo = "";}
		try{	if(ProtocolInfo !=null)	this.ProtocolInfo= new String(ProtocolInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ProtocolInfo = "";}
		try{	if(SystemName !=null)	this.SystemName= new String(SystemName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.SystemName = "";}
		try{	if(PasswordDeprecated !=null)	this.PasswordDeprecated= new String(PasswordDeprecated, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.PasswordDeprecated = "";}
		try{	if(MaxOrderRef !=null)	this.MaxOrderRef= new String(MaxOrderRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MaxOrderRef = "";}
		try{	if(SHFETime !=null)	this.SHFETime= new String(SHFETime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.SHFETime = "";}
		try{	if(DCETime !=null)	this.DCETime= new String(DCETime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.DCETime = "";}
		try{	if(CZCETime !=null)	this.CZCETime= new String(CZCETime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CZCETime = "";}
		try{	if(FFEXTime !=null)	this.FFEXTime= new String(FFEXTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FFEXTime = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
		try{	if(OneTimePassword !=null)	this.OneTimePassword= new String(OneTimePassword, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OneTimePassword = "";}
		try{	if(INETime !=null)	this.INETime= new String(INETime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.INETime = "";}
		this.IsQryControl=IsQryControl;
		try{	if(LoginRemark !=null)	this.LoginRemark= new String(LoginRemark, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LoginRemark = "";}
		try{	if(Password !=null)	this.Password= new String(Password, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Password = "";}
	}
}
