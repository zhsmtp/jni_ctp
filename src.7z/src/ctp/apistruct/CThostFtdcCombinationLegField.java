package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcCombinationLegField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String CombInstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public int LegID;
	public String LegInstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public char Direction;
	public int LegMultiple;
	public int ImplyLevel;

	public CThostFtdcCombinationLegField(){}

	public CThostFtdcCombinationLegField(byte[] CombInstrumentID,int LegID,byte[] LegInstrumentID,char Direction,int LegMultiple,int ImplyLevel){
		try{	if(CombInstrumentID !=null)	this.CombInstrumentID= new String(CombInstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CombInstrumentID = "";}
		this.LegID=LegID;
		try{	if(LegInstrumentID !=null)	this.LegInstrumentID= new String(LegInstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LegInstrumentID = "";}
		this.Direction=Direction;
		this.LegMultiple=LegMultiple;
		this.ImplyLevel=ImplyLevel;
	}
}
