package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMarketDataLastMatchField implements Serializable {
	private static final long serialVersionUID = 1L;
	public double LastPrice;
	public int Volume;
	public double Turnover;
	public double OpenInterest;

	public CThostFtdcMarketDataLastMatchField(){}

	public CThostFtdcMarketDataLastMatchField(double LastPrice,int Volume,double Turnover,double OpenInterest){
		this.LastPrice=LastPrice;
		this.Volume=Volume;
		this.Turnover=Turnover;
		this.OpenInterest=OpenInterest;
	}
}
