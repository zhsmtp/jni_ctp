package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcRspUserAuthMethodField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int UsableAuthMethod;

	public CThostFtdcRspUserAuthMethodField(){}

	public CThostFtdcRspUserAuthMethodField(int UsableAuthMethod){
		this.UsableAuthMethod=UsableAuthMethod;
	}
}
