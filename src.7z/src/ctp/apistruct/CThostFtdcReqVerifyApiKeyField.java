package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcReqVerifyApiKeyField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int ApiHandshakeDataLen;
	public String ApiHandshakeData = "";	 //char[301]	(TThostFtdcHandshakeDataType)

	public CThostFtdcReqVerifyApiKeyField(){}

	public CThostFtdcReqVerifyApiKeyField(int ApiHandshakeDataLen,byte[] ApiHandshakeData){
		this.ApiHandshakeDataLen=ApiHandshakeDataLen;
		try{	if(ApiHandshakeData !=null)	this.ApiHandshakeData= new String(ApiHandshakeData, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ApiHandshakeData = "";}
	}
}
