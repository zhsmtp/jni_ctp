package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcRspQueryTradeResultBySerialField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradeCode = "";	 //char[7]	(TThostFtdcTradeCodeType)
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankBranchID = "";	 //char[5]	(TThostFtdcBankBrchIDType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String BrokerBranchID = "";	 //char[31]	(TThostFtdcFutureBranchIDType)
	public String TradeDate = "";	 //char[9]	(TThostFtdcTradeDateType)
	public String TradeTime = "";	 //char[9]	(TThostFtdcTradeTimeType)
	public String BankSerial = "";	 //char[13]	(TThostFtdcBankSerialType)
	public int PlateSerial;
	public char LastFragment;
	public int SessionID;
	public int ErrorID;
	public String ErrorMsg = "";	 //char[81]	(TThostFtdcErrorMsgType)
	public int Reference;
	public char RefrenceIssureType;
	public String RefrenceIssure = "";	 //char[36]	(TThostFtdcOrganCodeType)
	public String OriginReturnCode = "";	 //char[7]	(TThostFtdcReturnCodeType)
	public String OriginDescrInfoForReturnCode = "";	 //char[129]	(TThostFtdcDescrInfoForReturnCodeType)
	public String BankAccount = "";	 //char[41]	(TThostFtdcBankAccountType)
	public String BankPassWord = "";	 //char[41]	(TThostFtdcPasswordType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String Password = "";	 //char[41]	(TThostFtdcPasswordType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public double TradeAmount;
	public String Digest = "";	 //char[36]	(TThostFtdcDigestType)

	public CThostFtdcRspQueryTradeResultBySerialField(){}

	public CThostFtdcRspQueryTradeResultBySerialField(byte[] TradeCode,byte[] BankID,byte[] BankBranchID,byte[] BrokerID,byte[] BrokerBranchID,byte[] TradeDate,byte[] TradeTime,byte[] BankSerial,int PlateSerial,char LastFragment,int SessionID,int ErrorID,byte[] ErrorMsg,int Reference,char RefrenceIssureType,byte[] RefrenceIssure,byte[] OriginReturnCode,byte[] OriginDescrInfoForReturnCode,byte[] BankAccount,byte[] BankPassWord,byte[] AccountID,byte[] Password,byte[] CurrencyID,double TradeAmount,byte[] Digest){
		try{	if(TradeCode !=null)	this.TradeCode= new String(TradeCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeCode = "";}
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankBranchID !=null)	this.BankBranchID= new String(BankBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankBranchID = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(BrokerBranchID !=null)	this.BrokerBranchID= new String(BrokerBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerBranchID = "";}
		try{	if(TradeDate !=null)	this.TradeDate= new String(TradeDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeDate = "";}
		try{	if(TradeTime !=null)	this.TradeTime= new String(TradeTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeTime = "";}
		try{	if(BankSerial !=null)	this.BankSerial= new String(BankSerial, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankSerial = "";}
		this.PlateSerial=PlateSerial;
		this.LastFragment=LastFragment;
		this.SessionID=SessionID;
		this.ErrorID=ErrorID;
		try{	if(ErrorMsg !=null)	this.ErrorMsg= new String(ErrorMsg, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ErrorMsg = "";}
		this.Reference=Reference;
		this.RefrenceIssureType=RefrenceIssureType;
		try{	if(RefrenceIssure !=null)	this.RefrenceIssure= new String(RefrenceIssure, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.RefrenceIssure = "";}
		try{	if(OriginReturnCode !=null)	this.OriginReturnCode= new String(OriginReturnCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OriginReturnCode = "";}
		try{	if(OriginDescrInfoForReturnCode !=null)	this.OriginDescrInfoForReturnCode= new String(OriginDescrInfoForReturnCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OriginDescrInfoForReturnCode = "";}
		try{	if(BankAccount !=null)	this.BankAccount= new String(BankAccount, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankAccount = "";}
		try{	if(BankPassWord !=null)	this.BankPassWord= new String(BankPassWord, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankPassWord = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(Password !=null)	this.Password= new String(Password, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Password = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		this.TradeAmount=TradeAmount;
		try{	if(Digest !=null)	this.Digest= new String(Digest, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Digest = "";}
	}
}
