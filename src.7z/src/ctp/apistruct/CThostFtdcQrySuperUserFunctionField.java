package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQrySuperUserFunctionField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)

	public CThostFtdcQrySuperUserFunctionField(){}

	public CThostFtdcQrySuperUserFunctionField(byte[] UserID){
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
	}
}
