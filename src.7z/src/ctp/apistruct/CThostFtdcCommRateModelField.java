package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcCommRateModelField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String CommModelID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String CommModelName = "";	 //char[161]	(TThostFtdcCommModelNameType)

	public CThostFtdcCommRateModelField(){}

	public CThostFtdcCommRateModelField(byte[] BrokerID,byte[] CommModelID,byte[] CommModelName){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(CommModelID !=null)	this.CommModelID= new String(CommModelID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CommModelID = "";}
		try{	if(CommModelName !=null)	this.CommModelName= new String(CommModelName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CommModelName = "";}
	}
}
