package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcSyncingInvestorField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorGroupID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String InvestorName = "";	 //char[81]	(TThostFtdcPartyNameType)
	public char IdentifiedCardType;
	public String IdentifiedCardNo = "";	 //char[51]	(TThostFtdcIdentifiedCardNoType)
	public int IsActive;
	public String Telephone = "";	 //char[41]	(TThostFtdcTelephoneType)
	public String Address = "";	 //char[101]	(TThostFtdcAddressType)
	public String OpenDate = "";	 //char[9]	(TThostFtdcDateType)
	public String Mobile = "";	 //char[41]	(TThostFtdcMobileType)
	public String CommModelID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String MarginModelID = "";	 //char[13]	(TThostFtdcInvestorIDType)

	public CThostFtdcSyncingInvestorField(){}

	public CThostFtdcSyncingInvestorField(byte[] InvestorID,byte[] BrokerID,byte[] InvestorGroupID,byte[] InvestorName,char IdentifiedCardType,byte[] IdentifiedCardNo,int IsActive,byte[] Telephone,byte[] Address,byte[] OpenDate,byte[] Mobile,byte[] CommModelID,byte[] MarginModelID){
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorGroupID !=null)	this.InvestorGroupID= new String(InvestorGroupID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorGroupID = "";}
		try{	if(InvestorName !=null)	this.InvestorName= new String(InvestorName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorName = "";}
		this.IdentifiedCardType=IdentifiedCardType;
		try{	if(IdentifiedCardNo !=null)	this.IdentifiedCardNo= new String(IdentifiedCardNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IdentifiedCardNo = "";}
		this.IsActive=IsActive;
		try{	if(Telephone !=null)	this.Telephone= new String(Telephone, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Telephone = "";}
		try{	if(Address !=null)	this.Address= new String(Address, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Address = "";}
		try{	if(OpenDate !=null)	this.OpenDate= new String(OpenDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OpenDate = "";}
		try{	if(Mobile !=null)	this.Mobile= new String(Mobile, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Mobile = "";}
		try{	if(CommModelID !=null)	this.CommModelID= new String(CommModelID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CommModelID = "";}
		try{	if(MarginModelID !=null)	this.MarginModelID= new String(MarginModelID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MarginModelID = "";}
	}
}
