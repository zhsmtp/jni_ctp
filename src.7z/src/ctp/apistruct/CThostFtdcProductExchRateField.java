package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcProductExchRateField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ProductID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String QuoteCurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public double ExchangeRate;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)

	public CThostFtdcProductExchRateField(){}

	public CThostFtdcProductExchRateField(byte[] ProductID,byte[] QuoteCurrencyID,double ExchangeRate,byte[] ExchangeID){
		try{	if(ProductID !=null)	this.ProductID= new String(ProductID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ProductID = "";}
		try{	if(QuoteCurrencyID !=null)	this.QuoteCurrencyID= new String(QuoteCurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.QuoteCurrencyID = "";}
		this.ExchangeRate=ExchangeRate;
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
	}
}
