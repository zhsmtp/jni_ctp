package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTransferQryBankReqField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String FutureAccount = "";	 //char[13]	(TThostFtdcAccountIDType)
	public char FuturePwdFlag;
	public String FutureAccPwd = "";	 //char[17]	(TThostFtdcFutureAccPwdType)

	public CThostFtdcTransferQryBankReqField(){}

	public CThostFtdcTransferQryBankReqField(byte[] FutureAccount,char FuturePwdFlag,byte[] FutureAccPwd){
		try{	if(FutureAccount !=null)	this.FutureAccount= new String(FutureAccount, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FutureAccount = "";}
		this.FuturePwdFlag=FuturePwdFlag;
		try{	if(FutureAccPwd !=null)	this.FutureAccPwd= new String(FutureAccPwd, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FutureAccPwd = "";}
	}
}
