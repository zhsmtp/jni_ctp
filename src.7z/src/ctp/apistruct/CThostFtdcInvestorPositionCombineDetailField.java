package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcInvestorPositionCombineDetailField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public String OpenDate = "";	 //char[9]	(TThostFtdcDateType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public int SettlementID;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String ComTradeID = "";	 //char[21]	(TThostFtdcTradeIDType)
	public String TradeID = "";	 //char[21]	(TThostFtdcTradeIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public char HedgeFlag;
	public char Direction;
	public int TotalAmt;
	public double Margin;
	public double ExchMargin;
	public double MarginRateByMoney;
	public double MarginRateByVolume;
	public int LegID;
	public int LegMultiple;
	public String CombInstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public int TradeGroupID;
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)

	public CThostFtdcInvestorPositionCombineDetailField(){}

	public CThostFtdcInvestorPositionCombineDetailField(byte[] TradingDay,byte[] OpenDate,byte[] ExchangeID,int SettlementID,byte[] BrokerID,byte[] InvestorID,byte[] ComTradeID,byte[] TradeID,byte[] InstrumentID,char HedgeFlag,char Direction,int TotalAmt,double Margin,double ExchMargin,double MarginRateByMoney,double MarginRateByVolume,int LegID,int LegMultiple,byte[] CombInstrumentID,int TradeGroupID,byte[] InvestUnitID){
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		try{	if(OpenDate !=null)	this.OpenDate= new String(OpenDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OpenDate = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		this.SettlementID=SettlementID;
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(ComTradeID !=null)	this.ComTradeID= new String(ComTradeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ComTradeID = "";}
		try{	if(TradeID !=null)	this.TradeID= new String(TradeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		this.HedgeFlag=HedgeFlag;
		this.Direction=Direction;
		this.TotalAmt=TotalAmt;
		this.Margin=Margin;
		this.ExchMargin=ExchMargin;
		this.MarginRateByMoney=MarginRateByMoney;
		this.MarginRateByVolume=MarginRateByVolume;
		this.LegID=LegID;
		this.LegMultiple=LegMultiple;
		try{	if(CombInstrumentID !=null)	this.CombInstrumentID= new String(CombInstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CombInstrumentID = "";}
		this.TradeGroupID=TradeGroupID;
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
	}
}
