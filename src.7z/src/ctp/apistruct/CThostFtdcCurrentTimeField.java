package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcCurrentTimeField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String CurrDate = "";	 //char[9]	(TThostFtdcDateType)
	public String CurrTime = "";	 //char[9]	(TThostFtdcTimeType)
	public int CurrMillisec;
	public String ActionDay = "";	 //char[9]	(TThostFtdcDateType)

	public CThostFtdcCurrentTimeField(){}

	public CThostFtdcCurrentTimeField(byte[] CurrDate,byte[] CurrTime,int CurrMillisec,byte[] ActionDay){
		try{	if(CurrDate !=null)	this.CurrDate= new String(CurrDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrDate = "";}
		try{	if(CurrTime !=null)	this.CurrTime= new String(CurrTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrTime = "";}
		this.CurrMillisec=CurrMillisec;
		try{	if(ActionDay !=null)	this.ActionDay= new String(ActionDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActionDay = "";}
	}
}
