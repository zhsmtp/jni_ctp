package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcBrokerUserField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String UserName = "";	 //char[81]	(TThostFtdcUserNameType)
	public char UserType;
	public int IsActive;
	public int IsUsingOTP;
	public int IsAuthForce;

	public CThostFtdcBrokerUserField(){}

	public CThostFtdcBrokerUserField(byte[] BrokerID,byte[] UserID,byte[] UserName,char UserType,int IsActive,int IsUsingOTP,int IsAuthForce){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(UserName !=null)	this.UserName= new String(UserName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserName = "";}
		this.UserType=UserType;
		this.IsActive=IsActive;
		this.IsUsingOTP=IsUsingOTP;
		this.IsAuthForce=IsAuthForce;
	}
}
