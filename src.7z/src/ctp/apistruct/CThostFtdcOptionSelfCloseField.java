package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcOptionSelfCloseField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String OptionSelfCloseRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public int Volume;
	public int RequestID;
	public String BusinessUnit = "";	 //char[21]	(TThostFtdcBusinessUnitType)
	public char HedgeFlag;
	public char OptSelfCloseFlag;
	public String OptionSelfCloseLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String ClientID = "";	 //char[11]	(TThostFtdcClientIDType)
	public String ExchangeInstID = "";	 //char[31]	(TThostFtdcExchangeInstIDType)
	public String TraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public int InstallID;
	public char OrderSubmitStatus;
	public int NotifySequence;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public int SettlementID;
	public String OptionSelfCloseSysID = "";	 //char[21]	(TThostFtdcOrderSysIDType)
	public String InsertDate = "";	 //char[9]	(TThostFtdcDateType)
	public String InsertTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String CancelTime = "";	 //char[9]	(TThostFtdcTimeType)
	public char ExecResult;
	public String ClearingPartID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public int SequenceNo;
	public int FrontID;
	public int SessionID;
	public String UserProductInfo = "";	 //char[11]	(TThostFtdcProductInfoType)
	public String StatusMsg = "";	 //char[81]	(TThostFtdcErrorMsgType)
	public String ActiveUserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public int BrokerOptionSelfCloseSeq;
	public String BranchID = "";	 //char[9]	(TThostFtdcBranchIDType)
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)

	public CThostFtdcOptionSelfCloseField(){}

	public CThostFtdcOptionSelfCloseField(byte[] BrokerID,byte[] InvestorID,byte[] InstrumentID,byte[] OptionSelfCloseRef,byte[] UserID,int Volume,int RequestID,byte[] BusinessUnit,char HedgeFlag,char OptSelfCloseFlag,byte[] OptionSelfCloseLocalID,byte[] ExchangeID,byte[] ParticipantID,byte[] ClientID,byte[] ExchangeInstID,byte[] TraderID,int InstallID,char OrderSubmitStatus,int NotifySequence,byte[] TradingDay,int SettlementID,byte[] OptionSelfCloseSysID,byte[] InsertDate,byte[] InsertTime,byte[] CancelTime,char ExecResult,byte[] ClearingPartID,int SequenceNo,int FrontID,int SessionID,byte[] UserProductInfo,byte[] StatusMsg,byte[] ActiveUserID,int BrokerOptionSelfCloseSeq,byte[] BranchID,byte[] InvestUnitID,byte[] AccountID,byte[] CurrencyID,byte[] IPAddress,byte[] MacAddress){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(OptionSelfCloseRef !=null)	this.OptionSelfCloseRef= new String(OptionSelfCloseRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OptionSelfCloseRef = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.Volume=Volume;
		this.RequestID=RequestID;
		try{	if(BusinessUnit !=null)	this.BusinessUnit= new String(BusinessUnit, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BusinessUnit = "";}
		this.HedgeFlag=HedgeFlag;
		this.OptSelfCloseFlag=OptSelfCloseFlag;
		try{	if(OptionSelfCloseLocalID !=null)	this.OptionSelfCloseLocalID= new String(OptionSelfCloseLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OptionSelfCloseLocalID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(ClientID !=null)	this.ClientID= new String(ClientID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientID = "";}
		try{	if(ExchangeInstID !=null)	this.ExchangeInstID= new String(ExchangeInstID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeInstID = "";}
		try{	if(TraderID !=null)	this.TraderID= new String(TraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TraderID = "";}
		this.InstallID=InstallID;
		this.OrderSubmitStatus=OrderSubmitStatus;
		this.NotifySequence=NotifySequence;
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.SettlementID=SettlementID;
		try{	if(OptionSelfCloseSysID !=null)	this.OptionSelfCloseSysID= new String(OptionSelfCloseSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OptionSelfCloseSysID = "";}
		try{	if(InsertDate !=null)	this.InsertDate= new String(InsertDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InsertDate = "";}
		try{	if(InsertTime !=null)	this.InsertTime= new String(InsertTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InsertTime = "";}
		try{	if(CancelTime !=null)	this.CancelTime= new String(CancelTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CancelTime = "";}
		this.ExecResult=ExecResult;
		try{	if(ClearingPartID !=null)	this.ClearingPartID= new String(ClearingPartID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClearingPartID = "";}
		this.SequenceNo=SequenceNo;
		this.FrontID=FrontID;
		this.SessionID=SessionID;
		try{	if(UserProductInfo !=null)	this.UserProductInfo= new String(UserProductInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserProductInfo = "";}
		try{	if(StatusMsg !=null)	this.StatusMsg= new String(StatusMsg, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.StatusMsg = "";}
		try{	if(ActiveUserID !=null)	this.ActiveUserID= new String(ActiveUserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActiveUserID = "";}
		this.BrokerOptionSelfCloseSeq=BrokerOptionSelfCloseSeq;
		try{	if(BranchID !=null)	this.BranchID= new String(BranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BranchID = "";}
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
	}
}
