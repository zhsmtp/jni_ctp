package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcCFMMCBrokerKeyField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String CreateDate = "";	 //char[9]	(TThostFtdcDateType)
	public String CreateTime = "";	 //char[9]	(TThostFtdcTimeType)
	public int KeyID;
	public String CurrentKey = "";	 //char[21]	(TThostFtdcCFMMCKeyType)
	public char KeyKind;

	public CThostFtdcCFMMCBrokerKeyField(){}

	public CThostFtdcCFMMCBrokerKeyField(byte[] BrokerID,byte[] ParticipantID,byte[] CreateDate,byte[] CreateTime,int KeyID,byte[] CurrentKey,char KeyKind){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(CreateDate !=null)	this.CreateDate= new String(CreateDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CreateDate = "";}
		try{	if(CreateTime !=null)	this.CreateTime= new String(CreateTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CreateTime = "";}
		this.KeyID=KeyID;
		try{	if(CurrentKey !=null)	this.CurrentKey= new String(CurrentKey, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrentKey = "";}
		this.KeyKind=KeyKind;
	}
}
