package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcExchangeExecOrderActionField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ExecOrderSysID = "";	 //char[21]	(TThostFtdcExecOrderSysIDType)
	public char ActionFlag;
	public String ActionDate = "";	 //char[9]	(TThostFtdcDateType)
	public String ActionTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String TraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public int InstallID;
	public String ExecOrderLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public String ActionLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String ClientID = "";	 //char[11]	(TThostFtdcClientIDType)
	public String BusinessUnit = "";	 //char[21]	(TThostFtdcBusinessUnitType)
	public char OrderActionStatus;
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public char ActionType;
	public String BranchID = "";	 //char[9]	(TThostFtdcBranchIDType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)
	public String ExchangeInstID = "";	 //char[31]	(TThostFtdcExchangeInstIDType)
	public int Volume;

	public CThostFtdcExchangeExecOrderActionField(){}

	public CThostFtdcExchangeExecOrderActionField(byte[] ExchangeID,byte[] ExecOrderSysID,char ActionFlag,byte[] ActionDate,byte[] ActionTime,byte[] TraderID,int InstallID,byte[] ExecOrderLocalID,byte[] ActionLocalID,byte[] ParticipantID,byte[] ClientID,byte[] BusinessUnit,char OrderActionStatus,byte[] UserID,char ActionType,byte[] BranchID,byte[] IPAddress,byte[] MacAddress,byte[] ExchangeInstID,int Volume){
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ExecOrderSysID !=null)	this.ExecOrderSysID= new String(ExecOrderSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExecOrderSysID = "";}
		this.ActionFlag=ActionFlag;
		try{	if(ActionDate !=null)	this.ActionDate= new String(ActionDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActionDate = "";}
		try{	if(ActionTime !=null)	this.ActionTime= new String(ActionTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActionTime = "";}
		try{	if(TraderID !=null)	this.TraderID= new String(TraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TraderID = "";}
		this.InstallID=InstallID;
		try{	if(ExecOrderLocalID !=null)	this.ExecOrderLocalID= new String(ExecOrderLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExecOrderLocalID = "";}
		try{	if(ActionLocalID !=null)	this.ActionLocalID= new String(ActionLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActionLocalID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(ClientID !=null)	this.ClientID= new String(ClientID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientID = "";}
		try{	if(BusinessUnit !=null)	this.BusinessUnit= new String(BusinessUnit, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BusinessUnit = "";}
		this.OrderActionStatus=OrderActionStatus;
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.ActionType=ActionType;
		try{	if(BranchID !=null)	this.BranchID= new String(BranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BranchID = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
		try{	if(ExchangeInstID !=null)	this.ExchangeInstID= new String(ExchangeInstID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeInstID = "";}
		this.Volume=Volume;
	}
}
