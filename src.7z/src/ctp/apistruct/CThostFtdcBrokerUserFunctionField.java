package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcBrokerUserFunctionField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public char BrokerFunctionCode;

	public CThostFtdcBrokerUserFunctionField(){}

	public CThostFtdcBrokerUserFunctionField(byte[] BrokerID,byte[] UserID,char BrokerFunctionCode){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.BrokerFunctionCode=BrokerFunctionCode;
	}
}
