package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcRspApiHandshakeField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int FrontHandshakeDataLen;
	public String FrontHandshakeData = "";	 //char[301]	(TThostFtdcHandshakeDataType)
	public int IsApiAuthEnabled;

	public CThostFtdcRspApiHandshakeField(){}

	public CThostFtdcRspApiHandshakeField(int FrontHandshakeDataLen,byte[] FrontHandshakeData,int IsApiAuthEnabled){
		this.FrontHandshakeDataLen=FrontHandshakeDataLen;
		try{	if(FrontHandshakeData !=null)	this.FrontHandshakeData= new String(FrontHandshakeData, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FrontHandshakeData = "";}
		this.IsApiAuthEnabled=IsApiAuthEnabled;
	}
}
