package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryContractBankField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankBrchID = "";	 //char[5]	(TThostFtdcBankBrchIDType)

	public CThostFtdcQryContractBankField(){}

	public CThostFtdcQryContractBankField(byte[] BrokerID,byte[] BankID,byte[] BankBrchID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankBrchID !=null)	this.BankBrchID= new String(BankBrchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankBrchID = "";}
	}
}
