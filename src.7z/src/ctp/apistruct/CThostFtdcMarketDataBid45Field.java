package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMarketDataBid45Field implements Serializable {
	private static final long serialVersionUID = 1L;
	public double BidPrice4;
	public int BidVolume4;
	public double BidPrice5;
	public int BidVolume5;

	public CThostFtdcMarketDataBid45Field(){}

	public CThostFtdcMarketDataBid45Field(double BidPrice4,int BidVolume4,double BidPrice5,int BidVolume5){
		this.BidPrice4=BidPrice4;
		this.BidVolume4=BidVolume4;
		this.BidPrice5=BidPrice5;
		this.BidVolume5=BidVolume5;
	}
}
