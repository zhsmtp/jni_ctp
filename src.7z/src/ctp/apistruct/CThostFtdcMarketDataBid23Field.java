package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMarketDataBid23Field implements Serializable {
	private static final long serialVersionUID = 1L;
	public double BidPrice2;
	public int BidVolume2;
	public double BidPrice3;
	public int BidVolume3;

	public CThostFtdcMarketDataBid23Field(){}

	public CThostFtdcMarketDataBid23Field(double BidPrice2,int BidVolume2,double BidPrice3,int BidVolume3){
		this.BidPrice2=BidPrice2;
		this.BidVolume2=BidVolume2;
		this.BidPrice3=BidPrice3;
		this.BidVolume3=BidVolume3;
	}
}
