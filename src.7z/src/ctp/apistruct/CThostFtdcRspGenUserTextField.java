package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcRspGenUserTextField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int UserTextSeq;

	public CThostFtdcRspGenUserTextField(){}

	public CThostFtdcRspGenUserTextField(int UserTextSeq){
		this.UserTextSeq=UserTextSeq;
	}
}
