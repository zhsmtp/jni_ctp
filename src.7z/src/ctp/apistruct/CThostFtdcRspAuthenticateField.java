package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcRspAuthenticateField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String UserProductInfo = "";	 //char[11]	(TThostFtdcProductInfoType)
	public String AppID = "";	 //char[33]	(TThostFtdcAppIDType)
	public char AppType;

	public CThostFtdcRspAuthenticateField(){}

	public CThostFtdcRspAuthenticateField(byte[] BrokerID,byte[] UserID,byte[] UserProductInfo,byte[] AppID,char AppType){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(UserProductInfo !=null)	this.UserProductInfo= new String(UserProductInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserProductInfo = "";}
		try{	if(AppID !=null)	this.AppID= new String(AppID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AppID = "";}
		this.AppType=AppType;
	}
}
