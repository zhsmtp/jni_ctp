package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTransferSerialField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int PlateSerial;
	public String TradeDate = "";	 //char[9]	(TThostFtdcTradeDateType)
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public String TradeTime = "";	 //char[9]	(TThostFtdcTradeTimeType)
	public String TradeCode = "";	 //char[7]	(TThostFtdcTradeCodeType)
	public int SessionID;
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankBranchID = "";	 //char[5]	(TThostFtdcBankBrchIDType)
	public char BankAccType;
	public String BankAccount = "";	 //char[41]	(TThostFtdcBankAccountType)
	public String BankSerial = "";	 //char[13]	(TThostFtdcBankSerialType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String BrokerBranchID = "";	 //char[31]	(TThostFtdcFutureBranchIDType)
	public char FutureAccType;
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public int FutureSerial;
	public char IdCardType;
	public String IdentifiedCardNo = "";	 //char[51]	(TThostFtdcIdentifiedCardNoType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public double TradeAmount;
	public double CustFee;
	public double BrokerFee;
	public char AvailabilityFlag;
	public String OperatorCode = "";	 //char[17]	(TThostFtdcOperatorCodeType)
	public String BankNewAccount = "";	 //char[41]	(TThostFtdcBankAccountType)
	public int ErrorID;
	public String ErrorMsg = "";	 //char[81]	(TThostFtdcErrorMsgType)

	public CThostFtdcTransferSerialField(){}

	public CThostFtdcTransferSerialField(int PlateSerial,byte[] TradeDate,byte[] TradingDay,byte[] TradeTime,byte[] TradeCode,int SessionID,byte[] BankID,byte[] BankBranchID,char BankAccType,byte[] BankAccount,byte[] BankSerial,byte[] BrokerID,byte[] BrokerBranchID,char FutureAccType,byte[] AccountID,byte[] InvestorID,int FutureSerial,char IdCardType,byte[] IdentifiedCardNo,byte[] CurrencyID,double TradeAmount,double CustFee,double BrokerFee,char AvailabilityFlag,byte[] OperatorCode,byte[] BankNewAccount,int ErrorID,byte[] ErrorMsg){
		this.PlateSerial=PlateSerial;
		try{	if(TradeDate !=null)	this.TradeDate= new String(TradeDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeDate = "";}
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		try{	if(TradeTime !=null)	this.TradeTime= new String(TradeTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeTime = "";}
		try{	if(TradeCode !=null)	this.TradeCode= new String(TradeCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeCode = "";}
		this.SessionID=SessionID;
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankBranchID !=null)	this.BankBranchID= new String(BankBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankBranchID = "";}
		this.BankAccType=BankAccType;
		try{	if(BankAccount !=null)	this.BankAccount= new String(BankAccount, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankAccount = "";}
		try{	if(BankSerial !=null)	this.BankSerial= new String(BankSerial, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankSerial = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(BrokerBranchID !=null)	this.BrokerBranchID= new String(BrokerBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerBranchID = "";}
		this.FutureAccType=FutureAccType;
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.FutureSerial=FutureSerial;
		this.IdCardType=IdCardType;
		try{	if(IdentifiedCardNo !=null)	this.IdentifiedCardNo= new String(IdentifiedCardNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IdentifiedCardNo = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		this.TradeAmount=TradeAmount;
		this.CustFee=CustFee;
		this.BrokerFee=BrokerFee;
		this.AvailabilityFlag=AvailabilityFlag;
		try{	if(OperatorCode !=null)	this.OperatorCode= new String(OperatorCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OperatorCode = "";}
		try{	if(BankNewAccount !=null)	this.BankNewAccount= new String(BankNewAccount, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankNewAccount = "";}
		this.ErrorID=ErrorID;
		try{	if(ErrorMsg !=null)	this.ErrorMsg= new String(ErrorMsg, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ErrorMsg = "";}
	}
}
