package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcOpenAccountField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradeCode = "";	 //char[7]	(TThostFtdcTradeCodeType)
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankBranchID = "";	 //char[5]	(TThostFtdcBankBrchIDType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String BrokerBranchID = "";	 //char[31]	(TThostFtdcFutureBranchIDType)
	public String TradeDate = "";	 //char[9]	(TThostFtdcTradeDateType)
	public String TradeTime = "";	 //char[9]	(TThostFtdcTradeTimeType)
	public String BankSerial = "";	 //char[13]	(TThostFtdcBankSerialType)
	public int PlateSerial;
	public char LastFragment;
	public int SessionID;
	public String CustomerName = "";	 //char[51]	(TThostFtdcIndividualNameType)
	public char IdCardType;
	public String IdentifiedCardNo = "";	 //char[51]	(TThostFtdcIdentifiedCardNoType)
	public char Gender;
	public String CountryCode = "";	 //char[21]	(TThostFtdcCountryCodeType)
	public char CustType;
	public String Address = "";	 //char[101]	(TThostFtdcAddressType)
	public String ZipCode = "";	 //char[7]	(TThostFtdcZipCodeType)
	public String Telephone = "";	 //char[41]	(TThostFtdcTelephoneType)
	public String MobilePhone = "";	 //char[21]	(TThostFtdcMobilePhoneType)
	public String Fax = "";	 //char[41]	(TThostFtdcFaxType)
	public String EMail = "";	 //char[41]	(TThostFtdcEMailType)
	public char MoneyAccountStatus;
	public String BankAccount = "";	 //char[41]	(TThostFtdcBankAccountType)
	public String BankPassWord = "";	 //char[41]	(TThostFtdcPasswordType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String Password = "";	 //char[41]	(TThostFtdcPasswordType)
	public int InstallID;
	public char VerifyCertNoFlag;
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public char CashExchangeCode;
	public String Digest = "";	 //char[36]	(TThostFtdcDigestType)
	public char BankAccType;
	public String DeviceID = "";	 //char[3]	(TThostFtdcDeviceIDType)
	public char BankSecuAccType;
	public String BrokerIDByBank = "";	 //char[33]	(TThostFtdcBankCodingForFutureType)
	public String BankSecuAcc = "";	 //char[41]	(TThostFtdcBankAccountType)
	public char BankPwdFlag;
	public char SecuPwdFlag;
	public String OperNo = "";	 //char[17]	(TThostFtdcOperNoType)
	public int TID;
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public int ErrorID;
	public String ErrorMsg = "";	 //char[81]	(TThostFtdcErrorMsgType)
	public String LongCustomerName = "";	 //char[161]	(TThostFtdcLongIndividualNameType)

	public CThostFtdcOpenAccountField(){}

	public CThostFtdcOpenAccountField(byte[] TradeCode,byte[] BankID,byte[] BankBranchID,byte[] BrokerID,byte[] BrokerBranchID,byte[] TradeDate,byte[] TradeTime,byte[] BankSerial,int PlateSerial,char LastFragment,int SessionID,byte[] CustomerName,char IdCardType,byte[] IdentifiedCardNo,char Gender,byte[] CountryCode,char CustType,byte[] Address,byte[] ZipCode,byte[] Telephone,byte[] MobilePhone,byte[] Fax,byte[] EMail,char MoneyAccountStatus,byte[] BankAccount,byte[] BankPassWord,byte[] AccountID,byte[] Password,int InstallID,char VerifyCertNoFlag,byte[] CurrencyID,char CashExchangeCode,byte[] Digest,char BankAccType,byte[] DeviceID,char BankSecuAccType,byte[] BrokerIDByBank,byte[] BankSecuAcc,char BankPwdFlag,char SecuPwdFlag,byte[] OperNo,int TID,byte[] UserID,int ErrorID,byte[] ErrorMsg,byte[] LongCustomerName){
		try{	if(TradeCode !=null)	this.TradeCode= new String(TradeCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeCode = "";}
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankBranchID !=null)	this.BankBranchID= new String(BankBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankBranchID = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(BrokerBranchID !=null)	this.BrokerBranchID= new String(BrokerBranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerBranchID = "";}
		try{	if(TradeDate !=null)	this.TradeDate= new String(TradeDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeDate = "";}
		try{	if(TradeTime !=null)	this.TradeTime= new String(TradeTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeTime = "";}
		try{	if(BankSerial !=null)	this.BankSerial= new String(BankSerial, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankSerial = "";}
		this.PlateSerial=PlateSerial;
		this.LastFragment=LastFragment;
		this.SessionID=SessionID;
		try{	if(CustomerName !=null)	this.CustomerName= new String(CustomerName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CustomerName = "";}
		this.IdCardType=IdCardType;
		try{	if(IdentifiedCardNo !=null)	this.IdentifiedCardNo= new String(IdentifiedCardNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IdentifiedCardNo = "";}
		this.Gender=Gender;
		try{	if(CountryCode !=null)	this.CountryCode= new String(CountryCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CountryCode = "";}
		this.CustType=CustType;
		try{	if(Address !=null)	this.Address= new String(Address, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Address = "";}
		try{	if(ZipCode !=null)	this.ZipCode= new String(ZipCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ZipCode = "";}
		try{	if(Telephone !=null)	this.Telephone= new String(Telephone, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Telephone = "";}
		try{	if(MobilePhone !=null)	this.MobilePhone= new String(MobilePhone, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MobilePhone = "";}
		try{	if(Fax !=null)	this.Fax= new String(Fax, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Fax = "";}
		try{	if(EMail !=null)	this.EMail= new String(EMail, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.EMail = "";}
		this.MoneyAccountStatus=MoneyAccountStatus;
		try{	if(BankAccount !=null)	this.BankAccount= new String(BankAccount, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankAccount = "";}
		try{	if(BankPassWord !=null)	this.BankPassWord= new String(BankPassWord, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankPassWord = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(Password !=null)	this.Password= new String(Password, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Password = "";}
		this.InstallID=InstallID;
		this.VerifyCertNoFlag=VerifyCertNoFlag;
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		this.CashExchangeCode=CashExchangeCode;
		try{	if(Digest !=null)	this.Digest= new String(Digest, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Digest = "";}
		this.BankAccType=BankAccType;
		try{	if(DeviceID !=null)	this.DeviceID= new String(DeviceID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.DeviceID = "";}
		this.BankSecuAccType=BankSecuAccType;
		try{	if(BrokerIDByBank !=null)	this.BrokerIDByBank= new String(BrokerIDByBank, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerIDByBank = "";}
		try{	if(BankSecuAcc !=null)	this.BankSecuAcc= new String(BankSecuAcc, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankSecuAcc = "";}
		this.BankPwdFlag=BankPwdFlag;
		this.SecuPwdFlag=SecuPwdFlag;
		try{	if(OperNo !=null)	this.OperNo= new String(OperNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OperNo = "";}
		this.TID=TID;
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.ErrorID=ErrorID;
		try{	if(ErrorMsg !=null)	this.ErrorMsg= new String(ErrorMsg, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ErrorMsg = "";}
		try{	if(LongCustomerName !=null)	this.LongCustomerName= new String(LongCustomerName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LongCustomerName = "";}
	}
}
