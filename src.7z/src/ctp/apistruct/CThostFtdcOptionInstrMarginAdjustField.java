package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcOptionInstrMarginAdjustField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public char InvestorRange;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public double SShortMarginRatioByMoney;
	public double SShortMarginRatioByVolume;
	public double HShortMarginRatioByMoney;
	public double HShortMarginRatioByVolume;
	public double AShortMarginRatioByMoney;
	public double AShortMarginRatioByVolume;
	public int IsRelative;
	public double MShortMarginRatioByMoney;
	public double MShortMarginRatioByVolume;

	public CThostFtdcOptionInstrMarginAdjustField(){}

	public CThostFtdcOptionInstrMarginAdjustField(byte[] InstrumentID,char InvestorRange,byte[] BrokerID,byte[] InvestorID,double SShortMarginRatioByMoney,double SShortMarginRatioByVolume,double HShortMarginRatioByMoney,double HShortMarginRatioByVolume,double AShortMarginRatioByMoney,double AShortMarginRatioByVolume,int IsRelative,double MShortMarginRatioByMoney,double MShortMarginRatioByVolume){
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		this.InvestorRange=InvestorRange;
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.SShortMarginRatioByMoney=SShortMarginRatioByMoney;
		this.SShortMarginRatioByVolume=SShortMarginRatioByVolume;
		this.HShortMarginRatioByMoney=HShortMarginRatioByMoney;
		this.HShortMarginRatioByVolume=HShortMarginRatioByVolume;
		this.AShortMarginRatioByMoney=AShortMarginRatioByMoney;
		this.AShortMarginRatioByVolume=AShortMarginRatioByVolume;
		this.IsRelative=IsRelative;
		this.MShortMarginRatioByMoney=MShortMarginRatioByMoney;
		this.MShortMarginRatioByVolume=MShortMarginRatioByVolume;
	}
}
