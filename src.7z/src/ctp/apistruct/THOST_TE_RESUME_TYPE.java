package ctp.apistruct;
public class THOST_TE_RESUME_TYPE {
	public static final int THOST_TERT_RESTART = 0;
	public static final int THOST_TERT_RESUME = 1;
	public static final int THOST_TERT_QUICK = 2;
}
