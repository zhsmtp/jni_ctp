package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcExchangeRateField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String FromCurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public double FromCurrencyUnit;
	public String ToCurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public double ExchangeRate;

	public CThostFtdcExchangeRateField(){}

	public CThostFtdcExchangeRateField(byte[] BrokerID,byte[] FromCurrencyID,double FromCurrencyUnit,byte[] ToCurrencyID,double ExchangeRate){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(FromCurrencyID !=null)	this.FromCurrencyID= new String(FromCurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FromCurrencyID = "";}
		this.FromCurrencyUnit=FromCurrencyUnit;
		try{	if(ToCurrencyID !=null)	this.ToCurrencyID= new String(ToCurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ToCurrencyID = "";}
		this.ExchangeRate=ExchangeRate;
	}
}
