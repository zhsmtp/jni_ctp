package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcSpecificInstrumentField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)

	public CThostFtdcSpecificInstrumentField(){}

	public CThostFtdcSpecificInstrumentField(byte[] InstrumentID){
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
	}
}
