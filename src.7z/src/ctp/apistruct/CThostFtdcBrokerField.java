package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcBrokerField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String BrokerAbbr = "";	 //char[9]	(TThostFtdcBrokerAbbrType)
	public String BrokerName = "";	 //char[81]	(TThostFtdcBrokerNameType)
	public int IsActive;

	public CThostFtdcBrokerField(){}

	public CThostFtdcBrokerField(byte[] BrokerID,byte[] BrokerAbbr,byte[] BrokerName,int IsActive){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(BrokerAbbr !=null)	this.BrokerAbbr= new String(BrokerAbbr, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerAbbr = "";}
		try{	if(BrokerName !=null)	this.BrokerName= new String(BrokerName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerName = "";}
		this.IsActive=IsActive;
	}
}
