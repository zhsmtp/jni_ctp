package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcLinkManField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public char PersonType;
	public char IdentifiedCardType;
	public String IdentifiedCardNo = "";	 //char[51]	(TThostFtdcIdentifiedCardNoType)
	public String PersonName = "";	 //char[81]	(TThostFtdcPartyNameType)
	public String Telephone = "";	 //char[41]	(TThostFtdcTelephoneType)
	public String Address = "";	 //char[101]	(TThostFtdcAddressType)
	public String ZipCode = "";	 //char[7]	(TThostFtdcZipCodeType)
	public int Priority;
	public String UOAZipCode = "";	 //char[11]	(TThostFtdcUOAZipCodeType)
	public String PersonFullName = "";	 //char[101]	(TThostFtdcInvestorFullNameType)

	public CThostFtdcLinkManField(){}

	public CThostFtdcLinkManField(byte[] BrokerID,byte[] InvestorID,char PersonType,char IdentifiedCardType,byte[] IdentifiedCardNo,byte[] PersonName,byte[] Telephone,byte[] Address,byte[] ZipCode,int Priority,byte[] UOAZipCode,byte[] PersonFullName){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.PersonType=PersonType;
		this.IdentifiedCardType=IdentifiedCardType;
		try{	if(IdentifiedCardNo !=null)	this.IdentifiedCardNo= new String(IdentifiedCardNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IdentifiedCardNo = "";}
		try{	if(PersonName !=null)	this.PersonName= new String(PersonName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.PersonName = "";}
		try{	if(Telephone !=null)	this.Telephone= new String(Telephone, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Telephone = "";}
		try{	if(Address !=null)	this.Address= new String(Address, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Address = "";}
		try{	if(ZipCode !=null)	this.ZipCode= new String(ZipCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ZipCode = "";}
		this.Priority=Priority;
		try{	if(UOAZipCode !=null)	this.UOAZipCode= new String(UOAZipCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UOAZipCode = "";}
		try{	if(PersonFullName !=null)	this.PersonFullName= new String(PersonFullName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.PersonFullName = "";}
	}
}
