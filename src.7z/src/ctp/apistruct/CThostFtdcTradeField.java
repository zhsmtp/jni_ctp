package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTradeField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String OrderRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String TradeID = "";	 //char[21]	(TThostFtdcTradeIDType)
	public char Direction;
	public String OrderSysID = "";	 //char[21]	(TThostFtdcOrderSysIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String ClientID = "";	 //char[11]	(TThostFtdcClientIDType)
	public char TradingRole;
	public String ExchangeInstID = "";	 //char[31]	(TThostFtdcExchangeInstIDType)
	public char OffsetFlag;
	public char HedgeFlag;
	public double Price;
	public int Volume;
	public String TradeDate = "";	 //char[9]	(TThostFtdcDateType)
	public String TradeTime = "";	 //char[9]	(TThostFtdcTimeType)
	public char TradeType;
	public char PriceSource;
	public String TraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public String OrderLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public String ClearingPartID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String BusinessUnit = "";	 //char[21]	(TThostFtdcBusinessUnitType)
	public int SequenceNo;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public int SettlementID;
	public int BrokerOrderSeq;
	public char TradeSource;
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)

	public CThostFtdcTradeField(){}

	public CThostFtdcTradeField(byte[] BrokerID,byte[] InvestorID,byte[] InstrumentID,byte[] OrderRef,byte[] UserID,byte[] ExchangeID,byte[] TradeID,char Direction,byte[] OrderSysID,byte[] ParticipantID,byte[] ClientID,char TradingRole,byte[] ExchangeInstID,char OffsetFlag,char HedgeFlag,double Price,int Volume,byte[] TradeDate,byte[] TradeTime,char TradeType,char PriceSource,byte[] TraderID,byte[] OrderLocalID,byte[] ClearingPartID,byte[] BusinessUnit,int SequenceNo,byte[] TradingDay,int SettlementID,int BrokerOrderSeq,char TradeSource,byte[] InvestUnitID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(OrderRef !=null)	this.OrderRef= new String(OrderRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderRef = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(TradeID !=null)	this.TradeID= new String(TradeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeID = "";}
		this.Direction=Direction;
		try{	if(OrderSysID !=null)	this.OrderSysID= new String(OrderSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderSysID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(ClientID !=null)	this.ClientID= new String(ClientID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientID = "";}
		this.TradingRole=TradingRole;
		try{	if(ExchangeInstID !=null)	this.ExchangeInstID= new String(ExchangeInstID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeInstID = "";}
		this.OffsetFlag=OffsetFlag;
		this.HedgeFlag=HedgeFlag;
		this.Price=Price;
		this.Volume=Volume;
		try{	if(TradeDate !=null)	this.TradeDate= new String(TradeDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeDate = "";}
		try{	if(TradeTime !=null)	this.TradeTime= new String(TradeTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeTime = "";}
		this.TradeType=TradeType;
		this.PriceSource=PriceSource;
		try{	if(TraderID !=null)	this.TraderID= new String(TraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TraderID = "";}
		try{	if(OrderLocalID !=null)	this.OrderLocalID= new String(OrderLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderLocalID = "";}
		try{	if(ClearingPartID !=null)	this.ClearingPartID= new String(ClearingPartID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClearingPartID = "";}
		try{	if(BusinessUnit !=null)	this.BusinessUnit= new String(BusinessUnit, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BusinessUnit = "";}
		this.SequenceNo=SequenceNo;
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.SettlementID=SettlementID;
		this.BrokerOrderSeq=BrokerOrderSeq;
		this.TradeSource=TradeSource;
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
	}
}
