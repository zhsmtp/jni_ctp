package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQueryFreqField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int QueryFreq;

	public CThostFtdcQueryFreqField(){}

	public CThostFtdcQueryFreqField(int QueryFreq){
		this.QueryFreq=QueryFreq;
	}
}
