package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcErrExecOrderField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String ExecOrderRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public int Volume;
	public int RequestID;
	public String BusinessUnit = "";	 //char[21]	(TThostFtdcBusinessUnitType)
	public char OffsetFlag;
	public char HedgeFlag;
	public char ActionType;
	public char PosiDirection;
	public char ReservePositionFlag;
	public char CloseFlag;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public String ClientID = "";	 //char[11]	(TThostFtdcClientIDType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)
	public int ErrorID;
	public String ErrorMsg = "";	 //char[81]	(TThostFtdcErrorMsgType)

	public CThostFtdcErrExecOrderField(){}

	public CThostFtdcErrExecOrderField(byte[] BrokerID,byte[] InvestorID,byte[] InstrumentID,byte[] ExecOrderRef,byte[] UserID,int Volume,int RequestID,byte[] BusinessUnit,char OffsetFlag,char HedgeFlag,char ActionType,char PosiDirection,char ReservePositionFlag,char CloseFlag,byte[] ExchangeID,byte[] InvestUnitID,byte[] AccountID,byte[] CurrencyID,byte[] ClientID,byte[] IPAddress,byte[] MacAddress,int ErrorID,byte[] ErrorMsg){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(ExecOrderRef !=null)	this.ExecOrderRef= new String(ExecOrderRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExecOrderRef = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.Volume=Volume;
		this.RequestID=RequestID;
		try{	if(BusinessUnit !=null)	this.BusinessUnit= new String(BusinessUnit, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BusinessUnit = "";}
		this.OffsetFlag=OffsetFlag;
		this.HedgeFlag=HedgeFlag;
		this.ActionType=ActionType;
		this.PosiDirection=PosiDirection;
		this.ReservePositionFlag=ReservePositionFlag;
		this.CloseFlag=CloseFlag;
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		try{	if(ClientID !=null)	this.ClientID= new String(ClientID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientID = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
		this.ErrorID=ErrorID;
		try{	if(ErrorMsg !=null)	this.ErrorMsg= new String(ErrorMsg, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ErrorMsg = "";}
	}
}
