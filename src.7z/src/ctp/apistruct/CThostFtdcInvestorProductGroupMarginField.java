package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcInvestorProductGroupMarginField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ProductGroupID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public int SettlementID;
	public double FrozenMargin;
	public double LongFrozenMargin;
	public double ShortFrozenMargin;
	public double UseMargin;
	public double LongUseMargin;
	public double ShortUseMargin;
	public double ExchMargin;
	public double LongExchMargin;
	public double ShortExchMargin;
	public double CloseProfit;
	public double FrozenCommission;
	public double Commission;
	public double FrozenCash;
	public double CashIn;
	public double PositionProfit;
	public double OffsetAmount;
	public double LongOffsetAmount;
	public double ShortOffsetAmount;
	public double ExchOffsetAmount;
	public double LongExchOffsetAmount;
	public double ShortExchOffsetAmount;
	public char HedgeFlag;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)

	public CThostFtdcInvestorProductGroupMarginField(){}

	public CThostFtdcInvestorProductGroupMarginField(byte[] ProductGroupID,byte[] BrokerID,byte[] InvestorID,byte[] TradingDay,int SettlementID,double FrozenMargin,double LongFrozenMargin,double ShortFrozenMargin,double UseMargin,double LongUseMargin,double ShortUseMargin,double ExchMargin,double LongExchMargin,double ShortExchMargin,double CloseProfit,double FrozenCommission,double Commission,double FrozenCash,double CashIn,double PositionProfit,double OffsetAmount,double LongOffsetAmount,double ShortOffsetAmount,double ExchOffsetAmount,double LongExchOffsetAmount,double ShortExchOffsetAmount,char HedgeFlag,byte[] ExchangeID,byte[] InvestUnitID){
		try{	if(ProductGroupID !=null)	this.ProductGroupID= new String(ProductGroupID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ProductGroupID = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.SettlementID=SettlementID;
		this.FrozenMargin=FrozenMargin;
		this.LongFrozenMargin=LongFrozenMargin;
		this.ShortFrozenMargin=ShortFrozenMargin;
		this.UseMargin=UseMargin;
		this.LongUseMargin=LongUseMargin;
		this.ShortUseMargin=ShortUseMargin;
		this.ExchMargin=ExchMargin;
		this.LongExchMargin=LongExchMargin;
		this.ShortExchMargin=ShortExchMargin;
		this.CloseProfit=CloseProfit;
		this.FrozenCommission=FrozenCommission;
		this.Commission=Commission;
		this.FrozenCash=FrozenCash;
		this.CashIn=CashIn;
		this.PositionProfit=PositionProfit;
		this.OffsetAmount=OffsetAmount;
		this.LongOffsetAmount=LongOffsetAmount;
		this.ShortOffsetAmount=ShortOffsetAmount;
		this.ExchOffsetAmount=ExchOffsetAmount;
		this.LongExchOffsetAmount=LongExchOffsetAmount;
		this.ShortExchOffsetAmount=ShortExchOffsetAmount;
		this.HedgeFlag=HedgeFlag;
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
	}
}
