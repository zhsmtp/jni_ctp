package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcInvestUnitField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)
	public String InvestorUnitName = "";	 //char[81]	(TThostFtdcPartyNameType)
	public String InvestorGroupID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String CommModelID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String MarginModelID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)

	public CThostFtdcInvestUnitField(){}

	public CThostFtdcInvestUnitField(byte[] BrokerID,byte[] InvestorID,byte[] InvestUnitID,byte[] InvestorUnitName,byte[] InvestorGroupID,byte[] CommModelID,byte[] MarginModelID,byte[] AccountID,byte[] CurrencyID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
		try{	if(InvestorUnitName !=null)	this.InvestorUnitName= new String(InvestorUnitName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorUnitName = "";}
		try{	if(InvestorGroupID !=null)	this.InvestorGroupID= new String(InvestorGroupID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorGroupID = "";}
		try{	if(CommModelID !=null)	this.CommModelID= new String(CommModelID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CommModelID = "";}
		try{	if(MarginModelID !=null)	this.MarginModelID= new String(MarginModelID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MarginModelID = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
	}
}
