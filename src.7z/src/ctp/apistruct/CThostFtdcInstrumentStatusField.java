package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcInstrumentStatusField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ExchangeInstID = "";	 //char[31]	(TThostFtdcExchangeInstIDType)
	public String SettlementGroupID = "";	 //char[9]	(TThostFtdcSettlementGroupIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public char InstrumentStatus;
	public int TradingSegmentSN;
	public String EnterTime = "";	 //char[9]	(TThostFtdcTimeType)
	public char EnterReason;

	public CThostFtdcInstrumentStatusField(){}

	public CThostFtdcInstrumentStatusField(byte[] ExchangeID,byte[] ExchangeInstID,byte[] SettlementGroupID,byte[] InstrumentID,char InstrumentStatus,int TradingSegmentSN,byte[] EnterTime,char EnterReason){
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ExchangeInstID !=null)	this.ExchangeInstID= new String(ExchangeInstID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeInstID = "";}
		try{	if(SettlementGroupID !=null)	this.SettlementGroupID= new String(SettlementGroupID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.SettlementGroupID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		this.InstrumentStatus=InstrumentStatus;
		this.TradingSegmentSN=TradingSegmentSN;
		try{	if(EnterTime !=null)	this.EnterTime= new String(EnterTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.EnterTime = "";}
		this.EnterReason=EnterReason;
	}
}
