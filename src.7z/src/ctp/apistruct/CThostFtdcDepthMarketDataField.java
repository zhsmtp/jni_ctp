package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcDepthMarketDataField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ExchangeInstID = "";	 //char[31]	(TThostFtdcExchangeInstIDType)
	public double LastPrice;
	public double PreSettlementPrice;
	public double PreClosePrice;
	public double PreOpenInterest;
	public double OpenPrice;
	public double HighestPrice;
	public double LowestPrice;
	public int Volume;
	public double Turnover;
	public double OpenInterest;
	public double ClosePrice;
	public double SettlementPrice;
	public double UpperLimitPrice;
	public double LowerLimitPrice;
	public double PreDelta;
	public double CurrDelta;
	public String UpdateTime = "";	 //char[9]	(TThostFtdcTimeType)
	public int UpdateMillisec;
	public double BidPrice1;
	public int BidVolume1;
	public double AskPrice1;
	public int AskVolume1;
	public double BidPrice2;
	public int BidVolume2;
	public double AskPrice2;
	public int AskVolume2;
	public double BidPrice3;
	public int BidVolume3;
	public double AskPrice3;
	public int AskVolume3;
	public double BidPrice4;
	public int BidVolume4;
	public double AskPrice4;
	public int AskVolume4;
	public double BidPrice5;
	public int BidVolume5;
	public double AskPrice5;
	public int AskVolume5;
	public double AveragePrice;
	public String ActionDay = "";	 //char[9]	(TThostFtdcDateType)

	public CThostFtdcDepthMarketDataField(){}

	public CThostFtdcDepthMarketDataField(byte[] TradingDay,byte[] InstrumentID,byte[] ExchangeID,byte[] ExchangeInstID,double LastPrice,double PreSettlementPrice,double PreClosePrice,double PreOpenInterest,double OpenPrice,double HighestPrice,double LowestPrice,int Volume,double Turnover,double OpenInterest,double ClosePrice,double SettlementPrice,double UpperLimitPrice,double LowerLimitPrice,double PreDelta,double CurrDelta,byte[] UpdateTime,int UpdateMillisec,double BidPrice1,int BidVolume1,double AskPrice1,int AskVolume1,double BidPrice2,int BidVolume2,double AskPrice2,int AskVolume2,double BidPrice3,int BidVolume3,double AskPrice3,int AskVolume3,double BidPrice4,int BidVolume4,double AskPrice4,int AskVolume4,double BidPrice5,int BidVolume5,double AskPrice5,int AskVolume5,double AveragePrice,byte[] ActionDay){
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ExchangeInstID !=null)	this.ExchangeInstID= new String(ExchangeInstID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeInstID = "";}
		this.LastPrice=LastPrice;
		this.PreSettlementPrice=PreSettlementPrice;
		this.PreClosePrice=PreClosePrice;
		this.PreOpenInterest=PreOpenInterest;
		this.OpenPrice=OpenPrice;
		this.HighestPrice=HighestPrice;
		this.LowestPrice=LowestPrice;
		this.Volume=Volume;
		this.Turnover=Turnover;
		this.OpenInterest=OpenInterest;
		this.ClosePrice=ClosePrice;
		this.SettlementPrice=SettlementPrice;
		this.UpperLimitPrice=UpperLimitPrice;
		this.LowerLimitPrice=LowerLimitPrice;
		this.PreDelta=PreDelta;
		this.CurrDelta=CurrDelta;
		try{	if(UpdateTime !=null)	this.UpdateTime= new String(UpdateTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UpdateTime = "";}
		this.UpdateMillisec=UpdateMillisec;
		this.BidPrice1=BidPrice1;
		this.BidVolume1=BidVolume1;
		this.AskPrice1=AskPrice1;
		this.AskVolume1=AskVolume1;
		this.BidPrice2=BidPrice2;
		this.BidVolume2=BidVolume2;
		this.AskPrice2=AskPrice2;
		this.AskVolume2=AskVolume2;
		this.BidPrice3=BidPrice3;
		this.BidVolume3=BidVolume3;
		this.AskPrice3=AskPrice3;
		this.AskVolume3=AskVolume3;
		this.BidPrice4=BidPrice4;
		this.BidVolume4=BidVolume4;
		this.AskPrice4=AskPrice4;
		this.AskVolume4=AskVolume4;
		this.BidPrice5=BidPrice5;
		this.BidVolume5=BidVolume5;
		this.AskPrice5=AskPrice5;
		this.AskVolume5=AskVolume5;
		this.AveragePrice=AveragePrice;
		try{	if(ActionDay !=null)	this.ActionDay= new String(ActionDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActionDay = "";}
	}
}
