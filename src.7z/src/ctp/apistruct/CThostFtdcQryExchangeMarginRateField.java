package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryExchangeMarginRateField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public char HedgeFlag;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)

	public CThostFtdcQryExchangeMarginRateField(){}

	public CThostFtdcQryExchangeMarginRateField(byte[] BrokerID,byte[] InstrumentID,char HedgeFlag,byte[] ExchangeID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		this.HedgeFlag=HedgeFlag;
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
	}
}
