package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcExchangeOrderActionErrorField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String OrderSysID = "";	 //char[21]	(TThostFtdcOrderSysIDType)
	public String TraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public int InstallID;
	public String OrderLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public String ActionLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public int ErrorID;
	public String ErrorMsg = "";	 //char[81]	(TThostFtdcErrorMsgType)

	public CThostFtdcExchangeOrderActionErrorField(){}

	public CThostFtdcExchangeOrderActionErrorField(byte[] ExchangeID,byte[] OrderSysID,byte[] TraderID,int InstallID,byte[] OrderLocalID,byte[] ActionLocalID,int ErrorID,byte[] ErrorMsg){
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(OrderSysID !=null)	this.OrderSysID= new String(OrderSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderSysID = "";}
		try{	if(TraderID !=null)	this.TraderID= new String(TraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TraderID = "";}
		this.InstallID=InstallID;
		try{	if(OrderLocalID !=null)	this.OrderLocalID= new String(OrderLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderLocalID = "";}
		try{	if(ActionLocalID !=null)	this.ActionLocalID= new String(ActionLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActionLocalID = "";}
		this.ErrorID=ErrorID;
		try{	if(ErrorMsg !=null)	this.ErrorMsg= new String(ErrorMsg, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ErrorMsg = "";}
	}
}
