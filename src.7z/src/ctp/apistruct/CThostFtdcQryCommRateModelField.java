package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryCommRateModelField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String CommModelID = "";	 //char[13]	(TThostFtdcInvestorIDType)

	public CThostFtdcQryCommRateModelField(){}

	public CThostFtdcQryCommRateModelField(byte[] BrokerID,byte[] CommModelID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(CommModelID !=null)	this.CommModelID= new String(CommModelID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CommModelID = "";}
	}
}
