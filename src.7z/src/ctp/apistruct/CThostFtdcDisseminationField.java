package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcDisseminationField implements Serializable {
	private static final long serialVersionUID = 1L;
	public short SequenceSeries;
	public int SequenceNo;

	public CThostFtdcDisseminationField(){}

	public CThostFtdcDisseminationField(short SequenceSeries,int SequenceNo){
		this.SequenceSeries=SequenceSeries;
		this.SequenceNo=SequenceNo;
	}
}
