package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTradingCodeField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ClientID = "";	 //char[11]	(TThostFtdcClientIDType)
	public int IsActive;
	public char ClientIDType;
	public String BranchID = "";	 //char[9]	(TThostFtdcBranchIDType)
	public char BizType;
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)

	public CThostFtdcTradingCodeField(){}

	public CThostFtdcTradingCodeField(byte[] InvestorID,byte[] BrokerID,byte[] ExchangeID,byte[] ClientID,int IsActive,char ClientIDType,byte[] BranchID,char BizType,byte[] InvestUnitID){
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ClientID !=null)	this.ClientID= new String(ClientID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientID = "";}
		this.IsActive=IsActive;
		this.ClientIDType=ClientIDType;
		try{	if(BranchID !=null)	this.BranchID= new String(BranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BranchID = "";}
		this.BizType=BizType;
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
	}
}
