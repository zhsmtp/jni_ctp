package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryTransferBankField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankBrchID = "";	 //char[5]	(TThostFtdcBankBrchIDType)

	public CThostFtdcQryTransferBankField(){}

	public CThostFtdcQryTransferBankField(byte[] BankID,byte[] BankBrchID){
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankBrchID !=null)	this.BankBrchID= new String(BankBrchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankBrchID = "";}
	}
}
