package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcReqUserLoginField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String Password = "";	 //char[41]	(TThostFtdcPasswordType)
	public String UserProductInfo = "";	 //char[11]	(TThostFtdcProductInfoType)
	public String InterfaceProductInfo = "";	 //char[11]	(TThostFtdcProductInfoType)
	public String ProtocolInfo = "";	 //char[11]	(TThostFtdcProtocolInfoType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)
	public String OneTimePassword = "";	 //char[41]	(TThostFtdcPasswordType)
	public String ClientIPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String LoginRemark = "";	 //char[36]	(TThostFtdcLoginRemarkType)
	public int ClientIPPort;

	public CThostFtdcReqUserLoginField(){}

	public CThostFtdcReqUserLoginField(byte[] TradingDay,byte[] BrokerID,byte[] UserID,byte[] Password,byte[] UserProductInfo,byte[] InterfaceProductInfo,byte[] ProtocolInfo,byte[] MacAddress,byte[] OneTimePassword,byte[] ClientIPAddress,byte[] LoginRemark,int ClientIPPort){
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(Password !=null)	this.Password= new String(Password, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Password = "";}
		try{	if(UserProductInfo !=null)	this.UserProductInfo= new String(UserProductInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserProductInfo = "";}
		try{	if(InterfaceProductInfo !=null)	this.InterfaceProductInfo= new String(InterfaceProductInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InterfaceProductInfo = "";}
		try{	if(ProtocolInfo !=null)	this.ProtocolInfo= new String(ProtocolInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ProtocolInfo = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
		try{	if(OneTimePassword !=null)	this.OneTimePassword= new String(OneTimePassword, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OneTimePassword = "";}
		try{	if(ClientIPAddress !=null)	this.ClientIPAddress= new String(ClientIPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientIPAddress = "";}
		try{	if(LoginRemark !=null)	this.LoginRemark= new String(LoginRemark, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LoginRemark = "";}
		this.ClientIPPort=ClientIPPort;
	}
}
