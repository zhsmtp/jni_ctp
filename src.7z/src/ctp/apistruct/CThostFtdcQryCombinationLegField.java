package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryCombinationLegField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String CombInstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public int LegID;
	public String LegInstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)

	public CThostFtdcQryCombinationLegField(){}

	public CThostFtdcQryCombinationLegField(byte[] CombInstrumentID,int LegID,byte[] LegInstrumentID){
		try{	if(CombInstrumentID !=null)	this.CombInstrumentID= new String(CombInstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CombInstrumentID = "";}
		this.LegID=LegID;
		try{	if(LegInstrumentID !=null)	this.LegInstrumentID= new String(LegInstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LegInstrumentID = "";}
	}
}
