package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMarketDataAveragePriceField implements Serializable {
	private static final long serialVersionUID = 1L;
	public double AveragePrice;

	public CThostFtdcMarketDataAveragePriceField(){}

	public CThostFtdcMarketDataAveragePriceField(double AveragePrice){
		this.AveragePrice=AveragePrice;
	}
}
