package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcUserIPField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String IPMask = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)

	public CThostFtdcUserIPField(){}

	public CThostFtdcUserIPField(byte[] BrokerID,byte[] UserID,byte[] IPAddress,byte[] IPMask,byte[] MacAddress){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(IPMask !=null)	this.IPMask= new String(IPMask, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPMask = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
	}
}
