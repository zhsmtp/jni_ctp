package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryNoticeField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)

	public CThostFtdcQryNoticeField(){}

	public CThostFtdcQryNoticeField(byte[] BrokerID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
	}
}
