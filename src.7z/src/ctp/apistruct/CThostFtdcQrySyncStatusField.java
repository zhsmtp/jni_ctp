package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQrySyncStatusField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)

	public CThostFtdcQrySyncStatusField(){}

	public CThostFtdcQrySyncStatusField(byte[] TradingDay){
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
	}
}
