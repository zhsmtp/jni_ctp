package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTransferHeaderField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String Version = "";	 //char[4]	(TThostFtdcVersionType)
	public String TradeCode = "";	 //char[7]	(TThostFtdcTradeCodeType)
	public String TradeDate = "";	 //char[9]	(TThostFtdcTradeDateType)
	public String TradeTime = "";	 //char[9]	(TThostFtdcTradeTimeType)
	public String TradeSerial = "";	 //char[9]	(TThostFtdcTradeSerialType)
	public String FutureID = "";	 //char[11]	(TThostFtdcFutureIDType)
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankBrchID = "";	 //char[5]	(TThostFtdcBankBrchIDType)
	public String OperNo = "";	 //char[17]	(TThostFtdcOperNoType)
	public String DeviceID = "";	 //char[3]	(TThostFtdcDeviceIDType)
	public String RecordNum = "";	 //char[7]	(TThostFtdcRecordNumType)
	public int SessionID;
	public int RequestID;

	public CThostFtdcTransferHeaderField(){}

	public CThostFtdcTransferHeaderField(byte[] Version,byte[] TradeCode,byte[] TradeDate,byte[] TradeTime,byte[] TradeSerial,byte[] FutureID,byte[] BankID,byte[] BankBrchID,byte[] OperNo,byte[] DeviceID,byte[] RecordNum,int SessionID,int RequestID){
		try{	if(Version !=null)	this.Version= new String(Version, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Version = "";}
		try{	if(TradeCode !=null)	this.TradeCode= new String(TradeCode, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeCode = "";}
		try{	if(TradeDate !=null)	this.TradeDate= new String(TradeDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeDate = "";}
		try{	if(TradeTime !=null)	this.TradeTime= new String(TradeTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeTime = "";}
		try{	if(TradeSerial !=null)	this.TradeSerial= new String(TradeSerial, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeSerial = "";}
		try{	if(FutureID !=null)	this.FutureID= new String(FutureID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FutureID = "";}
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankBrchID !=null)	this.BankBrchID= new String(BankBrchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankBrchID = "";}
		try{	if(OperNo !=null)	this.OperNo= new String(OperNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OperNo = "";}
		try{	if(DeviceID !=null)	this.DeviceID= new String(DeviceID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.DeviceID = "";}
		try{	if(RecordNum !=null)	this.RecordNum= new String(RecordNum, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.RecordNum = "";}
		this.SessionID=SessionID;
		this.RequestID=RequestID;
	}
}
