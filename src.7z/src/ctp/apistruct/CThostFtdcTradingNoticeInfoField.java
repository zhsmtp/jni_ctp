package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTradingNoticeInfoField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String SendTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String FieldContent = "";	 //char[501]	(TThostFtdcContentType)
	public short SequenceSeries;
	public int SequenceNo;
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)

	public CThostFtdcTradingNoticeInfoField(){}

	public CThostFtdcTradingNoticeInfoField(byte[] BrokerID,byte[] InvestorID,byte[] SendTime,byte[] FieldContent,short SequenceSeries,int SequenceNo,byte[] InvestUnitID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(SendTime !=null)	this.SendTime= new String(SendTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.SendTime = "";}
		try{	if(FieldContent !=null)	this.FieldContent= new String(FieldContent, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FieldContent = "";}
		this.SequenceSeries=SequenceSeries;
		this.SequenceNo=SequenceNo;
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
	}
}
