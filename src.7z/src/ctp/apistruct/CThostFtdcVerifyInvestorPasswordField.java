package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcVerifyInvestorPasswordField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String Password = "";	 //char[41]	(TThostFtdcPasswordType)

	public CThostFtdcVerifyInvestorPasswordField(){}

	public CThostFtdcVerifyInvestorPasswordField(byte[] BrokerID,byte[] InvestorID,byte[] Password){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(Password !=null)	this.Password= new String(Password, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Password = "";}
	}
}
