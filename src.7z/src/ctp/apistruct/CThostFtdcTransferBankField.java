package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTransferBankField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankBrchID = "";	 //char[5]	(TThostFtdcBankBrchIDType)
	public String BankName = "";	 //char[101]	(TThostFtdcBankNameType)
	public int IsActive;

	public CThostFtdcTransferBankField(){}

	public CThostFtdcTransferBankField(byte[] BankID,byte[] BankBrchID,byte[] BankName,int IsActive){
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankBrchID !=null)	this.BankBrchID= new String(BankBrchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankBrchID = "";}
		try{	if(BankName !=null)	this.BankName= new String(BankName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankName = "";}
		this.IsActive=IsActive;
	}
}
