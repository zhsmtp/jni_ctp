package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcSyncDepositField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String DepositSeqNo = "";	 //char[15]	(TThostFtdcDepositSeqNoType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public double Deposit;
	public int IsForce;
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)

	public CThostFtdcSyncDepositField(){}

	public CThostFtdcSyncDepositField(byte[] DepositSeqNo,byte[] BrokerID,byte[] InvestorID,double Deposit,int IsForce,byte[] CurrencyID){
		try{	if(DepositSeqNo !=null)	this.DepositSeqNo= new String(DepositSeqNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.DepositSeqNo = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.Deposit=Deposit;
		this.IsForce=IsForce;
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
	}
}
