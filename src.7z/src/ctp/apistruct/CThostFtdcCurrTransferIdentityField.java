package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcCurrTransferIdentityField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int IdentityID;

	public CThostFtdcCurrTransferIdentityField(){}

	public CThostFtdcCurrTransferIdentityField(int IdentityID){
		this.IdentityID=IdentityID;
	}
}
