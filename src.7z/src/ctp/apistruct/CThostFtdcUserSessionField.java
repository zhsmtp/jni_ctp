package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcUserSessionField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int FrontID;
	public int SessionID;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String LoginDate = "";	 //char[9]	(TThostFtdcDateType)
	public String LoginTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String UserProductInfo = "";	 //char[11]	(TThostFtdcProductInfoType)
	public String InterfaceProductInfo = "";	 //char[11]	(TThostFtdcProductInfoType)
	public String ProtocolInfo = "";	 //char[11]	(TThostFtdcProtocolInfoType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)
	public String LoginRemark = "";	 //char[36]	(TThostFtdcLoginRemarkType)

	public CThostFtdcUserSessionField(){}

	public CThostFtdcUserSessionField(int FrontID,int SessionID,byte[] BrokerID,byte[] UserID,byte[] LoginDate,byte[] LoginTime,byte[] IPAddress,byte[] UserProductInfo,byte[] InterfaceProductInfo,byte[] ProtocolInfo,byte[] MacAddress,byte[] LoginRemark){
		this.FrontID=FrontID;
		this.SessionID=SessionID;
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(LoginDate !=null)	this.LoginDate= new String(LoginDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LoginDate = "";}
		try{	if(LoginTime !=null)	this.LoginTime= new String(LoginTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LoginTime = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(UserProductInfo !=null)	this.UserProductInfo= new String(UserProductInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserProductInfo = "";}
		try{	if(InterfaceProductInfo !=null)	this.InterfaceProductInfo= new String(InterfaceProductInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InterfaceProductInfo = "";}
		try{	if(ProtocolInfo !=null)	this.ProtocolInfo= new String(ProtocolInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ProtocolInfo = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
		try{	if(LoginRemark !=null)	this.LoginRemark= new String(LoginRemark, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.LoginRemark = "";}
	}
}
