package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryFrontStatusField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int FrontID;

	public CThostFtdcQryFrontStatusField(){}

	public CThostFtdcQryFrontStatusField(int FrontID){
		this.FrontID=FrontID;
	}
}
