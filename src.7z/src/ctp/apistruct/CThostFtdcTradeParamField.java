package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTradeParamField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public char TradeParamID;
	public String TradeParamValue = "";	 //char[256]	(TThostFtdcSettlementParamValueType)
	public String Memo = "";	 //char[161]	(TThostFtdcMemoType)

	public CThostFtdcTradeParamField(){}

	public CThostFtdcTradeParamField(byte[] BrokerID,char TradeParamID,byte[] TradeParamValue,byte[] Memo){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		this.TradeParamID=TradeParamID;
		try{	if(TradeParamValue !=null)	this.TradeParamValue= new String(TradeParamValue, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeParamValue = "";}
		try{	if(Memo !=null)	this.Memo= new String(Memo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.Memo = "";}
	}
}
