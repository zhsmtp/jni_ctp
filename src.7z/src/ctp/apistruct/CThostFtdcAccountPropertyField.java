package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcAccountPropertyField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String BankID = "";	 //char[4]	(TThostFtdcBankIDType)
	public String BankAccount = "";	 //char[41]	(TThostFtdcBankAccountType)
	public String OpenName = "";	 //char[101]	(TThostFtdcInvestorFullNameType)
	public String OpenBank = "";	 //char[101]	(TThostFtdcOpenBankType)
	public int IsActive;
	public char AccountSourceType;
	public String OpenDate = "";	 //char[9]	(TThostFtdcDateType)
	public String CancelDate = "";	 //char[9]	(TThostFtdcDateType)
	public String OperatorID = "";	 //char[65]	(TThostFtdcOperatorIDType)
	public String OperateDate = "";	 //char[9]	(TThostFtdcDateType)
	public String OperateTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)

	public CThostFtdcAccountPropertyField(){}

	public CThostFtdcAccountPropertyField(byte[] BrokerID,byte[] AccountID,byte[] BankID,byte[] BankAccount,byte[] OpenName,byte[] OpenBank,int IsActive,char AccountSourceType,byte[] OpenDate,byte[] CancelDate,byte[] OperatorID,byte[] OperateDate,byte[] OperateTime,byte[] CurrencyID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(BankID !=null)	this.BankID= new String(BankID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankID = "";}
		try{	if(BankAccount !=null)	this.BankAccount= new String(BankAccount, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BankAccount = "";}
		try{	if(OpenName !=null)	this.OpenName= new String(OpenName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OpenName = "";}
		try{	if(OpenBank !=null)	this.OpenBank= new String(OpenBank, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OpenBank = "";}
		this.IsActive=IsActive;
		this.AccountSourceType=AccountSourceType;
		try{	if(OpenDate !=null)	this.OpenDate= new String(OpenDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OpenDate = "";}
		try{	if(CancelDate !=null)	this.CancelDate= new String(CancelDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CancelDate = "";}
		try{	if(OperatorID !=null)	this.OperatorID= new String(OperatorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OperatorID = "";}
		try{	if(OperateDate !=null)	this.OperateDate= new String(OperateDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OperateDate = "";}
		try{	if(OperateTime !=null)	this.OperateTime= new String(OperateTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OperateTime = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
	}
}
