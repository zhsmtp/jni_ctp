package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcCurrDRIdentityField implements Serializable {
	private static final long serialVersionUID = 1L;
	public int DRIdentityID;

	public CThostFtdcCurrDRIdentityField(){}

	public CThostFtdcCurrDRIdentityField(int DRIdentityID){
		this.DRIdentityID=DRIdentityID;
	}
}
