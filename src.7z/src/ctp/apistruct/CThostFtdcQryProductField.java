package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryProductField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ProductID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public char ProductClass;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)

	public CThostFtdcQryProductField(){}

	public CThostFtdcQryProductField(byte[] ProductID,char ProductClass,byte[] ExchangeID){
		try{	if(ProductID !=null)	this.ProductID= new String(ProductID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ProductID = "";}
		this.ProductClass=ProductClass;
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
	}
}
