package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcMarketDataBestPriceField implements Serializable {
	private static final long serialVersionUID = 1L;
	public double BidPrice1;
	public int BidVolume1;
	public double AskPrice1;
	public int AskVolume1;

	public CThostFtdcMarketDataBestPriceField(){}

	public CThostFtdcMarketDataBestPriceField(double BidPrice1,int BidVolume1,double AskPrice1,int AskVolume1){
		this.BidPrice1=BidPrice1;
		this.BidVolume1=BidVolume1;
		this.AskPrice1=AskPrice1;
		this.AskVolume1=AskVolume1;
	}
}
