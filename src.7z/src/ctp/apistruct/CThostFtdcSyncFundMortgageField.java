package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcSyncFundMortgageField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String MortgageSeqNo = "";	 //char[15]	(TThostFtdcDepositSeqNoType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String FromCurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public double MortgageAmount;
	public String ToCurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)

	public CThostFtdcSyncFundMortgageField(){}

	public CThostFtdcSyncFundMortgageField(byte[] MortgageSeqNo,byte[] BrokerID,byte[] InvestorID,byte[] FromCurrencyID,double MortgageAmount,byte[] ToCurrencyID){
		try{	if(MortgageSeqNo !=null)	this.MortgageSeqNo= new String(MortgageSeqNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MortgageSeqNo = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(FromCurrencyID !=null)	this.FromCurrencyID= new String(FromCurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FromCurrencyID = "";}
		this.MortgageAmount=MortgageAmount;
		try{	if(ToCurrencyID !=null)	this.ToCurrencyID= new String(ToCurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ToCurrencyID = "";}
	}
}
