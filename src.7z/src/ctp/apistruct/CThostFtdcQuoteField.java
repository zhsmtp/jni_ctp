package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQuoteField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String QuoteRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public double AskPrice;
	public double BidPrice;
	public int AskVolume;
	public int BidVolume;
	public int RequestID;
	public String BusinessUnit = "";	 //char[21]	(TThostFtdcBusinessUnitType)
	public char AskOffsetFlag;
	public char BidOffsetFlag;
	public char AskHedgeFlag;
	public char BidHedgeFlag;
	public String QuoteLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String ClientID = "";	 //char[11]	(TThostFtdcClientIDType)
	public String ExchangeInstID = "";	 //char[31]	(TThostFtdcExchangeInstIDType)
	public String TraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public int InstallID;
	public int NotifySequence;
	public char OrderSubmitStatus;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public int SettlementID;
	public String QuoteSysID = "";	 //char[21]	(TThostFtdcOrderSysIDType)
	public String InsertDate = "";	 //char[9]	(TThostFtdcDateType)
	public String InsertTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String CancelTime = "";	 //char[9]	(TThostFtdcTimeType)
	public char QuoteStatus;
	public String ClearingPartID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public int SequenceNo;
	public String AskOrderSysID = "";	 //char[21]	(TThostFtdcOrderSysIDType)
	public String BidOrderSysID = "";	 //char[21]	(TThostFtdcOrderSysIDType)
	public int FrontID;
	public int SessionID;
	public String UserProductInfo = "";	 //char[11]	(TThostFtdcProductInfoType)
	public String StatusMsg = "";	 //char[81]	(TThostFtdcErrorMsgType)
	public String ActiveUserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public int BrokerQuoteSeq;
	public String AskOrderRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String BidOrderRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public String ForQuoteSysID = "";	 //char[21]	(TThostFtdcOrderSysIDType)
	public String BranchID = "";	 //char[9]	(TThostFtdcBranchIDType)
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)

	public CThostFtdcQuoteField(){}

	public CThostFtdcQuoteField(byte[] BrokerID,byte[] InvestorID,byte[] InstrumentID,byte[] QuoteRef,byte[] UserID,double AskPrice,double BidPrice,int AskVolume,int BidVolume,int RequestID,byte[] BusinessUnit,char AskOffsetFlag,char BidOffsetFlag,char AskHedgeFlag,char BidHedgeFlag,byte[] QuoteLocalID,byte[] ExchangeID,byte[] ParticipantID,byte[] ClientID,byte[] ExchangeInstID,byte[] TraderID,int InstallID,int NotifySequence,char OrderSubmitStatus,byte[] TradingDay,int SettlementID,byte[] QuoteSysID,byte[] InsertDate,byte[] InsertTime,byte[] CancelTime,char QuoteStatus,byte[] ClearingPartID,int SequenceNo,byte[] AskOrderSysID,byte[] BidOrderSysID,int FrontID,int SessionID,byte[] UserProductInfo,byte[] StatusMsg,byte[] ActiveUserID,int BrokerQuoteSeq,byte[] AskOrderRef,byte[] BidOrderRef,byte[] ForQuoteSysID,byte[] BranchID,byte[] InvestUnitID,byte[] AccountID,byte[] CurrencyID,byte[] IPAddress,byte[] MacAddress){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(QuoteRef !=null)	this.QuoteRef= new String(QuoteRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.QuoteRef = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.AskPrice=AskPrice;
		this.BidPrice=BidPrice;
		this.AskVolume=AskVolume;
		this.BidVolume=BidVolume;
		this.RequestID=RequestID;
		try{	if(BusinessUnit !=null)	this.BusinessUnit= new String(BusinessUnit, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BusinessUnit = "";}
		this.AskOffsetFlag=AskOffsetFlag;
		this.BidOffsetFlag=BidOffsetFlag;
		this.AskHedgeFlag=AskHedgeFlag;
		this.BidHedgeFlag=BidHedgeFlag;
		try{	if(QuoteLocalID !=null)	this.QuoteLocalID= new String(QuoteLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.QuoteLocalID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(ClientID !=null)	this.ClientID= new String(ClientID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientID = "";}
		try{	if(ExchangeInstID !=null)	this.ExchangeInstID= new String(ExchangeInstID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeInstID = "";}
		try{	if(TraderID !=null)	this.TraderID= new String(TraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TraderID = "";}
		this.InstallID=InstallID;
		this.NotifySequence=NotifySequence;
		this.OrderSubmitStatus=OrderSubmitStatus;
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.SettlementID=SettlementID;
		try{	if(QuoteSysID !=null)	this.QuoteSysID= new String(QuoteSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.QuoteSysID = "";}
		try{	if(InsertDate !=null)	this.InsertDate= new String(InsertDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InsertDate = "";}
		try{	if(InsertTime !=null)	this.InsertTime= new String(InsertTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InsertTime = "";}
		try{	if(CancelTime !=null)	this.CancelTime= new String(CancelTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CancelTime = "";}
		this.QuoteStatus=QuoteStatus;
		try{	if(ClearingPartID !=null)	this.ClearingPartID= new String(ClearingPartID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClearingPartID = "";}
		this.SequenceNo=SequenceNo;
		try{	if(AskOrderSysID !=null)	this.AskOrderSysID= new String(AskOrderSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AskOrderSysID = "";}
		try{	if(BidOrderSysID !=null)	this.BidOrderSysID= new String(BidOrderSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BidOrderSysID = "";}
		this.FrontID=FrontID;
		this.SessionID=SessionID;
		try{	if(UserProductInfo !=null)	this.UserProductInfo= new String(UserProductInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserProductInfo = "";}
		try{	if(StatusMsg !=null)	this.StatusMsg= new String(StatusMsg, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.StatusMsg = "";}
		try{	if(ActiveUserID !=null)	this.ActiveUserID= new String(ActiveUserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActiveUserID = "";}
		this.BrokerQuoteSeq=BrokerQuoteSeq;
		try{	if(AskOrderRef !=null)	this.AskOrderRef= new String(AskOrderRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AskOrderRef = "";}
		try{	if(BidOrderRef !=null)	this.BidOrderRef= new String(BidOrderRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BidOrderRef = "";}
		try{	if(ForQuoteSysID !=null)	this.ForQuoteSysID= new String(ForQuoteSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ForQuoteSysID = "";}
		try{	if(BranchID !=null)	this.BranchID= new String(BranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BranchID = "";}
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
	}
}
