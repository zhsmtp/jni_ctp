package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcTradingAccountReserveField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String AccountID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public double Reserve;
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)

	public CThostFtdcTradingAccountReserveField(){}

	public CThostFtdcTradingAccountReserveField(byte[] BrokerID,byte[] AccountID,double Reserve,byte[] CurrencyID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(AccountID !=null)	this.AccountID= new String(AccountID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.AccountID = "";}
		this.Reserve=Reserve;
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
	}
}
