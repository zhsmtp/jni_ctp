package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQrySecAgentTradeInfoField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String BrokerSecAgentID = "";	 //char[13]	(TThostFtdcAccountIDType)

	public CThostFtdcQrySecAgentTradeInfoField(){}

	public CThostFtdcQrySecAgentTradeInfoField(byte[] BrokerID,byte[] BrokerSecAgentID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(BrokerSecAgentID !=null)	this.BrokerSecAgentID= new String(BrokerSecAgentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerSecAgentID = "";}
	}
}
