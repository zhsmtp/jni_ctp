package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcQryInstrumentStatusField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String ExchangeInstID = "";	 //char[31]	(TThostFtdcExchangeInstIDType)

	public CThostFtdcQryInstrumentStatusField(){}

	public CThostFtdcQryInstrumentStatusField(byte[] ExchangeID,byte[] ExchangeInstID){
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(ExchangeInstID !=null)	this.ExchangeInstID= new String(ExchangeInstID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeInstID = "";}
	}
}
