package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcSyncDelaySwapField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String DelaySwapSeqNo = "";	 //char[15]	(TThostFtdcDepositSeqNoType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String FromCurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public double FromAmount;
	public double FromFrozenSwap;
	public double FromRemainSwap;
	public String ToCurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public double ToAmount;

	public CThostFtdcSyncDelaySwapField(){}

	public CThostFtdcSyncDelaySwapField(byte[] DelaySwapSeqNo,byte[] BrokerID,byte[] InvestorID,byte[] FromCurrencyID,double FromAmount,double FromFrozenSwap,double FromRemainSwap,byte[] ToCurrencyID,double ToAmount){
		try{	if(DelaySwapSeqNo !=null)	this.DelaySwapSeqNo= new String(DelaySwapSeqNo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.DelaySwapSeqNo = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(FromCurrencyID !=null)	this.FromCurrencyID= new String(FromCurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.FromCurrencyID = "";}
		this.FromAmount=FromAmount;
		this.FromFrozenSwap=FromFrozenSwap;
		this.FromRemainSwap=FromRemainSwap;
		try{	if(ToCurrencyID !=null)	this.ToCurrencyID= new String(ToCurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ToCurrencyID = "";}
		this.ToAmount=ToAmount;
	}
}
