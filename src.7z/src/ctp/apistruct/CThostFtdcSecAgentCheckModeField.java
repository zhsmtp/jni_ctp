package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcSecAgentCheckModeField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String CurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public String BrokerSecAgentID = "";	 //char[13]	(TThostFtdcAccountIDType)
	public int CheckSelfAccount;

	public CThostFtdcSecAgentCheckModeField(){}

	public CThostFtdcSecAgentCheckModeField(byte[] InvestorID,byte[] BrokerID,byte[] CurrencyID,byte[] BrokerSecAgentID,int CheckSelfAccount){
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(CurrencyID !=null)	this.CurrencyID= new String(CurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CurrencyID = "";}
		try{	if(BrokerSecAgentID !=null)	this.BrokerSecAgentID= new String(BrokerSecAgentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerSecAgentID = "";}
		this.CheckSelfAccount=CheckSelfAccount;
	}
}
