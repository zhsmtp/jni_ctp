package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcOrderActionField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public int OrderActionRef;
	public String OrderRef = "";	 //char[13]	(TThostFtdcOrderRefType)
	public int RequestID;
	public int FrontID;
	public int SessionID;
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public String OrderSysID = "";	 //char[21]	(TThostFtdcOrderSysIDType)
	public char ActionFlag;
	public double LimitPrice;
	public int VolumeChange;
	public String ActionDate = "";	 //char[9]	(TThostFtdcDateType)
	public String ActionTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String TraderID = "";	 //char[21]	(TThostFtdcTraderIDType)
	public int InstallID;
	public String OrderLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public String ActionLocalID = "";	 //char[13]	(TThostFtdcOrderLocalIDType)
	public String ParticipantID = "";	 //char[11]	(TThostFtdcParticipantIDType)
	public String ClientID = "";	 //char[11]	(TThostFtdcClientIDType)
	public String BusinessUnit = "";	 //char[21]	(TThostFtdcBusinessUnitType)
	public char OrderActionStatus;
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public String StatusMsg = "";	 //char[81]	(TThostFtdcErrorMsgType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String BranchID = "";	 //char[9]	(TThostFtdcBranchIDType)
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)
	public String IPAddress = "";	 //char[16]	(TThostFtdcIPAddressType)
	public String MacAddress = "";	 //char[21]	(TThostFtdcMacAddressType)

	public CThostFtdcOrderActionField(){}

	public CThostFtdcOrderActionField(byte[] BrokerID,byte[] InvestorID,int OrderActionRef,byte[] OrderRef,int RequestID,int FrontID,int SessionID,byte[] ExchangeID,byte[] OrderSysID,char ActionFlag,double LimitPrice,int VolumeChange,byte[] ActionDate,byte[] ActionTime,byte[] TraderID,int InstallID,byte[] OrderLocalID,byte[] ActionLocalID,byte[] ParticipantID,byte[] ClientID,byte[] BusinessUnit,char OrderActionStatus,byte[] UserID,byte[] StatusMsg,byte[] InstrumentID,byte[] BranchID,byte[] InvestUnitID,byte[] IPAddress,byte[] MacAddress){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.OrderActionRef=OrderActionRef;
		try{	if(OrderRef !=null)	this.OrderRef= new String(OrderRef, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderRef = "";}
		this.RequestID=RequestID;
		this.FrontID=FrontID;
		this.SessionID=SessionID;
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		try{	if(OrderSysID !=null)	this.OrderSysID= new String(OrderSysID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderSysID = "";}
		this.ActionFlag=ActionFlag;
		this.LimitPrice=LimitPrice;
		this.VolumeChange=VolumeChange;
		try{	if(ActionDate !=null)	this.ActionDate= new String(ActionDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActionDate = "";}
		try{	if(ActionTime !=null)	this.ActionTime= new String(ActionTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActionTime = "";}
		try{	if(TraderID !=null)	this.TraderID= new String(TraderID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TraderID = "";}
		this.InstallID=InstallID;
		try{	if(OrderLocalID !=null)	this.OrderLocalID= new String(OrderLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OrderLocalID = "";}
		try{	if(ActionLocalID !=null)	this.ActionLocalID= new String(ActionLocalID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ActionLocalID = "";}
		try{	if(ParticipantID !=null)	this.ParticipantID= new String(ParticipantID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ParticipantID = "";}
		try{	if(ClientID !=null)	this.ClientID= new String(ClientID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ClientID = "";}
		try{	if(BusinessUnit !=null)	this.BusinessUnit= new String(BusinessUnit, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BusinessUnit = "";}
		this.OrderActionStatus=OrderActionStatus;
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		try{	if(StatusMsg !=null)	this.StatusMsg= new String(StatusMsg, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.StatusMsg = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(BranchID !=null)	this.BranchID= new String(BranchID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BranchID = "";}
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
		try{	if(IPAddress !=null)	this.IPAddress= new String(IPAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.IPAddress = "";}
		try{	if(MacAddress !=null)	this.MacAddress= new String(MacAddress, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.MacAddress = "";}
	}
}
