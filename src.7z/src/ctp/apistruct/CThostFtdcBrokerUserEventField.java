package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcBrokerUserEventField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String UserID = "";	 //char[16]	(TThostFtdcUserIDType)
	public char UserEventType;
	public int EventSequenceNo;
	public String EventDate = "";	 //char[9]	(TThostFtdcDateType)
	public String EventTime = "";	 //char[9]	(TThostFtdcTimeType)
	public String UserEventInfo = "";	 //char[1025]	(TThostFtdcUserEventInfoType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)

	public CThostFtdcBrokerUserEventField(){}

	public CThostFtdcBrokerUserEventField(byte[] BrokerID,byte[] UserID,char UserEventType,int EventSequenceNo,byte[] EventDate,byte[] EventTime,byte[] UserEventInfo,byte[] InvestorID,byte[] InstrumentID){
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(UserID !=null)	this.UserID= new String(UserID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserID = "";}
		this.UserEventType=UserEventType;
		this.EventSequenceNo=EventSequenceNo;
		try{	if(EventDate !=null)	this.EventDate= new String(EventDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.EventDate = "";}
		try{	if(EventTime !=null)	this.EventTime= new String(EventTime, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.EventTime = "";}
		try{	if(UserEventInfo !=null)	this.UserEventInfo= new String(UserEventInfo, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.UserEventInfo = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
	}
}
