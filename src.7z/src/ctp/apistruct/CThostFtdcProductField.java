package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcProductField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String ProductID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String ProductName = "";	 //char[21]	(TThostFtdcProductNameType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public char ProductClass;
	public int VolumeMultiple;
	public double PriceTick;
	public int MaxMarketOrderVolume;
	public int MinMarketOrderVolume;
	public int MaxLimitOrderVolume;
	public int MinLimitOrderVolume;
	public char PositionType;
	public char PositionDateType;
	public char CloseDealType;
	public String TradeCurrencyID = "";	 //char[4]	(TThostFtdcCurrencyIDType)
	public char MortgageFundUseRange;
	public String ExchangeProductID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public double UnderlyingMultiple;

	public CThostFtdcProductField(){}

	public CThostFtdcProductField(byte[] ProductID,byte[] ProductName,byte[] ExchangeID,char ProductClass,int VolumeMultiple,double PriceTick,int MaxMarketOrderVolume,int MinMarketOrderVolume,int MaxLimitOrderVolume,int MinLimitOrderVolume,char PositionType,char PositionDateType,char CloseDealType,byte[] TradeCurrencyID,char MortgageFundUseRange,byte[] ExchangeProductID,double UnderlyingMultiple){
		try{	if(ProductID !=null)	this.ProductID= new String(ProductID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ProductID = "";}
		try{	if(ProductName !=null)	this.ProductName= new String(ProductName, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ProductName = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		this.ProductClass=ProductClass;
		this.VolumeMultiple=VolumeMultiple;
		this.PriceTick=PriceTick;
		this.MaxMarketOrderVolume=MaxMarketOrderVolume;
		this.MinMarketOrderVolume=MinMarketOrderVolume;
		this.MaxLimitOrderVolume=MaxLimitOrderVolume;
		this.MinLimitOrderVolume=MinLimitOrderVolume;
		this.PositionType=PositionType;
		this.PositionDateType=PositionDateType;
		this.CloseDealType=CloseDealType;
		try{	if(TradeCurrencyID !=null)	this.TradeCurrencyID= new String(TradeCurrencyID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeCurrencyID = "";}
		this.MortgageFundUseRange=MortgageFundUseRange;
		try{	if(ExchangeProductID !=null)	this.ExchangeProductID= new String(ExchangeProductID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeProductID = "";}
		this.UnderlyingMultiple=UnderlyingMultiple;
	}
}
