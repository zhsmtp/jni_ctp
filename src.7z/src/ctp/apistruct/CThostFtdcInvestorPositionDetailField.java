package ctp.apistruct;
import java.io.Serializable;
public class CThostFtdcInvestorPositionDetailField implements Serializable {
	private static final long serialVersionUID = 1L;
	public String InstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String BrokerID = "";	 //char[11]	(TThostFtdcBrokerIDType)
	public String InvestorID = "";	 //char[13]	(TThostFtdcInvestorIDType)
	public char HedgeFlag;
	public char Direction;
	public String OpenDate = "";	 //char[9]	(TThostFtdcDateType)
	public String TradeID = "";	 //char[21]	(TThostFtdcTradeIDType)
	public int Volume;
	public double OpenPrice;
	public String TradingDay = "";	 //char[9]	(TThostFtdcDateType)
	public int SettlementID;
	public char TradeType;
	public String CombInstrumentID = "";	 //char[31]	(TThostFtdcInstrumentIDType)
	public String ExchangeID = "";	 //char[9]	(TThostFtdcExchangeIDType)
	public double CloseProfitByDate;
	public double CloseProfitByTrade;
	public double PositionProfitByDate;
	public double PositionProfitByTrade;
	public double Margin;
	public double ExchMargin;
	public double MarginRateByMoney;
	public double MarginRateByVolume;
	public double LastSettlementPrice;
	public double SettlementPrice;
	public int CloseVolume;
	public double CloseAmount;
	public int TimeFirstVolume;
	public String InvestUnitID = "";	 //char[17]	(TThostFtdcInvestUnitIDType)

	public CThostFtdcInvestorPositionDetailField(){}

	public CThostFtdcInvestorPositionDetailField(byte[] InstrumentID,byte[] BrokerID,byte[] InvestorID,char HedgeFlag,char Direction,byte[] OpenDate,byte[] TradeID,int Volume,double OpenPrice,byte[] TradingDay,int SettlementID,char TradeType,byte[] CombInstrumentID,byte[] ExchangeID,double CloseProfitByDate,double CloseProfitByTrade,double PositionProfitByDate,double PositionProfitByTrade,double Margin,double ExchMargin,double MarginRateByMoney,double MarginRateByVolume,double LastSettlementPrice,double SettlementPrice,int CloseVolume,double CloseAmount,int TimeFirstVolume,byte[] InvestUnitID){
		try{	if(InstrumentID !=null)	this.InstrumentID= new String(InstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InstrumentID = "";}
		try{	if(BrokerID !=null)	this.BrokerID= new String(BrokerID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.BrokerID = "";}
		try{	if(InvestorID !=null)	this.InvestorID= new String(InvestorID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestorID = "";}
		this.HedgeFlag=HedgeFlag;
		this.Direction=Direction;
		try{	if(OpenDate !=null)	this.OpenDate= new String(OpenDate, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.OpenDate = "";}
		try{	if(TradeID !=null)	this.TradeID= new String(TradeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradeID = "";}
		this.Volume=Volume;
		this.OpenPrice=OpenPrice;
		try{	if(TradingDay !=null)	this.TradingDay= new String(TradingDay, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.TradingDay = "";}
		this.SettlementID=SettlementID;
		this.TradeType=TradeType;
		try{	if(CombInstrumentID !=null)	this.CombInstrumentID= new String(CombInstrumentID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.CombInstrumentID = "";}
		try{	if(ExchangeID !=null)	this.ExchangeID= new String(ExchangeID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.ExchangeID = "";}
		this.CloseProfitByDate=CloseProfitByDate;
		this.CloseProfitByTrade=CloseProfitByTrade;
		this.PositionProfitByDate=PositionProfitByDate;
		this.PositionProfitByTrade=PositionProfitByTrade;
		this.Margin=Margin;
		this.ExchMargin=ExchMargin;
		this.MarginRateByMoney=MarginRateByMoney;
		this.MarginRateByVolume=MarginRateByVolume;
		this.LastSettlementPrice=LastSettlementPrice;
		this.SettlementPrice=SettlementPrice;
		this.CloseVolume=CloseVolume;
		this.CloseAmount=CloseAmount;
		this.TimeFirstVolume=TimeFirstVolume;
		try{	if(InvestUnitID !=null)	this.InvestUnitID= new String(InvestUnitID, "gb2312").replace((char) 0x0, (char) 0x20).trim();	}catch(java.io.UnsupportedEncodingException e){this.InvestUnitID = "";}
	}
}
